﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Imp.Interface;
using MLS.Models;
using System.Data.Entity.Core.Objects;
using System.Transactions;
using MLS.Helper;

namespace MLS.Imp.Interface
{
    public interface IMenuSvc
    {
        List<MenuViewModel> GetMenus(String username);
    }
}
