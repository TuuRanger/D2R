﻿using MLS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Imp.Interface
{
    public interface IAuthenSvc
    {
        String Login(string Username, string Password);
        UserDataResult GetUserDataByToken(string token);
        UserToken IsTokenValid(string username, string token);
    }
}
