﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Models;

namespace MLS.Imp.Interface
{
    public interface INCBSvc
    {
        NCBResult GetNCBResult(String firstName, String middleName, string lastName, DateTime birthDate, String IDCard, String userID);
        void InsertNCBResult(NCBResult ncbResult, String username);
    }
}
