﻿using MLS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Imp.Interface
{
    public interface IRemarkSvc
    {
        void InsertOrUpdateRemark(List<RemarkModel> listRemark,
            string CPNCOD,
            string CPNBRNCOD,
            string ACCBUSTYP,
            string CONNUM,
            string USRCOD);
    }
}
