﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Models;

namespace MLS.Imp.Interface
{
    public interface IFinanceCalSvc
    {
        FinanceAmountCalcResult FinanceAmountCalc(
                                         double CONINSAMTx,
                                         int CONLNDTRMx,
                                         double CONINTRTEx,
                                         string CONINTTYPx,
                                         string CONINSPERx,
                                         string CONINTCALx,
                                         string CONINTPERx,
                                         string CONIRATEx,
                                         double CONFRATEx,
                                         string CONIRATEBNKREFx,
                                         double CONBLNAMTx,
                                         double SUBSDYAMTx,
                                         double ROUND_UPx,
                                         double ROUND_FACTORx,
                                         string INS_EQUAx,
                                         double LND_RoundUP,
                                         double LND_RoundFactor);

        InstallmentCalcResult InstallmentCalc(double CONFINAMTx,
           int CONLNDTRMx,
           double CONINTRTEx,
           string CONINTTYPx,
           string CONINSPERx,
           string CONINTCALx,
           string CONINTPERx,
           string CONIRATEx,
           double CONFRATEx,
           string CONIRATEBNKREFx,
           double CONBLNAMTx,
           double SUBSDYAMTx,
           double ROUND_UPx,
           double ROUND_FACTORx,
           string INS_EQUAx,
           double LND_RoundUP,
           double LND_RoundFactor);

        TermCalcResult TermCalc(double CONFINAMTx,
                             double CONINSAMTx,
                             double CONINTRTEx,
                             string CONINTTYPx,
                             string CONINSPERx,
                             string CONINTCALx,
                             string CONINTPERx,
                             string CONIRATEx,
                             double CONFRATEx,
                             string CONIRATEBNKREFx,
                             double CONBLNAMTx,
                             double SUBSDYAMTx,
                             double TRMSTEPUPx,
                             double ROUND_UPx,
                             double ROUND_FACTORx,
                             string INS_EQUAx,
                             double LND_RoundUP,
                             double LND_RoundFactor);

        //CreditLimitResult GetCreditLimit(String CPNCOD, String CPNBRNCOD, String ACCBUSTYP, String GENAPPNUM);
        CreditLimitResult GetCreditLimit(ContractDetailResult contractDetail);
        PaymentAbilityResult GetPaymentAbility(String ADR1_OWNERCOD,TelVerifyResult telVerifyResult);

        List<InstallmentTableResult> GetInstallmentTable(string ACCBUSTYP,
                                                         Nullable<int> CONDUEDAY,
                                                         Nullable<decimal> CONFINAMT,
                                                         Nullable<int> CONLNDTRM,
                                                         Nullable<decimal> CONLNDAMT,
                                                         Nullable<decimal> CONINSAMT,
                                                         Nullable<decimal> CONEFFRTE,
                                                         Nullable<decimal> CONINTRTE,
                                                         Nullable<decimal> INCOMERTE,
                                                         Nullable<decimal> CRUSGRTE,
                                                         Nullable<System.DateTime> CONEFFDTE,
                                                         Nullable<System.DateTime> CONSTRINS,
                                                         Nullable<System.DateTime> CONSECINS,
                                                         string CONINTPER,
                                                         Nullable<decimal> SUBSDYAMT,
                                                         string CONINTCAL);
    }
}
