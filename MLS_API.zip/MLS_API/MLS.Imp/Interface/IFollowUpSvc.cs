﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Models;

namespace MLS.Imp.Interface
{
    public interface IFollowUpSvc
    {
        List<FollowUpHeaderResult> GetFollowUpHeader(string CPNCOD,
                                                            string CPNBRNCOD_FROM,
                                                            string CPNBRNCOD_TO,
                                                            string FOLSTATE,
                                                            Nullable<int> OVDDAY_FROM,
                                                            Nullable<int> OVDDAY_TO,
                                                            string ADRSPCARA_FROM,
                                                            string ADRSPCARA_TO);

        List<vwFollowUpHeader> GetWorkLoadByUser(String FOLWERCOD);

        void AssignJob(string JOB_STEP,
                             string JOB_FUNCTION,
                             string FOLWERCOD,
                             List<FollowUpHeaderResult> jobList,
                             string USERNAM);

        void DeassignJob(string jobSetp, string jobFunction, string fOLWERCOD, List<FollowUpHeaderResult> jobList, string username);

        List<vwFollowUpHeader> GetFollowUpByContract(string CONNUM, string CPNCOD, string CPNBRNCOD, String ACCBUSTYP);

        List<vwFollowUpAlarm> GetFollowUpAlarm(String FOLWERCOD);

        void InsertOrUpdateFollowUpDetail(
            List<MLTFLH> jobHeaderList,
            List<vwFollowUpDetail> jobDetailList,
            String username);

        void InsertOrUpdateAlarm(List<vwFollowUpAlarm> listAlarm, string username);

        List<vwFollowUpDetail> GetFollowUpDetail(String JOBASGNUM, String CPNCOD, String CPNBRNCOD, String ACCBUSTYP);

        List<vwUserSection> GetChildFollower(String GroupID);
    }
}
