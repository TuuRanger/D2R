﻿using MLS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Imp.Implement
{
    public interface IFactorySvc
    {
        List<InvoiceResult> InvoiceVerifying(List<String> fileNames,String username);
        List<InvoiceListResult> GetInvoiceList(String productType, DateTime? InvoiceDateFrom, DateTime? invoiceDateTo, DateTime? dueDateFrom, DateTime? dueDateTo);
        void InsertInvoiceTransaction(List<InvoiceListResult> selectedInvoices, string username);
        InvoiceCreditInfoResult GetInvoiceCreditInfo();
    }
}
