﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Models;

namespace MLS.Imp.Interface
{
    public interface IValidationSvc
    {
        List<FieldValidateResult> GetFieldValidation(List<String> listValidateID);
        RejectResult GetContractAutoRejectResult(ContractDetailResult contractDetail);
        bool CheckAccountMaxCreditLine(String ACCBUSTYP, decimal sourceValue);

        bool CheckAccountMaxCreditPerTime(String ACCBUSTYP, decimal sourceValue);
        bool CheckAccountMinCreditPerTime(String ACCBUSTYP, decimal sourceValue);
        bool CheckAccountMinAdvanceRate(decimal sourceValue);
        bool CheckAccountMaxAdvanceRate(decimal sourceValue);
    }
}
