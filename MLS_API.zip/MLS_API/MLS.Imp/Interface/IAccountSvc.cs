﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Models;

namespace MLS.Imp.Interface
{
    public interface IAccountSvc
    {
        List<AccountResult> SearchAccount(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string ACCDEAWTH, string SEARCH_STR);
        List<vwAccountContract> GetContractByAccount(String ACCCOD, String CPNCOD, String CPNBRNCOD, String ACCBUSTYP);
        InsertOrUpdateCDMACCResult InsertOrUpdateAccount(AccountProcessViewModel entity, String username);
        List<SearchAccountWithPagingResult> SearchAccountWithPaging(String ACCBUSTYP,string ACCCOD, string GENAPPNUM, string ACCNAMTHA, string ACCDEAWTH, string RECSTSCOD_FROM, string RECSTSCOD_TO, int pageNo, int pageSize);
        AccountDetailResult GetAccountDetail(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string GENAPPNUM);
        List<AccountCustomerResult> GetAccountCustomers(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string GENAPPNUM);
        void VerifyAccount(AccountProcessViewModel accountProcessViewModel, String username);
        void SendBackAccount(AccountProcessViewModel accountProcessViewModel, String username);
        GenAccountResult GenAccount(AccountProcessViewModel accountProcessViewModel, String username);
        CDSACCCFG GetAccountConfig(String ACCBUSTYP, String ACCDEAWTH, String CPNBRNCOD);
        CustomerInAccountResult CheckCustomerInAccount(String CUSCOD, String ACCCOD);

        int CheckAccountExistsBeforeGen(String GENAPPNUM, String ACCCOD);
    }
}
