﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Models;
namespace MLS.Imp.Interface
{
    interface IDistrictSvc
    {
        List<DistrictByNameResult> GetDistrictyName(string districtName);
    }
}
