﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Models;

namespace MLS.Imp.Interface
{
    interface IReferencePersonSvc
    {
         List<RefListResult> GetRefList(String GENAPPNUM);



        void InsertOrUpdateReferencePerson(List<RefListResult> refPersonList,
           String CPNCOD,
           String CPNBRNCOD,
           String ACCBUSTYP,
           String CONNUM,
           String username);
    }
}
