﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Models;

namespace MLS.Imp.Interface
{
    interface IProductSvc
    {
        List<ProductSpecInputFieldResult> GetProductSpecInputField(string PRDGRPCOD, string PRDSUBCOD);
        void InsertOrUpdateProductSepc(String CPNCOD, String CPNBRNCOD, String ACCBUSTYP, String CONNUM, Dictionary<String, String> ProductSepc);
        List<vwCDMPRD> GetProduct(String CPNCOD, String CPNBRNCOD, String ACCBUSTYP, String CONNUM);
    }
}
