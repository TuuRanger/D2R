﻿using MLS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Imp.Interface
{
    public interface IUISvc
    {
        List<ScreenLabelTextResult> GetScreenLabelText(string SCREEN_CD, string LANG_CD);
        List<GlobalMessageResult> GetGlobalMessage(String language);
    }
}
