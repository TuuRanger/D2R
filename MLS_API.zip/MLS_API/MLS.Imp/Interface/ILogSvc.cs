﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Imp.Interface
{
    public interface ILogSvc
    {
        void InsertLogXML(string CUSCOD, string CONNUM, string ACCCOD, string METHOD, string LOG_DATA, string CRTUSRCOD, string REMARK, Nullable<int> CRDRSLSTP);
    }
}
