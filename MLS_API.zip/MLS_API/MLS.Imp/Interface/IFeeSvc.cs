﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Models;

namespace MLS.Imp.Interface
{
    interface IFeeSvc
    {
        void InsertOrUpdateFee(List<FeeConfigResult> listFee, String username);

        List<FeeConfigResult> GetFeeList(string CPNCOD,
              string CPNBRNCOD,
              string ACCBUSTYP,
              string CONNUM,
              Nullable<decimal> CREDIT_APPROVE,
              Nullable<decimal> CONDWNAMT,
              string CONAPPLY_PROJEC);

        //List<FeeConfigResult> GetFeeConfig(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP);
    }
}
