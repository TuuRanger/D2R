﻿using MLS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Imp.Interface
{
    public interface ICustomerSvc
    {
        vwCUSINFO GetCustomerInfoWithAccount(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string ID, string CUSTYPCOD);
   
        List<SearchCustomerWithPagingResult> SearchCustomerPaging(String name, String surname, String ID,String customerType, int pageNo, int pageSize);
        vwCustomerSearch GetCustomerInfo(String ID, String CUSTYPCOD);
        List<String> InsertOrUpdateCustomer(List<vwCUSINFO> customerList, String username);
    }
}
