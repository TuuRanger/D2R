﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Models;

namespace MLS.Imp.Interface
{
    public interface IComboBoxSvc
    {
        List<DropDownDealerResult> GetDropDownDealer(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string PROJECTCODE);
        List<DropDownProductBrandResult> GetDropDownProductBrand(string PRDGRPCOD, string PRDSUBCOD, string CONAPPLY_PROJEC, string BrandInput);
        List<DropDownProductModelResult> GetDropDownProductModel(string PRDGRPCOD, string PRDSUBCOD, string Brnad, string CONAPPLY_PROJEC, string ModelInput);
        List<AccountResult> SearchAccount(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string ACCDEAWTH, string SEARCH_STR);
        List<DroDownCompanyResult> GetDropDownCompany();
        List<vwUserSection> GetUserInSectionGroup(String SectionID , String GroupID);
    }
}
