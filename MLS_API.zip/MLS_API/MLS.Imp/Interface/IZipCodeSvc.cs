﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Models;

namespace MLS.Imp.Interface
{
    interface IZipCodeSvc
    {
        List<ZipCodeResult> GetZipCode(int districtID, int amphurID, int provinceID);
        List<ZipCodeByZipCodeResult> GetZipCodeByZipCode(string zipCode);
    }
}
