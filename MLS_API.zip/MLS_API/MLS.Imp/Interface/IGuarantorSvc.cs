﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Models;

namespace MLS.Imp.Interface
{
    public interface IGuarantorSvc
    {
        List<GuarantorListResult> GetGuarantorList(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string CONNUM);
        void InsertOrUpdateGuarantor(List<GuarantorListResult> guarantorList,
            String CPNCOD,
            String CPNBRNCOD,
            String ACCBUSTYP,
            String CONNUM,
            String username);
    }
}
