﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Models;
namespace MLS.Imp.Interface
{
    public interface IContractSvc
    {
        List<ContractListResult> GetContractList(string CONAPPLY_PROJEC,
             string VENDOR,
             string CPNBRNCOD,
             string CRDSTPFROM,
             string CRDSTPTO,
             string PSNREGIDN,
             string CUSNAMTHA,
             string CUSSURTHA,
             string GENAPPNUM);

        ContractDetailResult GetContractDetail(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string GENAPPNUM);


        ContractDetailResult InsertOrUpdateContract(ContractDetailResult contractDetail);

        List<ContractListFactoringWithPagingResult> GetContractListFactoringWithPaging(string sponsorName, string CONNUM, string GENAPPNUM, string stepFrom, string stepTo, Nullable<int> pageSize, Nullable<int> pageNo);
       
    }
}
