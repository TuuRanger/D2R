﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Models;

namespace MLS.Imp.Interface
{
    interface ISysConfig
    {
        List<CDMTABListResult> GetCDMTABList(string tabKeyOne, String tabKeyTwo);
    }
}
