﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Models;
using MLS.Imp.Interface;
using MLS.Models.CustomModels;
using Newtonsoft.Json;
using MLS.Helper;

namespace MLS.Imp.Implement
{
    public class ProductSvc : IProductSvc
    {
        public class eComboBoxDataSourceType
        {
            public const String DB = "DB";
            public const String JSON = "JSON";
        }

        public class eControlType
        {
            public const String mlsComboBox = "mlsComboBox"; 
        }

        public List<ProductSpecInputFieldResult> GetProductSpecInputField(string PRDGRPCOD, string PRDSUBCOD)
        {
            using (MLSEntities db = new MLSEntities())
            {
                List<ProductSpecInputFieldResult> result = db.GetProductSpecInputField(PRDGRPCOD, PRDSUBCOD).ToList();
                foreach (var item in result)
                {
                    if (item.ControlType == eControlType.mlsComboBox)
                    {
                        if (item.ComboBoxDataSourceType == eComboBoxDataSourceType.DB)
                        {
                            item.ComboBoxDataSource = db.Database.SqlQuery<ComboBoxDataSource>(item.ComboBoxDataSourceText).ToList();
                        }
                        else if (item.ComboBoxDataSourceType == eComboBoxDataSourceType.JSON)
                        {
                            List<ComboBoxDataSource> comboBoxDataSource = JsonConvert.DeserializeObject<List<ComboBoxDataSource>>(item.ComboBoxDataSourceText);
                            item.ComboBoxDataSource = comboBoxDataSource;
                        }
                        else
                        {
                            var dataSource = item.ComboBoxDataSourceText.Split(item.ComboBoxDataSourceType[0]).ToList();
                            List<ComboBoxDataSource> comboBoxDataSource = new List<ComboBoxDataSource>();
                            foreach (String data in dataSource)
                            {
                                comboBoxDataSource.Add(new ComboBoxDataSource() { DisplayMember = data, ValueMember = data });
                            }
                            item.ComboBoxDataSource = comboBoxDataSource;
                        }
                    }
                    
                }
                return result;  
            }
        }

        public void InsertOrUpdateProductSepc(String CPNCOD, String CPNBRNCOD, String ACCBUSTYP, String CONNUM, Dictionary<String, String> ProductSepc)
        {
            String productSpecXML = ProductSepc.ToXml();
            using (MLSEntities db = new MLSEntities())
            {
                db.UpdateProductDetail(CPNCOD, CPNBRNCOD, ACCBUSTYP, CONNUM, productSpecXML);
            }
        }

        public Dictionary<String, String> GetProductDetail(String CPNCOD, String CPNBRNCOD, String ACCBUSTYP, String CONNUM)
        {
            using (MLSEntities db = new MLSEntities())
            {
                List<ProductDetailResult> productDetail = db.GetProductDetail(CPNCOD, CPNBRNCOD, ACCBUSTYP, CONNUM).ToList();
                return productDetail.ToDictionary(x => x.Key, x => x.Value);
            }
        }

        public List<vwCDMPRD> GetProduct(String CPNCOD, String CPNBRNCOD, String ACCBUSTYP, String CONNUM)
        {
            using (MLSEntities db = new MLSEntities())
            {
                List<vwCDMPRD> result = db.vwCDMPRDs.Where(x => x.CPNCOD == CPNCOD && x.CPNBRNCOD == CPNBRNCOD && x.ACCBUSTYP == ACCBUSTYP && x.CONNUM == CONNUM).ToList();
                return result;
            }
        }
            
    }
}
