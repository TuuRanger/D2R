﻿using MLS.Imp.Interface;
using MLS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Imp.Implement
{
    public class InternalBlackListSvc : IInternalBlackListSvc
    {
        public InternalBlackListResult GetInternalBlackList(string PSNREGIDN, string SRCINF)
        {
            using (MLSEntities db = new MLSEntities())
            {
               return db.GetInternalBlackList(PSNREGIDN,SRCINF).FirstOrDefault();
            }
        }
    }
}
