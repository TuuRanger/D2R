﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Helper;
using MLS.Imp.Interface;
using MLS.Models;
using System.Transactions;

namespace MLS.Imp.Implement
{
    public class ContractSvc : IContractSvc
    {

        MLSEntities _db;

        public ContractSvc()
        {
            _db = new MLSEntities();
        }

        public List<ContractListResult> GetContractList(string CONAPPLY_PROJEC,
            string VENDOR,
            string CPNBRNCOD,
            string CRDSTPFROM,
            string CRDSTPTO,
            string PSNREGIDN,
            string CUSNAMTHA,
            string CUSSURTHA,
            string GENAPPNUM)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetContractList(CONAPPLY_PROJEC, VENDOR, CPNBRNCOD, CRDSTPFROM, CRDSTPTO, PSNREGIDN, CUSNAMTHA, CUSSURTHA, GENAPPNUM).ToList();
            }
        }

        public ContractDetailResult GetContractDetail(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string GENAPPNUM)
        {
            using (MLSEntities db = new MLSEntities())
            {
                ContractDetailResult contractDetail = db.GetContractDetail(CPNCOD, CPNBRNCOD, ACCBUSTYP, GENAPPNUM).FirstOrDefault();
                return contractDetail;
            }
        }

        public ContractRoundResult GetContractRound(String CONAPPLY_PROJEC, String PRDMDLCOD)
        {
            using (MLSEntities db = new MLSEntities())
            {
                ContractRoundResult contractRoundResult = db.GetContractRound(CONAPPLY_PROJEC, PRDMDLCOD).FirstOrDefault();
                return contractRoundResult;
            }
        }

        public ContractDetailResult InsertOrUpdateContract(ContractDetailResult contractDetail)
        {
            InsertOrUpdateContractResult insertResult = null;
            ContractDetailResult newContractDetail = null;
            using (MLSEntities db = new MLSEntities())
            {
                //if (Convert.ToInt32(contractDetail.CRDNXTSTP) == 3 || Convert.ToInt32(contractDetail.CRDNXTSTP) == 4  && contractDetail.CRDRSLSTP == "Y")
                //{
                if (contractDetail.IsRecalculateCreditLimit)
                {
                    IFinanceCalSvc financeSvc = new FinanceCalSvc();

                    CreditLimitResult creditLimitResult = financeSvc.GetCreditLimit(contractDetail);
                    contractDetail.CRDLIMAMT = creditLimitResult.CreditLimit;
                    contractDetail.CRDLIMTRM = creditLimitResult.TermLimit;

                    //if (contractDetail.CONFINAMT.GetValueOrDefault(0) <= 0)
                    //{
                    ContractRoundResult roundResult = this.GetContractRound(contractDetail.CONAPPLY_PROJEC, contractDetail.PRDMDLCOD);
                    MLMCampaignResult campaignResult = db.GetMLMCampaignByProjectCode(contractDetail.CONAPPLY_PROJEC).FirstOrDefault();

                    if (contractDetail.CONPRDAMT.GetValueOrDefault(0) <= 0) /* ถ้าค่าถูก entry/save ไปแล้วไม่ควรเปลี่ยน ให้ user เปลี่ยนเอง*/
                    {
                        contractDetail.CONPRDAMT = contractDetail.CRDLIMAMT; /*set default value*/

                        contractDetail.CONPRDTAX = contractDetail.CONPRDAMT.Value.CalculateTaxByNet(contractDetail.ContractTaxPercent.GetValueOrDefault(0));
                        contractDetail.CONPRDGRS = contractDetail.CONPRDAMT + contractDetail.CONPRDTAX;
                        contractDetail.CONDWNTAX = contractDetail.CONDWNAMT.GetValueOrDefault(0).CalculateTaxByNet(contractDetail.ContractTaxPercent.GetValueOrDefault(0));
                        contractDetail.CONDWNGRS = contractDetail.CONDWNTAX.GetValueOrDefault(0) + contractDetail.CONDWNAMT.GetValueOrDefault(0);

                        contractDetail.CONLNDTRM = contractDetail.CRDLIMTRM; /*set default value*/

                        contractDetail.CONFINAMT = contractDetail.CONPRDAMT.GetValueOrDefault(0) - contractDetail.CONDWNAMT.GetValueOrDefault(0);
                        contractDetail.CONFINTAX = contractDetail.CONPRDTAX.GetValueOrDefault(0) - contractDetail.CONDWNTAX.GetValueOrDefault(0);
                        contractDetail.CONFINGRS = contractDetail.CONPRDGRS.GetValueOrDefault(0) - contractDetail.CONDWNGRS.GetValueOrDefault(0);

                        InstallmentCalcResult installmentResult = financeSvc.InstallmentCalc(
                                contractDetail.CONFINAMT.GetValueOrDefault(0).ToDouble(),
                                contractDetail.CONLNDTRM.GetValueOrDefault(0),
                                contractDetail.CONINTRTE.GetValueOrDefault(0),
                                contractDetail.CONINTTYP,
                                contractDetail.CONINSPER,
                                contractDetail.CONINTCAL,
                                contractDetail.CONINTPER,
                                "",
                                0,
                                "",
                                0,
                                contractDetail.SUBSDYAMT.GetValueOrDefault(0).ToDouble(),
                                roundResult.RoundTo.GetValueOrDefault(0).ToDouble(),
                                roundResult.RoundFactor.GetValueOrDefault(0).ToDouble(),
                                campaignResult.IsInstallmentEquals,
                                campaignResult.LoanAmountRoundTo.GetValueOrDefault(0).ToDouble(),
                                campaignResult.LoanAmountRoundFactor.GetValueOrDefault(0).ToDouble()
                                );


                        contractDetail.CONINSAMT = installmentResult.CONINSAMT.ToDecimal();
                        contractDetail.CONINSTAX = contractDetail.CONINSAMT.Value.CalculateTaxByNet(contractDetail.ContractTaxPercent.GetValueOrDefault(0));
                        contractDetail.CONINSGRS = contractDetail.CONINSTAX + contractDetail.CONINSAMT;

                        contractDetail.CONEFFRTE = installmentResult.CONEFFRTE;

                        contractDetail.CONLNDAMT = installmentResult.CONLNDAMT.ToDecimal();
                        contractDetail.CONLNDTAX = contractDetail.CONLNDAMT.Value.CalculateTaxByNet(contractDetail.ContractTaxPercent.GetValueOrDefault(0));
                        contractDetail.CONLNDGRS = contractDetail.CONLNDAMT + contractDetail.CONLNDTAX;

                        contractDetail.MaxInstallment = Math.Round(contractDetail.CRDLIMAMT.GetValueOrDefault(0) / contractDetail.CRDLIMTRM.GetValueOrDefault(0));

                        if (campaignResult.MaxInstallmentMultiplier != null)
                        {
                            contractDetail.MaxInstallment = campaignResult.MaxInstallmentMultiplier.GetValueOrDefault(0) * contractDetail.PSNMTHINC.GetValueOrDefault(0);
                        }
                    }
                }

                if (contractDetail.GENAPPNUM.IsEmpty() || contractDetail.ACCCOD.IsEmpty())
                {
                    SetupResult creditLineConfig = db.GetSetup("ACCCRDLIN", contractDetail.ACCBUSTYP, "N").FirstOrDefault();
                    contractDetail.ACCCRDLIN = creditLineConfig.TABSETAMT1;
                    contractDetail.ACCCRDTIM = creditLineConfig.TABSETAMT2.GetValueOrDefault(0).ToInt();
                }

                insertResult = db.InsertOrUpdateContract(contractDetail.CPNCOD
                                                 , contractDetail.CPNBRNCOD
                                                 , contractDetail.CPNBRNACS
                                                 , contractDetail.ACCBUSTYP
                                                 , contractDetail.GENAPPNUM
                                                 , contractDetail.CONNUM
                                                 , contractDetail.GENAPPDTE
                                                 , contractDetail.GENEFFDTE
                                                 , contractDetail.GENAPRDTE
                                                 , contractDetail.ACCCOD
                                                 , contractDetail.CONOBJCOD
                                                 , contractDetail.ACCCODRCV1
                                                 , contractDetail.CUSCOD
                                                 , contractDetail.CUSTTLTHA
                                                 , contractDetail.CUSNAMTHA
                                                 , contractDetail.CUSSURTHA
                                                 , contractDetail.CUSNICNAM
                                                 , contractDetail.CUSPHNNUM
                                                 , contractDetail.PSNREGIDN
                                                 , contractDetail.PSNBTHDTE
                                                 , contractDetail.PSNMTHINC
                                                 , contractDetail.PSNOTHINC
                                                 , contractDetail.PSNMARSTS
                                                 , contractDetail.PSNCHDNUM
                                                 , contractDetail.PSNSEXCOD
                                                 , contractDetail.PSNOCCCOD
                                                 , contractDetail.PSNPOSITN
                                                 , contractDetail.CONAPPLY_TYP
                                                 , contractDetail.CONAPPLY_VIA
                                                 , contractDetail.CONAPPLY_PROJEC
                                                 , contractDetail.CONAPPLY_PROMOT
                                                 , contractDetail.PSNNETINC
                                                 , contractDetail.PSNGRSINC
                                                 , contractDetail.PSNCPNSTF
                                                 , contractDetail.PSNWRKPLCCCP
                                                 , contractDetail.PSNWRKPLC
                                                 , contractDetail.PSNWRKPRD
                                                 , contractDetail.PSNWRKPRD_MON
                                                 , contractDetail.PSNCPNTYP
                                                 , contractDetail.PSNBTHDAY
                                                 , contractDetail.PSNEMPLOY_TYP
                                                 , contractDetail.PSNSALRCVTYP
                                                 , contractDetail.CRDREQAMT
                                                 , contractDetail.CRDREQTRM
                                                 , contractDetail.CRDLIMAMT
                                                 , contractDetail.CRDLIMTRM
                                                 , contractDetail.CRDLIMRSL
                                                 , contractDetail.FINBNKCODCR
                                                 , contractDetail.FINBRNCODCR
                                                 , contractDetail.FINBNKNUMCR
                                                 , contractDetail.CRDCURSTP
                                                 , contractDetail.CRDNXTSTP
                                                 , contractDetail.CRDRSLSTP
                                                 , contractDetail.CRDDEVIAT
                                                 , contractDetail.GENREMARK
                                                 , contractDetail.CONINTTYP
                                                 , contractDetail.CONINTCAL
                                                 , Convert.ToDecimal(contractDetail.CONINTRTE.GetValueOrDefault(0))
                                                 , Convert.ToDecimal(contractDetail.CONEFFRTE.GetValueOrDefault(0))
                                                 , contractDetail.CONINSPER
                                                 , contractDetail.CONLNDTRM
                                                 , contractDetail.CONINTPER
                                                 , contractDetail.CONIRATE
                                                 , Convert.ToDecimal(contractDetail.CONFRATE.GetValueOrDefault(0))
                                                 , contractDetail.IRATEBNKREF
                                                 , contractDetail.PRDCSTGRS
                                                 , contractDetail.PRDCSTAMT
                                                 , contractDetail.PRDCSTTAX
                                                 , contractDetail.CONPRDGRS
                                                 , contractDetail.CONPRDAMT
                                                 , contractDetail.CONPRDTAX
                                                 , contractDetail.CONDWNGRS
                                                 , contractDetail.CONDWNAMT
                                                 , contractDetail.CONDWNTAX
                                                 , contractDetail.CONFINGRS
                                                 , contractDetail.CONFINAMT
                                                 , contractDetail.CONFINTAX
                                                 , contractDetail.CONBLNGRS
                                                 , contractDetail.CONBLNAMT
                                                 , contractDetail.CONBLNTAX
                                                 , contractDetail.PCOPTGRS
                                                 , contractDetail.PCOPTAMT
                                                 , contractDetail.PCOPTTAX
                                                 , contractDetail.CONDEPGRS
                                                 , contractDetail.CONDEPAMT
                                                 , contractDetail.CONDEPTAX
                                                 , contractDetail.CONINSGRS
                                                 , contractDetail.CONINSAMT
                                                 , contractDetail.CONINSTAX
                                                 , contractDetail.CONLNDGRS
                                                 , contractDetail.CONLNDAMT
                                                 , contractDetail.CONLNDTAX
                                                 , contractDetail.SUBSDYGRS
                                                 , contractDetail.SUBSDYAMT
                                                 , contractDetail.SUBSDYTAX
                                                 , contractDetail.CONDEFINC
                                                 , contractDetail.CONSTSCOD
                                                 , contractDetail.CONDWNCND
                                                 , contractDetail.CONPAYTYP
                                                 , contractDetail.CONTAXTYP
                                                 , contractDetail.CONPRCTYP
                                                 , contractDetail.CONDUEDAY
                                                 , contractDetail.CRDQUESTION1
                                                 , contractDetail.CRDQUESTION2
                                                 , contractDetail.CRDQUESTION3
                                                 , contractDetail.CRDANSWER1
                                                 , contractDetail.CRDANSWER2
                                                 , contractDetail.CRDANSWER3
                                                 , "ADMIN"
                                                 , contractDetail.ACCCODMKT
                                                 , contractDetail.ACCCODDLR
                                                 , contractDetail.ACCCODSDY
                                                 , contractDetail.ACCCODBUY
                                                 , contractDetail.PREPAIDTRM
                                                 , contractDetail.BLNPAYMTD
                                                 , contractDetail.DEBROLDAY
                                                 , contractDetail.CONSTRINS
                                                 , contractDetail.CONSECINS
                                                 , contractDetail.CONENDINS
                                                 , contractDetail.CONBLNDUE
                                                 , contractDetail.TRNFERCOD
                                                 , contractDetail.PNTSTDFML
                                                 , contractDetail.PNTRTE
                                                 , contractDetail.PNTDAY
                                                 , contractDetail.PNTTME
                                                 , contractDetail.PNTINCVAT
                                                 , contractDetail.PNTAMTMIN
                                                 , contractDetail.PNTPRNMIN
                                                 , contractDetail.FLWSTDFML
                                                 , contractDetail.FLWRTE
                                                 , contractDetail.FLWDAY
                                                 , contractDetail.FLWTME
                                                 , contractDetail.FLWINCVAT
                                                 , contractDetail.FLWAMTMIN
                                                 , contractDetail.FLWPRNMIN
                                                 , contractDetail.CONCOMPCN
                                                 , contractDetail.CONCOMPAMT
                                                 , contractDetail.CONCOMAMT
                                                 , contractDetail.CONCOMEXT
                                                 , contractDetail.ACCCODRCV2
                                                 , contractDetail.ACCCODRCV3
                                                 , contractDetail.COMAMTRCV00
                                                 , contractDetail.COMAMTRCV01
                                                 , contractDetail.COMAMTRCV02
                                                 , contractDetail.COMAMTRCV03
                                                 , contractDetail.COMWHTRCV00
                                                 , contractDetail.COMVATRCV00
                                                 , contractDetail.COMWHTRCV01
                                                 , contractDetail.COMVATRCV01
                                                 , contractDetail.COMWHTRCV02
                                                 , contractDetail.COMVATRCV02
                                                 , contractDetail.COMWHTRCV03
                                                 , contractDetail.COMVATRCV03
                                                 , contractDetail.RADIOAMT
                                                 , contractDetail.COOPERATAMT
                                                 , contractDetail.RADIONUM
                                                 , contractDetail.TAXINUM
                                                 , contractDetail.ACCCODCFF
                                                 , contractDetail.CFFSTSCOD
                                                 , contractDetail.CFFTAXTYP
                                                 , contractDetail.CFFPRDGRS
                                                 , contractDetail.CFFPRDAMT
                                                 , contractDetail.CFFPRDTAX
                                                 , contractDetail.CFFDWNGRS
                                                 , contractDetail.CFFDWNAMT
                                                 , contractDetail.CFFDWNTAX
                                                 , contractDetail.CFFBLNGRS
                                                 , contractDetail.CFFBLNAMT
                                                 , contractDetail.CFFBLNTAX
                                                 , contractDetail.CFFFINGRS
                                                 , contractDetail.CFFFINAMT
                                                 , contractDetail.CFFFINTAX
                                                 , contractDetail.CFFINSGRS
                                                 , contractDetail.CFFINSAMT
                                                 , contractDetail.CFFINSTAX
                                                 , contractDetail.CFFLNDGRS
                                                 , contractDetail.CFFLNDAMT
                                                 , contractDetail.CFFLNDTAX
                                                 , contractDetail.CFFDEFINC
                                                 , contractDetail.CFFLNDTRM
                                                 , contractDetail.CFFBEGTRM
                                                 , contractDetail.CFFINSPER
                                                 , contractDetail.CFFINTTYP
                                                 , contractDetail.CFFINTRTE
                                                 , contractDetail.CFFEFFRTE
                                                 , contractDetail.CFFYIELD
                                                 , contractDetail.CFFINTPER
                                                 , contractDetail.CFFINTCAL
                                                 , contractDetail.CFFSTRINS
                                                 , contractDetail.CFFSECINS
                                                 , contractDetail.CFFENDINS
                                                 , contractDetail.CFFLEGTYP
                                                 , contractDetail.CFFPURPOS
                                                 , contractDetail.CFFDWNCND
                                                 , contractDetail.CFFPAYTYP
                                                 , contractDetail.CFFDUEDAY
                                                 , contractDetail.CFFBLNDUE
                                                 , contractDetail.CFFCLSDTE
                                                 , contractDetail.CFFIRATE
                                                 , contractDetail.CFFFRATE
                                                 , contractDetail.CFFLNDTYP
                                                 , contractDetail.CFFDWNDEF
                                                 , contractDetail.CFFCONNUM
                                                 , contractDetail.ACCCODVER
                                                 , contractDetail.PRDGRPCOD
                                                 , contractDetail.PRDSUBCOD
                                                 , contractDetail.PRDTYPE
                                                 , contractDetail.PRDBRNCOD
                                                 , contractDetail.PRDLISPRC
                                                 , contractDetail.PRDCSTPRC
                                                 , contractDetail.PRDSALPRC
                                                 , contractDetail.PRDNEWUSE
                                                 , contractDetail.PRDDETAIL
                                                 , contractDetail.PRDREMARK
                                                 , contractDetail.PRDMDLCOD
                                                 , contractDetail.PRDSRLNUM
                                                 , contractDetail.PRDINCACSOR
                                                 , contractDetail.PRDITMNUM
                                                 , contractDetail.APPRISALAMT
                                                 , contractDetail.LOCATN
                                                 , contractDetail.PRDCOD
                                                 , contractDetail.PRDSTSCOD
                                                 , contractDetail.ACCESSORYAMT
                                                 , contractDetail.CUSTTLENG
                                                 , contractDetail.CUSNAMENG
                                                 , contractDetail.CUSSURENG
                                                 , contractDetail.CUSTYPCOD
                                                 , contractDetail.CUSCRDCOD
                                                 , contractDetail.CUSLEVCOD
                                                 , contractDetail.CUSBOTCOD
                                                 , contractDetail.CUSCRDLNE
                                                 , contractDetail.CUSBUSCNT
                                                 , contractDetail.GENTAXNUM
                                                 , contractDetail.CUS_FINBNKCOD1
                                                 , contractDetail.CUS_FINBNKBRN1
                                                 , contractDetail.CUS_FINBNKNUM1
                                                 , contractDetail.CUS_FINBNKCOD2
                                                 , contractDetail.CUS_FINBNKBRN2
                                                 , contractDetail.CUS_FINBNKNUM2
                                                 , contractDetail.CUS_FINBNKCOD3
                                                 , contractDetail.CUS_FINBNKBRN3
                                                 , contractDetail.CUS_FINBNKNUM3
                                                 , contractDetail.ADRCOD01
                                                 , contractDetail.ADRCOD02
                                                 , contractDetail.ADRCOD03
                                                 , contractDetail.ADRCOD04
                                                 , contractDetail.ADRCOD05
                                                 , contractDetail.ADRCOD06
                                                 , contractDetail.ADRCOD07
                                                 , contractDetail.ADRCOD08
                                                 , contractDetail.ADRCOD09
                                                 , contractDetail.ADRCOD10
                                                 , contractDetail.CUSCITZEN
                                                 , contractDetail.CUSNATION
                                                 , contractDetail.VATREGISTER
                                                 , contractDetail.CUS_ADRTELNUM
                                                 , contractDetail.CUSEMAIL
                                                 , contractDetail.COOPERATE_TYPE
                                                 , contractDetail.OLD_LOAN_CPN
                                                 , contractDetail.OLD_CREDIT_LINE
                                                 , contractDetail.LAST_OUTSTD_AMT
                                                 , contractDetail.CHECK_HOME_TEL
                                                 , contractDetail.CHECK_HOME_NAME_RSLT
                                                 , contractDetail.CHECK_HOME_NAME_REMARK
                                                 , contractDetail.CHECK_HOME_ADR_RSLT
                                                 , contractDetail.CHECK_HOME_ADR_REMARK
                                                 , contractDetail.CHECK_OFFC_TEL
                                                 , contractDetail.CHECK_OFFC_NAME_RSLT
                                                 , contractDetail.CHECK_OFFC_NAME_REMARK
                                                 , contractDetail.CHECK_OFFC_ADR_RSLT
                                                 , contractDetail.CHECK_OFFC_ADR_REMARK
                                                 , contractDetail.CHECK_SSO_RSLT
                                                 , contractDetail.CHECK_DBD_RSLT
                                                 , contractDetail.VENDORBRN
                                                 , contractDetail.CONAPPLY_VIABRN
                                                 , contractDetail.PSNREGSIN
                                                 , contractDetail.PSNREGEXP
                                                 , contractDetail.PSNSALDTE
                                                 , contractDetail.PSNRELTME
                                                 , contractDetail.CONPRDPRCINC
                                                 , contractDetail.CONPRDPRCNET
                                                 , contractDetail.CONPRDPRCTAX
                                                 , contractDetail.INCOMERTE
                                                 , contractDetail.CRUSGRTE
                                                 , contractDetail.R_FLAG
                                                 , contractDetail.CUSPHNNUM_TELSEQNUM
                                                 , contractDetail.CRDPNDSTS
                                                 , contractDetail.ACCCRDLIN
                                                 , contractDetail.ACCCRDTIM
                                                 , contractDetail.ACCLNDTYP
                                                 , contractDetail.CPNREGNUM
                                                 , contractDetail.CPNBUSTYP
                                                 , contractDetail.CPNREGDTE
                                                 , contractDetail.CPNYERINC
                                                 , contractDetail.CPNYERPRF
                                                 , contractDetail.REFDOCDTE
                                                 , contractDetail.CPNCNTPSN
                                                 , contractDetail.CPNCNTPOS
                                                 , contractDetail.FACADVRTE
                                                 , contractDetail.CONDUETYP
                                                 , contractDetail.CONCRDTRM).FirstOrDefault();
                newContractDetail = this.GetContractDetail(insertResult.CPNCOD, insertResult.CPNBRNCOD, insertResult.ACCBUSTPY, insertResult.GENAPPNUM);
                newContractDetail.MaxInstallment = contractDetail.MaxInstallment;
            }

            return newContractDetail;
        }

        public ContractDetailResult InsertOrUpdateContractFactoring(ContractDetailResult contractDetail, String username)
        {
            InsertOrUpdateContractFactoringResult insertResult = null;
            ContractDetailResult newContractDetail = null;
            using (TransactionScope trans = new TransactionScope())
            {
                insertResult = _db.InsertOrUpdateContractFactoring(contractDetail.CPNCOD
                                                 , contractDetail.CPNBRNCOD
                                                 , contractDetail.CPNBRNACS
                                                 , contractDetail.ACCBUSTYP
                                                 , contractDetail.GENAPPNUM
                                                 , contractDetail.CONNUM
                                                 , contractDetail.GENAPPDTE
                                                 , contractDetail.GENEFFDTE
                                                 , contractDetail.GENAPRDTE
                                                 , contractDetail.ACCCOD
                                                 , contractDetail.CONOBJCOD
                                                 , contractDetail.ACCCODRCV1
                                                 , contractDetail.CUSCOD
                                                 , contractDetail.CUSTTLTHA
                                                 , contractDetail.CUSNAMTHA
                                                 , contractDetail.CUSSURTHA
                                                 , contractDetail.CUSNICNAM
                                                 , contractDetail.CUSPHNNUM
                                                 , contractDetail.PSNREGIDN
                                                 , contractDetail.PSNBTHDTE
                                                 , contractDetail.PSNMTHINC
                                                 , contractDetail.PSNOTHINC
                                                 , contractDetail.PSNMARSTS
                                                 , contractDetail.PSNCHDNUM
                                                 , contractDetail.PSNSEXCOD
                                                 , contractDetail.PSNOCCCOD
                                                 , contractDetail.PSNPOSITN
                                                 , contractDetail.CONAPPLY_TYP
                                                 , contractDetail.CONAPPLY_VIA
                                                 , contractDetail.CONAPPLY_PROJEC
                                                 , contractDetail.CONAPPLY_PROMOT
                                                 , contractDetail.PSNNETINC
                                                 , contractDetail.PSNGRSINC
                                                 , contractDetail.PSNCPNSTF
                                                 , contractDetail.PSNWRKPLCCCP
                                                 , contractDetail.PSNWRKPLC
                                                 , contractDetail.PSNWRKPRD
                                                 , contractDetail.PSNWRKPRD_MON
                                                 , contractDetail.PSNCPNTYP
                                                 , contractDetail.PSNBTHDAY
                                                 , contractDetail.PSNEMPLOY_TYP
                                                 , contractDetail.PSNSALRCVTYP
                                                 , contractDetail.CRDREQAMT
                                                 , contractDetail.CRDREQTRM
                                                 , contractDetail.CRDLIMAMT
                                                 , contractDetail.CRDLIMTRM
                                                 , contractDetail.CRDLIMRSL
                                                 , contractDetail.FINBNKCODCR
                                                 , contractDetail.FINBRNCODCR
                                                 , contractDetail.FINBNKNUMCR
                                                 , contractDetail.CRDCURSTP
                                                 , contractDetail.CRDNXTSTP
                                                 , contractDetail.CRDRSLSTP
                                                 , contractDetail.CRDDEVIAT
                                                 , contractDetail.GENREMARK
                                                 , contractDetail.CONINTTYP
                                                 , contractDetail.CONINTCAL
                                                 , Convert.ToDecimal(contractDetail.CONINTRTE.GetValueOrDefault(0))
                                                 , Convert.ToDecimal(contractDetail.CONEFFRTE.GetValueOrDefault(0))
                                                 , contractDetail.CONINSPER
                                                 , contractDetail.CONLNDTRM
                                                 , contractDetail.CONINTPER
                                                 , contractDetail.CONIRATE
                                                 , Convert.ToDecimal(contractDetail.CONFRATE.GetValueOrDefault(0))
                                                 , contractDetail.IRATEBNKREF
                                                 , contractDetail.PRDCSTGRS
                                                 , contractDetail.PRDCSTAMT
                                                 , contractDetail.PRDCSTTAX
                                                 , contractDetail.CONPRDGRS
                                                 , contractDetail.CONPRDAMT
                                                 , contractDetail.CONPRDTAX
                                                 , contractDetail.CONDWNGRS
                                                 , contractDetail.CONDWNAMT
                                                 , contractDetail.CONDWNTAX
                                                 , contractDetail.CONFINGRS
                                                 , contractDetail.CONFINAMT
                                                 , contractDetail.CONFINTAX
                                                 , contractDetail.CONBLNGRS
                                                 , contractDetail.CONBLNAMT
                                                 , contractDetail.CONBLNTAX
                                                 , contractDetail.PCOPTGRS
                                                 , contractDetail.PCOPTAMT
                                                 , contractDetail.PCOPTTAX
                                                 , contractDetail.CONDEPGRS
                                                 , contractDetail.CONDEPAMT
                                                 , contractDetail.CONDEPTAX
                                                 , contractDetail.CONINSGRS
                                                 , contractDetail.CONINSAMT
                                                 , contractDetail.CONINSTAX
                                                 , contractDetail.CONLNDGRS
                                                 , contractDetail.CONLNDAMT
                                                 , contractDetail.CONLNDTAX
                                                 , contractDetail.SUBSDYGRS
                                                 , contractDetail.SUBSDYAMT
                                                 , contractDetail.SUBSDYTAX
                                                 , contractDetail.CONDEFINC
                                                 , contractDetail.CONSTSCOD
                                                 , contractDetail.CONDWNCND
                                                 , contractDetail.CONPAYTYP
                                                 , contractDetail.CONTAXTYP
                                                 , contractDetail.CONPRCTYP
                                                 , contractDetail.CONDUEDAY
                                                 , contractDetail.CRDQUESTION1
                                                 , contractDetail.CRDQUESTION2
                                                 , contractDetail.CRDQUESTION3
                                                 , contractDetail.CRDANSWER1
                                                 , contractDetail.CRDANSWER2
                                                 , contractDetail.CRDANSWER3
                                                 , username
                                                 , contractDetail.ACCCODMKT
                                                 , contractDetail.ACCCODDLR
                                                 , contractDetail.ACCCODSDY
                                                 , contractDetail.ACCCODBUY
                                                 , contractDetail.PREPAIDTRM
                                                 , contractDetail.BLNPAYMTD
                                                 , contractDetail.DEBROLDAY
                                                 , contractDetail.CONSTRINS
                                                 , contractDetail.CONSECINS
                                                 , contractDetail.CONENDINS
                                                 , contractDetail.CONBLNDUE
                                                 , contractDetail.TRNFERCOD
                                                 , contractDetail.PNTSTDFML
                                                 , contractDetail.PNTRTE
                                                 , contractDetail.PNTDAY
                                                 , contractDetail.PNTTME
                                                 , contractDetail.PNTINCVAT
                                                 , contractDetail.PNTAMTMIN
                                                 , contractDetail.PNTPRNMIN
                                                 , contractDetail.FLWSTDFML
                                                 , contractDetail.FLWRTE
                                                 , contractDetail.FLWDAY
                                                 , contractDetail.FLWTME
                                                 , contractDetail.FLWINCVAT
                                                 , contractDetail.FLWAMTMIN
                                                 , contractDetail.FLWPRNMIN
                                                 , contractDetail.CONCOMPCN
                                                 , contractDetail.CONCOMPAMT
                                                 , contractDetail.CONCOMAMT
                                                 , contractDetail.CONCOMEXT
                                                 , contractDetail.ACCCODRCV2
                                                 , contractDetail.ACCCODRCV3
                                                 , contractDetail.COMAMTRCV00
                                                 , contractDetail.COMAMTRCV01
                                                 , contractDetail.COMAMTRCV02
                                                 , contractDetail.COMAMTRCV03
                                                 , contractDetail.COMWHTRCV00
                                                 , contractDetail.COMVATRCV00
                                                 , contractDetail.COMWHTRCV01
                                                 , contractDetail.COMVATRCV01
                                                 , contractDetail.COMWHTRCV02
                                                 , contractDetail.COMVATRCV02
                                                 , contractDetail.COMWHTRCV03
                                                 , contractDetail.COMVATRCV03
                                                 , contractDetail.RADIOAMT
                                                 , contractDetail.COOPERATAMT
                                                 , contractDetail.RADIONUM
                                                 , contractDetail.TAXINUM
                                                 , contractDetail.ACCCODCFF
                                                 , contractDetail.CFFSTSCOD
                                                 , contractDetail.CFFTAXTYP
                                                 , contractDetail.CFFPRDGRS
                                                 , contractDetail.CFFPRDAMT
                                                 , contractDetail.CFFPRDTAX
                                                 , contractDetail.CFFDWNGRS
                                                 , contractDetail.CFFDWNAMT
                                                 , contractDetail.CFFDWNTAX
                                                 , contractDetail.CFFBLNGRS
                                                 , contractDetail.CFFBLNAMT
                                                 , contractDetail.CFFBLNTAX
                                                 , contractDetail.CFFFINGRS
                                                 , contractDetail.CFFFINAMT
                                                 , contractDetail.CFFFINTAX
                                                 , contractDetail.CFFINSGRS
                                                 , contractDetail.CFFINSAMT
                                                 , contractDetail.CFFINSTAX
                                                 , contractDetail.CFFLNDGRS
                                                 , contractDetail.CFFLNDAMT
                                                 , contractDetail.CFFLNDTAX
                                                 , contractDetail.CFFDEFINC
                                                 , contractDetail.CFFLNDTRM
                                                 , contractDetail.CFFBEGTRM
                                                 , contractDetail.CFFINSPER
                                                 , contractDetail.CFFINTTYP
                                                 , contractDetail.CFFINTRTE
                                                 , contractDetail.CFFEFFRTE
                                                 , contractDetail.CFFYIELD
                                                 , contractDetail.CFFINTPER
                                                 , contractDetail.CFFINTCAL
                                                 , contractDetail.CFFSTRINS
                                                 , contractDetail.CFFSECINS
                                                 , contractDetail.CFFENDINS
                                                 , contractDetail.CFFLEGTYP
                                                 , contractDetail.CFFPURPOS
                                                 , contractDetail.CFFDWNCND
                                                 , contractDetail.CFFPAYTYP
                                                 , contractDetail.CFFDUEDAY
                                                 , contractDetail.CFFBLNDUE
                                                 , contractDetail.CFFCLSDTE
                                                 , contractDetail.CFFIRATE
                                                 , contractDetail.CFFFRATE
                                                 , contractDetail.CFFLNDTYP
                                                 , contractDetail.CFFDWNDEF
                                                 , contractDetail.CFFCONNUM
                                                 , contractDetail.ACCCODVER
                                                 , contractDetail.PRDGRPCOD
                                                 , contractDetail.PRDSUBCOD
                                                 , contractDetail.PRDTYPE
                                                 , contractDetail.PRDBRNCOD
                                                 , contractDetail.PRDLISPRC
                                                 , contractDetail.PRDCSTPRC
                                                 , contractDetail.PRDSALPRC
                                                 , contractDetail.PRDNEWUSE
                                                 , contractDetail.PRDDETAIL
                                                 , contractDetail.PRDREMARK
                                                 , contractDetail.PRDMDLCOD
                                                 , contractDetail.PRDSRLNUM
                                                 , contractDetail.PRDINCACSOR
                                                 , contractDetail.PRDITMNUM
                                                 , contractDetail.APPRISALAMT
                                                 , contractDetail.LOCATN
                                                 , contractDetail.PRDCOD
                                                 , contractDetail.PRDSTSCOD
                                                 , contractDetail.ACCESSORYAMT
                                                 , contractDetail.CUSTTLENG
                                                 , contractDetail.CUSNAMENG
                                                 , contractDetail.CUSSURENG
                                                 , contractDetail.CUSTYPCOD
                                                 , contractDetail.CUSCRDCOD
                                                 , contractDetail.CUSLEVCOD
                                                 , contractDetail.CUSBOTCOD
                                                 , contractDetail.CUSCRDLNE
                                                 , contractDetail.CUSBUSCNT
                                                 , contractDetail.GENTAXNUM
                                                 , contractDetail.CUS_FINBNKCOD1
                                                 , contractDetail.CUS_FINBNKBRN1
                                                 , contractDetail.CUS_FINBNKNUM1
                                                 , contractDetail.CUS_FINBNKCOD2
                                                 , contractDetail.CUS_FINBNKBRN2
                                                 , contractDetail.CUS_FINBNKNUM2
                                                 , contractDetail.CUS_FINBNKCOD3
                                                 , contractDetail.CUS_FINBNKBRN3
                                                 , contractDetail.CUS_FINBNKNUM3
                                                 , contractDetail.ADRCOD01
                                                 , contractDetail.ADRCOD02
                                                 , contractDetail.ADRCOD03
                                                 , contractDetail.ADRCOD04
                                                 , contractDetail.ADRCOD05
                                                 , contractDetail.ADRCOD06
                                                 , contractDetail.ADRCOD07
                                                 , contractDetail.ADRCOD08
                                                 , contractDetail.ADRCOD09
                                                 , contractDetail.ADRCOD10
                                                 , contractDetail.CUSCITZEN
                                                 , contractDetail.CUSNATION
                                                 , contractDetail.VATREGISTER
                                                 , contractDetail.CUS_ADRTELNUM
                                                 , contractDetail.CUSEMAIL
                                                 , contractDetail.COOPERATE_TYPE
                                                 , contractDetail.OLD_LOAN_CPN
                                                 , contractDetail.OLD_CREDIT_LINE
                                                 , contractDetail.LAST_OUTSTD_AMT
                                                 , contractDetail.CHECK_HOME_TEL
                                                 , contractDetail.CHECK_HOME_NAME_RSLT
                                                 , contractDetail.CHECK_HOME_NAME_REMARK
                                                 , contractDetail.CHECK_HOME_ADR_RSLT
                                                 , contractDetail.CHECK_HOME_ADR_REMARK
                                                 , contractDetail.CHECK_OFFC_TEL
                                                 , contractDetail.CHECK_OFFC_NAME_RSLT
                                                 , contractDetail.CHECK_OFFC_NAME_REMARK
                                                 , contractDetail.CHECK_OFFC_ADR_RSLT
                                                 , contractDetail.CHECK_OFFC_ADR_REMARK
                                                 , contractDetail.CHECK_SSO_RSLT
                                                 , contractDetail.CHECK_DBD_RSLT
                                                 , contractDetail.VENDORBRN
                                                 , contractDetail.CONAPPLY_VIABRN
                                                 , contractDetail.PSNREGSIN
                                                 , contractDetail.PSNREGEXP
                                                 , contractDetail.PSNSALDTE
                                                 , contractDetail.PSNRELTME
                                                 , contractDetail.CONPRDPRCINC
                                                 , contractDetail.CONPRDPRCNET
                                                 , contractDetail.CONPRDPRCTAX
                                                 , contractDetail.INCOMERTE
                                                 , contractDetail.CRUSGRTE
                                                 , contractDetail.R_FLAG
                                                 , contractDetail.CUSPHNNUM_TELSEQNUM
                                                 , contractDetail.CRDPNDSTS
                                                 , contractDetail.ACCCRDLIN
                                                 , contractDetail.ACCCRDTIM
                                                 , contractDetail.ACCLNDTYP
                                                 , contractDetail.CPNREGNUM
                                                 , contractDetail.CPNBUSTYP
                                                 , contractDetail.CPNREGDTE
                                                 , contractDetail.CPNYERINC
                                                 , contractDetail.CPNYERPRF
                                                 , contractDetail.REFDOCDTE
                                                 , contractDetail.CPNCNTPSN
                                                 , contractDetail.CPNCNTPOS
                                                 , contractDetail.FACADVRTE
                                                 , contractDetail.CONDUETYP
                                                 , contractDetail.CONCRDTRM).FirstOrDefault();

                this.InsertOrUpdateFee(contractDetail.CPNCOD, contractDetail.CPNBRNCOD, contractDetail.ACCBUSTYP, insertResult.CONNUM, contractDetail.FeeList, username);

                newContractDetail = this.GetContractDetail(insertResult.CPNCOD, insertResult.CPNBRNCOD, insertResult.ACCBUSTPY, insertResult.GENAPPNUM);

                trans.Complete();
            }


            return newContractDetail;
        }


        public List<ContractListFactoringWithPagingResult> GetContractListFactoringWithPaging(string sponsorName, string CONNUM, string GENAPPNUM, string stepFrom, string stepTo, Nullable<int> pageSize, Nullable<int> pageNo)
        {
            return _db.GetContractListFactoringWithPaging(sponsorName, CONNUM, GENAPPNUM, stepFrom, stepTo, pageSize, pageNo).ToList();
        }

        #region private
        private void InsertOrUpdateFee(String CPNCOD,String CPNBRNCOD, String ACCBUSTYP,String CONNUM,List<FeeConfigResult> feeConfigList, String username)
        {
            FeeResult feeResult = new FeeResult();
            foreach (FeeConfigResult fee in feeConfigList)
            {
                feeResult.GetType().GetProperty("FEETYP" + fee.TRNGRPSEQ).SetValue(feeResult, fee.TRNCOD);
                feeResult.GetType().GetProperty("FEEGRS" + fee.TRNGRPSEQ).SetValue(feeResult, fee.FEEGRS);
                feeResult.GetType().GetProperty("FEENET" + fee.TRNGRPSEQ).SetValue(feeResult, fee.FEENET);
                feeResult.GetType().GetProperty("FEETAX" + fee.TRNGRPSEQ).SetValue(feeResult, fee.FEETAX);
                feeResult.GetType().GetProperty("FEEWAIVER" + fee.TRNGRPSEQ).SetValue(feeResult, fee.FEEWAIVER);
                feeResult.CPNCOD = CPNCOD;
                feeResult.CPNBRNCOD = CPNBRNCOD;
                feeResult.ACCBUSTYP = ACCBUSTYP;
                feeResult.CONNUM = CONNUM;

            }

            _db.InsertOrUpdateFee(
                   feeResult.CPNCOD,
                   feeResult.CPNBRNCOD,
                   feeResult.ACCBUSTYP,
                   feeResult.CONNUM,
                   feeResult.FEETYP1,
                   feeResult.FEETYP1_DSC,
                   feeResult.FEEGRS1,
                   feeResult.FEENET1,
                   feeResult.FEETAX1,
                   feeResult.FEEWAIVER1,
                   feeResult.FEETYP2,
                   feeResult.FEETYP2_DSC,
                   feeResult.FEEGRS2,
                   feeResult.FEENET2,
                   feeResult.FEETAX2,
                   feeResult.FEEWAIVER2,
                   feeResult.FEETYP3,
                   feeResult.FEETYP3_DSC,
                   feeResult.FEEGRS3,
                   feeResult.FEENET3,
                   feeResult.FEETAX3,
                   feeResult.FEEWAIVER3,
                   feeResult.FEETYP4,
                   feeResult.FEEGRS4,
                   feeResult.FEENET4,
                   feeResult.FEETAX4,
                   feeResult.FEEWAIVER4,
                   feeResult.FEETYP5,
                   feeResult.FEEGRS5,
                   feeResult.FEENET5,
                   feeResult.FEETAX5,
                   feeResult.FEEWAIVER5,
                   feeResult.FEETYP6,
                   feeResult.FEEGRS6,
                   feeResult.FEENET6,
                   feeResult.FEETAX6,
                   feeResult.FEEWAIVER6,
                   feeResult.FEETYP7,
                   feeResult.FEEGRS7,
                   feeResult.FEENET7,
                   feeResult.FEETAX7,
                   feeResult.FEEWAIVER7,
                   feeResult.FEETYP8,
                   feeResult.FEEGRS8,
                   feeResult.FEENET8,
                   feeResult.FEETAX8,
                   feeResult.FEEWAIVER8,
                   feeResult.FEETYP9,
                   feeResult.FEEGRS9,
                   feeResult.FEENET9,
                   feeResult.FEETAX9,
                   feeResult.FEEWAIVER9,
                   feeResult.FEETYP10,
                   feeResult.FEEGRS10,
                   feeResult.FEENET10,
                   feeResult.FEETAX10,
                   feeResult.FEEWAIVER10,
                   feeResult.FEETYP11,
                   feeResult.FEEGRS11,
                   feeResult.FEENET11,
                   feeResult.FEETAX11,
                   feeResult.FEEWAIVER11,
                   feeResult.FEETYP12,
                   feeResult.FEEGRS12,
                   feeResult.FEENET12,
                   feeResult.FEETAX12,
                   feeResult.FEEWAIVER12,
                   feeResult.FEETYP13,
                   feeResult.FEEGRS13,
                   feeResult.FEENET13,
                   feeResult.FEETAX13,
                   feeResult.FEEWAIVER13,
                   feeResult.FEETYP14,
                   feeResult.FEEGRS14,
                   feeResult.FEENET14,
                   feeResult.FEETAX14,
                   feeResult.FEEWAIVER14,
                   feeResult.FEETYP15,
                   feeResult.FEEGRS15,
                   feeResult.FEENET15,
                   feeResult.FEETAX15,
                   feeResult.FEEWAIVER15,
                   username);

        }
        #endregion
    }
}
