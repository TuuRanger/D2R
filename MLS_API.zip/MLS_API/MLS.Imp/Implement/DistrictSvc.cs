﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Imp.Interface;
using MLS.Models;
namespace MLS.Imp.Implement
{
    public class DistrictSvc : IDistrictSvc
    { 
        public List<DistrictByNameResult> GetDistrictyName(string districtName)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetDistrictByName(districtName).ToList();
            }
        }
    }
}
