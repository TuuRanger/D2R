﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Imp.Interface;
using MLS.Models;
namespace MLS.Imp.Implement
{
   public class AutoCompleteSvc : IAutoCompleteSvc
    {
        public List<TabkeyOneAutoCompleteResult> GetAutoCompleteTabkeyOne(String input)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.AutoCompleteGetTabkeyOne(input).ToList();
            }
        }
    }
}
