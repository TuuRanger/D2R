﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Models;
using FINANCECALDLL;
using MLS.Imp.Interface;
using MLS.Helper;

namespace MLS.Imp.Implement
{
    public class FinanceCalSvc : IFinanceCalSvc
    {
        private FINANCECAL libFinanceCalc = null;

        public FinanceCalSvc()
        {
            libFinanceCalc = new FINANCECAL();
        }

        public FinanceAmountCalcResult FinanceAmountCalc(
                                         double CONINSAMTx,
                                         int CONLNDTRMx,
                                         double CONINTRTEx,
                                         string CONINTTYPx,
                                         string CONINSPERx,
                                         string CONINTCALx,
                                         string CONINTPERx,
                                         string CONIRATEx,
                                         double CONFRATEx,
                                         string CONIRATEBNKREFx,
                                         double CONBLNAMTx,
                                         double SUBSDYAMTx,
                                         double ROUND_UPx,
                                         double ROUND_FACTORx,
                                         string INS_EQUAx,
                                         double LND_RoundUP,
                                         double LND_RoundFactor)
        {
            FinanceAmountCalcResult result = new FinanceAmountCalcResult();
            libFinanceCalc.FinanceAmountCalc(CONINSAMTx,
                                                CONLNDTRMx,
                                                CONINTRTEx,
                                                CONINTTYPx,
                                                CONINSPERx,
                                                CONINTCALx,
                                                CONINTPERx,
                                                CONIRATEx,
                                                CONFRATEx,
                                                CONIRATEBNKREFx,
                                                CONBLNAMTx,
                                                SUBSDYAMTx,
                                                ROUND_UPx,
                                                ROUND_FACTORx,
                                                INS_EQUAx,
                                                LND_RoundUP,
                                                LND_RoundFactor,
                                                out result.CONFINAMT,
                                                out result.CONLNDAMT,
                                                out result.CONINSAMT,
                                                out result.CONEFFRTE);
            return result;
        }

        public InstallmentCalcResult InstallmentCalc(double CONFINAMTx,
            int CONLNDTRMx,
            double CONINTRTEx,
            string CONINTTYPx,
            string CONINSPERx,
            string CONINTCALx,
            string CONINTPERx,
            string CONIRATEx,
            double CONFRATEx,
            string CONIRATEBNKREFx,
            double CONBLNAMTx,
            double SUBSDYAMTx,
            double ROUND_UPx,
            double ROUND_FACTORx,
            string INS_EQUAx,
            double LND_RoundUP,
            double LND_RoundFactor)
        {
            InstallmentCalcResult result = new InstallmentCalcResult();
            libFinanceCalc.InstallmentCalc(
                                        CONFINAMTx,
                                        CONLNDTRMx,
                                        CONINTRTEx,
                                        CONINTTYPx,
                                        CONINSPERx,
                                        CONINTCALx,
                                        CONINTPERx,
                                        CONIRATEx,
                                        CONFRATEx,
                                        CONIRATEBNKREFx,
                                        CONBLNAMTx,
                                        SUBSDYAMTx,
                                        ROUND_UPx,
                                        ROUND_FACTORx,
                                        INS_EQUAx,
                                        LND_RoundUP,
                                        LND_RoundFactor,
                                        out result.CONLNDAMT,
                                        out result.CONINSAMT,
                                        out result.CONEFFRTE);
            return result;
        }


        public TermCalcResult TermCalc(double CONFINAMTx,
                                 double CONINSAMTx,
                                 double CONINTRTEx,
                                 string CONINTTYPx,
                                 string CONINSPERx,
                                 string CONINTCALx,
                                 string CONINTPERx,
                                 string CONIRATEx,
                                 double CONFRATEx,
                                 string CONIRATEBNKREFx,
                                 double CONBLNAMTx,
                                 double SUBSDYAMTx,
                                 double TRMSTEPUPx,
                                 double ROUND_UPx,
                                 double ROUND_FACTORx,
                                 string INS_EQUAx,
                                 double LND_RoundUP,
                                 double LND_RoundFactor)
        {
            TermCalcResult result = new TermCalcResult();
            libFinanceCalc.TermCalc(
                                     CONFINAMTx,
                                     CONINSAMTx,
                                     CONINTRTEx,
                                     CONINTTYPx,
                                     CONINSPERx,
                                     CONINTCALx,
                                     CONINTPERx,
                                     CONIRATEx,
                                     CONFRATEx,
                                     CONIRATEBNKREFx,
                                     CONBLNAMTx,
                                     SUBSDYAMTx,
                                     TRMSTEPUPx,
                                     ROUND_UPx,
                                     ROUND_FACTORx,
                                     INS_EQUAx,
                                     LND_RoundUP,
                                     LND_RoundFactor,
                                     out result.CONFINAMT,
                                     out result.CONLNDAMT,
                                     out result.CONLNDTRM,
                                     out result.CONINSAMT,
                                     out result.CONEFFRTE);
            return result;
        }

        public CreditLimitResult GetCreditLimit(ContractDetailResult contractDetail)
        {
            using (MLSEntities db = new MLSEntities())
            {
                CreditLimitResult creditLimitResult = new CreditLimitResult();
                //ContractDetailResult contractDetail = db.GetContractDetail(CPNCOD, CPNBRNCOD, ACCBUSTYP, GENAPPNUM).FirstOrDefault();
                //TelVerifyResult telVerifyResult = GetTelVerifyResult(contractDetail);
                //PaymentAbilityResult paymentAbilityResult = GetPaymentAbility(contractDetail.ADR1_OWNERCOD, telVerifyResult);
                MLMCampaignResult campaignResult = db.GetMLMCampaignByProjectCode(contractDetail.CONAPPLY_PROJEC).FirstOrDefault();
                //Decimal salaryCalculator = GetSalaryCalculator(contractDetail.PSNMTHINC.GetValueOrDefault(0), contractDetail.PSNSALRCVTYP, contractDetail.COOPERATE_TYPE);

                /////*Calulate Creditlimit*/
                //if (paymentAbilityResult != null)
                //{

                //    creditLimitResult.MaxInstallment = salaryCalculator * paymentAbilityResult.Ability.GetValueOrDefault(0);
                //    creditLimitResult.TermLimit = paymentAbilityResult.Term.GetValueOrDefault(0);
                //    creditLimitResult.CreditLimit = creditLimitResult.MaxInstallment * creditLimitResult.TermLimit;

                //    Decimal creditLimit1 = 0;
                //    Decimal creditLimit2 = 0;
                //    String BankReference = "";
                //    String ReferenceInterest = "";
                //    double BalloonAmount = 0;
                //    double InterestExtraRate = 0;
                //    FinanceAmountCalcResult financeCalcResult = this.FinanceAmountCalc(Convert.ToDouble(creditLimitResult.MaxInstallment),
                //                                        creditLimitResult.TermLimit,
                //                                        contractDetail.CONINTRTE.GetValueOrDefault(0),
                //                                        contractDetail.CONINTTYP,
                //                                        contractDetail.CONINSPER,
                //                                        contractDetail.CONINTCAL,
                //                                        contractDetail.CONINTPER,
                //                                        ReferenceInterest,
                //                                        InterestExtraRate,
                //                                        BankReference,
                //                                        BalloonAmount,
                //                                        Convert.ToDouble(contractDetail.SUBSDYAMT),
                //                                        Convert.ToDouble(campaignResult.RoundTo),
                //                                        Convert.ToDouble(campaignResult.RoundFactor),
                //                                        campaignResult.IsInstallmentEquals,
                //                                        Convert.ToDouble(campaignResult.LoanAmountRoundTo),
                //                                        Convert.ToDouble(campaignResult.LoanAmountRoundFactor));



                //    if (contractDetail.CRDREQAMT.GetValueOrDefault(0) == 0)
                //    {
                //        creditLimit1 = salaryCalculator * campaignResult.SalaryMultiplier1.GetValueOrDefault(0);
                //    }
                //    else
                //    {
                //        creditLimit1 = salaryCalculator * campaignResult.SalaryMultiplier2.GetValueOrDefault(0);
                //    }

                //    creditLimit2 = Convert.ToDecimal(financeCalcResult.CONFINAMT);

                //    if (creditLimit1 < creditLimit2)
                //    {
                //        creditLimitResult.CreditLimit = creditLimit1;
                //    }
                //    else
                //    {
                //        creditLimitResult.CreditLimit = creditLimit2;
                //    }

                //}
                //else
                //{
                //    creditLimitResult.IsPaymentAbilityNotFound = true;
                //}

                if (campaignResult.MaxValueBy == Helper.Constants.MAXVALUEBY.PROJECT)
                {
                    if (campaignResult.isCheckPaymentAbility == Helper.Constants.YesNoFlag.YES)
                    {
                        creditLimitResult.CreditLimit = contractDetail.PSNMTHINC.GetValueOrDefault(0) * 5;
                        creditLimitResult.TermLimit = 36;
                        creditLimitResult.MaxInstallment = creditLimitResult.CreditLimit / creditLimitResult.TermLimit;
                    }
                    else
                    {
                        creditLimitResult.CreditLimit = campaignResult.MaxCredit.GetValueOrDefault(0);
                        creditLimitResult.TermLimit = campaignResult.MaxTerm.GetValueOrDefault(0).ToInt();
                        creditLimitResult.MaxInstallment = campaignResult.MaxInstallment.GetValueOrDefault(0);
                    }
                }
                else
                {
                    creditLimitResult.CreditLimit = contractDetail.PRDSALPRC.GetValueOrDefault(0);
                    int maxTermByProduct =  db.GetSetup("CONLNDTRM" + contractDetail.CONAPPLY_PROJEC, contractDetail.PRDMDLCOD,"N").Max(x =>  Convert.ToInt32( x.TABSETVAL1)); 
                    creditLimitResult.TermLimit = maxTermByProduct;
                    creditLimitResult.MaxInstallment = creditLimitResult.CreditLimit / maxTermByProduct;
                }

                return creditLimitResult;
            }

        }
         
        public PaymentAbilityResult GetPaymentAbility(String ADR1_OWNERCOD, TelVerifyResult telVerifyResult)
        {
            using (MLSEntities db = new MLSEntities())
            {

                return db.GetPaymentAbility(ADR1_OWNERCOD, telVerifyResult.HasTH,
                    telVerifyResult.HasTM,
                    telVerifyResult.HasTO,
                    telVerifyResult.HasTF,
                    telVerifyResult.HasTR).FirstOrDefault();
            }
        }

        public List<InstallmentTableResult> GetInstallmentTable(string ACCBUSTYP,
                                                         Nullable<int> CONDUEDAY,
                                                         Nullable<decimal> CONFINAMT,
                                                         Nullable<int> CONLNDTRM,
                                                         Nullable<decimal> CONLNDAMT,
                                                         Nullable<decimal> CONINSAMT,
                                                         Nullable<decimal> CONEFFRTE,
                                                         Nullable<decimal> CONINTRTE,
                                                         Nullable<decimal> INCOMERTE,
                                                         Nullable<decimal> CRUSGRTE,
                                                         Nullable<System.DateTime> CONEFFDTE,
                                                         Nullable<System.DateTime> CONSTRINS,
                                                         Nullable<System.DateTime> CONSECINS,
                                                         string CONINTPER,
                                                         Nullable<decimal> SUBSDYAMT,
                                                         string CONINTCAL)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetInstallmentTable(ACCBUSTYP,
                                              CONDUEDAY,
                                              CONFINAMT,
                                              CONLNDTRM,
                                              CONLNDAMT,
                                              CONINSAMT,
                                              CONEFFRTE,
                                              CONINTRTE,
                                              INCOMERTE,
                                              CRUSGRTE,
                                              CONEFFDTE,
                                              CONSTRINS,
                                              CONSECINS,
                                              CONINTPER,
                                              SUBSDYAMT,
                                              CONINTCAL).ToList();
            }
        }

        #region private function
        private TelVerifyResult GetTelVerifyResult(ContractDetailResult contractDetail)
        { 
            String HasTH = null;
            String HasTM = null;
            String HasTO = null;
            String HasTF = null;
            String HasTR = null;

            using (MLSEntities db = new MLSEntities())
            {
                List<TelListResult> telList = db.GetTelList(contractDetail.CPNCOD,
                                                                    contractDetail.CPNBRNCOD,
                                                                    contractDetail.ACCBUSTYP,
                                                                    contractDetail.GENAPPNUM).ToList();

                telList = telList.Where(x => x.TELPHNTYP != Constants.TELPHNTYP.NONE).ToList();

                if (Convert.ToInt32(contractDetail.CRDCURSTP) >= 5)
                {
                    List<SetupResult> listSetupResult = null;
                    listSetupResult = db.GetSetup("TELLEVRSLO", "", "N").ToList();
                    listSetupResult = listSetupResult.Union(db.GetSetup("TELLEVRSLH", "", "N").ToList()).ToList();
                    listSetupResult = listSetupResult.Union(db.GetSetup("TELLEVRSLM", "", "N").ToList()).ToList();
                    listSetupResult = listSetupResult.Union(db.GetSetup("TELLEVRSLR", "", "N").ToList()).ToList();
                    listSetupResult = listSetupResult.Union(db.GetSetup("TELLEVRSLF", "", "N").ToList()).ToList();

                    foreach (TelListResult tel in telList)
                    {
                        SetupResult telSetup = listSetupResult.Where(x => x.TABKEYONE[x.TABKEYONE.Length - 1].ToString() == tel.TELPHNTYP && tel.RMKCALRSL == x.TABKEYTWO).FirstOrDefault();
                        if (telSetup != null)
                            tel.PaymentAbilityResult = telSetup.TABSETSTS1;
                    }




                    /*Find tel result*/
                    TelListResult TelHome = telList.Where(x => x.TELPHNTYP == Constants.TELPHNTYP.HOME && x.PaymentAbilityResult == Constants.YesNoFlag.YES).FirstOrDefault();
                    TelListResult TelOffice = telList.Where(x => x.TELPHNTYP == Constants.TELPHNTYP.OFFICE && x.PaymentAbilityResult == Constants.YesNoFlag.YES).FirstOrDefault();
                    TelListResult TelMobile = telList.Where(x => x.TELPHNTYP == Constants.TELPHNTYP.MOBILE && x.PaymentAbilityResult == Constants.YesNoFlag.YES).FirstOrDefault();
                    TelListResult TelRelative = telList.Where(x => x.TELPHNTYP == Constants.TELPHNTYP.RELATIVE && x.PaymentAbilityResult == Constants.YesNoFlag.YES).FirstOrDefault();
                    TelListResult TelFamily = telList.Where(x => x.TELPHNTYP == Constants.TELPHNTYP.FAMILY && x.PaymentAbilityResult == Constants.YesNoFlag.YES).FirstOrDefault();

                    HasTM = Constants.YesNoFlag.YES;
                    HasTH = Constants.YesNoFlag.YES;
                    HasTO = Constants.YesNoFlag.YES;

                    HasTF = Constants.YesNoFlag.NO;
                    HasTR = Constants.YesNoFlag.NO;



                    if (TelHome != null) HasTH = Constants.YesNoFlag.NO;
                    if (TelOffice != null) HasTO = Constants.YesNoFlag.NO;
                    if (TelMobile != null) HasTM = Constants.YesNoFlag.NO;

                    /*priority if has tel-family use tel-family to find payment ability */
                    if (TelFamily != null) HasTF = Constants.YesNoFlag.YES;
                    else if (TelRelative != null) HasTR = Constants.YesNoFlag.YES;
                }
                else
                {
                    TelListResult TelHome = telList.Where(x => x.TELPHNTYP == Constants.TELPHNTYP.HOME && x.PaymentAbilityResult == Constants.YesNoFlag.YES).FirstOrDefault();
                    TelListResult TelOffice = telList.Where(x => x.TELPHNTYP == Constants.TELPHNTYP.OFFICE && x.PaymentAbilityResult == Constants.YesNoFlag.YES).FirstOrDefault();
                    TelListResult TelMobile = telList.Where(x => x.TELPHNTYP == Constants.TELPHNTYP.MOBILE && x.PaymentAbilityResult == Constants.YesNoFlag.YES).FirstOrDefault();
                    TelListResult TelRelative = telList.Where(x => x.TELPHNTYP == Constants.TELPHNTYP.RELATIVE && x.PaymentAbilityResult == Constants.YesNoFlag.YES).FirstOrDefault();
                    TelListResult TelFamily = telList.Where(x => x.TELPHNTYP == Constants.TELPHNTYP.FAMILY && x.PaymentAbilityResult == Constants.YesNoFlag.YES).FirstOrDefault();


                    //telList.Where(x => x.TELPHNTYP)
                    HasTH = (TelHome != null).BoolToYesNoFlag();
                    HasTM = (TelMobile != null).BoolToYesNoFlag();
                    HasTO = (TelOffice != null).BoolToYesNoFlag();


                    HasTF = Constants.YesNoFlag.NO;
                    HasTR = Constants.YesNoFlag.NO;

                    if (TelFamily != null) HasTF = Constants.YesNoFlag.YES;
                    else if (TelRelative != null) HasTR = Constants.YesNoFlag.YES;

                }

                return new TelVerifyResult()
                {
                    HasTF = HasTF,
                    HasTH = HasTH,
                    HasTM = HasTM,
                    HasTO = HasTO,
                    HasTR =
                    HasTR
                };

            }


        }

        private Decimal GetSalaryCalculator(Decimal PSNMTHINC, String PSNSALRCVTYP, String COOPERATE_TYPE)
        {
            Decimal salary = PSNMTHINC;
            if (PSNSALRCVTYP == Constants.SalaryReceiveType.Cash) //'รับเงินสด
            {
                if (COOPERATE_TYPE == Constants.CooperateType.GovernmentOfficials ||
                        COOPERATE_TYPE == Constants.CooperateType.StateEnterpriseOfficer)
                {
                    if (Constants.CashConstantForCooperateType.GovernmentOfficials < salary)
                    {
                        salary = Constants.CashConstantForCooperateType.GovernmentOfficials;
                    }
                }
                else if (COOPERATE_TYPE == Constants.CooperateType.BusinessEmployee)
                {
                    if (Constants.CashConstantForCooperateType.BusinessEmployee < salary)
                    {
                        salary = Constants.CashConstantForCooperateType.BusinessEmployee;
                    }
                }
            }
            return salary;

        }
        #endregion  
    }

}






