﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Imp.Interface;
using MLS.Models;
using System.Transactions;

namespace MLS.Imp.Implement
{
    public class RemarkSvc : IRemarkSvc
    {
        public void InsertOrUpdateRemark(List<RemarkModel> listRemark,
            string CPNCOD,
            string CPNBRNCOD,
            string ACCBUSTYP,
            string CONNUM,
            string USRCOD)
        {
            using (MLSEntities db = new MLSEntities())
            {
                foreach (RemarkModel remark in listRemark)
                {
                    db.InsertOrUpdateRemark(
                         remark.REMARK_ID, 
                         CPNCOD, 
                         CPNBRNCOD,
                         ACCBUSTYP, 
                         CONNUM, 
                         remark.RMKLEVRSL,
                         remark.GENREMARK,
                         remark.GENPROGRM, 
                         USRCOD);
                }
               
            }
        }
    }
}
