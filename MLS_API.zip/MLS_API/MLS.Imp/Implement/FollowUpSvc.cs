﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using MLS.Imp.Interface;
using MLS.Models;
using MLS.Helper;

namespace MLS.Imp.Implement
{
    public class FollowUpSvc : IFollowUpSvc
    {
        public List<FollowUpHeaderResult> GetFollowUpHeader(string CPNCOD,
                                                            string CPNBRNCOD_FROM,
                                                            string CPNBRNCOD_TO,
                                                            string FOLSTATE,
                                                            Nullable<int> OVDDAY_FROM,
                                                            Nullable<int> OVDDAY_TO,
                                                            string ADRSPCARA_FROM,
                                                            string ADRSPCARA_TO)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetFollowUpHeader(CPNCOD,
                                            CPNBRNCOD_FROM,
                                            CPNBRNCOD_TO,
                                            FOLSTATE,
                                            OVDDAY_FROM,
                                            OVDDAY_TO,
                                            ADRSPCARA_FROM,
                                            ADRSPCARA_TO).ToList();
            }
        }

        public List<vwFollowUpHeader> GetWorkLoadByUser(String FOLWERCOD)
        {
            using (MLSEntities db = new MLSEntities())
            {
                //return db.FollowUpGetWorkLoadByUser(FOLWERCOD).ToList();
                return db.vwFollowUpHeaders.Where(x => x.FOLWERCOD == FOLWERCOD).ToList();
            }
        }


        public void AssignJob(string JOB_STEP,
                              string JOB_FUNCTION, 
                              string FOLWERCOD, 
                              List<FollowUpHeaderResult> jobList,
                              string USERNAM)
        {
            using (TransactionScope trans = new TransactionScope())
            {
                DateTime ASSIGNDTE = DateTime.Now;
                using (MLSEntities db = new MLSEntities())
                {
                    foreach (FollowUpHeaderResult job in jobList)
                    {
                          db.InsertOrUpdateMLTFLH(
                              job.CPNCOD,
                              job.CPNBRNCOD,
                              job.ACCBUSTYP,
                              job.RECSTSCOD,
                              JOB_STEP,
                              JOB_FUNCTION,
                              job.CONNUM,
                              job.ACCCOD,
                              ASSIGNDTE,
                              FOLWERCOD,
                              job.JOBASGNUM,
                              USERNAM).ToList();
                    }
                  
                }
                trans.Complete();
            }
            
        }

        public void DeassignJob(string JOB_STEP,
                            string JOB_FUNCTION,
                            string FOLWERCOD,
                            List<FollowUpHeaderResult> jobList,
                            string USERNAM)
        {
            using (TransactionScope trans = new TransactionScope())
            {
                DateTime ASSIGNDTE = DateTime.Now;
                using (MLSEntities db = new MLSEntities())
                {
                    foreach (FollowUpHeaderResult job in jobList)
                    {
                        db.InsertOrUpdateMLTFLH(
                            job.CPNCOD,
                            job.CPNBRNCOD,
                            job.ACCBUSTYP,
                            job.RECSTSCOD,
                            JOB_STEP,
                            JOB_FUNCTION,
                            job.CONNUM,
                            job.ACCCOD,
                            ASSIGNDTE,
                            FOLWERCOD,
                            job.JOBASGNUM,
                            USERNAM).ToList();
                    }

                }
                trans.Complete();
            }

        }

        public List<vwFollowUpHeader> GetFollowUpByContract(string CONNUM,string CPNCOD,string CPNBRNCOD,String ACCBUSTYP)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.vwFollowUpHeaders.Where(x => x.CONNUM == CONNUM && 
                x.CPNCOD == CPNCOD && 
                x.CPNBRNCOD == CPNBRNCOD && 
                x.ACCBUSTYP == ACCBUSTYP &&
                //(RECSTSCODs.Length == 0 || RECSTSCODs.Contains(x.RECSTSCOD) ) &&
                x.RECACTCOD != "I").ToList();

            }
        }

        public List<vwFollowUpAlarm> GetFollowUpAlarm(String FOLWERCOD)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.vwFollowUpAlarms.Where(x =>  x.FOLWERCOD == FOLWERCOD).ToList();
            }
        }

        public void InsertOrUpdateAlarm( List<vwFollowUpAlarm> listAlarm, string username)
        {
            using (MLSEntities db = new MLSEntities())
            {
                foreach (vwFollowUpAlarm alarm in listAlarm)
                { 
                    db.InsertOrUpdateAlarm(
                         alarm.RECORD_ID,
                         alarm. RECSTSCOD, 
                         alarm. CPNCOD, 
                         alarm. CPNBRNCOD,
                         alarm. GROUPNAM,
                         alarm. CONNUM,
                         alarm.ACCCOD,
                         alarm.ALMDTE,
                         alarm.MESSAGE,
                         alarm.JOBASGNUM,
                         username);
                }
                
            }
        }


        public void InsertOrUpdateFollowUpDetail(List<MLTFLH> jobHeaderList, List<vwFollowUpDetail> jobDetailList,String username)
        { 
                using (MLSEntities db = new MLSEntities())
                {
                    foreach (MLTFLH job in jobHeaderList)
                    {
                        db.UpdateFollowUpHeader(
                          job.RECSTSCOD,
                          job.CNTSEQNUM,
                          job.CNTSUBSEQ,
                          job.SUBSEQNUM,
                          job.PROMISDTE,
                          job.CPNCOD,
                          job.CPNBRNCOD,
                          job.ACCBUSTYP,
                          job.CONNUM,
                          job.JOBASGNUM);
                    }

                    foreach (vwFollowUpDetail job in jobDetailList)
                    {
                         job.RECORDDTE = DateTime.Now;
                         db.InsertOrUpdateFollowUpDetail(
                             job.RECACTCOD,
                             job.RECSTSCOD,
                             job.CPNCOD,
                             job.CPNBRNCOD,
                             job.ACCBUSTYP,
                             job.JOBASGNUM,
                             job.RECORDDTE,
                             job.FOLWUPRSL,
                             job.FOLWUPMRK,
                             job.FOLWERGRP,
                             job.FOLWERCOD,
                             job.PROMISDTE,
                             job.ASGSEQNUM,
                             job.SUBSEQNUM,
                             job.FOLACTCOD,
                             job.FOLWHERE,
                             username);
                }

                } 
        }


        public List<vwFollowUpDetail> GetFollowUpDetail(String JOBASGNUM, String CPNCOD,String CPNBRNCOD,String ACCBUSTYP)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.vwFollowUpDetails.Where(x => x.JOBASGNUM == JOBASGNUM &&
               x.ACCBUSTYP == ACCBUSTYP &&
               x.CPNCOD == CPNCOD &&
               x.CPNBRNCOD == CPNBRNCOD
                ).ToList();
            }
        }


        public List<vwUserSection> GetChildFollower(String GroupID)
        {
            using (MLSEntities db = new MLSEntities())
            {

                SetupResult GroupConfig = db.GetSetup("SECTINMGR", GroupID, "N").FirstOrDefault();
                List<SetupResult> SubGroupsConfig = db.GetSetup(GroupConfig.TABLNKKEY, "", "N").ToList();
                String[] subGroups = SubGroupsConfig.Select(x => x.TABKEYTWO).ToArray();
                List<vwUserSection> result = db.vwUserSections.Where(x => subGroups.Contains(x.GROUPID) &&  x.SECTIONID == "FOLWER").ToList();

                //foreach (vwUserSection item in result)
                //{
                //    item.FollowUpWorkLoad = this.GetWorkLoadByUser(item.USRID);
                //}

                return result;
            }
        }

    }
}
