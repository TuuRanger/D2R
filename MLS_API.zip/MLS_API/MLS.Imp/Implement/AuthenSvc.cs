﻿using MLS.Imp.Interface;
using MLS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Imp.Implement
{
    public class AuthenSvc : IAuthenSvc
    {
        public static String secretKey = "GQDstcKsx0NHjPOuXOYg5MbeJ1XT0uFiwDVvVBrk";
        private long TTL = 7200;

        private IUserSectionSvc _userSectionSvc = null;

        public AuthenSvc()
        {
            _userSectionSvc = new UserSectionSvc();
        }

        public String Login(string Username, string Password)
        {
            using (MLSEntities db = new MLSEntities())
            {
                LoginResult result = db.Login(Username, Password).FirstOrDefault();
                if (result != null)
                {
                    return EncryptToken(result);
                }
                return null;
            }
        }

        public UserDataResult GetUserDataByToken(string token)
        {
            UserToken userToken = this.DecryptToken(token);
            List<vwUserSection> userSections = null;
            vwUserProfile userProfile = null;
            using (MLSEntities db = new MLSEntities())
            { 
                userProfile = db.vwUserProfiles.Where(x => x.USRID == userToken.Username).FirstOrDefault();
                userSections = db.vwUserSections.Where(x => x.USRID == userToken.Username).ToList();
            }
        
           
            UserDataResult result = new UserDataResult()
            {
                Username = userToken.Username,
                LoginDateTime = userToken.LoginDateTime,
                TimeToLive = userToken.TTL,
                Sections = userSections,
                UserProfile = userProfile
            };
            
            return result;
        }

        private String EncryptToken(LoginResult loginResult)
        {
            var payload = new Dictionary<String, Object>()
            {
                { "username", loginResult.USRID }, 
                { "loginTime",  DateTime.Now.ToBinary()},
                { "unique", Guid.NewGuid().ToByteArray()},
                { "TTL" , TTL}
            };

            String token = JWT.JsonWebToken.Encode(payload, secretKey, JWT.JwtHashAlgorithm.HS256);
            return token;
        }

        private UserToken DecryptToken(String token)
        {
            UserToken result = null;

            var payload = JWT.JsonWebToken.DecodeToObject(token, secretKey) as IDictionary<string, object>;
            DateTime when = DateTime.FromBinary((long)payload["loginTime"]);
            String username = (String)payload["username"]; 
            Int64 TTL = Convert.ToInt64(payload["TTL"]);
            result = new UserToken()
            {
                Username = username,
                LoginDateTime = when,
                TokenString = token,
                TTL = TTL,
            };

            return result;
        }


        public UserToken IsTokenValid(string username, string token)
        {
            UserToken result = null;
            Boolean tokenExpired = true;
            Boolean usernameMatch = false;

            result = this.DecryptToken(token);

            //if (result.LoginDateTime >= DateTime.UtcNow.AddHours(-24))
            //{
            //    tokenExpired = false;
            //}

            //if (!tokenExpired)
            //{
            //    usernameMatch = username.CompareTo(result.Username) == 0;
            //}

            usernameMatch = username.CompareTo(result.Username) == 0;

            //if (tokenExpired || !usernameMatch)
            //{
            //    result = null;
            //}

            if ( !usernameMatch)
            {
                result = null;
            }
            return result;
        }

    }
}
