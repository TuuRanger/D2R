﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Imp.Interface;
using MLS.Helper;
using System.Diagnostics;
using System.Reflection;
using MLS.Models;
using System.IO;

namespace MLS.Imp.Implement
{
    public class NCBSvc : INCBSvc
    {
        ILogSvc _logService = null;
        BlackList.NCB _ncbLib = null;
        public NCBSvc()
        {
            _logService = new LogSvc();
            _ncbLib = new BlackList.NCB();
        }


        public NCBResult GetNCBResult(String firstName, String middleName, string lastName, DateTime birthDate, String IDCard, String userID)
        {
            NCBResult result = null;
            String inquiryResult = "";
            String TUEFText = "";

            if (Constants.NCBConfig.isOfflineTestNCB)
            {
                inquiryResult = this.GetFakeResult();
            }
            else
            {
                TUEFText = _ncbLib.Generate_TUEF_Text(
                Constants.NCBConfig.memberCode,
                Constants.NCBConfig.memberName,
                Constants.NCBConfig.password,
                Constants.NCBConfig.enquiryPurpose,
                Constants.NCBConfig.enquiryAmount,
                Constants.NCBConfig.detailsFlag,
                firstName,
                middleName,
                lastName,
                birthDate.ToString("yyyyMMdd"),
                IDCard);

                inquiryResult = this.GetNCBInquiryResult(TUEFText, IDCard, userID);
            }

            String ResultReason = "";
            bool isPassed = _ncbLib.GetTUEFResult(inquiryResult, false, false, ref ResultReason);
            result = new NCBResult()
            {
                IsPassed = isPassed,
                Reason = ResultReason,
                TUEF_Text = TUEFText,
                inquiryResult = inquiryResult,
                PSNREGIDN = IDCard
            };



            _logService.InsertLogXML(IDCard, IDCard, IDCard, Utils.GetCurrentMethod(), result.ToXml().ToString(), userID, "NCB_FINAL_RESULT", null);
            return result;

        }

        public void InsertNCBResult(NCBResult ncbResult,String username)
        {
            using (MLSEntities db = new MLSEntities())
            {
                
                db.InsertOrUpdateReturnResult(
                    ncbResult.PSNREGIDN, 
                    ncbResult.CUSCOD, 
                    ncbResult.GENAPPNUM, 
                    ncbResult.CONAPPLY_PROJEC,
                    ncbResult.inquiryResult, 
                    ncbResult.TUEF_Text, 
                    ncbResult.Reason,
                    ncbResult.IsPassed.BoolToYesNoFlag(), 
                    username);
            }
        }

        #region private method
        private string GetFakeResult()
        {
            String dummyResultPath = Path.Combine(Constants.APP_PATH, "NCB_DUMMY_RESULT", Constants.NCBConfig.DummyResultFile);
            if (File.Exists(dummyResultPath))
            {
                using (StreamReader reader = new StreamReader(dummyResultPath))
                {
                    return reader.ReadToEnd();
                }
            }
            return "";
        }

        private String GetNCBInquiryResult(String TUEFText, String IDCard, String userID)
        {
            String IP = Constants.NCBConfig.IP;
            int Port = Constants.NCBConfig.Port;

            dynamic logDataBeginRequest = new
            {
                TUEFText = TUEFText,
                IPAddress = IP,
                Port = Port
            };

            _logService.InsertLogXML(IDCard, IDCard, IDCard, Utils.GetCurrentMethod(), DynamicHelper.ToXmlString(logDataBeginRequest), userID, "NCB_BEGIN_REQUEST", null);
            TCPHelper tcpHelper = new TCPHelper(IP, Port);
            String inquiryResult = tcpHelper.SendText(TUEFText);

            dynamic logDataFinishRequest = new
            {
                TUEFText = TUEFText,
                IPAddress = IP,
                Port = Port,
                Result = inquiryResult
            };

            _logService.InsertLogXML(IDCard, IDCard, IDCard, Utils.GetCurrentMethod(), DynamicHelper.ToXmlString(logDataFinishRequest), userID, "NCB_FINISH_REQUEST", null);
            return inquiryResult;
        }
        #endregion



    }
}
