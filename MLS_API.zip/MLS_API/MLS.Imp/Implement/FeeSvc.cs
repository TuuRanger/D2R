﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using MLS.Helper;
using MLS.Imp.Interface;
using MLS.Models;
namespace MLS.Imp.Implement
{
    public class FeeSvc : IFeeSvc
    {
        public void InsertOrUpdateFee(List<FeeConfigResult> listFee, String username)
        {
            using (MLSEntities db = new MLSEntities())
            {
                FeeResult feeResult = new FeeResult();
                foreach (FeeConfigResult fee in listFee)
                {
                    feeResult.GetType().GetProperty("FEETYP" + fee.TRNGRPSEQ).SetValue(feeResult, fee.TRNCOD);
                    feeResult.GetType().GetProperty("FEEGRS" + fee.TRNGRPSEQ).SetValue(feeResult, fee.FEEGRS);
                    feeResult.GetType().GetProperty("FEENET" + fee.TRNGRPSEQ).SetValue(feeResult, fee.FEENET);
                    feeResult.GetType().GetProperty("FEETAX" + fee.TRNGRPSEQ).SetValue(feeResult, fee.FEETAX);
                    feeResult.GetType().GetProperty("FEEWAIVER" + fee.TRNGRPSEQ).SetValue(feeResult, fee.FEEWAIVER);
                    feeResult.CPNCOD = fee.CPNCOD;
                    feeResult.CPNBRNCOD = fee.CPNBRNCOD;
                    feeResult.ACCBUSTYP = fee.ACCBUSTYP;
                    feeResult.CONNUM = fee.CONNUM;

                }
                 
                db.InsertOrUpdateFee(
                   feeResult.CPNCOD,
                   feeResult.CPNBRNCOD,
                   feeResult.ACCBUSTYP,
                   feeResult.CONNUM,
                   feeResult.FEETYP1,
                   feeResult.FEETYP1_DSC,
                   feeResult.FEEGRS1,
                   feeResult.FEENET1,
                   feeResult.FEETAX1,
                   feeResult.FEEWAIVER1,
                   feeResult.FEETYP2,
                   feeResult.FEETYP2_DSC,
                   feeResult.FEEGRS2,
                   feeResult.FEENET2,
                   feeResult.FEETAX2,
                   feeResult.FEEWAIVER2,
                   feeResult.FEETYP3,
                   feeResult.FEETYP3_DSC,
                   feeResult.FEEGRS3,
                   feeResult.FEENET3,
                   feeResult.FEETAX3,
                   feeResult.FEEWAIVER3,
                   feeResult.FEETYP4, 
                   feeResult.FEEGRS4,
                   feeResult.FEENET4,
                   feeResult.FEETAX4,
                   feeResult.FEEWAIVER4,
                   feeResult.FEETYP5,
                   feeResult.FEEGRS5,
                   feeResult.FEENET5,
                   feeResult.FEETAX5,
                   feeResult.FEEWAIVER5,
                   feeResult.FEETYP6,
                   feeResult.FEEGRS6,
                   feeResult.FEENET6,
                   feeResult.FEETAX6,
                   feeResult.FEEWAIVER6,
                   feeResult.FEETYP7,
                   feeResult.FEEGRS7,
                   feeResult.FEENET7,
                   feeResult.FEETAX7,
                   feeResult.FEEWAIVER7,
                   feeResult.FEETYP8,
                   feeResult.FEEGRS8,
                   feeResult.FEENET8,
                   feeResult.FEETAX8,
                   feeResult.FEEWAIVER8,
                   feeResult.FEETYP9,
                   feeResult.FEEGRS9,
                   feeResult.FEENET9,
                   feeResult.FEETAX9,
                   feeResult.FEEWAIVER9,
                   feeResult.FEETYP10,
                   feeResult.FEEGRS10,
                   feeResult.FEENET10,
                   feeResult.FEETAX10,
                   feeResult.FEEWAIVER10,
                   feeResult.FEETYP11,
                   feeResult.FEEGRS11,
                   feeResult.FEENET11,
                   feeResult.FEETAX11,
                   feeResult.FEEWAIVER11,
                   feeResult.FEETYP12,
                   feeResult.FEEGRS12,
                   feeResult.FEENET12,
                   feeResult.FEETAX12,
                   feeResult.FEEWAIVER12,
                   feeResult.FEETYP13,
                   feeResult.FEEGRS13,
                   feeResult.FEENET13,
                   feeResult.FEETAX13,
                   feeResult.FEEWAIVER13,
                   feeResult.FEETYP14,
                   feeResult.FEEGRS14,
                   feeResult.FEENET14,
                   feeResult.FEETAX14,
                   feeResult.FEEWAIVER14,
                   feeResult.FEETYP15,
                   feeResult.FEEGRS15,
                   feeResult.FEENET15,
                   feeResult.FEETAX15,
                   feeResult.FEEWAIVER15,
                   username);
            }
        }

        //public FeeResult GetFee(string CPNCOD,
        //   string CPNBRNCOD,
        //   string ACCBUSTYP,
        //   string CONNUM,
        //   Nullable<decimal> CREDIT_APPROVE,
        //   Nullable<decimal> CONDWNAMT,
        //   string CONAPPLY_PROJEC)
        //{
        //    using (MLSEntities db = new MLSEntities())
        //    {
        //        return db.GetFee(CPNCOD, 
        //            CPNBRNCOD, 
        //            ACCBUSTYP, 
        //            CONNUM, 
        //            CREDIT_APPROVE.GetValueOrDefault(0) + CONDWNAMT.GetValueOrDefault(0), 
        //            CONAPPLY_PROJEC).FirstOrDefault();
        //    }
        //}

        public List<FeeConfigResult> GetFeeList(string CPNCOD,
           string CPNBRNCOD,
           string ACCBUSTYP,
           string CONNUM,
           Nullable<decimal> CREDIT_APPROVE,
           Nullable<decimal> CONDWNAMT,
           string CONAPPLY_PROJEC)
        {
            using (MLSEntities db = new MLSEntities())
            {
                List<FeeConfigResult> feeConfig = db.GetFeeConfig(CPNCOD, CPNBRNCOD, ACCBUSTYP).ToList();
                FeeResult feeResult = db.GetFee(CPNCOD,
                    CPNBRNCOD,
                    ACCBUSTYP,
                    CONNUM,
                    CREDIT_APPROVE.GetValueOrDefault(0) + CONDWNAMT.GetValueOrDefault(0),
                    CONAPPLY_PROJEC).FirstOrDefault();

                if (feeResult != null)
                {
                    foreach (FeeConfigResult fee in feeConfig)
                    {
                        //fee.FEETYP = feeResult.GetType().GetProperty("FEETYP" + fee.TRNGRPSEQ).GetValue(feeResult, null).ToStringOrEmpty();
                        fee.FEEGRS = ((decimal?)feeResult.GetType().GetProperty("FEEGRS" + fee.TRNGRPSEQ).GetValue(feeResult, null)).GetValueOrDefault(0);
                        fee.FEENET = ((decimal?)feeResult.GetType().GetProperty("FEENET" + fee.TRNGRPSEQ).GetValue(feeResult, null)).GetValueOrDefault(0);
                        fee.FEETAX = ((decimal?)feeResult.GetType().GetProperty("FEETAX" + fee.TRNGRPSEQ).GetValue(feeResult, null)).GetValueOrDefault(0);
                        fee.FEEWAIVER = feeResult.GetType().GetProperty("FEEWAIVER" + fee.TRNGRPSEQ).GetValue(feeResult, null).ToStringOrEmpty();
                        fee.CPNCOD = feeResult.CPNCOD;
                        fee.CPNBRNCOD = feeResult.CPNBRNCOD;
                        fee.ACCBUSTYP = feeResult.ACCBUSTYP;
                        fee.CONNUM = feeResult.CONNUM;
                    }
                }

                return feeConfig;
            }
        }

    }
}
