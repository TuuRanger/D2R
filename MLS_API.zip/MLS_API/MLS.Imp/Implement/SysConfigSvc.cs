﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Imp.Interface;
using MLS.Models;

namespace MLS.Imp.Implement
{
    public class SysConfigSvc : ISysConfig
    {
        public List<CDMTABListResult> GetCDMTABList(string tabKeyOne,String tabKeyTwo)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetCDMTABList(tabKeyOne, tabKeyTwo).ToList();
            }
        }
    }
}
