﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Imp.Interface;
using MLS.Models;
using System.Transactions;
using MLS.Helper;

namespace MLS.Imp.Implement
{
    public class ReferencePersonSvc : IReferencePersonSvc
    {
        public List<RefListResult> GetRefList(String CONNUM)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetRefList(CONNUM).ToList();
            }
        }

        public void InsertOrUpdateReferencePerson(List<RefListResult> refPersonList,
            String CPNCOD,
            String CPNBRNCOD,
            String ACCBUSTYP,
            String CONNUM, 
            String username)
        {
            //using (var trans = new TransactionScope())
            //{
            using (MLSEntities db = new MLSEntities())
            {
                //db.DeleteReferencePerson(CPNCOD, CPNBRNCOD, ACCBUSTYP, CONNUM);

                foreach (RefListResult refperson in refPersonList)
                {
                    if ((refperson.RECACTCOD == "I" && refperson.CUSCOD.IsEmpty()) == false) // if new refperson has deleted not call database
                    {
                        db.InsertOrUpdateReferencePerson(CPNCOD,
                                                         CPNBRNCOD,
                                                         ACCBUSTYP,
                                                         CONNUM,
                                                         refperson.COCCOLNUM,
                                                         refperson.CUSCOD,
                                                         refperson.CUSTTLTHA,
                                                         refperson.CUSNAMTHA,
                                                         refperson.CUSSURTHA,
                                                         refperson.CUSNICNAM,
                                                         refperson.COLCUSREL,
                                                         refperson.COLRELYER,
                                                         refperson.CUSPHNNUM,
                                                         username,
                                                         refperson.RECACTCOD,
                                                        refperson.COCRELTYP);
                    }

                }
                //trans.Complete();
            }

            //}
        }
    }
}
