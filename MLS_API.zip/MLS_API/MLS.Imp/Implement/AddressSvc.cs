﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using MLS.Imp.Interface;
using MLS.Models;


namespace MLS.Imp.Implement
{
    public class AddressSvc : IAddressSvc
    {


        public void InsertOrUpdateAddress(List<CustomerAddressResult> listAddress,string CUSCOD,String username)
        {
            using (var trans = new TransactionScope())
            {
                using (MLSEntities db = new MLSEntities())
                {
                    foreach(CustomerAddressResult address in listAddress)
                    {

                        if ((address.RECACTCOD == "I" && address.ADRCOD == null) == false) /*Not call database if new address (add new in UI) has delete*/
                        { 
                            InsertOrUpdateAddressResult insertResult = db.InsertOrUpdateAddress(
                                 CUSCOD,
                                 address.ADRTYPCOD,
                                 address.ADRREFCOD,
                                 address.ADRCOD,
                                 address.ADRDTLLN1,
                                 address.ADRZIPCOD,
                                 address.ADRCTYCOD,
                                 address.ADRLIVSIN,
                                 address.ADRFAXNUM,
                                 address.ADREMAIL,
                                 address.ADROWNERCOD,
                                 address.ADRDISTRICT,
                                 address.ADRAMPHUR,
                                 address.ADRPROVINCE,
                                 address.ADRTELNUM,
                                 address.ADRMEMBER,
                                 address.TELFRMNUM,
                                 address.TELENDNUM,
                                 address.TELEXTNUM,
                                 username,
                                 address.RECACTCOD).FirstOrDefault();

                            db.InsertOrUpdateTel(address.TELSEQNUM,
                                CUSCOD,
                                insertResult.ADRCOD,
                                null,
                                address.ADRTELNUM,
                                address.TELFRMNUM,
                                address.TELENDNUM,
                                address.TELEXTNUM,
                                username,
                                address.RECACTCOD);
                        }
                    }
                   
                }
                trans.Complete();
            }
            
        }

        public List<CustomerAddressResult> GetCustomerAddress(string  CUSCOD)
        {
            using (MLSEntities db = new MLSEntities())
            {
               return db.GetCustomerAddress(CUSCOD).ToList();
            }
        }

       
    }
}
