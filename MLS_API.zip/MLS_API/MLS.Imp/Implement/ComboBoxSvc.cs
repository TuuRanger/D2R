﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Imp.Interface;
using MLS.Models;
using MLS.Helper;

namespace MLS.Imp.Implement
{
    public class ComboBoxSvc : IComboBoxSvc
    {
        public List<DropDownDealerResult> GetDropDownDealer(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string PROJECTCODE)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetDropDownDealer(CPNCOD, CPNBRNCOD, ACCBUSTYP, PROJECTCODE).ToList();
            }
        }

        public List<DropDownProductBrandResult> GetDropDownProductBrand(string PRDGRPCOD, string PRDSUBCOD, string CONAPPLY_PROJEC, string BrandInput)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetDropDownProductBrand( PRDGRPCOD,  PRDSUBCOD,  CONAPPLY_PROJEC,  BrandInput).ToList();
            }
        }

        public List<DropDownProductModelResult> GetDropDownProductModel(string PRDGRPCOD, string PRDSUBCOD, string Brnad, string CONAPPLY_PROJEC, string ModelInput)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetDropDownProductModel(PRDGRPCOD, PRDSUBCOD,  Brnad,  CONAPPLY_PROJEC,  ModelInput).ToList();
            }
        }

        public List<AccountResult> SearchAccount(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string ACCDEAWTH, string SEARCH_STR)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.SearchAccount(CPNCOD, CPNBRNCOD, ACCBUSTYP, ACCDEAWTH, SEARCH_STR).ToList();
            }
        }

        public List<DroDownCompanyResult> GetDropDownCompany()
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetDroDownCompany().ToList();
            }
        }

        public List<vwUserSection> GetUserInSectionGroup(String SectionID,String GroupID)
        {
            //String xmlSetionID = SectionIDs.ToXml();
            using (MLSEntities db = new MLSEntities())
            {
               List<vwUserSection> result = db.vwUserSections.Where(x => x.SECTIONID == x.SECTIONID && x.GROUPID == GroupID).ToList();
               return result;
                //return db.GetUserInSection(xmlSetionID).ToList();
            }
        }


    }
}
