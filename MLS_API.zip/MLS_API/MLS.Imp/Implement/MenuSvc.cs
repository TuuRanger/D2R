﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Imp.Interface;
using MLS.Models;
using System.Data.Entity.Core.Objects;
using System.Transactions;
using MLS.Helper;
using AutoMapper;

namespace MLS.Imp.Implement
{
    public class MenuSvc : IMenuSvc
    {
        MapperConfiguration cfgMenuMapper = null;
        IMapper mapper = null;
        public MenuSvc()
        { 
            var cfgMenuMapper = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<MenuResult, MenuViewModel>();
            });
            mapper = cfgMenuMapper.CreateMapper();
        }
        
        private List<MenuViewModel> AddChilds(MenuViewModel parent, List<MenuViewModel> menuList)
        {
            List<MenuViewModel> childs = menuList.Where(x => x.Parent == parent.MenuCode).ToList();
            parent.ChildMenus = childs;

            foreach (MenuViewModel child in childs)
            {
                child.ChildMenus =  AddChilds(child, menuList);
            }

            return childs;
        }

        public List<MenuViewModel> GetMenus(String token)
        {
            IAuthenSvc _authenSvc = new AuthenSvc();
            UserDataResult _userData = _authenSvc.GetUserDataByToken(token);
            List<MenuViewModel> result = null;
            using (MLSEntities db = new MLSEntities())
            {
                
              
                List<MenuResult> temp = db.GetMenu(_userData.Username).OrderBy(x => x.DisplaySeq).ToList();

                if (temp.Count > 0) 
                {
                    result = mapper.Map<List<MenuViewModel>>(temp.Where(x => x.Parent.IsEmpty()));

                    foreach (MenuViewModel parent in result)
                    {
                         AddChilds(parent, mapper.Map<List<MenuViewModel>>(temp.Where(x => !x.Parent.IsEmpty())));
                    } 
                }
                 
                 
            }
            return result;
        }
    }
}
