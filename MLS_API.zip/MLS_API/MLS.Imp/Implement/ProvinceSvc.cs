﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Imp.Interface;
using MLS.Models;
namespace MLS.Imp.Implement
{
    public class ProvinceSvc : IProvinceSvc
    {
        public List<ProvinceByNameResult> GetProvinceByName(String provinceName)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetProvinceByName(provinceName).ToList();
            }
        }

        public List<ProvinceByIDResult> GetProvinceByID(int provinceID)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetProvinceByID(provinceID).ToList();
            }
        }

    }
}
