﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Imp.Interface;
using MLS.Models;
using System.Data.Entity.Core.Objects;
using System.Transactions;
using MLS.Helper;

namespace MLS.Imp.Implement
{
    public class AccountSvc : IAccountSvc
    {
        public List<AccountResult> SearchAccount(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string ACCDEAWTH, string SEARCH_STR)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.SearchAccount(CPNCOD, CPNBRNCOD, ACCBUSTYP, ACCDEAWTH, SEARCH_STR).ToList();
            }
        }

        public List<vwAccountContract> GetContractByAccount(String ACCCOD, String CPNCOD, String CPNBRNCOD, String ACCBUSTYP)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.vwAccountContracts.Where(x => x.ACCCOD == ACCCOD && x.CPNCOD == CPNCOD && x.CPNBRNCOD == CPNBRNCOD && x.ACCBUSTYP == ACCBUSTYP).ToList();
            }
        }
         
        public InsertOrUpdateCDMACCResult InsertOrUpdateAccount(AccountProcessViewModel accountProcessViewModel, String username)
        {
            InsertOrUpdateCDMACCResult insertAccountResult = null;
            List<String> cuscodList = null;
            List<vwCUSINFO> customerList = accountProcessViewModel.CustomerList;
            List<RefListResult> referencePersonList = accountProcessViewModel.ReferencePersonList;
            List<GuarantorListResult> guarantorList = accountProcessViewModel.GuarantorList;
            using (TransactionScope trans = new TransactionScope())
            {
                using (MLSEntities db = new MLSEntities())
                {
                    insertAccountResult = db.InsertOrUpdateCDMACC(accountProcessViewModel.RECORD_ID,
                                                                  accountProcessViewModel.RECACTCOD,
                                                                  accountProcessViewModel.RECSTSCOD,
                                                                  username,
                                                                  username,
                                                                  accountProcessViewModel.CPNCOD,
                                                                  accountProcessViewModel.CPNBRNCOD,
                                                                  accountProcessViewModel.CPNBRNACS,
                                                                  accountProcessViewModel.ACCBUSTYP,
                                                                  accountProcessViewModel.ACCCOD,
                                                                  accountProcessViewModel.GENAPPNUM,
                                                                  accountProcessViewModel.GENEFFDTE,
                                                                  accountProcessViewModel.ACCNAMTHA,
                                                                  accountProcessViewModel.ACCNAMENG,
                                                                  accountProcessViewModel.CUSGRPCOD,
                                                                  accountProcessViewModel.GENAPPDTE,
                                                                  accountProcessViewModel.GENAPRDTE,
                                                                  accountProcessViewModel.GENAPRSTS,
                                                                  accountProcessViewModel.ACCCNTTYP,
                                                                  accountProcessViewModel.ACCLNDTYP,
                                                                  accountProcessViewModel.ACCCRDLIN,
                                                                  accountProcessViewModel.ACCMAXLND,
                                                                  accountProcessViewModel.ACCMINLND,
                                                                  accountProcessViewModel.ACCBALAMT,
                                                                  accountProcessViewModel.ACCDEAWTH,
                                                                  accountProcessViewModel.ACCINTCND,
                                                                  accountProcessViewModel.ACCTRMCND,
                                                                  accountProcessViewModel.ACCCRDTIM,
                                                                  accountProcessViewModel.ACCMBRNUM,
                                                                  accountProcessViewModel.ACCMBRTYP,
                                                                  accountProcessViewModel.ACCMBRSTS,
                                                                  accountProcessViewModel.ACCMBRSNC,
                                                                  accountProcessViewModel.ACCMBRBEG,
                                                                  accountProcessViewModel.ACCMBREXP,
                                                                  accountProcessViewModel.ACCGRDCOD,
                                                                  accountProcessViewModel.ACCLEVCOD,
                                                                  accountProcessViewModel.ACCCRDSCR,
                                                                  accountProcessViewModel.ACCPAYEE,
                                                                  accountProcessViewModel.ACCPARENT,
                                                                  accountProcessViewModel.ACCSNDINV,
                                                                  accountProcessViewModel.ACCSNDRCP,
                                                                  accountProcessViewModel.ACCSNDADV,
                                                                  accountProcessViewModel.ACCVERDTE,
                                                                  accountProcessViewModel.ACCVERSTS,
                                                                  accountProcessViewModel.R_FLAG,
                                                                  accountProcessViewModel.ACCCASE,
                                                                  accountProcessViewModel.CRDLINRTE,
                                                                  accountProcessViewModel.ADVRATIO,
                                                                  accountProcessViewModel.LNDTRM,
                                                                  accountProcessViewModel.INTPER,
                                                                  accountProcessViewModel.ODLINE,
                                                                  accountProcessViewModel.ODINTRTE,
                                                                  accountProcessViewModel.OPRFEERTE,
                                                                  accountProcessViewModel.COLFEERTE,
                                                                  accountProcessViewModel.FEEAMT,
                                                                  accountProcessViewModel.REGINTRAT,
                                                                  accountProcessViewModel.CONIRATE,
                                                                  accountProcessViewModel.IRATEBNKREF,
                                                                  accountProcessViewModel.CONFRATE,
                                                                  accountProcessViewModel.COLFEETYP,
                                                                  accountProcessViewModel.OPRFEETYP,
                                                                  accountProcessViewModel.RETENTAMT,
                                                                  accountProcessViewModel.RETENTRTE,
                                                                  accountProcessViewModel.PREFINRTE,
                                                                  accountProcessViewModel.ACCCRDLIN2,
                                                                  accountProcessViewModel.CRDLINRTE2,
                                                                  accountProcessViewModel.CONIRATE2,
                                                                  accountProcessViewModel.IRATEBNKREF2,
                                                                  accountProcessViewModel.CONFRATE2,
                                                                  accountProcessViewModel.ADVRATIO2,
                                                                  accountProcessViewModel.RETENTTYP,
                                                                  accountProcessViewModel.MAXINVAMT,
                                                                  accountProcessViewModel.FIXFEETYP,
                                                                  accountProcessViewModel.ACCSECCOD,
                                                                  accountProcessViewModel.FINBNKCODDR,
                                                                  accountProcessViewModel.FINBNKBRNDR,
                                                                  accountProcessViewModel.FINBNKNUMDR,
                                                                  accountProcessViewModel.FINBNKCODCR,
                                                                  accountProcessViewModel.FINBNKBRNCR,
                                                                  accountProcessViewModel.FINBNKNUMCR,
                                                                  accountProcessViewModel.TRNPAYBYPAY,
                                                                  accountProcessViewModel.TRNPAYBYRCV,
                                                                  accountProcessViewModel.ACCDUETRM,
                                                                  accountProcessViewModel.ACCCRDTRM,
                                                                  accountProcessViewModel.FACADVRTE).FirstOrDefault();

                    if (accountProcessViewModel.AddressList.Count > 0) /* Account Address*/
                    {
                        foreach (CustomerAddressResult address in accountProcessViewModel.AddressList)
                        {
                            if (address != null)
                            {
                                if (false == (address.RECACTCOD == "I" && address.ADRCOD == null)) /*not call db if new address has deleted*/
                                {
                                    InsertOrUpdateAddressResult insertAddressResult = db.InsertOrUpdateAddress(
                                     insertAccountResult.GENAPPNUM,
                                     address.ADRTYPCOD,
                                     address.ADRREFCOD,
                                     address.ADRCOD,
                                     address.ADRDTLLN1,
                                     address.ADRZIPCOD,
                                     address.ADRCTYCOD,
                                     address.ADRLIVSIN,
                                     address.ADRFAXNUM,
                                     address.ADREMAIL,
                                     address.ADROWNERCOD,
                                     address.ADRDISTRICT,
                                     address.ADRAMPHUR,
                                     address.ADRPROVINCE,
                                     address.ADRTELNUM,
                                     address.ADRMEMBER,
                                     address.TELFRMNUM,
                                     address.TELENDNUM,
                                     address.TELEXTNUM,
                                     username,
                                     address.RECACTCOD).FirstOrDefault();

                                    db.InsertOrUpdateTel(address.TELSEQNUM,
                                        insertAccountResult.GENAPPNUM,
                                        insertAddressResult.ADRCOD,
                                        null,
                                        address.ADRTELNUM,
                                        address.TELFRMNUM,
                                        address.TELENDNUM,
                                        address.TELEXTNUM,
                                        username,
                                        address.RECACTCOD);
                                }
                            } 
                        }
                    }

                    if (customerList != null && customerList.Count > 0)
                    {
                        cuscodList = new List<string>();
                     
                        foreach (vwCUSINFO customer in customerList)
                        { 

                            if (false == (customer.RECACTCOD.ToStringTrim() == "I" && customer.ADDNEW_FLAG)) /*not insert if customer has been addnew and has deleted*/
                            {
                                ObjectParameter CUSCOD = new ObjectParameter("CUSCOD", customer.CUSCOD.ToStringOrEmpty());
                                if (customer.CUSCOD.IsEmpty())
                                { 
                                    db.InsertOrUpdateCustomer(customer.CPNCOD,
                                                          customer.CPNBRNCOD,
                                                          customer.CPNBRNCOD,
                                                          customer.CUSTTLTHA,
                                                          customer.CUSNAMTHA,
                                                          customer.CUSSURTHA,
                                                          customer.CUSNICNAM,
                                                          customer.PSNREGIDN,
                                                          customer.PSNBTHDTE,
                                                          customer.PSNMTHINC,
                                                          customer.PSNOTHINC,
                                                          customer.PSNMARSTS,
                                                          customer.PSNCHDNUM,
                                                          customer.PSNSEXCOD,
                                                          customer.PSNOCCCOD,
                                                          customer.PSNPOSITN,
                                                          customer.PSNNETINC,
                                                          customer.PSNGRSINC,
                                                          customer.PSNCPNSTF,
                                                          customer.PSNWRKPLC,
                                                          customer.PSNWRKPRD,
                                                          customer.PSNCPNTYP,
                                                          customer.PSNBTHDAY,
                                                          customer.PSNEMPLOY_TYP,
                                                          customer.PSNSALRCVTYP,
                                                          username,
                                                          customer.CUSPHNNUM,
                                                          customer.CUSTTLENG,
                                                          customer.CUSNAMENG,
                                                          customer.CUSSURENG,
                                                          customer.CUSTYPCOD,
                                                          customer.CUSCRDCOD,
                                                          customer.CUSLEVCOD,
                                                          customer.CUSBOTCOD,
                                                          customer.CUSCRDLNE,
                                                          customer.CUSBUSCNT,
                                                          customer.GENTAXNUM,
                                                          customer.CUS_FINBNKCOD1,
                                                          customer.CUS_FINBNKBRN1,
                                                          customer.CUS_FINBNKNUM1,
                                                          customer.CUS_FINBNKCOD2,
                                                          customer.CUS_FINBNKBRN2,
                                                          customer.CUS_FINBNKNUM2,
                                                          customer.CUS_FINBNKCOD3,
                                                          customer.CUS_FINBNKBRN3,
                                                          customer.CUS_FINBNKNUM3,
                                                          customer.ADRCOD01,
                                                          customer.ADRCOD02,
                                                          customer.ADRCOD03,
                                                          customer.ADRCOD04,
                                                          customer.ADRCOD05,
                                                          customer.ADRCOD06,
                                                          customer.ADRCOD07,
                                                          customer.ADRCOD08,
                                                          customer.ADRCOD09,
                                                          customer.ADRCOD10,
                                                          customer.CUSCITZEN,
                                                          customer.CUSNATION,
                                                          customer.VATREGISTER,
                                                          customer.CUS_ADRTELNUM,
                                                          customer.CUSEMAIL,
                                                          customer.COOPERATE_TYPE,
                                                          customer.PSNREGSIN,
                                                          customer.PSNREGEXP,
                                                          customer.PSNSALDTE,
                                                          customer.PSNRELTME,
                                                          customer.CPNREGNUM,
                                                          customer.CPNBUSTYP,
                                                          customer.CPNREGDTE,
                                                          customer.CPNYERINC,
                                                          customer.CPNYERPRF,
                                                          customer.REFDOCDTE,
                                                          customer.CPNCNTPSN,
                                                          customer.CPNCNTPOS,
                                                          CUSCOD
                                                          );
                                }

                                db.InsertOrUpdateCDRACU(customer.RECACTCOD,
                                                        accountProcessViewModel.RECSTSCOD,
                                                        username,
                                                        accountProcessViewModel.CPNCOD,
                                                        accountProcessViewModel.CPNBRNCOD,
                                                        accountProcessViewModel.ACCBUSTYP,
                                                        "ACC",
                                                        insertAccountResult.ACCCOD,
                                                        CUSCOD.Value.ToString(),
                                                        null);

                                foreach (CustomerAddressResult address in customer.AddressList)
                                {
                                    InsertOrUpdateAddressResult insertAddressResult = db.InsertOrUpdateAddress(
                                         CUSCOD.Value.ToString(),
                                         address.ADRTYPCOD,
                                         address.ADRREFCOD,
                                         address.ADRCOD,
                                         address.ADRDTLLN1,
                                         address.ADRZIPCOD,
                                         address.ADRCTYCOD,
                                         address.ADRLIVSIN,
                                         address.ADRFAXNUM,
                                         address.ADREMAIL,
                                         address.ADROWNERCOD,
                                         address.ADRDISTRICT,
                                         address.ADRAMPHUR,
                                         address.ADRPROVINCE,
                                         address.ADRTELNUM,
                                         address.ADRMEMBER,
                                         address.TELFRMNUM,
                                         address.TELENDNUM,
                                         address.TELEXTNUM,
                                         username,
                                         address.RECACTCOD).FirstOrDefault();

                                    db.InsertOrUpdateTel(address.TELSEQNUM,
                                        CUSCOD.Value.ToString(),
                                        insertAddressResult.ADRCOD,
                                        null,
                                        address.ADRTELNUM,
                                        address.TELFRMNUM,
                                        address.TELENDNUM,
                                        address.TELEXTNUM,
                                        username,
                                        address.RECACTCOD);
                                }
                            }  
                        } 
                    }

                    if (referencePersonList.Count > 0)
                    {
                        foreach (RefListResult refperson in referencePersonList)
                        {
                            if ((refperson.RECACTCOD == "I" && refperson.CUSCOD.IsEmpty()) == false) // if new refperson has deleted not call database
                            {
                                if (refperson.RECACTCOD != "I")
                                {
                                    refperson.RECACTCOD = "A";
                                }
                                db.InsertOrUpdateReferencePerson(insertAccountResult.CPNCOD,
                                                                 insertAccountResult.CPNBRNCOD,
                                                                 insertAccountResult.ACCBUSTYP,
                                                                 insertAccountResult.ACCCOD,
                                                                 refperson.COCCOLNUM,
                                                                 refperson.CUSCOD,
                                                                 refperson.CUSTTLTHA,
                                                                 refperson.CUSNAMTHA,
                                                                 refperson.CUSSURTHA,
                                                                 refperson.CUSNICNAM,
                                                                 refperson.COLCUSREL,
                                                                 refperson.COLRELYER,
                                                                 refperson.CUSPHNNUM,
                                                                 username,
                                                                 refperson.RECACTCOD,
                                                                 "ACC");
                            }

                        }
                    }

                    if (guarantorList.Count > 0)
                    {
                        foreach (GuarantorListResult gua in guarantorList)
                        {
                            if ((gua.RECACTCOD == "I" && gua.CUSCOD.IsEmpty()) == false) /*Not call database if new address (add new in UI) has delete*/
                            {
                                if (gua.RECACTCOD != "I")
                                {
                                    gua.RECACTCOD = "A";
                                }

                                InsertOrUpdateGuarantorResult result = db.InsertOrUpdateGuarantor(
                                                         insertAccountResult.CPNCOD,
                                                         insertAccountResult.CPNBRNCOD,
                                                         insertAccountResult.ACCBUSTYP,
                                                         insertAccountResult.ACCCOD,
                                                         gua.COCCOLNUM,
                                                         gua.CUSCOD,
                                                         gua.CUSTTLTHA,
                                                         gua.CUSNAMTHA,
                                                         gua.CUSSURTHA,
                                                         gua.COLCUSREL,
                                                         gua.COLRELYER,
                                                         gua.CUSPHNNUM,
                                                         gua.PSNREGIDN,
                                                         gua.PSNMTHINC,
                                                         //gua.CHECK_GUARANTOR_FLG,
                                                         //gua.CHECK_GUARANTOR_REMARK,
                                                         //gua.CHECK_AMLO_FLG,
                                                         //gua.CHECK_AMLO_REMARK,
                                                         gua.CUSTYPCOD,
                                                         username,
                                                         gua.RECACTCOD,
                                                         "ACC").FirstOrDefault();

                                if (gua.readOnlyCustomerInfo == false)
                                {
                                    foreach (CustomerAddressResult address in gua.AddressList)
                                    {
                                        String isActiveAddress = address.RECACTCOD;
                                        if (gua.RECACTCOD == "I")
                                        {
                                            isActiveAddress = "I";
                                        }


                                        InsertOrUpdateAddressResult insertResult = db.InsertOrUpdateAddress(
                                             result.CUSCOD,
                                             address.ADRTYPCOD,
                                             address.ADRREFCOD,
                                             address.ADRCOD,
                                             address.ADRDTLLN1,
                                             address.ADRZIPCOD,
                                             address.ADRCTYCOD,
                                             address.ADRLIVSIN,
                                             address.ADRFAXNUM,
                                             address.ADREMAIL,
                                             address.ADROWNERCOD,
                                             address.ADRDISTRICT,
                                             address.ADRAMPHUR,
                                             address.ADRPROVINCE,
                                             address.ADRTELNUM,
                                             address.ADRMEMBER,
                                             address.TELFRMNUM,
                                             address.TELENDNUM,
                                             address.TELEXTNUM,
                                             username,
                                             isActiveAddress).FirstOrDefault();

                                        db.InsertOrUpdateTel(address.TELSEQNUM,
                                            result.CUSCOD,
                                            insertResult.ADRCOD,
                                            null,
                                            address.ADRTELNUM,
                                            address.TELFRMNUM,
                                            address.TELENDNUM,
                                            address.TELEXTNUM,
                                            username,
                                            isActiveAddress);
                                    }
                                }
                               
                            }

                        }
                    }

/*
                    if (accountProcessViewModel.RECSTSCOD == "2")
                    {
                        db.InsertOrUpdateMLTCRD(accountProcessViewModel.RECACTCOD,
                                     accountProcessViewModel.RECSTSCOD,
                                     username,
                                     username,
                                     accountProcessViewModel.CPNCOD,
                                     accountProcessViewModel.CPNBRNCOD,
                                     accountProcessViewModel.CPNBRNACS,
                                     insertAccountResult.ACCBUSTYP,
                                     "APP",
                                     insertAccountResult.ACCCOD,
                                     "VER",
                                     accountProcessViewModel.ACCCODVER,
                                     accountProcessViewModel.RECSTSCOD,
                                     accountProcessViewModel.CRDVERRSL,
                                     accountProcessViewModel.CRDVERRSN,
                                     accountProcessViewModel.CRDVERRSL == "Y" ? null : accountProcessViewModel.CRDDEVIAT,
                                     accountProcessViewModel.CRDSCORE,
                                     null);

                        db.InsertOrUpdateCDTREM("A",
                                                null,
                                                username,
                                                username,
                                                accountProcessViewModel.CPNCOD,
                                                accountProcessViewModel.CPNBRNCOD,
                                                accountProcessViewModel.ACCBUSTYP,
                                                "APP",
                                                accountProcessViewModel.ACCCOD,
                                                "Account",
                                                accountProcessViewModel.GENREMARK,
                                                null);
                    }*/
                   

                }
                trans.Complete();
                return insertAccountResult;
            }

        }

        public void VerifyAccount(AccountProcessViewModel accountProcessViewModel, String username)
        {
            using (TransactionScope trans = new TransactionScope())
            {
                using (MLSEntities db = new MLSEntities())
                { 
                    db.VerifyAccount(
                          accountProcessViewModel.CPNCOD,
                          accountProcessViewModel.CPNBRNCOD,
                          accountProcessViewModel.ACCBUSTYP,
                          accountProcessViewModel.GENAPPNUM,
                          accountProcessViewModel.GENAPRDTE,
                          accountProcessViewModel.ACCGRDCOD,
                          accountProcessViewModel.ACCLEVCOD,
                          accountProcessViewModel.ACCCRDSCR,
                          accountProcessViewModel.CRDVERRSL, 
                          accountProcessViewModel.RECSTSCOD,
                          username);

                    db.InsertOrUpdateMLTCRD(accountProcessViewModel.RECACTCOD,
                                                            accountProcessViewModel.RECSTSCOD,
                                                            username,
                                                            username,
                                                            accountProcessViewModel.CPNCOD,
                                                            accountProcessViewModel.CPNBRNCOD,
                                                            accountProcessViewModel.CPNBRNACS,
                                                            accountProcessViewModel.ACCBUSTYP,
                                                            "APP",
                                                            accountProcessViewModel.GENAPPNUM,
                                                            "VER",
                                                            accountProcessViewModel.ACCCODVER_CRD,
                                                            accountProcessViewModel.RECSTSCOD,
                                                            accountProcessViewModel.CRDVERRSL,
                                                            accountProcessViewModel.CRDVERRSN,
                                                            accountProcessViewModel.CRDVERRSL == "Y" ? null : accountProcessViewModel.CRDDEVIAT,
                                                            accountProcessViewModel.CRDSCORE,
                                                            null);

                    db.InsertOrUpdateCDTREM("A",
                                            null,
                                            username,
                                            username,
                                            accountProcessViewModel.CPNCOD,
                                            accountProcessViewModel.CPNBRNCOD,
                                            accountProcessViewModel.ACCBUSTYP,
                                            "APP",
                                            accountProcessViewModel.GENAPPNUM,
                                            "Account",
                                            accountProcessViewModel.GENREMARK,
                                            null);
                }
                trans.Complete();
            }
        }
         
        public void SendBackAccount(AccountProcessViewModel accountProcessViewModel, String username)
        {
            using (MLSEntities db = new MLSEntities())
            {
                db.SendBackAccount(
                    accountProcessViewModel.CPNCOD,  
                    accountProcessViewModel.CPNBRNCOD,  
                    accountProcessViewModel.ACCBUSTYP,  
                    accountProcessViewModel.ACCCOD,
                    accountProcessViewModel.RECSTSCOD,  
                    username);
            } 
        }

        public GenAccountResult GenAccount(AccountProcessViewModel accountProcessViewModel, String username)
        {
            using (TransactionScope tran = new TransactionScope())
            {
                GenAccountResult result = null;
                using (MLSEntities db = new MLSEntities())
                {
                    db.VerifyAccount(
                         accountProcessViewModel.CPNCOD,
                         accountProcessViewModel.CPNBRNCOD,
                         accountProcessViewModel.ACCBUSTYP,
                         accountProcessViewModel.GENAPPNUM,
                         accountProcessViewModel.GENAPRDTE,
                         accountProcessViewModel.ACCGRDCOD,
                         accountProcessViewModel.ACCLEVCOD,
                         accountProcessViewModel.ACCCRDSCR,
                         accountProcessViewModel.CRDVERRSL,
                         accountProcessViewModel.RECSTSCOD,
                         username);

                    db.InsertOrUpdateMLTCRD(accountProcessViewModel.RECACTCOD,
                                                          accountProcessViewModel.RECSTSCOD,
                                                          username,
                                                          username,
                                                          accountProcessViewModel.CPNCOD,
                                                          accountProcessViewModel.CPNBRNCOD,
                                                          accountProcessViewModel.CPNBRNACS,
                                                          accountProcessViewModel.ACCBUSTYP,
                                                          "APP",
                                                          accountProcessViewModel.GENAPPNUM,
                                                          "VER",
                                                          accountProcessViewModel.ACCCODVER_CRD,
                                                          accountProcessViewModel.RECSTSCOD,
                                                          accountProcessViewModel.CRDVERRSL,
                                                          accountProcessViewModel.CRDVERRSN,
                                                          accountProcessViewModel.CRDVERRSL == "Y" ? null : accountProcessViewModel.CRDDEVIAT,
                                                          accountProcessViewModel.CRDSCORE,
                                                          null);

                    result = db.GenAccount(
                            accountProcessViewModel.RECORD_ID,
                            accountProcessViewModel.RECACTCOD,
                            accountProcessViewModel.RECSTSCOD,
                            accountProcessViewModel.CPNCOD,
                            accountProcessViewModel.CPNBRNCOD,
                            accountProcessViewModel.ACCBUSTYP,
                            accountProcessViewModel.GENAPPNUM,
                            accountProcessViewModel.ACCCOD,
                            accountProcessViewModel.ACCCODVER_ACC,
                            accountProcessViewModel.CRDVERRSL,
                            username).FirstOrDefault(); 
                }

                tran.Complete();
                return result;
            }
            
        }

        public List<SearchAccountWithPagingResult> SearchAccountWithPaging(String ACCBUSTYP,string ACCCOD, String GENAPPNUM,string ACCNAMTHA, string ACCDEAWTH, string RECSTSCOD_FROM, string RECSTSCOD_TO, int pageNo, int pageSize)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.SearchAccountWithPaging(ACCBUSTYP, ACCCOD, GENAPPNUM,ACCNAMTHA, ACCDEAWTH, RECSTSCOD_FROM, RECSTSCOD_TO, pageNo, pageSize).ToList();
            }
        }

        public AccountDetailResult GetAccountDetail(string CPNCOD,string CPNBRNCOD,string ACCBUSTYP,string GENAPPNUM)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetAccountDetail(CPNCOD,CPNBRNCOD,ACCBUSTYP,GENAPPNUM).FirstOrDefault();
            }
        }

        //public List<vwAccountCustomer> GetAccountCustomers(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string GENAPPNUM)
        //{
        //    using (MLSEntities db = new MLSEntities())
        //    {
        //        List<vwAccountCustomer> customerList = db.vwAccountCustomers.Where(x => x.CPNCOD == CPNCOD &&
        //       x.CPNBRNCOD == CPNBRNCOD &&
        //       x.ACCBUSTYP == ACCBUSTYP &&
        //       x.GENAPPNUM == GENAPPNUM &&
        //       x.RECACTCOD != "I").ToList();


        //        return customerList;
        //    }
        //}


        public List<AccountCustomerResult> GetAccountCustomers(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string GENAPPNUM)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetAccountCustomer(CPNCOD, CPNBRNCOD, ACCBUSTYP, GENAPPNUM).ToList(); 
            }
        }

        public CustomerInAccountResult CheckCustomerInAccount(String CUSCOD,String ACCCOD)
        {
            using (MLSEntities db = new MLSEntities())
            {
                CustomerInAccountResult result =  db.CheckCustomerInAccount(CUSCOD, ACCCOD).FirstOrDefault();
                return result;
            } 
        }

        public CDSACCCFG GetAccountConfig(String ACCBUSTYP,String ACCDEAWTH,String CPNBRNCOD)
        {
            using (MLSEntities db = new MLSEntities())
            {
                CDSACCCFG result = db.CDSACCCFGs.Where(x => x.ACCBUSTYP == ACCBUSTYP && x.ACCDEAWTH == ACCDEAWTH && x.CPNBRNCOD == CPNBRNCOD).FirstOrDefault();
                if(result == null)
                {
                    result = db.CDSACCCFGs.Where(x => x.ACCBUSTYP == ACCBUSTYP && x.ACCDEAWTH == ACCDEAWTH && x.CPNBRNCOD == "0000").FirstOrDefault();
                }

                return result;
            }
        }

        public int CheckAccountExistsBeforeGen(String GENAPPNUM,String ACCCOD)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.CheckAccountCodeExistsBeforeGen(GENAPPNUM, ACCCOD).FirstOrDefault().Value;
            }
        }
    }
}
