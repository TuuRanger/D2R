﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Imp.Interface;
using MLS.Models;
namespace MLS.Imp.Implement
{
    public class UserSectionSvc : IUserSectionSvc
    {
        public List<vwUserSection> GetUserSection(string USRID)
        {
            using (MLSEntities db = new MLSEntities())
            {
                List<vwUserSection> result = db.vwUserSections.Where(x => x.USRID == USRID).ToList();
                return result;
                //return db.GetUserSection(USRID, SECTIONID).ToList();
            }
        }
    }
}
