﻿using MLS.Imp.Interface;
using MLS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Imp.Implement
{
    public class UISvc : IUISvc
    {
        public List<ScreenLabelTextResult> GetScreenLabelText(string SCREEN_CD, string LANG_CD)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetScreenLabelText(SCREEN_CD, LANG_CD).ToList();
            }
        }


        public List<GlobalMessageResult> GetGlobalMessage(String language)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetGlobalMessage(language).ToList();
            }
        }
    }
}
