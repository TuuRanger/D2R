﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Imp.Interface;
using MLS.Models;
namespace MLS.Imp.Implement
{
    public class ZipCodeSvc : IZipCodeSvc
    {
        public List<ZipCodeResult> GetZipCode(int districtID, int amphurID, int provinceID)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetZipCode(districtID, amphurID, provinceID).ToList();
            }
        }

        public List<ZipCodeByZipCodeResult> GetZipCodeByZipCode(string zipCode)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetZipCodeByZipCode(zipCode).ToList();
            }
        }
    }
}
