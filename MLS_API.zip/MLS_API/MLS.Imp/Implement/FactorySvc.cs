﻿using MLS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Helper;
using System.Transactions;

namespace MLS.Imp.Implement
{
    public class FactorySvc : IFactorySvc
    {

        MLSEntities _db = null;
        public FactorySvc()
        {
            _db = new MLSEntities();
        }

        public List<InvoiceResult> InvoiceVerifying(List<String> fileNames, String username)
        {
            List<InvoiceResult> result = new List<InvoiceResult>();
            foreach (String fileName in fileNames)
            {
                /*Verify invoice implement later*/
                result = result.Union(this.InvoiceVerfying(fileName, username)).ToList();
            }
            return result;
        }

        private List<InvoiceResult> InvoiceVerfying(String fileName, String username)
        {
            List<InvoiceResult> invoiceList = ExcelManager.ReadExcel<InvoiceResult>(fileName, 1, 2);

            if (invoiceList.Count > 0)
            {
                int TRNSEQNUM = 0;
                vwUserProfile user = _db.vwUserProfiles.Where(x => x.USRID == username).FirstOrDefault();
                vwAccountDetail account = _db.vwAccountDetails.Where(x => x.ACCCOD == user.ACCCOD).FirstOrDefault();
                foreach (InvoiceResult invoice in invoiceList)
                {
                    String CPNCOD = "0001";
                    String CPNBRNCOD = "0001";
                    String ACCBUSTYP = "";
                    String TRNDOCNUM = "";
                    DateTime? TRNDOCDTE = null;
                    String TRNEVENT = null;
                    String CONPRCTYP = null;
                    DateTime? INVCOLDTE = null;
                    Decimal? ADVAMT = (invoice.InvoiceAmount * (account.FACADVRTE.ToDecimalOrZero() / 100));
                    Decimal? FINAMT = 0;
                    Decimal? RSVAMT = invoice.InvoiceAmount - ADVAMT;
                    Decimal? OPRFEE = null;
                    Decimal? COLFEE = null;
                    Decimal? INTWHTAMT = null;
                    Decimal? FEEWHTAMT = null;
                    Decimal? CLRAMT = null;
                    Decimal? PENLTYAMT = null;
                    Decimal? SHORTAMT = null;
                    Decimal? REFUNDAMT = null;
                    Decimal? OVERAMT = null;



                    _db.InsertOrUpdateInvoice("3",
                                              CPNCOD,
                                              CPNBRNCOD,
                                              ACCBUSTYP,
                                              TRNDOCNUM,
                                              TRNDOCDTE,
                                              TRNEVENT,
                                              CONPRCTYP,
                                              invoice.ContractNo,
                                              ++TRNSEQNUM,
                                              invoice.InvoiceNo,
                                              invoice.InvoiceDate,
                                              invoice.DueDate,
                                              INVCOLDTE,
                                              invoice.InvoiceAmount,
                                              ADVAMT,
                                              FINAMT,
                                              RSVAMT,
                                              invoice.InvoiceAmount,
                                              OPRFEE,
                                              COLFEE,
                                              INTWHTAMT,
                                              FEEWHTAMT,
                                              CLRAMT,
                                              PENLTYAMT,
                                              SHORTAMT,
                                              REFUNDAMT,
                                              OVERAMT,
                                              username);
                }
            }


            return invoiceList;
        }

        public List<InvoiceListResult> GetInvoiceList(String productType, DateTime? InvoiceDateFrom, DateTime? invoiceDateTo, DateTime? dueDateFrom, DateTime? dueDateTo)
        {
            return _db.GetInvoiceList().ToList();
        }

        public void InsertInvoiceTransaction(List<InvoiceListResult> selectedInvoices, string username)
        {
            using (TransactionScope trans = new TransactionScope())
            {
                foreach (InvoiceListResult invoice in selectedInvoices)
                {
                    _db.InsertInvoiceTransaction("3",
                                                 invoice.CPNCOD,
                                                 invoice.CPNBRNCOD,
                                                 invoice.ACCBUSTYP,
                                                 invoice.CONPRCTYP,
                                                 invoice.CONNUM,
                                                 invoice.INVNUM,
                                                 /*invoice.FINDTE*/ null,
                                                 /* invoice.FINSEQNUM*/ null,
                                                 invoice.CreditRequestAmount,
                                                 /*invoice.ACMGRPDOC*/ "",
                                                 username);

                    _db.InsertOrUpdateInvoice("3",
                                               null,
                                               null,
                                               null,
                                               null,
                                               null,
                                               null,
                                               null,
                                               null,
                                               null,
                                               invoice.INVNUM,
                                               null,
                                               null,
                                               null,
                                               null,
                                               null,
                                               invoice.CreditRequestAmount,
                                               null,
                                               null,
                                               null,
                                               null,
                                               null,
                                               null,
                                               null,
                                               null,
                                               null,
                                               null,
                                               null,
                                               username);
                }

                trans.Complete();
            }
        }

        public InvoiceCreditInfoResult GetInvoiceCreditInfo()
        {
            return _db.GetInvoiceCreditInfo().FirstOrDefault();
        }
    }
}
