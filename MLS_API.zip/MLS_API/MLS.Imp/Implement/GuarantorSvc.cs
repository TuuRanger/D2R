﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Imp.Interface;
using MLS.Models;

using System.Transactions;
using MLS.Helper;

namespace MLS.Imp.Implement
{
    public class GuarantorSvc : IGuarantorSvc
    {
        IAddressSvc addressSvc;

        public GuarantorSvc()
        {
            addressSvc = new AddressSvc();
        }

        public List<GuarantorListResult> GetGuarantorList(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string CONNUM)
        {
            List<GuarantorListResult> result = null;
            using (MLSEntities db = new MLSEntities())
            {
                result = db.GetGuarantorList(CPNCOD, CPNBRNCOD, ACCBUSTYP, CONNUM).ToList();

                foreach (GuarantorListResult gua in result)
                {
                    gua.AddressList = addressSvc.GetCustomerAddress(gua.CUSCOD);
                }
            }
            return result;
        }

        public void InsertOrUpdateGuarantor(List<GuarantorListResult> guarantorList,
            String CPNCOD,
            String CPNBRNCOD,
            String ACCBUSTYP,
            String CONNUM,  
            String username)
        {
            using (var trans = new TransactionScope())
            {
                using (MLSEntities db = new MLSEntities())
                {
                    //db.DeleteGuarantor(CPNCOD, CPNBRNCOD, ACCBUSTYP, CONNUM); 
                    foreach (GuarantorListResult gua in guarantorList)
                    {
                        if ((gua.RECACTCOD == "I" && gua.CUSCOD.IsEmpty()) == false) /*Not call database if new address (add new in UI) has delete*/
                        {
                            InsertOrUpdateGuarantorResult result = db.InsertOrUpdateGuarantor(
                                                     CPNCOD,
                                                     CPNBRNCOD,
                                                     ACCBUSTYP,
                                                     CONNUM,
                                                     gua.COCCOLNUM,
                                                     gua.CUSCOD,
                                                     gua.CUSTTLTHA,
                                                     gua.CUSNAMTHA,
                                                     gua.CUSSURTHA,
                                                     gua.COLCUSREL,
                                                     gua.COLRELYER,
                                                     gua.CUSPHNNUM,
                                                     gua.PSNREGIDN,
                                                     gua.PSNMTHINC,
                                                     //gua.CHECK_GUARANTOR_FLG,
                                                     //gua.CHECK_GUARANTOR_REMARK,
                                                     //gua.CHECK_AMLO_FLG,
                                                     //gua.CHECK_AMLO_REMARK,
                                                     gua.CUSTYPCOD,
                                                     username,
                                                     gua.RECACTCOD,
                                                     gua.COCRELTYP).FirstOrDefault();

                            foreach (CustomerAddressResult address in gua.AddressList)
                            {
                                String isActiveAddress = address.RECACTCOD; 
                                if (gua.RECACTCOD == "I")
                                {
                                    isActiveAddress = "I";
                                } 
                                 

                                InsertOrUpdateAddressResult insertResult = db.InsertOrUpdateAddress(
                                     result.CUSCOD,
                                     address.ADRTYPCOD,
                                     address.ADRREFCOD,
                                     address.ADRCOD,
                                     address.ADRDTLLN1,
                                     address.ADRZIPCOD,
                                     address.ADRCTYCOD,
                                     address.ADRLIVSIN,
                                     address.ADRFAXNUM,
                                     address.ADREMAIL,
                                     address.ADROWNERCOD,
                                     address.ADRDISTRICT,
                                     address.ADRAMPHUR,
                                     address.ADRPROVINCE,
                                     address.ADRTELNUM,
                                     address.ADRMEMBER,
                                     address.TELFRMNUM,
                                     address.TELENDNUM,
                                     address.TELEXTNUM,
                                     username,
                                     isActiveAddress).FirstOrDefault();

                                db.InsertOrUpdateTel(address.TELSEQNUM,
                                    result.CUSCOD,
                                    insertResult.ADRCOD,
                                    null,
                                    address.ADRTELNUM,
                                    address.TELFRMNUM,
                                    address.TELENDNUM,
                                    address.TELEXTNUM,
                                    username,
                                    isActiveAddress);
                            }
                        }

                    }
                    trans.Complete();
                }

            }
        }
    }
}
