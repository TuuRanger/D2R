﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Imp.Interface;
using MLS.Helper;
using MLS.Models;

namespace MLS.Imp.Implement
{
    public class LogSvc : ILogSvc
    {
        public void InsertLogXML(string CUSCOD, string CONNUM, string ACCCOD, string METHOD, string LOG_DATA, string CRTUSRCOD, string REMARK, Nullable<int> CRDRSLSTP)
        {
            using (MLSEntities db = new MLSEntities())
            {
                DateTime createDate = DateTime.Now;
                db.InsertLogXml(CUSCOD, CONNUM, ACCCOD, METHOD, LOG_DATA, createDate , CRTUSRCOD, REMARK, CRDRSLSTP);
            }
            
        }
    }
}
