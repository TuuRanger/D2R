﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Imp.Interface;
using MLS.Models;
namespace MLS.Imp.Implement
{
  public  class SetupSvc : ISetupSvc
    {
        public List<SetupResult> GetSetup(string TABKEYONE, string TABKEYTWO, string SHOWALL = "N")
        {
            using (MLSEntities db = new MLSEntities())
            {
                List<SetupResult> result = db.GetSetup(TABKEYONE, TABKEYTWO, SHOWALL).ToList();
               return result;
            }
        }

        
    }
}
