﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Helper;
using MLS.Imp.Interface;
using MLS.Models;
using System.Data.Entity.Core.Objects;

namespace MLS.Imp.Implement
{
    public class CustomerSvc : ICustomerSvc
    {
        public vwCUSINFO GetCustomerInfoWithAccount(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string ID, string CUSTYPCOD)
        {
            using (MLSEntities db = new MLSEntities())
            {
                //(CPNCOD, CPNBRNCOD, ACCBUSTYP, PSNREGIDN).FirstOrDefault();
                List<vwCUSINFO> listResult = null;
                if (CUSTYPCOD == Helper.Constants.CustomerType.Jurictic)
                {
                    listResult = db.vwCUSINFOes.Where(x => x.CPNREGNUM == ID).ToList();
                }
                else if (CUSTYPCOD == Helper.Constants.CustomerType.Individual)
                {
                    listResult = db.vwCUSINFOes.Where(x => x.PSNREGIDN == ID).ToList();
                }

                if (listResult != null && listResult.Count > 0)
                {
                    vwCUSINFO result = listResult.Where(x => x.CPNCOD == CPNCOD && x.CPNBRNCOD == CPNBRNCOD && x.ACCBUSTYP == ACCBUSTYP).FirstOrDefault();
                    if (result != null)
                    {
                        return result;
                    }
                    else
                    {
                        result = listResult.FirstOrDefault();
                        return result;
                    }
                }
                else
                {
                    return null;
                }
            }
        }

        public vwCustomerSearch GetCustomerInfo(String ID,String CUSTYPCOD)
        {
            using (MLSEntities db = new MLSEntities())
            {
                vwCustomerSearch result = null;
                if (CUSTYPCOD == Helper.Constants.CustomerType.Jurictic)
                {
                    result  = db.vwCustomerSearches.Where(x => x.CPNREGNUM == ID).FirstOrDefault();
                }
                else if (CUSTYPCOD == Helper.Constants.CustomerType.Individual)
                {
                    result = db.vwCustomerSearches.Where(x => x.PSNREGIDN == ID).FirstOrDefault();
                }
                return result;
            }
        }
         
        public List<SearchCustomerWithPagingResult> SearchCustomerPaging(String name,String surname, String ID, String customerType, int pageNo, int pageSize)
        { 

            using (MLSEntities db = new MLSEntities())
            {
               return db.SearchCustomerWithPaging(ID,name,surname,customerType,pageNo,pageSize).ToList();
            }
             
        }
          
        public List<String> InsertOrUpdateCustomer(List<vwCUSINFO> customerList,String username)
        {
            List<String> result = null;
            if (customerList != null && customerList.Count > 0)
            {
                result = new List<string>();
                using (MLSEntities db = new MLSEntities())
                {
                    ObjectParameter CUSCOD = new ObjectParameter("CUSCOD", typeof(String));
                    foreach (vwCUSINFO customer in customerList)
                    {
                        db.InsertOrUpdateCustomer(customer.CPNCOD,
                        customer.CPNBRNCOD,
                        customer.CPNBRNCOD,
                        customer.CUSTTLTHA,
                        customer.CUSNAMTHA,
                        customer.CUSSURTHA,
                        customer.CUSNICNAM,
                        customer.PSNREGIDN,
                        customer.PSNBTHDTE,
                        customer.PSNMTHINC,
                        customer.PSNOTHINC,
                        customer.PSNMARSTS,
                        customer.PSNCHDNUM,
                        customer.PSNSEXCOD,
                        customer.PSNOCCCOD,
                        customer.PSNPOSITN,
                        customer.PSNNETINC,
                        customer.PSNGRSINC,
                        customer.PSNCPNSTF,
                        customer.PSNWRKPLC,
                        customer.PSNWRKPRD,
                        customer.PSNCPNTYP,
                        customer.PSNBTHDAY,
                        customer.PSNEMPLOY_TYP,
                        customer.PSNSALRCVTYP,
                        username,
                        customer.CUSPHNNUM,
                        customer.CUSTTLENG,
                        customer.CUSNAMENG,
                        customer.CUSSURENG,
                        customer.CUSTYPCOD,
                        customer.CUSCRDCOD,
                        customer.CUSLEVCOD,
                        customer.CUSBOTCOD,
                        customer.CUSCRDLNE,
                        customer.CUSBUSCNT,
                        customer.GENTAXNUM,
                        customer.CUS_FINBNKCOD1,
                        customer.CUS_FINBNKBRN1,
                        customer.CUS_FINBNKNUM1,
                        customer.CUS_FINBNKCOD2,
                        customer.CUS_FINBNKBRN2,
                        customer.CUS_FINBNKNUM2,
                        customer.CUS_FINBNKCOD3,
                        customer.CUS_FINBNKBRN3,
                        customer.CUS_FINBNKNUM3,
                        customer.ADRCOD01,
                        customer.ADRCOD02,
                        customer.ADRCOD03,
                        customer.ADRCOD04,
                        customer.ADRCOD05,
                        customer.ADRCOD06,
                        customer.ADRCOD07,
                        customer.ADRCOD08,
                        customer.ADRCOD09,
                        customer.ADRCOD10,
                        customer.CUSCITZEN,
                        customer.CUSNATION,
                        customer.VATREGISTER,
                        customer.CUS_ADRTELNUM,
                        customer.CUSEMAIL,
                        customer.COOPERATE_TYPE,
                        customer.PSNREGSIN,
                        customer.PSNREGEXP,
                        customer.PSNSALDTE,
                        customer.PSNRELTME,
                        customer.CPNREGNUM,
                        customer.CPNBUSTYP,
                        customer.CPNREGDTE,
                        customer.CPNYERINC,
                        customer.CPNYERPRF,
                        customer.REFDOCDTE,
                        customer.CPNCNTPSN,
                        customer.CPNCNTPOS,
                        CUSCOD
                        );

                        foreach (CustomerAddressResult address in customer.AddressList)
                        {

                            InsertOrUpdateAddressResult insertResult = db.InsertOrUpdateAddress(
                                 CUSCOD.Value.ToString(),
                                 address.ADRTYPCOD,
                                 address.ADRREFCOD,
                                 address.ADRCOD,
                                 address.ADRDTLLN1,
                                 address.ADRZIPCOD,
                                 address.ADRCTYCOD,
                                 address.ADRLIVSIN,
                                 address.ADRFAXNUM,
                                 address.ADREMAIL,
                                 address.ADROWNERCOD,
                                 address.ADRDISTRICT,
                                 address.ADRAMPHUR,
                                 address.ADRPROVINCE,
                                 address.ADRTELNUM,
                                 address.ADRMEMBER,
                                 address.TELFRMNUM,
                                 address.TELENDNUM,
                                 address.TELEXTNUM,
                                 username,
                                 address.RECACTCOD).FirstOrDefault();

                            db.InsertOrUpdateTel(address.TELSEQNUM,
                                CUSCOD.Value.ToString(),
                                insertResult.ADRCOD,
                                null,
                                address.ADRTELNUM,
                                address.TELFRMNUM,
                                address.TELENDNUM,
                                address.TELEXTNUM,
                                username,
                                address.RECACTCOD);
                        }
                        result.Add(CUSCOD.Value.ToString());
                    } 
                }
            }
            return result;

        }
    }
}
