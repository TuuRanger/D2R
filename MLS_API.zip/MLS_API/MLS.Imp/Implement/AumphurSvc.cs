﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Imp.Interface;
using MLS.Models;
namespace MLS.Imp.Implement
{
  public  class AumphurSvc : IAumphurSvc
    {
        public List<AumphurByNameResult>  GetAumphurByName(String amphurName)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetAumphurByName(amphurName).ToList(); 
            }
        }

        public List<AmphurByIDResult> GetAumphurByID(int amhurId)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetAmphurByID(amhurId).ToList();
            }
        }

    }
}
