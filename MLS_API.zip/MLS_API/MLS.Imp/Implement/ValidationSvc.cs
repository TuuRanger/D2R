﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Imp.Interface;
using MLS.Models;
using MLS.Helper;

namespace MLS.Imp.Implement
{
    public class ValidationSvc :IValidationSvc
    {
        MLSEntities _db = null; 
        public ValidationSvc()
        {
            _db = new MLSEntities();
        }

        public List<FieldValidateResult>  GetFieldValidation(List<String> listValidateID)
        {
            List<FieldValidateResult> result = null;
            using (MLSEntities db = new MLSEntities())
            {
                String validateXML = "<Root>";
                foreach (String validateID in listValidateID)
                {
                    validateXML += String.Format("<ValidateID><ID>{0}</ID></ValidateID>", validateID);
                }
                validateXML += "</Root>";
                result = db.GetFieldValidate(validateXML).ToList();
            }
            return result;
            //    result.Add(new FieldValidation()
            //    {
            //        FieldID = "txtPSNREGIDN",
            //        Condition = new Dictionary<string, string>() { { "required", "true" } },
            //        Message = new Dictionary<string, string>() { { "required", "VLD001"  } }
            //    });

        }

        public RejectResult GetContractAutoRejectResult(ContractDetailResult contractDetail)
        {
            RejectResult result = null;
          
            result = this._getRejectInternalBlackList(contractDetail.PSNREGIDN);
            if (result != null) return result; 

            result = this._getRejectAge(contractDetail.DeviateAge, contractDetail.PSNBTHDTE);
            if (result != null) return result;


            if (contractDetail.DeviateSalaryAction == Constants.DeviateSalaryAction.AUTO_REJECT)
            {
                result = this._getRejectSalary(contractDetail.DeviateSalary, contractDetail.PSNMTHINC);
                if (result != null) return result;
            }
           

            result = this._getRejectNetIncome(contractDetail.DeviateNetIncome, contractDetail.PSNNETINC);
            if (result != null) return result;


            result = this._getRejectOfficeProvince(contractDetail.AddressList);
            if (result != null) return result;

            result = this._getRejectNCBNotPass(contractDetail.GENAPPNUM);
            if (result != null) return result;


            result = this._getRejectOverCreditLine(contractDetail.ACCCOD,contractDetail.GENAPPNUM,contractDetail.ACCBUSTYP,contractDetail.CONFINAMT.GetValueOrDefault(0));
            if (result != null) return result;  

            
            result = new RejectResult()
            {
                IsReject = false
            };
            return result;
        }

        public bool CheckAccountMaxCreditLine(String ACCBUSTYP,decimal sourceValue)
        {
            SetupResult result = _db.GetSetup("CREDITVALUE" + ACCBUSTYP, "CREDITLINE","N").FirstOrDefault();
            return sourceValue <= result.TABSETAMT1.ToDecimalOrZero();
        }

        public bool CheckAccountMaxCreditPerTime(String ACCBUSTYP, decimal sourceValue)
        {
            SetupResult result = _db.GetSetup("CREDITVALUE" + ACCBUSTYP, "MAXIMUM", "N").FirstOrDefault();
            return sourceValue <= result.TABSETAMT1.ToDecimalOrZero();
        }

        public bool CheckAccountMinCreditPerTime(String ACCBUSTYP, decimal sourceValue)
        {
            SetupResult result = _db.GetSetup("CREDITVALUE" + ACCBUSTYP, "MINIMUM", "N").FirstOrDefault();
            return sourceValue >= result.TABSETAMT1.ToDecimalOrZero();
        }

        public bool CheckAccountMinAdvanceRate(decimal sourceValue)
        {
            SetupResult result = _db.GetSetup("MLSVALUE" , "FACADVRTE", "N").FirstOrDefault();
            return sourceValue >= result.TABSETRTE1.ToDecimalOrZero();
        }


        public bool CheckAccountMaxAdvanceRate(decimal sourceValue)
        {
            SetupResult result = _db.GetSetup("MLSVALUE", "FACADVRTE", "N").FirstOrDefault();
            return sourceValue <= result.TABSETRTE2.ToDecimalOrZero();
        }

        #region private method

        private RejectResult _getRejectInternalBlackList(String ID)
        {
            IInternalBlackListSvc _internalBlackListSvc = new InternalBlackListSvc();
            InternalBlackListResult internalBlackListResult = _internalBlackListSvc.GetInternalBlackList(ID, "AMLO");

            if (internalBlackListResult != null && internalBlackListResult.PSNREGIDN == ID)
            {
                return new RejectResult()
                {
                    IsReject = true,
                    RejectReasonID = "B02"
                };
            }

            return null;
        }

        private RejectResult _getRejectAge(String deviateAgeCode, DateTime? birthDate)
        {
            if (birthDate == null)
                return null;    
            using (MLSEntities db = new MLSEntities())
            {
                SetupResult deviateResult = db.GetSetup("DeviateAge", deviateAgeCode, "N").FirstOrDefault();
                int minValue = deviateResult.TABSETAMT1.GetValueOrDefault(0).ToInt();
                int maxValue = deviateResult.TABSETAMT2.GetValueOrDefault(0).ToInt();
                int currentValue = birthDate.Value.GetAge(DateTime.Now);
                if (currentValue < minValue || currentValue > maxValue)
                {
                    return new RejectResult()
                    {
                        IsReject = true,
                        RejectReasonID = "C01"
                    };
                }
                return null;
            }
        }


        private RejectResult _getRejectSalary(String deviateSalaryCode, decimal? salary)
        {
            if (salary == null)
                return null;
            using (MLSEntities db = new MLSEntities())
            {
                SetupResult deviateResult = db.GetSetup("DeviateNetIncome", deviateSalaryCode, "N").FirstOrDefault();
                int minValue = deviateResult.TABSETAMT1.GetValueOrDefault(0).ToInt();
                int maxValue = deviateResult.TABSETAMT2.GetValueOrDefault(0).ToInt();
                decimal currentValue = salary.Value;
                if (currentValue < minValue || currentValue > maxValue)
                {
                    return new RejectResult()
                    {
                        IsReject = true,
                        RejectReasonID = "E01"
                    };
                }
                return null;
            }
        }

        private RejectResult _getRejectNetIncome(String deviateNetIncomeCode, decimal? netIncome)
        {
            if (netIncome == null)
                return null;

            using (MLSEntities db = new MLSEntities())
            {
                SetupResult deviateResult = db.GetSetup("DeviateNetIncome", deviateNetIncomeCode, "N").FirstOrDefault();
                int minValue = deviateResult.TABSETAMT1.GetValueOrDefault(0).ToInt();
                int maxValue = deviateResult.TABSETAMT2.GetValueOrDefault(0).ToInt();
                decimal currentValue = netIncome.Value;
                if (currentValue < minValue || currentValue > maxValue)
                {
                    return new RejectResult()
                    {
                        IsReject = true,
                        RejectReasonID = "E02"
                    };
                }
                return null;
            }
        }


        private RejectResult _getRejectOfficeProvince(List<CustomerAddressResult> addressList)
        {
            String[] rejectProvinces = { "ยะลา", "ปัตตานี", "นราธิวาส" };
          
            using (MLSEntities db = new MLSEntities())
            { 
                if (addressList != null && addressList.Count > 0)
                {
                    CustomerAddressResult officeAdress = addressList.Where(x => x.ADRTYPCOD == "2").FirstOrDefault();
                    if (officeAdress != null)
                    {
                        if (rejectProvinces.Contains(officeAdress.ADRPROVINCE))
                        {
                            return new RejectResult()
                            {
                                IsReject = true,
                                RejectReasonID = "F01"
                            };
                        } 
                    }
                } 
             
                return null;
            }
              
        }


        private RejectResult _getRejectNCBNotPass(String GENAPPNUM)
        {
            if (GENAPPNUM.IsEmpty())
                return null;
            using (MLSEntities db = new MLSEntities())
            {
                CDMRTNRSL01 result = db.CDMRTNRSL01.Where(x => x.GENAPPNUM == GENAPPNUM).FirstOrDefault();
                if (result != null)
                {
                    if (result.isPassed == "N")
                    {
                        return new RejectResult()
                        {
                            IsReject = true,
                            RejectReasonID = "B03"
                        };
                    }
                }
                return null;
            }

        }

        private RejectResult _getRejectOverCreditLine(
            String ACCCOD, 
            String GENAPPNUM, 
            String ACCBUSTYP,
            decimal CONFINAMT
            )
        { 
            using (MLSEntities db = new MLSEntities())
            {
                CustomerCreditLineResult result = db.GetCustomerCreditLine(ACCCOD,GENAPPNUM.ToStringOrEmpty(), ACCBUSTYP).FirstOrDefault();
                if (result != null)
                {
                    CDMACC acc = db.CDMACCs.Where(x => x.ACCCOD == ACCCOD).FirstOrDefault();
                    if (CONFINAMT > result.CreditAvailable.GetValueOrDefault(0) ||   result.ACTIVATED_CONTRACT_COUNT.GetValueOrDefault(0) >= acc.ACCCRDTIM.GetValueOrDefault(0))
                    {
                        return new RejectResult()
                        {
                            IsReject = true,
                            RejectReasonID = "N08"
                        };
                    } 
                }
                return null;
            }

        }
         


        #endregion

    }
}
