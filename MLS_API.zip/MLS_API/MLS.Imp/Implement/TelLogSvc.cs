﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Imp.Interface;
using MLS.Models;

namespace MLS.Imp.Implement
{
    public class TelLogSvc : ITelLogSvc
    {

        public List<TelListResult> GetTelList(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string CONNUM)
        {
            using (MLSEntities db = new MLSEntities())
            {
                return db.GetTelList(CPNCOD, CPNBRNCOD, ACCBUSTYP, CONNUM).ToList();
            }
        }

        public void InsertOrUpDateTelLog(
            List<TelListResult> telList,
            String CPNCOD, 
            String CPNBRNCOD, 
            String ACCBUSTYP, 
            String CONNUM,
            String username)
        {
            using (MLSEntities db = new MLSEntities())
            {
                foreach (TelListResult item in telList)
                {
                    db.InsertOrUpdateTelLog( CPNCOD,CPNBRNCOD,ACCBUSTYP, CONNUM, item.TELPHNTYP,item.TELPRFCOD,item.RMKCALRSL,item.RMKLEVRSL,item.GENREMARK,username);
                }
               
            }
        }
    }
}
