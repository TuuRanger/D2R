﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Helper
{
    public class TCPHelper
    {
        private Socket _socket = null;
        private NetworkStream _netStream = null;
        public TCPHelper(String IP, int Port)
        {
            _netStream = this.GetConnection(IP,Port);
        }


        public String SendText(String text)
        {
            this.Write(text);
            return this.Read();
        }

        #region private method
        private NetworkStream GetConnection(String IP, int Port)
        {
            IPEndPoint ipEnpoint = new IPEndPoint(IPAddress.Parse(IP), Port);
            if (!_socket.Connected || _socket == null)
            {
                _socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                _socket.Connect(ipEnpoint);
                _netStream = new NetworkStream(_socket);
            }
            return _netStream;
        }

        private void Write(String text)
        {
            StreamWriter sw = new StreamWriter(_netStream, Encoding.Default);
            sw.WriteLine(text);
            sw.Flush();
            sw.Close();
        }

        private String Read()
        {
            StreamReader sr = new StreamReader(_netStream, Encoding.Default);
            String data = sr.ReadToEnd();
            sr.Close();
            return data;
        }
        #endregion


    }
}
