﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Helper
{
    public static class XMLHelper
    {
        public static String ToXml(this Dictionary<String, String> dic)
        {
            String result = "<Root>" ;
            foreach (KeyValuePair<String, String> item in dic)
            {
                result += String.Format("<Item><Key>{0}</Key><Value>{1}</Value></Item>", item.Key, item.Value); 
            }
            result += "</Root>";
            return result;
        }

        public static String ToXml(this Array arr)
        {
            String result = "<Root>";
            foreach (var item in arr)
            {
                result += String.Format("<Item><Value>{0}</Value></Item>", item);
            }
            result += "</Root>";
            return result;
        }

        
        public static string ToXMLFromObject<T>(this T obj)
        {
            if ((obj == null))
            {
                return null;
            }
            PropertyInfo[] props = typeof(T).GetProperties();
            string xmlResult = "<Root>";
            for (int i = 0; i <= props.Length - 1; i++)
            {
                xmlResult = xmlResult + string.Format("<{0}><Value>{1}</Value></{0}>", props[i].Name, props[i].GetValue(obj, null));
            }
            xmlResult = xmlResult + "</Root>";
            return xmlResult;
        }
         
        public static string ToXMLFromList<T>(this List<T> listT)
        {
            if ((listT == null))
            {
                return null;
            }
            PropertyInfo[] props = typeof(T).GetProperties();
            string xmlResult = "<Root>";
            foreach (T item in listT)
            {
                xmlResult = xmlResult + "<Item>";
                for (int i = 0; i <= props.Length - 1; i++)
                {
                    xmlResult = xmlResult + string.Format("<{0}><Value>{1}</Value></{0}>", props[i].Name, props[i].GetValue(item, null));
                }
                xmlResult = xmlResult + "</Item>";
            }

            xmlResult = xmlResult + "</Root>";
            return xmlResult;
        } 



    }
}
