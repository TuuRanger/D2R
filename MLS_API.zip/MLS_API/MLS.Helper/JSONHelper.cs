﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
namespace MLS.Helper
{
    public static class JSONHelper
    {
        public static String ConvertToJsonString(object obj, Formatting formatting = Formatting.None)
        {
            return JsonConvert.SerializeObject(obj, formatting);
        }

        public static T ConvertToObject<T>(String str)
        {
            return JsonConvert.DeserializeObject<T>(str);
        } 
    }
}
