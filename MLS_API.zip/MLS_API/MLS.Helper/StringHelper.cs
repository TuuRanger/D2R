﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Helper
{
    public static class StringHelper
    {
        public static bool IsEmpty(this Object obj)
        {
            if (obj == null)
                return true;

            if (obj.ToStringTrim() == "")
                return true;

            return false;
        }

        public static String ToStringTrim(this Object obj)
        { 
            return obj.ToStringOrEmpty().Trim();
        }

        public static bool IsNotEmpty(this Object obj)
        {
            return !obj.IsEmpty();
        }

        public static String ToStringOrEmpty(this Object obj)
        {
            if (obj == null)
                return "";

            return obj.ToString();
        }

        public static int LetterToNumber(this String letter,bool isZeroBase = false)
        {
            if (letter.IsEmpty())
            {
                throw new ArgumentNullException("columnName");
            }

            letter = letter.ToUpperInvariant();
            int sum = 0;

            for (int i = 0; i < letter.Length; i++)
            {
                sum = sum * 26;
                sum += (letter[i] - 'A' + 1);
            }

            if (isZeroBase) sum--;
            return sum;
        }

        public static bool IsNumeric(this String input)
        {
            decimal result = 0;
            return Decimal.TryParse(input, out result);
        }
    }
}
