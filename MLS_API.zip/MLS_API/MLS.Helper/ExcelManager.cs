﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using NPOI.HSSF.Util;
using NPOI.POIFS.FileSystem;
using NPOI.HPSF;
using NPOI.XSSF.UserModel;
using System.Reflection;
using System.IO;
using NPOI.HSSF.UserModel;

namespace MLS.Helper
{
    public class ExcelManager
    {
        public static List<T>  ReadExcel<T>(String fileName, int sheetIndex, int startRow) where T : new()
        {
            if (Path.GetExtension(fileName) == ".xls")
            {
                return ExcelManager.ReadXls<T>(fileName, sheetIndex, startRow);
            }
            else if (Path.GetExtension(fileName) == ".xlsx")
            {
                return ExcelManager.ReadXlsx<T>(fileName, sheetIndex, startRow);
            }
            else
            {
                throw new Exception(String.Format("Not support file extension, \"{0}\"",fileName));
            }
        }

        private static List<T> ReadXlsx<T>(String fileName, int sheetIndex, int startRow) where T : new()
        {

            sheetIndex--;
            startRow--; 

            if (File.Exists(fileName))
            {
                XSSFWorkbook _wb = null;
                using (FileStream stream = new FileStream(fileName, FileMode.Open, FileAccess.Read))
                {
                    _wb = new XSSFWorkbook(stream);
                }

                ISheet sheet = _wb.GetSheetAt(sheetIndex);
                return ExcelManager.GetSheetObjects<T>(sheet, startRow);
            }
            else
            {
                throw new FileNotFoundException(String.Format("{0} not found", fileName));
            }
        }

        private static List<T> ReadXls<T>(String fileName, int sheetIndex, int startRow) where T : new()
        {

            sheetIndex--;
            startRow--;



            if (File.Exists(fileName))
            {
                HSSFWorkbook _wb = null;
                using (FileStream stream = new FileStream(fileName, FileMode.Open, FileAccess.Read))
                {
                    _wb = new HSSFWorkbook(stream);
                }

                ISheet sheet = _wb.GetSheetAt(sheetIndex);
                return ExcelManager.GetSheetObjects<T>(sheet, startRow);
            }
            else
            {
                throw new FileNotFoundException(String.Format("{0} not found", fileName));
            }
        }

        private static List<T> GetSheetObjects<T>(ISheet sheet, int startRow) where T : new()
        {
            List<T> Result = new List<T>();
            PropertyInfo[] props = typeof(T).GetProperties();
            for (int rowIndex = startRow; rowIndex <= sheet.LastRowNum; rowIndex++)
            {
                T obj = new T();
                IRow row = sheet.GetRow(rowIndex);

                if (row != null)
                {
                    for (int i = 0; i < props.Length; i++)
                    {
                        PropertyInfo prop = props[i];
                        Object[] tmpColumnMapping = prop.GetCustomAttributes(typeof(CustomAttribute.ExcelReadColumnMappingAttribute), true);
                        if (tmpColumnMapping.Length > 0)
                        {
                            CustomAttribute.ExcelReadColumnMappingAttribute columMappingProp = (CustomAttribute.ExcelReadColumnMappingAttribute)tmpColumnMapping.First();
                            ICell cell = row.GetCell(columMappingProp.ColumLetter.LetterToNumber(true));

                            if (cell != null)
                            {
                                ExcelManager.SetObjectProperty<T>(ref obj,prop,cell); 
                            }
                        }

                        Object[] tmpCellMapping = prop.GetCustomAttributes(typeof(CustomAttribute.ExcelReadCellMappingAttribute), true);
                        if (tmpCellMapping.Length > 0)
                        {
                            CustomAttribute.ExcelReadCellMappingAttribute cellMappingProp = (CustomAttribute.ExcelReadCellMappingAttribute)tmpCellMapping.First();

                            if (cellMappingProp.CellName.Length != 2)
                            {
                                throw new Exception(String.Format("Invalid Cell Format \"{0}\"", cellMappingProp.CellName));
                            }

                            int colFixed = cellMappingProp.CellName[0].ToString().LetterToNumber(true);
                            int rowFixed = Convert.ToInt32(cellMappingProp.CellName[1]);
                            ICell cell = sheet.GetRow(rowFixed).GetCell(colFixed);

                            if (cell != null)
                            {
                                ExcelManager.SetObjectProperty<T>(ref obj, prop, cell); 
                            }
                        }
                    }
                }
                Result.Add(obj);
            }

            return Result;
        }
         
        private static void SetObjectProperty<T>(ref T obj,PropertyInfo prop,ICell cell)
        {
            if (prop.PropertyType == typeof(DateTime) || prop.PropertyType == typeof(DateTime?))
            { 
                try
                {
                    DateTime value = cell.DateCellValue;
                    prop.SetValue(obj, value, null);
                }
                catch (InvalidDataException)
                {  }
            }
            else if (prop.PropertyType == typeof(String))
            {
                try
                {
                    String value = cell.StringCellValue;
                    prop.SetValue(obj, value, null);
                }
                catch (InvalidOperationException)
                { 
                    double value = cell.NumericCellValue;
                    prop.SetValue(obj, value.ToString(), null);
                }
            }
            else if (prop.PropertyType == typeof(decimal) || prop.PropertyType == typeof(decimal?))
            {
                double value = 0;
                try
                {
                    value = cell.NumericCellValue;
                }
                catch (InvalidDataException)
                {
                    String stringValue = cell.StringCellValue;
                    if (stringValue.IsNumeric())
                    {
                        value = Convert.ToDouble(stringValue);
                    }
                }
                prop.SetValue(obj, Convert.ToDecimal(value), null);
            }
            else if (prop.PropertyType == typeof(int) || prop.PropertyType == typeof(int?))
            {
                double value = 0;
                try
                {
                    value = cell.NumericCellValue;
                }
                catch (InvalidDataException)
                {
                    String stringValue = cell.StringCellValue;
                    if (stringValue.IsNumeric())
                    {
                        value = Convert.ToDouble(stringValue);
                    }
                }
                prop.SetValue(obj, Convert.ToInt32(value), null);
            }
            else if (prop.PropertyType == typeof(double) || prop.PropertyType == typeof(double?))
            {
                double value = 0;
                try
                {
                    value = cell.NumericCellValue;
                }
                catch (InvalidDataException)
                {
                    String stringValue = cell.StringCellValue;
                    if (stringValue.IsNumeric())
                    {
                        value = Convert.ToDouble(stringValue);
                    }
                }
                prop.SetValue(obj, value, null);
            }
        }
    }
}
