﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
namespace MLS.Helper
{
    public static class FileHelper
    {
        public static void writeTextFile(String path,String content)
        {
            String dir = Path.GetDirectoryName(path);
            if (!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }

            using (StreamWriter write = new StreamWriter(path))
            {
                write.Write(content);
            }
        }
    }
}
