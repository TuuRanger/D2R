﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;

namespace MLS.Helper
{
    public class Constants
    {
        public static String LOG_PATH = "C:/Work/Log";
        public static String APP_PATH = Path.Combine( AppDomain.CurrentDomain.BaseDirectory,"../");
        public static String UPLOAD_PATH = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "../FILE_UPLOADED");
        public static class YesNoFlag
        {
            public const String YES = "Y";
            public const String NO = "N"; 
        }

        public static class CONOBJCOD
        {
            public const String Collaborate = "11";

        }

        public static class TELPHNTYP
        {
            public const string HOME = "H";
            public const string OFFICE = "O";
            public const string MOBILE = "M";
            public const string RELATIVE = "R";
            public const string FAMILY = "F";
            public const string NONE = "N";
        } 
        public static class SalaryReceiveType
        {
            public const  String Transfer    = "01";
            public const  String Cash     = "02";
            public const String Cheq     = "03";
        }

        public static class CooperateType
        {
            public const String GovernmentOfficials = "01";
            public const String BusinessEmployee = "02";
            public const String StateEnterpriseOfficer = "03";
        }

        public static class CashConstantForCooperateType
        {
            public const Decimal GovernmentOfficials = 15000;
            public const Decimal BusinessEmployee = 10000;
        }

        public static class MAXVALUEBY
        {
            public const String PROJECT = "PROJECT";
            public const String PRODUCT = "PRODUCT";
        }

        public static class DeviateSalaryAction
        {
            public const String AUTO_REJECT = "AUTO_REJECT";
            public const String VALIDATE = "VALIDATE";
        }

        public static class NCBConfig
        {
            public static String IP = ConfigurationManager.AppSettings["NCB_IP"];
            public static int Port = Convert.ToInt32(ConfigurationManager.AppSettings["NCB_PORT"]);
            public static String memberCode = Convert.ToString(ConfigurationManager.AppSettings["memberCode"]);
            public static String memberName = Convert.ToString(ConfigurationManager.AppSettings["memberName"]);
            public static String password = Convert.ToString(ConfigurationManager.AppSettings["password"]);
            public static String enquiryPurpose = Convert.ToString(ConfigurationManager.AppSettings["enquiryPurpose"]);
            public static String enquiryAmount = Convert.ToString(ConfigurationManager.AppSettings["enquiryAmount"]);
            public static String detailsFlag = Convert.ToString(ConfigurationManager.AppSettings["detailsFlag"]);
            public static bool isDummyNCBData = Convert.ToBoolean(ConfigurationManager.AppSettings["isDummyNCBData"]);
            public static bool isOfflineTestNCB = Convert.ToBoolean(ConfigurationManager.AppSettings["isOfflineTestNCB"]);
            public static String DummyResultFile = Convert.ToString(ConfigurationManager.AppSettings["DummyResultFileName"]);
        }

        public static class CustomerType
        {
            public static String Individual = "02";
            public static String Jurictic = "01";
        }


        public static class AccountDealWith
        {
            public static String Customer = "CUS";
            public static String Dealer = "DLR";
            public static String Collector = "COL";
            public static String Verifier = "VER"; 
        }
    }
}
