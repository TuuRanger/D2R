﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Helper.CustomAttribute
{
    public class ExcelWriteCellMappingAttribute : Attribute
    { 
       public String CellName { get; set; }

        public ExcelWriteCellMappingAttribute(String CellName)
        {
            this.CellName = CellName;
        } 
    }
}
