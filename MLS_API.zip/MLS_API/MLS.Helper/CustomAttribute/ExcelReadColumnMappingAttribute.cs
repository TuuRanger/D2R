﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Helper.CustomAttribute
{
    public class ExcelReadColumnMappingAttribute : Attribute
    { 
       public String ColumLetter { get; set; }

        public ExcelReadColumnMappingAttribute(String ColumLetter)
        {
            this.ColumLetter = ColumLetter;
        } 
    }
}
