﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Helper
{
    public static class DoubleHelper
    {
        public static Decimal ToDecimal(this Double dec)
        {
            return Convert.ToDecimal(dec);
        }
    }
}
