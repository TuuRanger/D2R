﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Helper
{
    public static class CaculateHelper
    {
  
        public static decimal CalculateTaxByNet(this decimal amount, decimal taxPercent)
        {
            return Math.Round( amount * taxPercent / (100),2);
        }

        public static decimal CalculateTaxByGross(this decimal amount, decimal taxPercent)
        {
            return Math.Round(amount * taxPercent / (100 + taxPercent), 2);
        }
         

    }
}
