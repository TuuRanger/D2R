﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Helper
{
    public static class BooleanHelper
    {
        public static String BoolToYesNoFlag(this bool boolean)
        {
            if (boolean)
            {
               return Constants.YesNoFlag.YES;
            }
            else
            {
                return Constants.YesNoFlag.NO;
            }
        }
         
    }
}
