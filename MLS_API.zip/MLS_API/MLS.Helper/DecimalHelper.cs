﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Helper
{
    public static class DecimalHelper
    {
        public static Double ToDouble(this Decimal dec)
        {
            return Convert.ToDouble(dec);
        }

        public static decimal ToDecimalOrZero(this object val)
        {
            if (val == null)
                return 0;
             
            return Convert.ToDecimal(val.ToString().Replace(",",""));
        }

        public static int ToInt(this Decimal val)
        { 
            return Convert.ToInt32(val);
        }
    }
}
