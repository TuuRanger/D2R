﻿Imports System.Web
Imports Newtonsoft.Json
Imports System.IO
Imports MLS.JMT.Commons.SysConstants
Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Web.Mvc
Imports System.ComponentModel
Imports System.Globalization
Imports Ionic.Zip
Imports System.Web.Mvc.ControllerBase
Imports NPOI.HSSF.UserModel
Imports NPOI.SS.UserModel
Imports MLS.JMT.Commons

Imports NPOI.SS.Util
Imports NPOI.HSSF.Util
Imports NPOI.POIFS.FileSystem
Imports NPOI.HPSF
Imports NPOI.XSSF.UserModel

Public Class ExcelManager
    Public Function ReadExcel(Of T As New)(ByVal fielName As String, ByVal sheetIndex As Integer, ByVal startRow As Integer) As List(Of T)
        Dim props As PropertyInfo() = GetType(T).GetProperties()

        'fielName = "D:\WORK\D2R\MLS\_VERSIONING\21-08-2015\Download All Attachments [FW สรุปยอดขาย S6 Ed]\S6 Edge Jmt Project ผ่อน ตัว ก าร JMT PLUS  วันที่ 15-20.08. 58 .xls"
        Dim sheetIndex2 As Integer = sheetIndex - 1
        Dim startRow2 As Integer = startRow - 1

        Dim ListResult As New List(Of T)

        If (File.Exists(fielName)) Then
            Dim _wb As HSSFWorkbook
            Using file As New FileStream(fielName, FileMode.Open, FileAccess.Read)
                _wb = New HSSFWorkbook(file)
            End Using

            Dim sheet As ISheet = _wb.GetSheetAt(sheetIndex2)
            For row As Integer = startRow2 To sheet.LastRowNum
                Dim obj As New T
                If sheet.GetRow(row) IsNot Nothing Then
                    For i As Integer = 0 To props.Count - 1
                        Dim readFlg As Boolean = False
                        Dim tmpColumnMapping As Object() = props(i).GetCustomAttributes(GetType(CustomAttribute.ExcelReadColumnMappingAttribute), True)
                        If (tmpColumnMapping.Length > 0) Then
                            Dim columMappingProp As CustomAttribute.ExcelReadColumnMappingAttribute = CType(tmpColumnMapping.First, CustomAttribute.ExcelReadColumnMappingAttribute)

                            Dim cell As ICell = sheet.GetRow(row).GetCell(LetterToNumber(columMappingProp.Column, True))
                            If (cell IsNot Nothing) Then
                                If props(i).PropertyType Is GetType(DateTime) OrElse props(i).PropertyType Is GetType(DateTime?) Then
                                    Try
                                        Dim value As DateTime = cell.DateCellValue()
                                        props(i).SetValue(obj, value, Nothing)

                                    Catch ex As InvalidDataException

                                    End Try


                                ElseIf props(i).PropertyType Is GetType(String) Then
                                    Try
                                        Dim value As String = cell.StringCellValue()
                                        props(i).SetValue(obj, value, Nothing)
                                    Catch ex As System.InvalidOperationException
                                        Dim value As Long = cell.NumericCellValue()
                                        props(i).SetValue(obj, value.ToString(), Nothing)
                                    End Try
                                ElseIf props(i).PropertyType Is GetType(Decimal) OrElse props(i).PropertyType Is GetType(Decimal?) Then
                                    Dim value As Decimal = 0.0
                                    Try
                                        value = cell.NumericCellValue()
                                    Catch ex As InvalidOperationException
                                        If (IsNumeric(cell.StringCellValue())) Then
                                            value = Convert.ToDecimal(cell.StringCellValue())
                                        End If
                                    End Try
                                    props(i).SetValue(obj, value, Nothing)
                                ElseIf (props(i).PropertyType Is GetType(Integer) OrElse props(i).PropertyType Is GetType(Integer?)) Then

                                    Dim value As Integer = 0
                                    Try
                                        value = cell.NumericCellValue()
                                    Catch ex As InvalidOperationException
                                        If (IsNumeric(cell.StringCellValue())) Then
                                            value = Convert.ToInt32(cell.StringCellValue())
                                        End If
                                    End Try
                                    props(i).SetValue(obj, value, Nothing)

                                End If
                            End If
                        End If


                        Dim tmpColumnFixed As Object() = props(i).GetCustomAttributes(GetType(CustomAttribute.ExcelReadColumnFixedColumn), True)
                        If (tmpColumnFixed.Length > 0) Then
                            Dim columFixedProp As CustomAttribute.ExcelReadColumnFixedColumn = CType(tmpColumnFixed.First, CustomAttribute.ExcelReadColumnFixedColumn)

                            If 2 <> columFixedProp.Cell.Length Then
                                Throw New Exception(String.Format("Invalid Cell Format ""{0}""", columFixedProp.Cell))
                            End If

                            Dim colFixed As Integer = LetterToNumber(columFixedProp.Cell.Substring(0), True)
                            Dim rowFixed As Integer = Convert.ToInt32(columFixedProp.Cell.Substring(1))

                            Dim cell As ICell = sheet.GetRow(rowFixed).GetCell(colFixed)
                            If (cell IsNot Nothing) Then
                                If props(i).PropertyType Is GetType(DateTime) OrElse props(i).PropertyType Is GetType(DateTime?) Then
                                    Try
                                        Dim value As DateTime = cell.DateCellValue()
                                        props(i).SetValue(obj, value, Nothing)

                                    Catch ex As InvalidDataException

                                    End Try


                                ElseIf props(i).PropertyType Is GetType(String) Then
                                    Try
                                        Dim value As String = cell.StringCellValue()
                                        props(i).SetValue(obj, value, Nothing)
                                    Catch ex As System.InvalidOperationException
                                        Dim value As Long = cell.NumericCellValue()
                                        props(i).SetValue(obj, value.ToString(), Nothing)
                                    End Try

                                ElseIf props(i).PropertyType Is GetType(Decimal) OrElse props(i).PropertyType Is GetType(Decimal?) Then
                                    Dim value As Decimal = 0.0
                                    Try
                                        value = cell.NumericCellValue()
                                    Catch ex As InvalidOperationException
                                        If (IsNumeric(cell.StringCellValue())) Then
                                            value = Convert.ToDecimal(cell.StringCellValue())
                                        End If
                                    End Try
                                    props(i).SetValue(obj, value, Nothing)
                                ElseIf (props(i).PropertyType Is GetType(Integer) OrElse props(i).PropertyType Is GetType(Integer?)) Then

                                    Dim value As Integer = 0
                                    Try
                                        value = cell.NumericCellValue()
                                    Catch ex As InvalidOperationException
                                        If (IsNumeric(cell.StringCellValue())) Then
                                            value = Convert.ToInt32(cell.StringCellValue())
                                        End If
                                    End Try
                                    props(i).SetValue(obj, value, Nothing)

                                End If
                            End If
                        End If
                    Next


                End If

                ListResult.Add(obj)
            Next
        Else
            Throw New FileNotFoundException(String.Format("{0} not found", fielName))
        End If
        Return ListResult

    End Function

    Public Function ReadExcelX(Of T As New)(ByVal fielName As String, ByVal sheetIndex As Integer, ByVal startRow As Integer) As List(Of T)
        Dim props As PropertyInfo() = GetType(T).GetProperties()

        'fielName = "D:\WORK\D2R\MLS\_VERSIONING\21-08-2015\Download All Attachments [FW สรุปยอดขาย S6 Ed]\S6 Edge Jmt Project ผ่อน ตัว ก าร JMT PLUS  วันที่ 15-20.08. 58 .xls"
        sheetIndex = sheetIndex - 1
        startRow = startRow - 1
        Dim ListResult As New List(Of T)

        If (File.Exists(fielName)) Then
            Dim _wb As XSSFWorkbook
            Using file As New FileStream(fielName, FileMode.Open, FileAccess.Read)
                _wb = New XSSFWorkbook(file)
            End Using

            Dim sheet As ISheet = _wb.GetSheetAt(sheetIndex)
            For row As Integer = startRow To sheet.LastRowNum
                Dim obj As New T
                If sheet.GetRow(row) IsNot Nothing Then
                    For i As Integer = 0 To props.Count - 1
                        Dim tmpObj As Object() = props(i).GetCustomAttributes(GetType(CustomAttribute.ExcelReadColumnMappingAttribute), True)
                        If (tmpObj.Length > 0) Then
                            Dim columProp As CustomAttribute.ExcelReadColumnMappingAttribute = CType(tmpObj.First, CustomAttribute.ExcelReadColumnMappingAttribute)
                            Dim cell As ICell = sheet.GetRow(row).GetCell(LetterToNumber(columProp.Column, True))
                            If (cell IsNot Nothing) Then

                                If props(i).PropertyType Is GetType(DateTime) OrElse props(i).PropertyType Is GetType(DateTime?) Then
                                    Try
                                        Dim value As DateTime = cell.DateCellValue()
                                        props(i).SetValue(obj, value, Nothing)

                                    Catch ex As InvalidDataException

                                    End Try


                                ElseIf props(i).PropertyType Is GetType(String) Then
                                    Try
                                        Dim value As String = cell.StringCellValue()
                                        props(i).SetValue(obj, value, Nothing)
                                    Catch ex As System.InvalidOperationException
                                        Dim value As Long = cell.NumericCellValue()
                                        props(i).SetValue(obj, value.ToString(), Nothing)
                                    End Try
                                ElseIf props(i).PropertyType Is GetType(Decimal) OrElse props(i).PropertyType Is GetType(Decimal?) Then
                                    Dim value As Decimal = 0.0
                                    Try
                                        value = cell.NumericCellValue()
                                    Catch ex As InvalidOperationException
                                        If (IsNumeric(cell.StringCellValue())) Then
                                            value = Convert.ToDecimal(cell.StringCellValue())
                                        End If
                                    End Try
                                    props(i).SetValue(obj, value, Nothing)
                                ElseIf (props(i).PropertyType Is GetType(Integer) OrElse props(i).PropertyType Is GetType(Integer?)) Then

                                    Dim value As Integer = 0
                                    Try
                                        value = cell.NumericCellValue()
                                    Catch ex As InvalidOperationException
                                        If (IsNumeric(cell.StringCellValue())) Then
                                            value = Convert.ToInt32(cell.StringCellValue())
                                        End If
                                    End Try
                                    props(i).SetValue(obj, value, Nothing)

                                End If
                            End If
                        End If

                        Dim tmpColumnFixed As Object() = props(i).GetCustomAttributes(GetType(CustomAttribute.ExcelReadColumnFixedColumn), True)
                        If (tmpColumnFixed.Length > 0) Then
                            Dim columFixedProp As CustomAttribute.ExcelReadColumnFixedColumn = CType(tmpColumnFixed.First, CustomAttribute.ExcelReadColumnFixedColumn)

                            If 2 <> columFixedProp.Cell.Length Then
                                Throw New Exception(String.Format("Invalid Cell Format ""{0}""", columFixedProp.Cell))
                            End If

                            Dim colFixed As Integer = LetterToNumber(columFixedProp.Cell(0), True)
                            Dim rowFixed As Integer = Convert.ToInt32(columFixedProp.Cell(1).ToString()) - 1

                            Dim cell As ICell = sheet.GetRow(rowFixed).GetCell(colFixed)
                            If (cell IsNot Nothing) Then
                                If props(i).PropertyType Is GetType(DateTime) OrElse props(i).PropertyType Is GetType(DateTime?) Then
                                    Try
                                        Dim value As DateTime = cell.DateCellValue()
                                        props(i).SetValue(obj, value, Nothing)

                                    Catch ex As InvalidDataException

                                    End Try


                                ElseIf props(i).PropertyType Is GetType(String) Then
                                    Try
                                        Dim value As String = cell.StringCellValue()
                                        props(i).SetValue(obj, value, Nothing)
                                    Catch ex As System.InvalidOperationException
                                        Dim value As Long = cell.NumericCellValue()
                                        props(i).SetValue(obj, value.ToString(), Nothing)
                                    End Try

                                ElseIf props(i).PropertyType Is GetType(Decimal) OrElse props(i).PropertyType Is GetType(Decimal?) Then
                                    Dim value As Decimal = 0.0
                                    Try
                                        value = cell.NumericCellValue()
                                    Catch ex As InvalidOperationException
                                        If (IsNumeric(cell.StringCellValue())) Then
                                            value = Convert.ToDecimal(cell.StringCellValue())
                                        End If
                                    End Try
                                    props(i).SetValue(obj, value, Nothing)
                                ElseIf (props(i).PropertyType Is GetType(Integer) OrElse props(i).PropertyType Is GetType(Integer?)) Then

                                    Dim value As Integer = 0
                                    Try
                                        value = cell.NumericCellValue()
                                    Catch ex As InvalidOperationException
                                        If (IsNumeric(cell.StringCellValue())) Then
                                            value = Convert.ToInt32(cell.StringCellValue())
                                        End If
                                    End Try
                                    props(i).SetValue(obj, value, Nothing)

                                End If
                            End If
                        End If


                    Next


                End If

                ListResult.Add(obj)
            Next
        Else
            Throw New FileNotFoundException(String.Format("{0} not found", fielName))
        End If
        Return ListResult

    End Function

    Public Sub WriteExcel(Of T As New)(listData As List(Of T), ByVal fielName As String, ByVal sheetName As String, ByVal startRow As Integer)
        Dim props As PropertyInfo() = GetType(T).GetProperties()

        'fielName = "D:\WORK\D2R\MLS\_VERSIONING\21-08-2015\Download All Attachments [FW สรุปยอดขาย S6 Ed]\S6 Edge Jmt Project ผ่อน ตัว ก าร JMT PLUS  วันที่ 15-20.08. 58 .xls"

        startRow = startRow - 1

        Dim _wb As HSSFWorkbook
        _wb = New HSSFWorkbook()
        Dim sheet As ISheet = _wb.CreateSheet(sheetName)

        Dim obj As New T
        For i As Integer = 0 To listData.Count - 1
            Dim row As IRow = sheet.CreateRow(i + startRow)
            For j As Integer = 0 To props.Count - 1
                Dim tmpObj As Object() = props(j).GetCustomAttributes(GetType(CustomAttribute.ExcelWriteColumnMappingAttribute), True)
                If (tmpObj.Length > 0) Then
                    Dim columProp As CustomAttribute.ExcelWriteColumnMappingAttribute = CType(tmpObj.First, CustomAttribute.ExcelWriteColumnMappingAttribute)
                    Dim cell As ICell = row.CreateCell(LetterToNumber(columProp.Column, True))
                    Dim value As Object = props(j).GetValue(listData(i), Nothing)

                    If (value IsNot Nothing) Then
                        If props(j).PropertyType Is GetType(DateTime) OrElse props(j).PropertyType Is GetType(DateTime?) Then
                            cell.SetCellValue(DirectCast(value, DateTime).ToString("dd-MM-yyyy"))
                        ElseIf props(j).PropertyType Is GetType(String) Then
                            cell.SetCellValue(DirectCast(value, String))
                        ElseIf props(j).PropertyType Is GetType(Decimal) OrElse props(j).PropertyType Is GetType(Decimal?) Then
                            cell.SetCellValue(DirectCast(value, Decimal))
                        ElseIf props(j).PropertyType Is GetType(Integer?) OrElse props(j).PropertyType Is GetType(Integer) Then
                            cell.SetCellValue(DirectCast(value, Integer))
                        End If
                    End If
                End If
            Next
        Next

        Using fileData As New FileStream(fielName, FileMode.Create)
            _wb.Write(fileData)
        End Using

    End Sub


    Public Sub WriteExcelWithoutCreate(Of T As New)(listData As List(Of T), ByVal fielName As String, ByVal sheetName As String, ByVal startRow As Integer)
        Dim props As PropertyInfo() = GetType(T).GetProperties()

        startRow = startRow - 1

        Dim _wb As HSSFWorkbook
        Using file As New FileStream(fielName, FileMode.Open, FileAccess.Read)
            _wb = New HSSFWorkbook(file)
            file.Close()
        End Using

        Dim sheet As ISheet = _wb.GetSheet(sheetName)


        Dim obj As New T
        For i As Integer = 0 To listData.Count - 1
            Dim row As IRow = sheet.CreateRow(i + startRow)
            For j As Integer = 0 To props.Count - 1
                Dim tmpObj As Object() = props(j).GetCustomAttributes(GetType(CustomAttribute.ExcelWriteColumnMappingAttribute), True)
                If (tmpObj.Length > 0) Then
                    Dim columProp As CustomAttribute.ExcelWriteColumnMappingAttribute = CType(tmpObj.First, CustomAttribute.ExcelWriteColumnMappingAttribute)
                    Dim cell As ICell = row.CreateCell(LetterToNumber(columProp.Column, True))
                    Dim value As Object = props(j).GetValue(listData(i), Nothing)

                    If (value IsNot Nothing) Then
                        If props(j).PropertyType Is GetType(DateTime) Or props(j).PropertyType Is GetType(DateTime?) Then
                            cell.SetCellValue(DirectCast(value, DateTime).ToString("dd-MM-yyyy"))
                        ElseIf props(j).PropertyType Is GetType(String) Then
                            cell.SetCellValue(DirectCast(value, String))
                        ElseIf props(j).PropertyType Is GetType(Decimal) OrElse props(j).PropertyType Is GetType(Decimal?) Then
                            cell.SetCellValue(DirectCast(value, Decimal))
                        ElseIf props(j).PropertyType Is GetType(Integer) OrElse props(j).PropertyType Is GetType(Integer?) Then
                            cell.SetCellValue(DirectCast(value, Integer))
                        End If
                    End If
                    'sheet.AutoSizeColumn(LetterToNumber(columProp.Column, True), False)
                End If
            Next
        Next
        Using fileData As New FileStream(fielName, FileMode.Open, FileAccess.Write)
            _wb.Write(fileData)
        End Using

    End Sub

End Class
