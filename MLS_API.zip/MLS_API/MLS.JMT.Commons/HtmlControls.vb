﻿Imports System.Web
Imports System.Web.Mvc
Imports System.Linq.Expressions
Imports System.Reflection
Imports System.IO
Imports MLS.JMT.Commons.Utils
Public Class HtmlControls
    Private Const col_lg As String = "col-lg"
    Private Const col_sm As String = "col-sm"
    Private Const col_md As String = "col-md"
    Private Const FieldContainerColWidth = col_sm & "-4"
    Private Const FieldLabelColWidth = col_sm & "-6"
    Private Const FieldInputColWidth = col_sm & "-6"
    Private Const FieldInputWithIconColWidth = col_sm & "-5"
    Private Const FieldInputIconColWidth = col_sm & "-1"
    Public Shared Function CommonTextBoxClass(ByVal ParamArray keyValCollection() As HtmlKeyVal) As Dictionary(Of String, Object)
        Dim dic As New Dictionary(Of String, Object) From {{"class", "form-control"}}
        For Each keyVal As HtmlKeyVal In keyValCollection
            dic.Add(keyVal.Key, keyVal.Val)
        Next
        Return dic
    End Function

    Public Shared Function CommonTextBoxStep(ByVal stepNo As Integer, ByVal ParamArray keyValCollection() As HtmlKeyVal) As Dictionary(Of String, Object)
        Dim dic As New Dictionary(Of String, Object) From {{"class", "form-control"}}
        dic.Add("data-remark", "")
        dic.Add("data-step", stepNo)

        For Each keyVal As HtmlKeyVal In keyValCollection
            dic.Add(keyVal.Key, keyVal.Val)
        Next
        Return dic
    End Function


    Public Shared Function GetbtnSubmitAndNewNCB(ByVal stepNo As Integer, ByVal ActualStep As Integer) As IHtmlString
        Dim buttonAlias As String = "btnSubmitAndNewNCB"
        Return New HtmlString(String.Format("<button id='{1}_{0}' type='button' onclick='OnPending(""1"")' " & _
                                             " name='Button' class='btn btn-success' style='width:150px'> " & _
                                             " <i class='fa fa-plus-circle fa-lg'></i> Submit & New </button>", stepNo, buttonAlias))
    End Function

    Public Shared Function GetbtnCheckCondition(ByVal stepNo As Integer, ByVal ActualStep As Integer) As IHtmlString

        Dim buttonAlias As String = "btnCheckCondition"

        Return New HtmlString(String.Format("<button id='{2}_{1}' type='button' onclick='ShowModalConfirmNCB(""save"",""{2}"")' " & _
                                             " name='Button' class='btn btn-default' style='width:200px'> " & _
                                             " <i class='fa fa-check-circle fa-lg'></i> Check Condition & NCB </button>", stepNo, ActualStep, buttonAlias))
    End Function
    Public Shared Function GetbtnSubmitAndNextNCB(ByVal stepNo As Integer, ByVal ActualStep As Integer) As IHtmlString
        Dim buttonAlias As String = "btnSubmitAndNextNCB"
        Return New HtmlString(String.Format("<button id='{1}_{0}' type='button' onclick='ShowModalConfirmNCB(""next"",""{1}"")' " & _
                                            " name='Button' class='btn btn-primary' style='width:150px'> " & _
                                            " <i class='fa fa-chevron-circle-right fa-lg'></i> Submit & Next</button>", stepNo, buttonAlias))
    End Function


    Public Shared Function GetbtnSubmitAndNext(ByVal stepNo As Integer, ByVal ActualStep As Integer) As IHtmlString
        Return New HtmlString(String.Format("<button id='btnSubmitAndNext_{0}' type='button' onclick='SubmitForm(""next"",""{0}"")' name='Button' class='btn btn-primary' style='width:150px'><i class='fa fa-chevron-circle-right fa-lg'></i> Submit & Next</button>", stepNo))
    End Function

    Public Shared Function GetbtnPreviewCreditLimint(ByVal stepNo As Integer) As IHtmlString
        Return New HtmlString(String.Format("<button type='button' id='btnPreviewCreditLimint{0}' onclick='SubmitForm(""next"",""{0}"")' name='Button' class='btn btn-primary' style='width:150px'><i class='fa fa-chevron-circle-right fa-lg'></i> Confirm Credit Limit </button>", stepNo))
    End Function

    Public Shared Function GetbtnSubmit() As IHtmlString
        Return New HtmlString("<button type='button' onclick='SubmitForm(""return"")' name='Button' class='btn btn-success' style='width:150px'> <i class='fa fa-check-circle fa-lg'></i> Submit </button>")
    End Function

    Public Shared Function GetbtnSubmitAndNew(ByVal stepNo As Integer, ByVal ActualStep As Integer) As IHtmlString
        Return New HtmlString(String.Format("<button type='button' onclick='OnPending(""{0}"")' name='Button' class='btn btn-success' style='width:150px'> <i class='fa fa-plus-circle fa-lg'></i> Submit & New </button>", ActualStep))
        'Return New HtmlString(String.Format("<button type='button' onclick='SubmitForm(""new"",""{0}"")' name='Button' class='btn btn-success' style='width:150px'> <i class='fa fa-plus-circle fa-lg'></i> Submit & New </button>", ActualStep))
    End Function

    Public Shared Function GetbtnSave(ByVal stepNo As Integer) As IHtmlString
        Dim buttonAlias As String = "btnSave"
        Return New HtmlString(String.Format("<button type='button' onclick='OnPending(""{0}"")' id='{1}_{0}' name='{1}_{0}' class='btn btn-success' style='width:150px'> <i class='fa fa-floppy-o fa-lg'></i> Save </button>", stepNo, buttonAlias))
    End Function

    Public Shared Function GetbtnSaveCommon(OnClick As String) As IHtmlString
        Return New HtmlString(String.Format("<button type='button' onclick='{0}' name='Button' class='btn btn-success' style='width:150px'> <i class='fa fa-floppy-o fa-lg'></i> Save </button>", OnClick))
    End Function

    Public Shared Function GetbtnSaveAndCloseModal(ByVal stepNo As Integer) As IHtmlString
        Return New HtmlString(String.Format("<button type='button' onclick='SubmitForm(""{0}"",""{1}"")' name='Button' class='btn btn-success' style='width:150px'> <i class='fa fa-floppy-o fa-lg'></i> Save </button>", SysConstants.SubmitFormAction.SaveCloseModal, stepNo))
    End Function


    Public Shared Function GetbtnSaveAndCloseModalForJudgment(ByVal stepNo As Integer) As IHtmlString
        Return New HtmlString(String.Format("<button type='button' onclick='SubmitForm(""{0}"",""{1}"")' name='Button' class='btn btn-success' style='width:150px'> <i class='fa fa-floppy-o fa-lg'></i> Save & Close </button>", SysConstants.SubmitFormAction.SaveCloseModalForJudgment, stepNo))
    End Function

    Public Shared Function GetbtnSaveFullFill(ByVal stepNo As Integer) As IHtmlString
        Return New HtmlString(String.Format("<button type='button' onclick='InsertOrUpdateFullFill()' name='Button' class='btn btn-success' style='width:150px'> <i class='fa fa-floppy-o fa-lg'></i> Save </button>", stepNo))
    End Function

    Public Shared Function GetbtnSaveForJudgment(ByVal stepNo As Integer) As IHtmlString
        Dim html As String = ""
        html = html & String.Format("<button id='btnJudgSave{0}' style='width:100px;display:none' type='button' onclick='SubmitForm(""savejudgment"",""{0}"")' name='Button' class='btn btn-default'> <i class='fa fa-floppy-o fa-lg'></i> Save </button>", stepNo)
        Return New HtmlString(html)
    End Function

    Public Shared Function GetbtnExit(ByVal stepNo As Integer) As IHtmlString
        Dim onClick As String = String.Format("Exit({0})", stepNo)
        If stepNo = 7 Then onClick = "ExitFullFill()"
        Return New HtmlString(String.Format("<button type='button' onclick='{0}' class='btn btn-default exit' style='width:100px'> <i class='fa fa-sign-out fa-lg'></i> Exit</button>", onClick))
    End Function

    Public Shared Function GetbtnEdit(ByVal stepNo As Integer) As IHtmlString
        Return New HtmlString(String.Format("<button id='btnJudgEdit{0}' type='button' onclick='EditFor(this,{0})' class='btn btn-warning exit' style='width:100px'> <i class='fa fa-pencil fa-lg'></i> Edit</button>", stepNo))
    End Function

    Public Shared Function GetbtnApplicationProcessOperation(ByVal stepNo As Integer, ByVal currentStep As Integer) As IHtmlString

        Dim btnSubmitAndNew As HtmlString = GetbtnSubmitAndNew(stepNo, currentStep)
        Dim btnSubmitAndNext As HtmlString = GetbtnSubmitAndNext(stepNo, currentStep)
        Dim btnExit As HtmlString = GetbtnExit(stepNo)

        Return New HtmlString("<div id='oprBtn" & stepNo & "'  style='width: 460px;  margin:auto'>" _
                              & btnSubmitAndNew.ToString() & " " _
                              & btnSubmitAndNext.ToString() & " " _
                              & btnExit.ToString() &
                              "</div>")
    End Function

    'Public Shared Function GetbtnCollaborateOperation(ByVal stepNo As Integer, ByVal currentStep As Integer) As IHtmlString

    '    Dim btnSubmitAndNew As HtmlString = GetbtnSubmitAndNewNCB(stepNo, currentStep)
    '    Dim btnSubmitAndNext As HtmlString = GetbtnSubmitAndNextNCB(stepNo, currentStep)
    '    Dim btnReject As HtmlString = GetbtnReject(stepNo)
    '    Dim btnCancel As HtmlString = GetbtnCancel(stepNo)
    '    Dim btnExit As HtmlString = GetbtnExit(stepNo)
    '    Dim btnSave As HtmlString = GetbtnSave(currentStep)

    '    Dim set1 As String = "<div class='row' id='oprBtn" & stepNo & "'  style='width: 305px;  margin:auto'>" _
    '                         & btnSubmitAndNew.ToString() & " " _
    '                         & btnSubmitAndNext.ToString() & "</div>"

    '    Dim set2 As String = "<div class='row' id='oprBtn" & stepNo & "'  style='width: 565px;  margin:auto'>" _
    '                          & btnSave.ToString() & " " _
    '                          & btnReject.ToString() & " " _
    '                          & btnCancel.ToString() & " " _
    '                          & btnExit.ToString() & "</div>"

    '    Return New HtmlString(set1 & GetBlankRow().ToString() & set2)
    '    'Return New HtmlString("<div id='oprBtn" & stepNo & "'  style='width: 910px;  margin:auto'>" _
    '    '                      & btnSubmitAndNew.ToString() & " " _
    '    '                      & btnSubmitAndNext.ToString() & "<br>" _
    '    '                      & btnSave.ToString() & " " _
    '    '                      & btnReject.ToString() & " " _
    '    '                      & btnCancel.ToString() & " " _
    '    '                      & btnExit.ToString() & "</div>")
    'End Function

    Public Shared Function GetbtnCollaborateOperation(ByVal stepNo As Integer, ByVal currentStep As Integer, ByVal hasCheckedNCB As String) As IHtmlString

        Dim btnCheckCondition As HtmlString = GetbtnCheckCondition(stepNo, currentStep)
        Dim btnSubmitAndNext As HtmlString = GetbtnSubmitAndNextNCB(stepNo, currentStep)

        Dim set1Width = "355px"


        Dim btnReject As HtmlString = GetbtnReject(stepNo, 7)
        Dim btnCancel As HtmlString = GetbtnCancel(stepNo, 7)
        Dim btnExit As HtmlString = GetbtnExit(stepNo)
        Dim btnSave As HtmlString = GetbtnSave(currentStep)

        Dim set1 As String = String.Format("<div class='row' id='oprBtn" & stepNo & "'  style='width: {0};  margin:auto'>" _
                             & btnCheckCondition.ToString() & " " _
                             & btnSubmitAndNext.ToString() & "</div>", set1Width)

        Dim set2 As String = "<div class='row' id='oprBtn" & stepNo & "'  style='width: 565px;  margin:auto'>" _
                              & btnSave.ToString() & " " _
                              & btnReject.ToString() & " " _
                              & btnCancel.ToString() & " " _
                              & btnExit.ToString() & "</div>"

        Return New HtmlString(set1 & GetBlankRow().ToString() & set2)
    End Function

    'Public Shared Function GetbtnApplicationProcessOperation(ByVal stepNo As Integer, ByVal currentStep As Integer) As IHtmlString

    '    Dim btnSubmitAndNew As HtmlString = GetbtnSubmitAndNew(stepNo, currentStep)
    '    Dim btnSubmitAndNext As HtmlString = GetbtnSubmitAndNext(stepNo, currentStep)
    '    Dim btnExit As HtmlString = GetbtnExit(stepNo)

    '    Return New HtmlString("<div id='oprBtn" & stepNo & "'  style='width: 460px;  margin:auto'>" _
    '                          & btnSubmitAndNew.ToString() & " " _
    '                          & btnSubmitAndNext.ToString() & " " _
    '                          & btnExit.ToString() & "</div>")
    'End Function

    Public Shared Function GetButton(ByVal id As String, ByVal onclick As String, ByVal text As String, Optional width As Integer = 150, Optional btnClass As String = "btn-default") As IHtmlString
        Return New HtmlString(String.Format("<button id='{0}' type='button' onclick='{1}' name='Button' class='btn {2}' style='width:{4}px'>  {3} </button>", id, onclick, btnClass, text, width))
    End Function

    Public Shared Function GetbtnSubmitCheckNCB(ByVal stepNo As Integer, ByVal currentStep As Integer) As IHtmlString

        Dim btnSubmitAndNew As HtmlString = GetbtnSubmitAndNewNCB(stepNo, currentStep)
        Dim btnSubmitAndNext As HtmlString = GetbtnSubmitAndNextNCB(stepNo, currentStep)
        Dim btnExit As HtmlString = GetbtnExit(stepNo)

        Return New HtmlString("<div id='oprBtn" & stepNo & "'  style='width: 460px;  margin:auto'>" _
                              & btnSubmitAndNew.ToString() & " " _
                              & btnSubmitAndNext.ToString() & " " _
                              & btnExit.ToString() & "</div>")

    End Function


    Public Shared Function GetbtnFullFill() As IHtmlString

        Dim btnSave As HtmlString = GetbtnSaveFullFill(7)
        Dim btnExit As HtmlString = GetbtnExit(7)

        Return New HtmlString("<div id='oprBtn" & 7 & "'  style='width: 260px;  margin:auto'>" & btnSave.ToString() & " " & btnExit.ToString & "</div>")

    End Function

    Public Shared Function GetbtnPreviewCreditForVerify(ByVal stepNo As Integer, ByVal currentStep As Integer) As IHtmlString

        Dim btnApprove As HtmlString = GetbtnApprove(stepNo)
        Dim btnReject As HtmlString = GetbtnReject(stepNo)
        Dim btnCancel As HtmlString = GetbtnCancel(stepNo)

        Return New HtmlString("<div id='oprApprove" & stepNo & "'  style='width: 470px;  margin:auto'>" & btnApprove.ToString() & " " & btnReject.ToString & " " & btnCancel.ToString & "</div>")

    End Function

    Public Shared Function GetbtnContracInfo(ByVal stepNo As Integer) As IHtmlString
        Dim btnSubmit As HtmlString = GetbtnSubmit()
        Dim btnExit As HtmlString = GetbtnExit(stepNo)

        Return New HtmlString("<div id='oprBtn" & stepNo & "' style='width: 260px;  margin:auto'>" & _
                              btnSubmit.ToString() & " " & btnExit.ToString & "</div>")

    End Function

    Public Shared Function GetbtnConfirm(ByVal stepNo As Integer) As IHtmlString
        Return New HtmlString(String.Format("<button id='btnConfirm{0}' style='width:100px' type='button' onclick='OnConfirm({0})' class='btn btn-success'> <i class='fa fa-check-circle fa-lg'></i> Confirm </button>", stepNo))
    End Function

    Public Shared Function GetbtnSendBack(ByVal stepNo As Integer) As IHtmlString
        Return New HtmlString(String.Format("<button id='btnSendback{0}' style='width:100px' type='button' onclick='OnSendBack(" & stepNo & ")' class='btn btn-danger'> <i class='fa fa-arrow-circle-left  fa-lg'></i> Sendback </button>", stepNo))
    End Function

    Public Shared Function GetbtnJudgementOpertion(ByVal stepNo As Integer) As IHtmlString
        Dim btnSendBack = GetbtnSendBack(stepNo).ToString()
        Dim btnEdit = GetbtnEdit(stepNo).ToString()
        Dim btnConfirm = GetbtnConfirm(stepNo).ToString()
        Dim btnSave = GetbtnSaveForJudgment(stepNo).ToString()
        Return New HtmlString("<div id='oprBtn" & stepNo & "' style='width: 420px;  margin:auto'>" & btnSendBack & " " & btnSave & " " & btnEdit & " " & btnConfirm & "</div>")
    End Function

    Public Shared Function GetbtnOperationSaveAndCloseModal(ByVal stepNo As Integer) As IHtmlString
        Dim btnClose = GetbtnCloseModal().ToString()
        Dim btnSave = GetbtnSaveAndCloseModal(stepNo).ToString()
        Return New HtmlString("<div id='oprBtnSaveAndCloseModal" & stepNo & "' style='width: 270px;  margin:auto'>" & btnSave & " " & btnClose & "</div>")
    End Function


    Public Shared Function GetbtnOperationSaveAndCloseModalForJudgment(ByVal stepNo As Integer) As IHtmlString
        Dim btnClose = GetbtnCloseModal().ToString()
        Dim btnSave = GetbtnSaveAndCloseModalForJudgment(stepNo).ToString()
        Return New HtmlString("<div id='oprBtnSaveAndCloseModalForJudgment" & stepNo & "' style='width: 270px;  margin:auto'>" & btnSave & " " & btnClose & "</div>")
    End Function

    Public Shared Function GetLinkCusInfo(CPNCOD As String, CPNBRNCOD As String, ACCBUSTYP As String, GENAPPNUM As String, ByVal CusFullName As String) As IHtmlString
        Dim controllerUrl As String = Commons.SysConstants.CommonConstants.SITE_URL & "/Commons/ModalCusInfo"
        Return New HtmlString("<a style='cursor:pointer' onclick='ShowCusInfo(""" & controllerUrl & """,""" & CPNCOD & """,""" & CPNBRNCOD & """,""" & ACCBUSTYP & """,""" & GENAPPNUM & """)' style='width: 205px;  margin:auto'>" & CusFullName & "</a>")
    End Function
    Public Shared Function GetbtnCloseModal() As IHtmlString
        Return New HtmlString("<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>")
    End Function


    Public Shared Function GetbtnApprove(ByVal stepNo As Integer, Optional nextStep As Integer? = Nothing) As IHtmlString
        Return New HtmlString(String.Format("<button id='{1}' type='button' onclick='SubmitForm(""tojudg"",{0},5)' name='Button' class='btn btn-success' style='width:150px'> <i class='fa fa-check-circle fa-lg'></i> Approve </button>", stepNo, "btnApprove" & stepNo))
    End Function

    Public Shared Function GetbtnCancel(ByVal stepNo As Integer, Optional nextStep As Integer? = Nothing) As IHtmlString
        If nextStep Is Nothing Then
            nextStep = 6
        End If
        Return New HtmlString(String.Format("<button id='btnCancel{0}' type='button' onclick='OnCancel(""{0}"",""{1}"")' name='Button' class='btn btn-default' style='width:150px'> <i class='fa fa-times fa-lg'></i> Cancel </button>", stepNo, nextStep))
    End Function

    Public Shared Function GetbtnReject(ByVal stepNo As Integer, Optional nextStep As Integer? = Nothing) As IHtmlString
        If nextStep Is Nothing Then
            nextStep = 6
        End If
        Return New HtmlString(String.Format("<button id='btnReject{0}' type='button' onclick='OnReject(""{0}"",""{1}"")' name='Button' class='btn btn-danger' style='width:150px'> <i class='fa fa-times fa-lg'></i> Reject </button>", stepNo, nextStep))
    End Function

    Public Shared Function GetbtnVerify() As IHtmlString
        'Dim btnSubmitAndNew As HtmlString = GetbtnSubmitAndNew(5)
        Dim btnConfirmCreditLimint As HtmlString = GetbtnPreviewCreditLimint(5)
        Dim btnExit As HtmlString = GetbtnExit(5)

        Return New HtmlString("<div id='oprBtn" & 5 & "'  style='width: 260px;  margin:auto'>" & btnConfirmCreditLimint.ToString & " " & btnExit.ToString & "</div>")

        'Dim btnApprove As HtmlString = GetbtnApprove()
        'Dim btnReject As HtmlString = GetbtnReject()
        'Dim btnCancel As HtmlString = GetbtnCancel()
        'Return New HtmlString("<div  style='width: 460px;  margin:auto'>" & _
        '                      btnApprove.ToString() & " " & _
        '                      btnReject.ToString & " " & _
        '                      btnCancel.ToString & "</div>")
    End Function

    Private Shared Function GenerateProperty(ByVal ParamArray keyValCollection() As HtmlKeyVal) As String
        If (keyValCollection IsNot Nothing) Then
            If (keyValCollection.Length > 0) Then
                Dim propString As String = ""
                For Each item As HtmlKeyVal In keyValCollection
                    propString = propString & String.Format(" {0} = '{1}' ", item.Key, item.Val)
                Next
                Return propString
            End If
        End If
        Return ""
    End Function

    Public Shared Function GetPasswordField(Of TModel, TProperty) _
        (source As TModel, expression As System.Linq.Expressions.Expression(Of System.Func(Of TModel, TProperty)), _
         ByVal label As String, _
         ByVal ParamArray keyValCollection() As HtmlKeyVal) As IHtmlString

        Dim propName As String = ""
        Dim value As String = ""
        If TypeOf expression.Body Is MemberExpression Then
            propName = DirectCast(expression.Body, MemberExpression).Member.Name
        Else
            Dim op = DirectCast(expression.Body, UnaryExpression).Operand
            propName = DirectCast(op, MemberExpression).Member.Name

        End If

        If (source IsNot Nothing) Then
            Dim prop As PropertyInfo = source.GetType().GetProperty(propName)
            value = prop.GetValue(source, Nothing)
        End If


        Dim html As String = String.Format("<div class='{0}'>", FieldLabelColWidth)
        html = html & String.Format("<label class='control-label'> {0} </label>", label)
        html = html & "</div>"
        html = html & String.Format("<div class='form-group input-group {0}'>", FieldInputColWidth)
        html = html & String.Format("<input type='password' class='input-sm form-control' {0} name='{1}' id='{1}' value='{2}' />", GenerateProperty(keyValCollection), propName, value)
        html = html & "</div>"

        Return GetBoostrapColContainer("", html, Nothing)
    End Function

    Public Shared Function GetTextBoxFromTo(
         ByVal nameIDFrom As String, _
          ByVal nameIDTo As String, _
         ByVal label As String, _
          ByVal valueFrom As String, _
              ByVal valueTo As String, _
         ByVal labelColWidth As Integer?, _
         ByVal inputWidthPercent As Integer?, _
         ByVal containerColWidth As Integer?, _
         ByVal ParamArray keyValCollection() As HtmlKeyVal)

        Dim strlbColWidth As String = FieldLabelColWidth
        Dim strInpuColWidth As String = FieldInputColWidth
        If (labelColWidth IsNot Nothing) Then
            strlbColWidth = col_sm & "-" & labelColWidth
        End If


        Dim html As String = String.Format("<div class='{0}'>", strlbColWidth)
        html = html & String.Format("<label class='control-label'> {0} </label>", label)
        html = html & "</div>"
        'From 
        html = html & String.Format("<div class='form-group input-group' style='float:left;width:{0}%'>", inputWidthPercent)
        html = html & String.Format("<input type='text' name='{0}' id='{0}' value='{1}' class='form-control input-sm'>", nameIDFrom, valueFrom)
        html = html & "</div>"

        html = html & "<div class='form-group input-group  ' style='float:left;width:5%;text-align: center;'> - </div>"

        'To
        html = html & String.Format("<div class='form-group input-group' style='float:left;width:{0}%'>", inputWidthPercent)
        html = html & String.Format("<input type='text'  name='{0}' id='{0}' value='{1}' class='form-control input-sm'>", nameIDTo, valueTo)
        html = html & "</div>"


        Return GetBoostrapColContainer(nameIDFrom, html, containerColWidth)

    End Function

    Public Shared Function GetTextField(nameID As String, _
         ByVal label As String, _
         ByVal value As String, _
         ByVal labelColWidth As Integer?, _
         ByVal InputColWidth As Integer?, _
         ByVal containerColWidth As Integer?, _
         ByVal ParamArray keyValCollection() As HtmlKeyVal) As IHtmlString


        Dim strlbColWidth As String = FieldLabelColWidth
        Dim strInpuColWidth As String = FieldInputColWidth
        If (labelColWidth IsNot Nothing) Then
            strlbColWidth = col_sm & "-" & labelColWidth
        End If

        If (InputColWidth IsNot Nothing) Then
            strInpuColWidth = col_sm & "-" & InputColWidth
        End If

        Dim classVal As String = GetClassProperty(keyValCollection)



        Dim html As String = String.Format("<div class='{0}'>", strlbColWidth)
        html = html & String.Format("<label id='div{1}LabelContainer' class='control-label'> {0} </label>", label, nameID)
        html = html & "</div>"
        html = html & String.Format("<div id='div{1}InputContainer' class='form-group input-group {0}'>", strInpuColWidth, nameID)
        html = html & String.Format("<input class='input-sm form-control {3}' {0} name='{1}' id='{1}' value='{2}' />", GenerateProperty(keyValCollection), nameID, value, classVal)
        html = html & "</div>"

        Return GetBoostrapColContainer(nameID, html, containerColWidth)
    End Function

    Public Shared Function GetAutoCompleteField(ByVal nameID As String, _
                                           ByVal label As String, _
                                           ByVal value As String, _
                                           ByVal labelColWidth As Integer?, _
                                           ByVal InputColWidth As Integer?, _
                                           ByVal containerColWidth As Integer?, _
                                           ByVal Url As String,
                                           ByVal keyValMap As Dictionary(Of String, String),
                                           ByVal Method As String,
                                           ByVal DisplayMember As String,
                                           ByVal ValueMember As String,
                                           ByVal ParamArray keyValCollection() As HtmlKeyVal) As IHtmlString

        Dim strlbColWidth As String = FieldLabelColWidth
        Dim strInpuColWidth As String = FieldInputColWidth
        If (labelColWidth IsNot Nothing) Then
            strlbColWidth = col_sm & "-" & labelColWidth
        End If

        If (InputColWidth IsNot Nothing) Then
            strInpuColWidth = col_sm & "-" & InputColWidth
        End If


        Dim textBox As IHtmlString = GetTextField(nameID, label, value, labelColWidth, InputColWidth, containerColWidth, keyValCollection)
        Dim scriptStr As String = ""

        Dim keyValMapjson As String = "{"

        For Each var In keyValMap
            keyValMapjson = keyValMapjson & "" & var.Key & "" & ":" & "" & var.Value & ","
        Next

        keyValMapjson = keyValMapjson.Substring(0, keyValMapjson.Length - 1) & "}"
 
        scriptStr = scriptStr & "<script>"
        scriptStr = scriptStr & String.Format(" $(function() {{ $('#{0}').InitialAutoComplete('{0}','{1}','{2}',{3},'{4}','{5}') }} )", nameID, Url, Method, keyValMapjson, DisplayMember, ValueMember)
        scriptStr = scriptStr & "</script>"
        Dim scriptHtml As New HtmlString(scriptStr)

        Return New HtmlString(textBox.ToHtmlString() & scriptHtml.ToHtmlString())
    End Function


    Public Shared Function GetKendoDatePicker(ByVal nameID As String, _
                                        ByVal label As String, _
                                        ByVal value As String, _
                                        ByVal labelColWidth As Integer?, _
                                        ByVal InputColWidth As Integer?, _
                                        ByVal containerColWidth As Integer?, _
                                        ByVal format As String,
                                        ByVal maxDate As Date?,
                                        ByVal ParamArray keyValCollection() As HtmlKeyVal) As IHtmlString
        Dim strlbColWidth As String = FieldLabelColWidth
        Dim strInpuColWidth As String = FieldInputColWidth
        If (labelColWidth IsNot Nothing) Then
            strlbColWidth = col_sm & "-" & labelColWidth
        End If

        If (InputColWidth IsNot Nothing) Then
            strInpuColWidth = col_sm & "-" & InputColWidth
        End If

        Dim maxDateDay As Integer = 31
        Dim maxDateMonth As Integer = 12
        Dim maxDateYear As Integer = DateTime.Now.Year + 10
        If (maxDate IsNot Nothing) Then
            maxDateDay = maxDate.Value.Day
            maxDateMonth = maxDate.Value.Month
            maxDateYear = maxDate.Value.Year
        End If

        Dim html As String = String.Format("<div class='{0}'>", strlbColWidth)
        html = html & String.Format("<label class='control-label'> {0} </label>", label)
        html = html & "</div>"
        html = html & String.Format("<div class='form-group input-group {0}'>", strInpuColWidth)
        html = html & String.Format("<input style='width:100%'   {0} name='{1}' id='{1}' value='{2}' />", GenerateProperty(keyValCollection), nameID, value)
        html = html & "</div>"

        Dim scriptStr As String = ""

        Using reader As New StreamReader(Path.Combine(SysConstants.CommonConstants.GlobalAsset_ScriptTemplete, SysConstants.ScriptTemplete.KendoDatePicker))
            scriptStr = reader.ReadToEnd()
            scriptStr = String.Format(scriptStr, nameID, format, maxDateDay, maxDateMonth - 1, maxDateYear)
        End Using

        Return New HtmlString(GetBoostrapColContainer(nameID, html, containerColWidth).ToHtmlString & scriptStr)
    End Function

    Public Shared Function GetTextAreaField(nameID As String, _
        ByVal label As String, _
        ByVal value As String, _
        ByVal labelColWidth As Integer?, _
        ByVal InputColWidth As Integer?, _
        ByVal containerColWidth As Integer?, _
        ByVal ParamArray keyValCollection() As HtmlKeyVal) As IHtmlString


        Dim strlbColWidth As String = FieldLabelColWidth
        Dim strInpuColWidth As String = FieldInputColWidth
        If (labelColWidth IsNot Nothing) Then
            strlbColWidth = col_sm & "-" & labelColWidth
        End If

        If (InputColWidth IsNot Nothing) Then
            strInpuColWidth = col_sm & "-" & InputColWidth
        End If

        Dim rowAttr As String = "row='6'"
        If (keyValCollection IsNot Nothing) Then
            Dim rowKeyVal As HtmlKeyVal = keyValCollection.Where(Function(x) x.Key = "row").FirstOrDefault()
            If (rowKeyVal IsNot Nothing) Then
                rowAttr = rowKeyVal.Key & " = " & rowKeyVal.Val
            End If
        End If


        Dim classVal As String = GetClassProperty(keyValCollection)

        Dim html As String = String.Format("<div class='{0}'>", strlbColWidth)
        html = html & String.Format("<label class='control-label'> {0} </label>", label)
        html = html & "</div>"
        html = html & String.Format("<div class='form-group input-group {0}'>", strInpuColWidth)
        html = html & String.Format("<textarea {3} style='width:266px' class='input-sm form-control {4}' {0} name='{1}' id='{1}'  >{2}</textarea>", GenerateProperty(keyValCollection), nameID, value, rowAttr, classVal)
        html = html & "</div>"
        Return GetBoostrapColContainer(nameID, html, containerColWidth)
    End Function



    Public Shared Function GetInputField(Of TModel, TProperty) _
        (source As TModel, _
         expression As System.Linq.Expressions.Expression(Of System.Func(Of TModel, TProperty)), _
         ByVal label As String, _
         ByVal labelColWidth As Integer?, _
         ByVal InputColWidth As Integer?, _
         ByVal containerColWidth As Integer?, _
         ByVal ParamArray keyValCollection() As HtmlKeyVal) As IHtmlString

        Dim propName As String = ""
        Dim value As String = ""
        If TypeOf expression.Body Is MemberExpression Then
            propName = DirectCast(expression.Body, MemberExpression).Member.Name
        Else
            Dim op = DirectCast(expression.Body, UnaryExpression).Operand
            propName = DirectCast(op, MemberExpression).Member.Name

        End If

        If (source IsNot Nothing) Then
            Dim prop As PropertyInfo = source.GetType().GetProperty(propName)
            value = prop.GetValue(source, Nothing)
        End If



        Dim strlbColWidth As String = FieldLabelColWidth
        Dim strInpuColWidth As String = FieldInputColWidth
        If (labelColWidth IsNot Nothing) Then
            strlbColWidth = col_sm & "-" & labelColWidth
        End If

        If (InputColWidth IsNot Nothing) Then
            strInpuColWidth = col_sm & "-" & InputColWidth
        End If


        Dim html As String = String.Format("<div class='{0}'>", strlbColWidth)
        html = html & String.Format("<label class='control-label'> {0} </label>", label)
        html = html & "</div>"
        html = html & String.Format("<div class='form-group input-group {0}'>", strInpuColWidth)

        Dim classVal As String = GetClassProperty(keyValCollection)

        html = html & String.Format("<input type='text' class='input-sm form-control {3}' {0} name='{1}' id='{1}' value='{2}' />", GenerateProperty(keyValCollection), propName, value, classVal)
        html = html & "</div>"
        Return GetBoostrapColContainer(propName, html, containerColWidth)
    End Function



    Public Shared Function GetDisableInputField(Of TModel, TProperty) _
       (source As TModel, expression As System.Linq.Expressions.Expression(Of System.Func(Of TModel, TProperty)), _
        ByVal label As String, _
        ByVal ParamArray keyValCollection() As HtmlKeyVal) As IHtmlString

        Dim propName As String = ""
        Dim value As String = ""
        If TypeOf expression.Body Is MemberExpression Then
            propName = DirectCast(expression.Body, MemberExpression).Member.Name
        Else
            Dim op = DirectCast(expression.Body, UnaryExpression).Operand
            propName = DirectCast(op, MemberExpression).Member.Name

        End If

        If (source IsNot Nothing) Then
            Dim prop As PropertyInfo = source.GetType().GetProperty(propName)
            value = prop.GetValue(source, Nothing)
        End If


        Dim html As String = String.Format("<div class='{0}'>", FieldLabelColWidth)
        html = html & String.Format("<label class='control-label'> {0} </label>", label)
        html = html & "</div>"
        html = html & String.Format("<div class='form-group input-group {0}'>", FieldInputColWidth)
        html = html & String.Format("<input  name='{1}' id='{1}' readonly class='input-sm form-control' {0}  value='{2}' />", GenerateProperty(keyValCollection), propName, value)
        'html = html & String.Format("<input type='hidden' name='{1}' id='{1}' value='{0}'>", value, propName)
        html = html & "</div>"
        Return GetBoostrapColContainer(propName, html, Nothing)
    End Function



    Public Shared Function GetInputFieldWithIconAndTail(Of TModel, TProperty) _
      (source As TModel, expression As System.Linq.Expressions.Expression(Of System.Func(Of TModel, TProperty)), _
       ByVal label As String, _
       ByVal tail As String, ByVal fa As String, ByVal hoverMessage As String, _
       ByVal ParamArray keyValCollection() As HtmlKeyVal) As IHtmlString

        Dim propName As String = ""
        Dim value As String = ""
        If TypeOf expression.Body Is MemberExpression Then
            propName = DirectCast(expression.Body, MemberExpression).Member.Name
        Else
            Dim op = DirectCast(expression.Body, UnaryExpression).Operand
            propName = DirectCast(op, MemberExpression).Member.Name

        End If

        If (source IsNot Nothing) Then
            Dim prop As PropertyInfo = source.GetType().GetProperty(propName)
            value = prop.GetValue(source, Nothing)
        End If


        Dim html As String = String.Format("<div class='{0}'>", FieldLabelColWidth)
        html = html & String.Format("<label class='control-label'> {0} </label>", label)
        html = html & "</div>"
        html = html & String.Format("<div class='form-group input-group {0}'>", FieldInputColWidth)
        html = html & String.Format("<div class='form-control-feedback'>{0}</div>", fa)
        html = html & String.Format("<input onmouseover='showPopover($(this),""{3}"")' class='input-sm form-control' {0} name='{1}' id='{1}' value='{2}' />", GenerateProperty(keyValCollection), propName, value, hoverMessage)
        html = html & String.Format("<span class='input-group-addon'>{0}</span>", tail)

        html = html & "</div>"
        Return GetBoostrapColContainer(propName, html, Nothing)
    End Function



    Public Shared Function GetInputFieldWithIcon(Of TModel, TProperty) _
        (source As TModel, expression As System.Linq.Expressions.Expression(Of System.Func(Of TModel, TProperty)), _
         ByVal label As String, ByVal fa As String, ByVal hoverMessage As String, _
         ByVal ParamArray keyValCollection() As HtmlKeyVal) As IHtmlString

        Dim propName As String = ""
        Dim value As String = ""
        If TypeOf expression.Body Is MemberExpression Then
            propName = DirectCast(expression.Body, MemberExpression).Member.Name
        Else
            Dim op = DirectCast(expression.Body, UnaryExpression).Operand
            propName = DirectCast(op, MemberExpression).Member.Name

        End If

        If (source IsNot Nothing) Then
            Dim prop As PropertyInfo = source.GetType().GetProperty(propName)
            value = prop.GetValue(source, Nothing)
        End If


        Dim html As String = String.Format("<div class='{0}'>", FieldLabelColWidth)
        html = html & String.Format("<label class='control-label'> {0} </label>", label)
        html = html & "</div>"
        html = html & String.Format("<div class='form-group input-group {0}'>", FieldInputColWidth)
        html = html & String.Format("<input onmouseover='showPopover($(this),""{3}"")'  class='input-sm form-control' {0} name='{1}' id='{1}' value='{2}' />", _
                                    GenerateProperty(keyValCollection), propName, value, hoverMessage)
        html = html & String.Format("<div class='form-control-feedback'>{0}</div>", fa)
        html = html & "</div>"
        Return GetBoostrapColContainer(propName, html, Nothing)
    End Function

    Public Shared Function GetInputFieldWithTail(Of TModel, TProperty) _
        (source As TModel, expression As System.Linq.Expressions.Expression(Of System.Func(Of TModel, TProperty)), _
         ByVal label As String, _
         ByVal labelColWidth As Integer?, _
         ByVal InputColWidth As Integer?, _
         ByVal containerColWidth As Integer?, _
         ByVal tail As String, _
         ByVal ParamArray keyValCollection() As HtmlKeyVal) As IHtmlString

        Dim propName As String = ""
        Dim value As String = ""
        If TypeOf expression.Body Is MemberExpression Then
            propName = DirectCast(expression.Body, MemberExpression).Member.Name
        Else
            Dim op = DirectCast(expression.Body, UnaryExpression).Operand
            propName = DirectCast(op, MemberExpression).Member.Name

        End If

        If (source IsNot Nothing) Then
            Dim prop As PropertyInfo = source.GetType().GetProperty(propName)
            value = prop.GetValue(source, Nothing)
        End If

        Dim strlbColWidth As String = FieldLabelColWidth
        Dim strInpuColWidth As String = FieldInputColWidth
        If (labelColWidth IsNot Nothing) Then
            strlbColWidth = col_sm & "-" & labelColWidth
        End If

        If (InputColWidth IsNot Nothing) Then
            strInpuColWidth = col_sm & "-" & InputColWidth
        End If

        Dim classVal As String = GetClassProperty(keyValCollection)

        Dim html As String = String.Format("<div class='{0}'>", strlbColWidth)
        html = html & String.Format("<label class='control-label'> {0} </label>", label)
        html = html & "</div>"
        html = html & String.Format("<div class='form-group input-group {0}'>", strInpuColWidth)
        html = html & String.Format("<input class='input-sm form-control {3}' {0} name='{1}' id='{1}' value='{2}' />", GenerateProperty(keyValCollection), propName, value, classVal)
        html = html & String.Format(" <span class='input-group-addon'>{0}</span>", tail)
        html = html & "</div>"
        Return GetBoostrapColContainer(propName, html, containerColWidth)
    End Function

    Public Shared Function GetInputFieldWithTail _
        (ByVal nameID As String, _
         ByVal value As String, _
         ByVal label As String, _
         ByVal labelColWidth As Integer?, _
         ByVal InputColWidth As Integer?, _
         ByVal containerColWidth As Integer?, _
         ByVal tail As String, _
         ByVal ParamArray keyValCollection() As HtmlKeyVal) As IHtmlString

        Dim strlbColWidth As String = FieldLabelColWidth
        Dim strInpuColWidth As String = FieldInputColWidth
        If (labelColWidth IsNot Nothing) Then
            strlbColWidth = col_sm & "-" & labelColWidth
        End If

        If (InputColWidth IsNot Nothing) Then
            strInpuColWidth = col_sm & "-" & InputColWidth
        End If



        Dim html As String = String.Format("<div class='{0}'>", strlbColWidth)
        html = html & String.Format("<label class='control-label'> {0} </label>", label)
        html = html & "</div>"
        html = html & String.Format("<div class='form-group input-group {0}'>", strInpuColWidth)
        html = html & String.Format("<input class='input-sm form-control' {0} name='{1}' id='{1}' value='{2}' />", GenerateProperty(keyValCollection), nameID, value)
        html = html & String.Format(" <span class='input-group-addon'>{0}</span>", tail)
        html = html & "</div>"
        Return GetBoostrapColContainer(nameID, html, containerColWidth)
    End Function


    Public Shared Function GetDatePickerField(Of TModel, TProperty) _
      (source As TModel,
        expression As System.Linq.Expressions.Expression(Of System.Func(Of TModel, TProperty)),
        ByVal label As String,
        ByVal labelColWidth As Integer?, _
        ByVal InputColWidth As Integer?, _
        ByVal containerColWidth As Integer?,
        ByVal ParamArray keyValCollection() As HtmlKeyVal) As IHtmlString
        Dim propName As String = ""
        Dim value As String = ""
        If TypeOf expression.Body Is MemberExpression Then
            propName = DirectCast(expression.Body, MemberExpression).Member.Name
        Else
            Dim op = DirectCast(expression.Body, UnaryExpression).Operand
            propName = DirectCast(op, MemberExpression).Member.Name
        End If

        If (source IsNot Nothing) Then
            Dim prop As PropertyInfo = source.GetType().GetProperty(propName)
            value = prop.GetValue(source, Nothing)
        End If

        Dim strlbColWidth As String = FieldLabelColWidth
        Dim strInpuColWidth As String = FieldInputColWidth
        If (labelColWidth IsNot Nothing) Then
            strlbColWidth = col_sm & "-" & labelColWidth
        End If

        If (InputColWidth IsNot Nothing) Then
            strInpuColWidth = col_sm & "-" & InputColWidth
        End If


        Dim html As String = String.Format("<div class='{0}'>", strlbColWidth)
        html = html & String.Format("<label class='control-label'> {0} </label>", label)
        html = html & "</div>"
        html = html & String.Format("<div class='form-group input-group date {0}'>", strInpuColWidth)
        html = html & String.Format("<input class='input-sm form-control' {0} name='{1}' id='{1}' value='{2}'/>", GenerateProperty(keyValCollection), propName, value)
        html = html & "<span class='input-group-addon'> <span class='glyphicon glyphicon-calendar'> </span></span>"
        html = html & "</div>"
        Return GetBoostrapColContainer(propName, html, containerColWidth)

    End Function

    Public Shared Function GetDatePickerField(nameID As String, ByVal label As String, ByVal ParamArray keyValCollection() As HtmlKeyVal) As IHtmlString

        Dim value As String = ""

        Dim html As String = String.Format("<div class='{0}'>", FieldLabelColWidth)
        html = html & String.Format("<label class='control-label'> {0} </label>", label)
        html = html & "</div>"
        html = html & String.Format("<div class='form-group input-group {0} date col-sm-6'>", nameID)
        html = html & String.Format("<input class='input-sm form-control' {0} name='{1}' id='{1}' value='{2}'/>", GenerateProperty(keyValCollection), nameID, value)
        html = html & "<span class='input-group-addon'><span class='glyphicon glyphicon-calendar'></span> </span>"
        html = html & "</div>"
        Return GetBoostrapColContainer(nameID, html, Nothing)
    End Function

    Public Shared Function GetSelectPicker(Of TModel, TProperty) _
     (source As TModel, _
      expression As System.Linq.Expressions.Expression(Of System.Func(Of TModel, TProperty)),
      ByVal label As String,
      ByVal ddList As List(Of System.Web.Mvc.SelectListItem), _
      ByVal labelColWidth As Integer?, _
      ByVal InputColWidth As Integer?, _
      ByVal containerColWidth As Integer?, _
      ByVal ParamArray keyValCollection() As HtmlKeyVal _
      ) As IHtmlString
        Dim propName As String = ""
        Dim value As String = ""
        If TypeOf expression.Body Is MemberExpression Then
            propName = DirectCast(expression.Body, MemberExpression).Member.Name
        Else
            Dim op = DirectCast(expression.Body, UnaryExpression).Operand
            propName = DirectCast(op, MemberExpression).Member.Name
        End If

        If (source IsNot Nothing) Then
            Dim prop As PropertyInfo = source.GetType().GetProperty(propName)
            value = prop.GetValue(source, Nothing)

        End If

        Dim strlbColWidth As String = FieldLabelColWidth
        Dim strInpuColWidth As String = FieldInputColWidth
        If (labelColWidth IsNot Nothing) Then
            strlbColWidth = col_sm & "-" & labelColWidth
        End If

        If (InputColWidth IsNot Nothing) Then
            strInpuColWidth = col_sm & "-" & InputColWidth
        End If

        Dim html As String = String.Format("<div class='{0}'>", strlbColWidth)
        html = html & String.Format("<label class='control-label'> {0} </label>", label)
        html = html & "</div>" ' label
        html = html & String.Format("<div class='form-group input-group {0}'>", strInpuColWidth)
        html = html & String.Format("<select data-live-search='true' {0} name='{1}' id='{1}' >", GenerateProperty(keyValCollection), propName)
        html = html & "<option value=''></option>"
        For Each item As SelectListItem In ddList
            If (value.ToStringOrEmpty().Equals(item.Value)) Then
                html = html & String.Format("<option selected value='{0}'>{1}</option>", item.Value, item.Text)
            Else
                html = html & String.Format("<option value='{0}'>{1}</option>", item.Value, item.Text)
            End If

        Next
        html = html & "</select>"
        html = html & "</div>"
        'html = html & String.Format("<script> $(function() {{   $('#{0}').selectpicker()   }}      )</script>", propName)
        html = html & String.Format(ReadScript(Commons.SysConstants.CommonConstants.SCRIPT_HtmlControlsSelectpicker), propName)
        Return GetBoostrapColContainer(propName, html, containerColWidth)
    End Function


    Public Shared Function GetSelectPicker(nameID As String, _
      ByVal label As String,
      ByVal ddList As List(Of System.Web.Mvc.SelectListItem), _
      ByVal labelColWidth As Integer?, _
      ByVal InputColWidth As Integer?, _
      ByVal containerColWidth As Integer?, _
      ByVal ParamArray keyValCollection() As HtmlKeyVal _
      ) As IHtmlString


        Dim strlbColWidth As String = FieldLabelColWidth
        Dim strInpuColWidth As String = FieldInputColWidth
        If (labelColWidth IsNot Nothing) Then
            strlbColWidth = col_sm & "-" & labelColWidth
        End If

        If (InputColWidth IsNot Nothing) Then
            strInpuColWidth = col_sm & "-" & InputColWidth
        End If

        Dim html As String = String.Format("<div class='{0}'>", strlbColWidth)
        html = html & String.Format("<label class='control-label'> {0} </label>", label)
        html = html & "</div>" ' label
        html = html & String.Format("<div class='form-group input-group {0}'>", strInpuColWidth)
        html = html & String.Format("<select data-live-search='true' {0} name='{1}' id='{1}' >", GenerateProperty(keyValCollection), nameID)
        html = html & "<option value=''></option>"
        For Each item As SelectListItem In ddList
            html = html & String.Format("<option value='{0}'>{1}</option>", item.Value, item.Text)
        Next
        html = html & "</select>"
        html = html & "</div>"
        'html = html & String.Format("<script> $(function() {{   $('#{0}').selectpicker()   }}      )</script>", propName)
        html = html & String.Format(ReadScript(Commons.SysConstants.CommonConstants.SCRIPT_HtmlControlsSelectpicker), nameID)
        Return GetBoostrapColContainer(nameID, html, containerColWidth)
    End Function

    Public Shared Function InitialSelectPicker(Of T)(ByVal nameID As String, _
         ByVal label As String,
         ByVal listOfObject As List(Of T), _
         ByVal DisplayMember As String, _
         ByVal ValueMember As String, _
         ByVal labelColWidth As Integer?, _
         ByVal InputColWidth As Integer?, _
         ByVal containerColWidth As Integer?, _
         ByVal selectedValue As String, _
         ByVal ParamArray keyValCollection() As HtmlKeyVal _
         ) As IHtmlString

        Dim prop As PropertyInfo = GetType(T).GetProperty(ValueMember)
        Dim _jsJSONObject As String = Newtonsoft.Json.JsonConvert.SerializeObject(listOfObject, Newtonsoft.Json.Formatting.None)
        If (listOfObject.Count > 0) Then

            If (Not _jsJSONObject.Contains(DisplayMember)) Then
                Throw New Exception(String.Format("Not have field {0} for DisplayMember", DisplayMember))
            End If



            If (Not _jsJSONObject.Contains(ValueMember)) Then
                Throw New Exception(String.Format("Not have field {0} for ValueMember", ValueMember))
            End If
        End If



        '_jsJSONObject = _jsJSONObject.Replace(ValueMember, "value")
        '_jsJSONObject = _jsJSONObject.Replace(DisplayMember, "display")
        Dim strlbColWidth As String = FieldLabelColWidth
        Dim strInpuColWidth As String = FieldInputColWidth
        If (labelColWidth IsNot Nothing) Then
            strlbColWidth = col_sm & "-" & labelColWidth
        End If

        If (InputColWidth IsNot Nothing) Then
            strInpuColWidth = col_sm & "-" & InputColWidth
        End If


        Dim html As String = ""
        If (label.Trim() <> "" OrElse labelColWidth > 0) Then
            html = html & String.Format("<div id='div{1}LabelContainer' class='{0}'>", strlbColWidth, nameID)
            html = html & String.Format("<label  class='control-label'> {0} </label>", label)
            html = html & "</div>" ' label
        End If




        html = html & String.Format("<div id='div{1}InputContainer' class='form-group input-group {0}'>", strInpuColWidth, nameID)
        html = html & String.Format("<select {0} name='{1}' id='{1}' ><option selected value=''></option></select>", GenerateProperty(keyValCollection), nameID)
        html = html & "</div>"

        html = html & "<script>"
        html = html & String.Format(" $(function() {{ $('#{0}').InitialSelectPicker({1}, '{2}','{3}','{4}') }} )", nameID, _jsJSONObject, selectedValue, DisplayMember, ValueMember)
        html = html & "</script>"
        Return GetBoostrapColContainer(nameID, html, containerColWidth)
    End Function

    Public Shared Function GetDatePickerFromTo(nameIDFrom As String, nameIDTo As String, value1 As String, value2 As String,
                                              ByVal label As String,
                                              ByVal labelColWidth As Integer?, _
                                                ByVal InputColWidth As Integer?, _
                                                ByVal containerColWidth As Integer?,
                                                ByVal ParamArray keyValCollection() As HtmlKeyVal) As IHtmlString

        Dim strlbColWidth As String = FieldLabelColWidth
        Dim strInpuColWidth As String = FieldInputColWidth
        If (labelColWidth IsNot Nothing) Then
            strlbColWidth = col_sm & "-" & labelColWidth
        End If

        If (InputColWidth IsNot Nothing) Then
            strInpuColWidth = col_sm & "-" & InputColWidth
        End If


        Dim html As String = String.Format("<div class='{0}'>", strlbColWidth)
        html = html & String.Format("<label class='control-label'> {0} </label>", label)
        html = html & "</div>"

        html = html & String.Format("<div class='form-group input-group {0} date {1}' style='float:left'>", nameIDFrom, strInpuColWidth)
        html = html & String.Format("<input class='input-sm form-control' {0} name='{1}' id='{1}' value='{2}'/>", GenerateProperty(keyValCollection), nameIDFrom, value1)
        html = html & "<span class='input-group-addon'><span class='glyphicon glyphicon-calendar'></span> </span>"
        html = html & "</div>"
        html = html & "<div style='float:left;padding-left:5px;padding-right:5px'>-</div>"
        html = html & String.Format("<div class='form-group input-group {0} date {1}'>", nameIDTo, strInpuColWidth)
        html = html & String.Format("<input class='input-sm form-control' {0} name='{1}' id='{1}' value='{2}'/>", GenerateProperty(keyValCollection), nameIDTo, value2)
        html = html & "<span class='input-group-addon'><span class='glyphicon glyphicon-calendar'></span> </span>"
        html = html & "</div>"
        Return GetBoostrapColContainer(nameIDFrom, html, containerColWidth)
    End Function

    Public Shared Function InitialSelectPicker(ByVal nameID As String, _
    ByVal label As String,
    ByVal labelColWidth As Integer?, _
    ByVal InputColWidth As Integer?, _
    ByVal containerColWidth As Integer?, _
    ByVal ParamArray keyValCollection() As HtmlKeyVal _
    ) As IHtmlString

        Dim strlbColWidth As String = FieldLabelColWidth
        Dim strInpuColWidth As String = FieldInputColWidth
        If (labelColWidth IsNot Nothing) Then
            strlbColWidth = col_sm & "-" & labelColWidth
        End If

        If (InputColWidth IsNot Nothing) Then
            strInpuColWidth = col_sm & "-" & InputColWidth
        End If

        Dim html As String = String.Format("<div class='{0}'>", strlbColWidth)
        html = html & String.Format("<label class='control-label'> {0} </label>", label)
        html = html & "</div>" ' label
        html = html & String.Format("<div class='form-group input-group {0}'>", strInpuColWidth)
        html = html & String.Format("<select {0} name='{1}' id='{1}' >", GenerateProperty(keyValCollection), nameID)
        html = html & "</select>"
        html = html & "</div>"
        html = html & "<script>"
        html = html & String.Format("$('#{0}').InitialSelectPicker({1},'{2}')", nameID, "[]", "")
        html = html & "</script>"
        Return GetBoostrapColContainer(nameID, html, containerColWidth)
    End Function

    Public Shared Function GetSelect2(ByVal nameID As String, _
    ByVal label As String,
    ByVal labelColWidth As Integer?, _
    ByVal InputColWidth As Integer?, _
    ByVal containerColWidth As Integer?, _
    ByVal placeHolder As String, _
    ByVal ParamArray keyValCollection() As HtmlKeyVal _
    ) As IHtmlString

        Dim strlbColWidth As String = FieldLabelColWidth
        Dim strInpuColWidth As String = FieldInputColWidth
        If (labelColWidth IsNot Nothing) Then
            strlbColWidth = col_sm & "-" & labelColWidth
        End If

        If (InputColWidth IsNot Nothing) Then
            strInpuColWidth = col_sm & "-" & InputColWidth
        End If

        Dim html As String = String.Format("<div class='{0}'>", strlbColWidth)
        html = html & String.Format("<label class='control-label'> {0} </label>", label)
        html = html & "</div>" ' label
        html = html & String.Format("<div class='form-group input-group {0}'>", strInpuColWidth)
        html = html & String.Format("<select {0} name='{1}' id='{1}' >", GenerateProperty(keyValCollection), nameID)
        html = html & "</select>"
        html = html & "</div>"
        html = html & "<script>"
        html = html & String.Format("InitialSelect2($('#{0}'), '{1}', '{2}',null)", nameID, "[]", placeHolder)
        html = html & "</script>"
        Return GetBoostrapColContainer(nameID, html, containerColWidth)
    End Function

    Public Shared Function GetSelect2(Of T)(ByVal nameID As String, _
       ByVal label As String,
       ByVal listOfObject As List(Of T), _
       ByVal DisplayMember As String, _
       ByVal ValueMember As String, _
       ByVal labelColWidth As Integer?, _
       ByVal InputColWidth As Integer?, _
       ByVal containerColWidth As Integer?, _
       ByVal placeHolder As String, _
       ByVal selectedValue As String, _
       ByVal ParamArray keyValCollection() As HtmlKeyVal _
       ) As IHtmlString

        Dim prop As PropertyInfo = GetType(T).GetProperty(ValueMember)
        Dim jsonString As String = Newtonsoft.Json.JsonConvert.SerializeObject(listOfObject, Newtonsoft.Json.Formatting.None)
        If (Not jsonString.Contains(DisplayMember)) Then
            Throw New Exception(String.Format("Not have field {0} for DisplayMember", DisplayMember))
        End If

        If (Not jsonString.Contains(ValueMember)) Then
            Throw New Exception(String.Format("Not have field {0} for ValueMember", ValueMember))
        End If


        jsonString = jsonString.Replace(ValueMember, "id")
        jsonString = jsonString.Replace(DisplayMember, "text")
        Dim strlbColWidth As String = FieldLabelColWidth
        Dim strInpuColWidth As String = FieldInputColWidth
        If (labelColWidth IsNot Nothing) Then
            strlbColWidth = col_sm & "-" & labelColWidth
        End If

        If (InputColWidth IsNot Nothing) Then
            strInpuColWidth = col_sm & "-" & InputColWidth
        End If

        Dim html As String = String.Format("<div class='{0}'>", strlbColWidth)
        html = html & String.Format("<label class='control-label'> {0} </label>", label)
        html = html & "</div>" ' label
        html = html & String.Format("<div class='form-group input-group {0}'>", strInpuColWidth)
        html = html & String.Format("<select {0} name='{1}' id='{1}' ><option selected value=''></option></select>", GenerateProperty(keyValCollection), nameID)
        html = html & "</div>"
        html = html & "<script>"
        html = html & String.Format("InitialSelect2($('#{0}'), '{1}', '{2}','{3}')", nameID, jsonString, placeHolder, selectedValue)
        html = html & "</script>"
        Return GetBoostrapColContainer(nameID, html, containerColWidth)
    End Function

    'Public Shared Function GetbtnUpdate(ByVal stepNo As Integer, ByVal currentStep As Integer) As IHtmlString

    '    Dim btnUpdate As HtmlString = GetbtnUpdate(stepNo)
    '    Dim btnExit As HtmlString = GetbtnExit(9)
    '    Return New HtmlString("<div id='oprBtn" & 9 & "'  style='width: 260px;  margin:auto'>" & btnUpdate.ToString & " " & btnExit.ToString & "</div>")

    '    'Dim btnUpdate As HtmlString = GetbtnUpdate()
    '    'Dim btnExit As HtmlString = GetbtnExit()
    '    'Return New HtmlString("<div  style='width: 460px;  margin:auto'>" & _
    '    '                      btnUpdate.ToString() & " " & _
    '    '                      btnExit.ToString "</div>")
    'End Function


    'Public Shared Function GetSelectPicker(ByVal nameID As String, _
    '                                       ByVal label As String, _
    '                                       ByVal ddList As List(Of System.Web.Mvc.SelectListItem), _
    '                                       ByVal ParamArray keyValCollection() As HtmlKeyVal) As IHtmlString

    '    Dim html As String = String.Format("<div class='{0}'>", FieldLabelColWidth)
    '    html = html & String.Format("<label class='control-label'> {0} </label>", label)
    '    html = html & "</div>"
    '    html = html & String.Format("<div class='{0}'>", FieldInputColWidth)
    '    html = html & "<div class='form-group input-group'>"
    '    html = html & String.Format("<select data-live-search='true' {0} name='{1}' id='{1}' >", GenerateProperty(keyValCollection), nameID)
    '    html = html & "<option value=''></option>"
    '    For Each item As SelectListItem In ddList
    '        html = html & String.Format("<option value='{0}'>{1}</option>", item.Value, item.Text)
    '    Next
    '    html = html & "</select>"
    '    html = html & "</div>"
    '    html = html & "</div>"
    '    html = html & String.Format(ReadScript(Commons.SysConstants.CommonConstants.SCRIPT_HtmlControlsSelectpicker), nameID)
    '    Return PutToContainer(html)
    'End Function

    Public Shared Function GetBoostrapColContainer(ByVal idName As String, ByVal element As String, ByVal colWidth As Integer?, ByVal ParamArray keyValCollection() As HtmlKeyVal) As IHtmlString
        Dim strColWidth As String = FieldContainerColWidth
        If (colWidth IsNot Nothing) Then
            strColWidth = col_lg & "-" & colWidth
        End If

        Dim classProp As String = GetClassProperty(keyValCollection)

        Dim html As String = String.Format("<div id='div{3}FieldContainer'  class='{0} {2}' {1}>", strColWidth, GenerateProperty(keyValCollection), classProp, idName)
        html = html & element
        html = html & "</div>"
        Return New HtmlString(html)
    End Function





    Public Shared Function ReadScript(ByVal scriptFile As String) As String
        Using reader As New StreamReader(Path.Combine(Commons.SysConstants.CommonConstants.EXTERNAL_SCRIPT_PATH, scriptFile))
            Return reader.ReadToEnd()
        End Using

    End Function

    Public Shared Function GetLegendLine() As IHtmlString
        Return New HtmlString("<div style='height:10px'></div> <legend></legend> <div style='height:10px'></div>")
    End Function
    Public Shared Function GetBlankRow() As IHtmlString
        Return New HtmlString("<div style='height:10px'></div><div style='height:5px'></div>")
    End Function



#Region "Private Function"
    Private Shared Function GetClassProperty(ParamArray keyValCollection() As HtmlKeyVal) As String
        If (keyValCollection IsNot Nothing) Then
            Dim obj As HtmlKeyVal = keyValCollection.Where(Function(x) x.Key = "class").FirstOrDefault()

            If (obj Is Nothing) Then
                obj = New HtmlKeyVal
            Else
                keyValCollection.ToList().Remove(obj)
            End If
            Return obj.Val
        End If
        Return ""
    End Function
#End Region
End Class
