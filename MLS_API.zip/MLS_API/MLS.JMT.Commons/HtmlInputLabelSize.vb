﻿Public Class HtmlInputLabelSize
    Public Property InputColWidth As String
    Public Property LableColWidth As String
End Class
