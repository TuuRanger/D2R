﻿Imports System.Web
Imports Newtonsoft.Json
Imports System.IO
Imports MLS.JMT.Commons.SysConstants
Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Web.Mvc
Imports System.ComponentModel
Imports System.Globalization
Imports Ionic.Zip
Imports System.Web.Mvc.ControllerBase
Imports System.Text.RegularExpressions
Imports System.Text

Public Module Utils


    Public Function LetterToNumber(columnName As String, Optional zerobase As Boolean = False) As Integer
        If String.IsNullOrEmpty(columnName) Then
            Throw New ArgumentNullException("columnName")
        End If

        columnName = columnName.ToUpperInvariant()

        Dim sum As Integer = 0

        For i As Integer = 0 To columnName.Length - 1
            sum = sum * 26
            sum = sum + (Asc(columnName(i)) - Asc("A") + 1)
        Next

        Return If(zerobase, sum - 1, sum)
    End Function

    '=======================================================
    'Service provided by Telerik (www.telerik.com)
    'Conversion powered by NRefactory.
    'Twitter: @telerik
    'Facebook: facebook.com/telerik
    '=======================================================

    Public Function ConvertToJsonString(ByVal obj As Object) As String
        Return JsonConvert.SerializeObject(obj, Formatting.None)
    End Function

    Public Sub WriteJson(ByVal jsonString As Object, Optional FileName As String = "")
        If (FileName = "") Then
            FileName = DateTime.Now.ToString("ddMMyyyyHHmmss")
        End If
        If (Directory.Exists(CommonConstants.LOG_PATH) = False) Then
            Directory.CreateDirectory(CommonConstants.LOG_PATH)
        End If
        Using writer As New StreamWriter(CommonConstants.LOG_PATH + "/" + FileName + ".json")
            writer.Write(JsonConvert.SerializeObject(jsonString))
        End Using
    End Sub

    Public Sub WriteNGModel(ByVal obj As Object, Optional ObjectName As String = "", Optional FileName As String = "")
        Dim str As String = ""
        Dim props As PropertyInfo() = obj.GetType.GetProperties()

        For Each prop As PropertyInfo In props
            str = str + String.Format("ng-model=""{0}{1}""", ObjectName + ".", prop.Name) + System.Environment.NewLine
        Next

        If (FileName = "") Then
            FileName = DateTime.Now.ToString("ddMMyyyyHHmmss")
        End If
        If (Directory.Exists(CommonConstants.LOG_PATH) = False) Then
            Directory.CreateDirectory(CommonConstants.LOG_PATH)
        End If
        Using writer As New StreamWriter(CommonConstants.LOG_PATH + "/" + FileName + ".json")
            writer.Write(str)
        End Using
    End Sub


    <Extension> _
    Public Function IsEmpty(ByVal obj As Object) As Boolean
        If (obj Is Nothing) Then
            Return True
        ElseIf (obj.ToString().Trim() = "") Then
            Return True
        End If
        Return False
    End Function

    <Extension> _
    Public Function ToTelNoFormat(ByVal obj As String) As String
        obj.UnformatTelNo()
        If (obj IsNot Nothing) Then
            If (obj.Length = 10) Then
                obj = obj.Insert(3, "-")
                obj = obj.Insert(7, "-")
            ElseIf (obj.Length = 9) Then
                obj = obj.Insert(2, "-")
                obj = obj.Insert(6, "-")
            End If
            Return obj
        Else
            Return Nothing
        End If
    End Function

    <Extension> _
    Public Function UnformatTelNo(ByVal obj As String) As String
        If (obj IsNot Nothing) Then
            Return String.Join("", obj.Split("-"))
        Else
            Return Nothing
        End If

    End Function

    <Extension> _
    Public Function IsNotEmpty(ByVal obj As Object) As Boolean
        Return Not IsEmpty(obj)
    End Function

    <Extension> _
    Public Function BoolToYesNoFlag(ByVal obj As Boolean) As String
        If (obj) Then
            Return Commons.SysConstants.YesNoFlag.Yes
        ElseIf (obj = False OrElse obj.ToString().Trim() = "") Then
            Return Commons.SysConstants.YesNoFlag.No
        Else
            Return Commons.SysConstants.YesNoFlag.No
        End If
    End Function

    <Extension> _
    Public Function YesNoFlagToBool(ByVal obj As String) As Boolean
        If (obj = Commons.SysConstants.YesNoFlag.Yes) Then
            Return True
        Else
            Return False
        End If
    End Function

    <System.Runtime.CompilerServices.Extension> _
    Public Function ToSelectList(Of T)(Items__1 As List(Of T), getKey As Func(Of T, String), _
                                       getValue As Func(Of T, String), Optional selectedValue As String = Nothing, _
                                      Optional noSelection As String = "", Optional search As Boolean = False) As List(Of SelectListItem)

        Dim items__2 As New List(Of SelectListItem)()

        If search Then
            items__2.Add(New SelectListItem() With { _
                 .Selected = True, _
                 .Value = Nothing, _
                 .Text = noSelection _
            })
        End If

        For Each item In Items__1
            If (item IsNot Nothing) Then
                items__2.Add(New SelectListItem() With { _
             .Text = getKey(item), _
             .Value = getValue(item), _
             .Selected = If(selectedValue = getValue(item), True, False) _
        })
            End If
        Next

        Return items__2.OrderBy(Function(l) l.Text).ToList()

    End Function


    <System.Runtime.CompilerServices.Extension> _
    Public Function ToPipeSeparate(Of T)(list As List(Of T)) As String
        Dim sb As New StringBuilder()

        'Get the properties for type T for the headers
        Dim propInfos As PropertyInfo() = GetType(T).GetProperties()
        For i As Integer = 0 To propInfos.Length - 1
            sb.Append(propInfos(i).Name)

            If i < propInfos.Length - 1 Then
                sb.Append("|")
            End If
        Next

        sb.AppendLine()

        'Loop through the collection, then the properties and add the values
        For i As Integer = 0 To list.Count - 1
            Dim item As T = list(i)
            For j As Integer = 0 To propInfos.Length - 1
                Dim o As Object = item.[GetType]().GetProperty(propInfos(j).Name).GetValue(item, Nothing)
                If o IsNot Nothing Then
                    Dim value As String = o.ToString()

                    'Check if the value contans a comma and place it in quotes if so
                    If value.Contains(",") Then
                        value = String.Concat("""", value, """")
                    End If

                    'Replace any \r or \n special characters from a new line with a space
                    If value.Contains(vbCr) Then
                        value = value.Replace(vbCr, " ")
                    End If
                    If value.Contains(vbLf) Then
                        value = value.Replace(vbLf, " ")
                    End If

                    sb.Append(value)
                End If

                If j < propInfos.Length - 1 Then
                    sb.Append("|")
                End If
            Next

            sb.AppendLine()
        Next

        Return sb.ToString()
    End Function


    <Extension()> _
    Public Function ToMoneyFormat(ByVal obj As Object) As String
        If (obj IsNot Nothing) Then
            If (IsNumeric(obj)) Then
                Return String.Format("{0:N}", Convert.ToDecimal(obj))
            Else
                Return ""
            End If
        End If
    End Function

    <Extension()> _
    Public Function ToDecimalFormat(ByVal obj As Object, Optional decimalPlace As Integer = 2) As String
        Dim format As String = "{0:0."
        For i As Integer = 1 To decimalPlace
            format = format & "0"
        Next
        format = format & "}"
        If (obj IsNot Nothing) Then

            If (IsNumeric(obj)) Then
                Return String.Format(format, Convert.ToDecimal(obj))
            Else
                Return ""
            End If
        End If
    End Function


    <Extension()> _
    Public Function ToDecimalOrNull(ByVal obj As Object) As Decimal?
        If (IsNumeric(obj)) Then
            Return Convert.ToDecimal(obj)
        End If
        Return Nothing
    End Function

    <Extension()> _
    Public Function ToDecimalOrZero(ByVal obj As Object) As Decimal
        If (obj Is Nothing OrElse Not IsNumeric(obj)) Then
            Return 0
        End If

        If (obj.ToString().IsEmpty) Then
            Return 0
        End If

        Return Convert.ToDecimal(obj)
    End Function

    <Extension()> _
    Public Function ToStringTrim(ByVal obj As Object) As String
        If (obj Is Nothing) Then
            Return ""
        Else
            Return obj.ToString().Trim()
        End If
    End Function

    <Extension()> _
    Public Function ToStringOrEmpty(ByVal obj As Object) As String
        If (obj Is Nothing) Then
            Return ""
        ElseIf ToStringTrim(obj) = "" Then
            Return ""
        End If
        Return obj.ToString()
    End Function


    <Extension()> _
    Public Function ToStringOrDBNull(ByVal obj As Object) As Object
        If (obj Is Nothing) Then
            Return DBNull.Value
        End If
        Return obj.ToString()
    End Function


    <Extension()> _
    Public Function ToStringOrNull(ByVal obj As Object) As Object
        If (obj Is Nothing) Then
            Return Nothing
        ElseIf obj.ToString().Trim = "" Then
            Return Nothing
        End If
        Return obj.ToString()
    End Function


    <Extension()> _
    Public Function ToIntOrZero(ByVal obj As Object) As Integer
        If (obj Is Nothing OrElse Not IsNumeric(obj)) Then
            Return 0
        End If
        Return Convert.ToInt32(obj)
    End Function

    <Extension()> _
    Public Function ToIntOrNull(ByVal obj As Object) As Integer?
        If (obj Is Nothing OrElse Not IsNumeric(obj)) Then
            Return Nothing
        End If
        Return Convert.ToInt32(obj)
    End Function

    Public Function GetUniqueID() As String
        Return Guid.NewGuid().ToString("N")
    End Function

    <Extension()> _
    Public Function ToDatatable(Of T)(data As List(Of T)) As DataTable
        Dim props As PropertyDescriptorCollection = TypeDescriptor.GetProperties(GetType(T))
        Dim table As New DataTable()
        For i As Integer = 0 To props.Count - 1
            Dim prop As PropertyDescriptor = props(i)
            If prop.PropertyType.IsGenericType AndAlso prop.PropertyType.GetGenericTypeDefinition() = GetType(Nullable(Of )) Then
                table.Columns.Add(prop.Name, prop.PropertyType.GetGenericArguments()(0))
            Else
                table.Columns.Add(prop.Name, prop.PropertyType)
            End If
        Next
        Dim values As Object() = New Object(props.Count - 1) {}
        For Each item As T In data
            For i As Integer = 0 To values.Length - 1
                values(i) = props(i).GetValue(item)
            Next
            table.Rows.Add(values)
        Next
        Return table
    End Function

    <Extension()> _
    Public Function ToDisplayDate(ByVal dte As DateTime) As String
        Return dte.ToString(CommonConstants.SYS_DATE_FORMATE, CommonConstants.SYS_DATE_CULTURE)
    End Function

    <Extension()> _
    Public Function ToDisplayDateEN(ByVal dte As DateTime) As String
        Return dte.ToString(CommonConstants.SYS_DATE_FORMATE, CommonConstants.SYS_DATE_CULTURE_EN)
    End Function

    <Extension()> _
    Public Function ToDisplayDateTime(ByVal dte As DateTime) As String
        Return dte.ToString(CommonConstants.SYS_DATE_TIME_FORMATE, CommonConstants.SYS_DATE_CULTURE)
    End Function

    <Extension()> _
    Public Function ToDisplayDate(ByVal dte As Date?) As String
        If (dte IsNot Nothing) Then
            Return dte.Value.ToString(CommonConstants.SYS_DATE_FORMATE, CommonConstants.SYS_DATE_CULTURE)
        End If
        Return Nothing
    End Function

    <Extension()> _
    Public Function ToDisplayDateEN(ByVal dte As Date?) As String
        If (dte IsNot Nothing) Then
            Return dte.Value.ToString(CommonConstants.SYS_DATE_FORMATE, CommonConstants.SYS_DATE_CULTURE_EN)
        End If
        Return Nothing
    End Function


    <Extension()> _
    Public Function ToDisplayDateTime(ByVal dte As Date?) As String
        If (dte IsNot Nothing) Then
            Return dte.Value.ToString(CommonConstants.SYS_DATE_TIME_FORMATE, CommonConstants.SYS_DATE_CULTURE)
        End If
        Return Nothing
    End Function


    <Extension()> _
    Public Function BuddisToStoreDate(ByVal dte As String) As DateTime?
        Dim InvalidYear As Integer = DateTime.Now.Year - 543
        Dim tmpDate As DateTime
        If (DateTime.TryParseExact(dte, CommonConstants.SYS_DATE_FORMATE, CommonConstants.SYS_DATE_CULTURE, DateTimeStyles.None, tmpDate)) Then
            If (InvalidYear >= tmpDate.Year) Then
                tmpDate = New DateTime(tmpDate.Year + 543, tmpDate.Month, tmpDate.Day)
            End If
            Return tmpDate
        End If
        Return Nothing
    End Function

    <Extension()> _
    Public Function ToStoreDate(ByVal dte As String, Optional format As String = CommonConstants.SYS_DATE_FORMATE) As DateTime?
        Dim tmpDate As DateTime

        If (DateTime.TryParseExact(dte, format, System.Globalization.CultureInfo.InvariantCulture, DateTimeStyles.None, tmpDate)) Then
            Return tmpDate
        End If
        Return Nothing
    End Function

    Public Function ZipFolder(folder As String) As String
        Dim zipFile As String = String.Format("{0}.zip", folder)
        Using zip As New ZipFile
            zip.AddDirectory(folder)
            zip.Save(zipFile)
            System.IO.Directory.Delete(folder, True)
        End Using
        Return zipFile
    End Function

    Public Sub CreateFolder(folder As String)
        If (System.IO.Directory.Exists(folder)) Then
            System.IO.Directory.Delete(folder, True)
        Else
            System.IO.Directory.CreateDirectory(folder)
        End If
    End Sub


    <System.Runtime.CompilerServices.Extension> _
    Public Function RenderRazorViewToString(controller As Controller, viewName As String, model As Object) As String

        controller.ViewData.Model = model
        Using sw = New StringWriter()
            Dim viewResult = ViewEngines.Engines.FindPartialView(controller.ControllerContext, viewName)
            Dim viewContext = New ViewContext(controller.ControllerContext, viewResult.View, controller.ViewData, controller.TempData, sw)
            viewResult.View.Render(viewContext, sw)
            viewResult.ViewEngine.ReleaseView(controller.ControllerContext, viewResult.View)
            Return sw.GetStringBuilder().ToString()
        End Using
    End Function



    Public Sub WriteTextLog(Path As String, text As String)


        If Not Directory.Exists(Path) Then
            Directory.CreateDirectory(Path)
        End If

        Dim savePath As [String] = Path
        Dim writer As StreamWriter = Nothing
        Dim reader As StreamReader = Nothing
        Dim dateTime__1 As [String] = DateTime.Now.ToString("HH:mm:ss")
        Dim tempFile As [String] = SysConstants.CommonConstants.REPORT_TEMP + "/tempFile.xml"

        If File.Exists(savePath) Then
            writer = New StreamWriter(tempFile)
            writer.WriteLine([String].Format("<{0}>", dateTime__1))
            writer.WriteLine(text)
            writer.WriteLine([String].Format("</{0}>", dateTime__1))
            reader = New StreamReader(savePath)
            While Not reader.EndOfStream
                writer.WriteLine(reader.ReadLine())
            End While
            reader.Close()
            writer.Close()
            reader = New StreamReader(tempFile)
            writer = New StreamWriter(savePath)
            writer.Write(reader.ReadToEnd())
            reader.Close()
        Else
            writer = New StreamWriter(savePath)
            writer.WriteLine([String].Format("<{0}>", dateTime__1))
            writer.WriteLine(text)
            writer.WriteLine([String].Format("</{0}>", dateTime__1))
        End If
        writer.Close()

    End Sub


    Public Sub InitialExcelemplateToResultFile(ByVal TemplateFileName As String, ByVal resultFile As String)

        Dim resultPath As String = Path.GetDirectoryName(resultFile)

        If (Directory.Exists(resultPath)) Then
            Directory.Delete(resultPath, True)
        End If
        Threading.Thread.Sleep(3000)
        Directory.CreateDirectory(resultPath)

        System.IO.File.Copy(Path.Combine(SysConstants.CommonConstants.REPORT_TEMPLATE_PATH, TemplateFileName), resultFile, True)
    End Sub

    Public Function GetTHString(ByVal input As String) As String
        Dim reg As New Regex("[ก-๙(\s)]+", RegexOptions.IgnoreCase)
        Return reg.Match(input).Groups(0).Value
    End Function

    Public Function GetNumberString(ByVal input As String) As String
        Dim reg As New Regex("[0-9]+", RegexOptions.IgnoreCase)
        Return reg.Match(input).Groups(0).Value
    End Function


    <System.Runtime.CompilerServices.Extension> _
    Public Function ListToCSV(Of T)(list As List(Of T)) As String
        Dim sb As New StringBuilder()

        'Get the properties for type T for the headers
        Dim propInfos As PropertyInfo() = GetType(T).GetProperties()
        For i As Integer = 0 To propInfos.Length - 1
            sb.Append(propInfos(i).Name)

            If i < propInfos.Length - 1 Then
                sb.Append(",")
            End If
        Next

        sb.AppendLine()

        'Loop through the collection, then the properties and add the values
        For i As Integer = 0 To list.Count - 1
            Dim item As T = list(i)
            For j As Integer = 0 To propInfos.Length - 1
                Dim o As Object = item.[GetType]().GetProperty(propInfos(j).Name).GetValue(item, Nothing)
                If o IsNot Nothing Then
                    Dim value As String = o.ToString()

                    'Check if the value contans a comma and place it in quotes if so
                    If value.Contains(",") Then
                        value = String.Concat("""", value, """")
                    End If

                    'Replace any \r or \n special characters from a new line with a space
                    If value.Contains(vbCr) Then
                        value = value.Replace(vbCr, " ")
                    End If
                    If value.Contains(vbLf) Then
                        value = value.Replace(vbLf, " ")
                    End If

                    sb.Append(value)
                End If

                If j < propInfos.Length - 1 Then
                    sb.Append(",")
                End If
            Next

            sb.AppendLine()
        Next

        Return sb.ToString()
    End Function


    <System.Runtime.CompilerServices.Extension> _
    Public Function ListToAdlerFormat(Of T)(list As List(Of T)) As String
        Dim sb As New StringBuilder()

        'Get the properties for type T for the headers
        Dim propInfos As PropertyInfo() = GetType(T).GetProperties()
        For i As Integer = 0 To propInfos.Length - 1
            sb.Append(propInfos(i).Name)

            If i < propInfos.Length - 1 Then
                sb.Append(",")
            End If
        Next

        sb.AppendLine()

        'Loop through the collection, then the properties and add the values
        For i As Integer = 0 To list.Count - 1
            Dim item As T = list(i)
            For j As Integer = 0 To propInfos.Length - 1
                Dim o As Object = item.[GetType]().GetProperty(propInfos(j).Name).GetValue(item, Nothing)
                If o IsNot Nothing Then
                    Dim value As String = o.ToString()
                    If TypeOf o Is Date Or TypeOf o Is DateTime Then
                        value = DirectCast(o, Date).ToString("dd/MM/yyyy")
                    ElseIf TypeOf o Is Date? Or TypeOf o Is DateTime? Then
                        value = DirectCast(o, Date?).Value.ToString("dd/MM/yyyy")
                    ElseIf TypeOf o Is Decimal Or TypeOf o Is Decimal? Then
                        value = DirectCast(o, Decimal?).ToMoneyFormat()
                    End If


                    value = String.Concat("""", value, """")


                    'Replace any \r or \n special characters from a new line with a space
                    If value.Contains(vbCr) Then
                        value = value.Replace(vbCr, " ")
                    End If
                    If value.Contains(vbLf) Then
                        value = value.Replace(vbLf, " ")
                    End If

                    sb.Append(value)
                End If

                If j < propInfos.Length - 1 Then
                    sb.Append(",")
                End If
            Next

            sb.AppendLine()
        Next

        Return sb.ToString()
    End Function


    Public Function IsNullable(Of T)(value As T) As Boolean
        Return Nullable.GetUnderlyingType(GetType(T)) IsNot Nothing
    End Function

End Module



'=======================================================
