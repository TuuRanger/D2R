﻿Public Class HtmlKeyVal
    Public Property Key As String
    Public Property Val As String
End Class
