﻿Namespace CustomAttribute
    Public Class ExcelReadColumnMappingAttribute
        Inherits Attribute
        Public Property Column As String
        Public Sub New(ByVal Column As String)
            Me.Column = Column
        End Sub
    End Class
End Namespace

