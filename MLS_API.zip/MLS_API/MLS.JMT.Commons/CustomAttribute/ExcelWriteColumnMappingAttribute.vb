﻿Namespace CustomAttribute
    Public Class ExcelWriteColumnMappingAttribute
        Inherits Attribute
        Public Property Column As String
        Public Sub New(ByVal Column As String)
            Me.Column = Column
        End Sub
    End Class
End Namespace

