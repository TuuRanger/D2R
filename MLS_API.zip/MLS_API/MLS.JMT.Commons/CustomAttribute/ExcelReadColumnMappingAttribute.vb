﻿Namespace CustomAttribute
    Public Class ExcelReadColumnFixedColumn
        Inherits Attribute
        Public Property Cell As String
        Public Sub New(ByVal Cell As String)
            Me.Cell = Cell
        End Sub
    End Class
End Namespace

