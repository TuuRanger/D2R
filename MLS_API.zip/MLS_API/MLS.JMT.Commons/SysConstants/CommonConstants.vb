﻿Imports System.Web
Imports System.IO
Imports System.Configuration
Imports System.Globalization

Namespace SysConstants
    Public Class CommonConstants
        Public Const LOG_PATH As String = "D:/Temp File/JMTLOG"
        Public Shared APP_PATH As String = HttpContext.Current.Server.MapPath("~")
        Public Shared REPORT_TEMPLATE_PATH As String = Path.Combine(APP_PATH, "Template")
        Public Shared PATH_NCB As String = Path.Combine(APP_PATH, "NCB")
        Public Shared REPORT_TEMP As String = Path.Combine(APP_PATH, "REPORT_TEMP")
        Public Shared EXTERNAL_SCRIPT_PATH As String = Path.Combine(APP_PATH, "scripts/external")
        Public Shared SITE_URL As String = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) + New System.Web.UI.Control().ResolveUrl("~/")
        Public Shared TEST_MODE As Boolean = False
        Public Const SCRIPT_HtmlControlsSelectpicker As String = "HtmlControlsSelectpicker.txt"
        Public Const SYS_DATE_FORMATE As String = "dd/MM/yyyy"
        Public Const SYS_DATE_TIME_FORMATE As String = "dd/MM/yyyy HH:mm:ss"
        Public Const SYS_MONTHLY_FORMATE As String = "MM/yyyy"
        Public Shared SYS_DATE_CULTURE As CultureInfo = New CultureInfo("th-TH")
        Public Shared SYS_DATE_CULTURE_EN As CultureInfo = New CultureInfo("en-US")
        Public Shared PATH_BANK_LOGO_FOLDER As String = Path.Combine(APP_PATH, "BankLogo")
        Public Shared GlobalAsset_ScriptTemplete As String = Path.Combine(APP_PATH, "GlobalAsset/ScriptTemplate")
        Public Shared GlobalAsset_DisplayTemplete As String = Path.Combine(APP_PATH, "GlobalAsset/ScriptTemplate/DisplayTemplete")
    End Class

    Public Class ScriptTemplete
        Public Const BoostrapTypeHead As String = "BoostrapTypeHead.js"
        Public Const KendoDatePicker As String = "KendoDatePicker.js"
        Public Const KendoCheckBox As String = "KendoCheckBox.html"

    End Class

    Public Class DisplayTemplete
        Public Const ValueDetail As String = "ttValueDetail.html"
    End Class

    Public Class ImportType
        Public Const FIRSTREAD_PRODUCT_RECEIVE As String = "FIRSTREAD_PRODUCT_RECEIVE"
        Public Const PRODUCT_RECEIVE As String = "PRODUCT_RECEIVE"
        Public Const FIRSTREAD_MONEY_RECEIVE As String = "FIRSTREAD_MONEY_RECEIVE"
        Public Const MONEY_RECEIVE As String = "MONEY_RECEIVE"

        Public Const FIRSTREAD_ERROR_PRODUCT_RECEIVE As String = "FIRSTREAD_ERROR_PRODUCT_RECEIVE"
    End Class

    Public Enum ErrorCode
        DUPLICATE
        INVALID_NAME
        INVALID_TYPE
    End Enum

    Public Class Operation
        Public Const SaveAndClose As String = "SaveAndClose"
        Public Const Verify As String = "Verify"
        Public Const Judgment As String = "Judgment"
        Public Const ApplicationProcess As String = "ApplicationProcess"
    End Class

    Public Class Tags
        Public Const GetNCBData As String = "GetNCBData"
    End Class

    Public Class Keys
        Public Const CurrentScreen As String = "CommonsCurrentScreen"
        Public Const PageSize As String = "PageSize"
        Public Const PageCount As String = "PageCount"
        Public Const ReturnResult As String = "COMResutlResult"
        Public Const ReturnMsg As String = "COMReturnMsg"
        Public Const ReturnObject As String = "COMReturnObject"
    End Class

    Public Class Screens
        Public Const NewAppEntry As String = "NewAppEntry"
        Public Const AppProcess As String = "AppProcList"
        Public Const JudementEntry As String = "JudementEntry"
        Public Const FullFillEntry As String = "FullFillEntry"
    End Class

    Public Class YesNoFlag
        Public Const Yes As String = "Y"
        Public Const No As String = "N"
    End Class

    Public Class PaymentTableFieldResult
        Public Const Installment As String = "Installment"
        Public Const LoanApprove As String = "LoanApprove"
        Public Const TermApprove As String = "TermApprove"
    End Class


    Public Class SubmitFormAction
        Public Const Save As String = "save"
        Public Const Cancel As String = "cancel"
        Public Const Reject As String = "reject"
        Public Const SEND_BACK As String = "sendback"
        Public Const SaveCloseModal As String = "SaveClose"
        Public Const SaveCloseModalForJudgment As String = "SaveCloseModalForJudgment"
        Public Const SendToJudgment As String = "tojudg"
        Public Const SubmitNext As String = "next"
        Public Const SaveEditJudgment As String = "savejudgment"
        Public Const CANCEL_CONTRACT As String = "cancelContract"
        Public Const REJECTL_CONTRACT As String = "rejectContract"
        Public Const APPROVE_CONTRACT As String = "approveContracr"
        Public Const SubmitNew As String = "new"
        Public Const SaveFullFill As String = "SaveFullFill"
    End Class

    Public Class TEL_TYPE
        Public Const Home As String = "H"
        Public Const Office As String = "O"
        Public Const Mobile As String = "M"
        Public Const Relative As String = "R"
        Public Const Family As String = "F"
        Public Const None As String = "N"
    End Class

    Public Class TEL_RESULT
        Public Const _01 As String = "01"
        Public Const _02 As String = "02"
        Public Const _03 As String = "03"
        Public Const _04 As String = "04"
        Public Const _05 As String = "05"
    End Class

    Public Class ApplyPromotion
        Public Const MGM As String = "01"
    End Class

    Public Class TABKEYONE
        Public Const TELLEVRSLO As String = "TELLEVRSLO"
        Public Const TELLEVRSLH As String = "TELLEVRSLH"
        Public Const TELLEVRSLM As String = "TELLEVRSLM"
        Public Const TELLEVRSLR As String = "TELLEVRSLR"
        Public Const TELLEVRSLF As String = "TELLEVRSLF"
        Public Const CONAPPLY_PROJEC As String = "CONAPPLY_PROJEC"
        Public Const MLSVALUE As String = "MLSVALUE"
        Public Const CONINTRTES001 As String = "CONINTRTES001"
        Public Const SHOWREFTYP As String = "SHOWREFTYP"
        Public Const ACCBUSTYP As String = "ACCBUSTYP"
        Public Const CPNBRNCOD As String = "CPNBRNCOD"
        Public Const VENDORBRANCH As String = "VENDORBRANCH{0}"
        Public Const PRDSUBCOD As String = "PRDSUBCOD"
        Public Const CONAPPLY_VIABRN As String = "CONAPPLY_VIABRN"
        Public Const CONOBJCOD As String = "CONOBJCOD"
        Public Const INTERESTTYPE As String = "INTERESTTYPE"
        Public Const CONINTCAL As String = "CONINTCAL"

    End Class

    Public Class TABKEYTWO
        Public Const TERMSTEP As String = "TERMSTEP"
    End Class

    Public Class RegExPattern
        Public Const TH_ONLY As String = "^[ก-๙\\s\.]+$"
        Public Const NUMBERIC_ONLY As String = "^[0-9]+$"
        Public Const DISPLAY_DATE As String = "^[0-9]{2}\/[0-9]{2}\/[0-9]{4}$"
        Public Const HOMETELNO As String = "^[0-9]{2}-[0-9]{3}-[0-9]{4}$|^[0-9]{9}$"
        Public Const MOBILETELNO As String = "^[0-9]{3}-[0-9]{3}-[0-9]{4}$|^[0-9]{10}$"
    End Class

    Public Class ScreenMode
        Public Const ADD As String = "ADD"
        Public Const EDIT As String = "EDIT"
        Public Const View As String = "View"
    End Class

    Public Class ReturnResultCode
        Public Const OK As String = "OK"
        Public Const ERR As String = "ERR"

    End Class
End Namespace
