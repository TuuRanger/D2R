﻿Imports MLS.JMT.Commons.SysConstants.CommonConstants
Imports System.IO

Namespace SysConstants
    Public Class ReportAliasName
        Public Const RPT10000 As String = "ใบสรุปสำคัญจ่าย {0}"
        Public Const RPT30000 As String = "Sale Detail {0}"
        Public Const RPT40000 As String = "Installment Table {0}"
        Public Const RPT20000 As String = "Internal Memo {0}"
        Public Const RPTAccountBBLPayment As String = "BBL Payment"
    End Class
End Namespace


