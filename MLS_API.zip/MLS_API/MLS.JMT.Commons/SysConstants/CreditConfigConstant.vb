﻿Namespace SysConstants
    Public Class CreditConfigConstant

        Public Class ACTION
            Public Const AUTO_REJECT As String = "01"
        End Class


        Public Class Purpose
            Public Const SalaryMultiplier As String = "SAL_MUL"
        End Class


    End Class
End Namespace
