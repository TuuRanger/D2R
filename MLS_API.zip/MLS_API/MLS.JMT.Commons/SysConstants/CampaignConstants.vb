﻿Namespace SysConstants
    Public Class CampaignConstants
        Public Class Keys
            Public Const ScreenMode As String = "CPGMScreenMode"
        End Class
    End Class
End Namespace
