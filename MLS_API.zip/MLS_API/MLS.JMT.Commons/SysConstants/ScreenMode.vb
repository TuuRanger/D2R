﻿Namespace SysConstants
 

End Namespace
