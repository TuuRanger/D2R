﻿Namespace SysConstants
    Public Class BankTransferConstant
        Public Class BTHTYP
            Public Const JmtBranch As String = "JMTBRN"
            Public Const JmtNetwork As String = "JMTNET"
            Public Const BillPayment As String = "BP"
            Public Const VOID As String = "VOID"
            Public Const Adjust As String = "ADJ"
        End Class

        Public Class BTHGRP
            Public Const Receive As String = "R"
            Public Const Pay As String = "P"
            Public Const Void As String = "V"
        End Class

       
    End Class

    Public Class FileExtension
        Public Const xls As String = ".xls"
        Public Const xlsx As String = ".xlsx"
        Public Const txt As String = ".txt"
    End Class
End Namespace

