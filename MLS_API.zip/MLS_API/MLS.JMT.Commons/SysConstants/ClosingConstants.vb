﻿Namespace SysConstants
    Public Class ClosingConstants
        Public Class PayReceiveType
            Public Const Cash As String = "1"
            Public Const Cheque As String = "2"
            Public Const Transfer As String = "3"
            Public Const Direct As String = "4"
            Public Const MoneyOrder As String = "6"
            Public Const Suspend As String = "8" 
        End Class
    End Class 
End Namespace
