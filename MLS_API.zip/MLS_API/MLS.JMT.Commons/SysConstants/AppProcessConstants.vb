﻿Namespace SysConstants
    Public Class AppProcessConstants

        Public Class CreditStepResult
            Public Const CANCEL As String = "C"
            Public Const REJECT As String = "N"
            Public Const APPROVE As String = "Y"
            Public Const SEND_BACK As String = "B"
        End Class

        Public Class Key
            Public Const ActualStep As String = "APPActualStep"
            Public Const RemarkList As String = "APPRemarkList"
            Public Const RemarkCount As String = "APPRemarkCount"
            Public Const InstallmentTable As String = "APPInstallmentTable"
            Public Const FeeInfo As String = "APPFeeInfo"
            Public Const SessionKey As String = "APPSessionKey"
        End Class

        Public Class TermType
            Public Const MON As String = "MON"
        End Class

        Public Class CaculationMode
            Public Const Begining As String = "B"
            Public Const Ending As String = "E"
            Public Const Special As String = "S"
        End Class


        Public Enum CalculateFor
            Term
            Loan
            Installment
        End Enum

        Public Class CONAPPLY_PROJEC
            Public Const S001 As String = "S001"
            Public Const S002 As String = "S002"
            Public Const P012 As String = "P012"
            Public Const SamsungCollaborate As String = "C001"
            Public Const P014_WalkInPL As String = "P014"
            Public Const P015_FRANCHISE As String = "P015"
        End Class

        Public Class CONOBJCOD
            Public Const NORMAL_PL As String = "01"
            Public Const HR As String = "02"
            Public Const SWITCHING As String = "03"
            Public Const COLLABORATE As String = "11"
            Public Const CAR4CASH As String = "21"
            Public Const REFUN As String = "05"
        End Class

        Public Class ACCBUSTYP
            Public Const _2050 As String = "2050"
            Public Const _2060 As String = "2060"
            Public Const _2110 As String = "2110"
            Public Const CAR4CASH As String = "2065"
        End Class

        Public Class CRDDEVIAT
            Public Const E01 As String = "E01"
            Public Const C01 As String = "C01"
            Public Const E02 As String = "E02"
            Public Const B02 As String = "B02"
            Public Const F01 As String = "F01"
            Public Const M03 As String = "M03"
            Public Const M05 As String = "M05"
            Public Const B03 As String = "B03"
            Public Const B04 As String = "B04"
            Public Const N11 As String = "N11"
            Public Const N08 As String = "N08"
        End Class

        Public Class CONAPPLY_PROMOT
            Public Const MGM As String = "01"
        End Class

        Public Enum CONTRAC_MSG
            PAYMENT_ABILITY_NOT_FOUND
        End Enum

        Public Class SHOWREFTYP
            Public Const Reference As String = "REF"
            Public Const Guarantor As String = "GUA"
            Public Const Both As String = "BOT"
        End Class

        Public Class SalaryReceiveType
            Public Const Transfer As String = "01"
            Public Const Cash As String = "02"
            Public Const Cheq As String = "03"
        End Class

        Public Class CooperateType
            Public Const GovernmentOfficials As String = "01"
            Public Const BusinessEmployee As String = "02"
            Public Const StateEnterpriseOfficer As String = "03"
        End Class

        Public Class CashConstantForCooperateType
            Public Const GovernmentOfficials As Decimal = 15000
            Public Const BusinessEmployee As Decimal = 10000
        End Class

        Public Class R_FLAG
            Public Const JMTPLUS As String = "JMTPLUS"
            Public Const JMTNETWORK As String = "JMTNETWORK"
        End Class
    End Class
End Namespace
