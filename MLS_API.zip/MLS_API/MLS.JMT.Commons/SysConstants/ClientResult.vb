﻿Namespace SysConstants
    Public Enum ClientResult
        OK
        FAIL
    End Enum
End Namespace

