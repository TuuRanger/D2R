﻿Namespace SysConstants
    Public Class INQConstant
        Public Class Keys
            Public Const CustomerTransaction As String = "INQCustomerTransaction"
        End Class
    End Class
End Namespace
