﻿Namespace SysConstants
    Public Class NCBConstant
        Public Class Key
            Public Const NCBResult As String = "NCBNCBResult"
        End Class
    End Class
End Namespace

