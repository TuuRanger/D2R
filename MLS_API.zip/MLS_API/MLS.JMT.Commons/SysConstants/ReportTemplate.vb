﻿Imports MLS.JMT.Commons.SysConstants.CommonConstants
Imports System.IO

Namespace SysConstants

    Public Class ReportTemplate
        Public Shared LogoPath = Path.Combine(REPORT_TEMPLATE_PATH, "logo-JMT.png")
        Public Shared RPT1000_SimpleTemplatePath = Path.Combine(REPORT_TEMPLATE_PATH, "Simple.pdf")


        Public Class SamsungReceive
            Public Shared RPTJaymartPaymentReceived = Path.Combine(REPORT_TEMPLATE_PATH, "RPTJaymartPaymentReceived.xls")
            Public Shared RPTBillPaymentReceive = Path.Combine(REPORT_TEMPLATE_PATH, "RPTBillPaymentReceive.xls")
            Public Shared RPTSamsungProductReceived = Path.Combine(REPORT_TEMPLATE_PATH, "RPTSamsungProductReceived.xls")

            Public Shared SPC001 = Path.Combine(REPORT_TEMPLATE_PATH, "SPC001.xlsx")
        End Class
    End Class





End Namespace
