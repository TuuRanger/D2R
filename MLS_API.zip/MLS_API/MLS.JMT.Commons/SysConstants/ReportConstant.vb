﻿Namespace SysConstants
    Public Class ReportConstant

        Public Class Key
            Public Const Result As String = "RPTResult"
        End Class

        Public Class ReportResult
            Public Const NOT_FOUND As String = "NOT_FOUND"
        End Class



    End Class
End Namespace
