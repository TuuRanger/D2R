﻿Namespace SysConstants
    Public Class InquiryConstants
        Class Keys
            Public Const CustomertListCriteria As String = "INQCustomertListCriteria"

            Public Const CustomertListPageCount As String = "INQCustomertListPageCount"

            Public Const CustomertListCurrentPage As String = "INQCustomertListCurrentPage"
        End Class
    End Class
End Namespace

