﻿Namespace SysConstants
    Public Class BCMConstants
        Public Class Key
            Public Const SelectedContract As String = "BCMSelectedContract"
            'Public Const ContractDetailJSON As String = "BCMContractDetailJSON"
            Public Const ContractDetail As String = "BCMContractDetail"
            Public Const ScreenMode As String = "BCMScreenMode"
            Public Const Address As String = "BCMAddress"
            Public Const GuarantorList As String = "BCMGuarantorList"
            Public Const ReferencePersonList As String = "BCMReferencePersonList"
            Public Const TelNoList As String = "BCMTelNoList"
            Public Const TelNoList2 As String = "BCMTelNoList2"
            Public Const FullFillResult As String = "BCMFullFillResult"
            Public Const QuestionList As String = "BCMQuestionList"
            Public Const RemarkList As String = "BCMRemarkList"
            Public Const JugementList As String = "BCMJugementList"
            Public Const CurrentStep As String = "BCMCurrentStep"
            Public Const Tab1Attr As String = "BCMTab1Attr"
            Public Const Tab2Attr As String = "BCMTab2Attr"
            Public Const Tab3Attr As String = "BCMTab3Attr"
            Public Const Tab4Attr As String = "BCMTab4Attr"
            Public Const Tab5Attr As String = "BCMTab5Attr"
            Public Const Tab6Attr As String = "BCMTab6Attr"
            Public Const Tab7Attr As String = "BCMTab7Attr"
            Public Const ScreenName As String = "BCMScreenName"
            Public Const IsSubmitBasicInfo As String = "BCMIsSubmitBasicInfo"

            Public Const CONAPPLY_VIA_LIST As String = "BCMCONAPPLY_VIA_LIST"
            Public Const CONAPPLY_TYP_LIST As String = "BCMCONAPPLY_TYP_LIST"
            Public Const CONOBJCOD_LIST As String = "BCMCONOBJCOD_LIST"
            Public Const CONAPPLY_PROMOT_LIST As String = "BCMCONAPPLY_PROMOT_LIST"
        End Class

      
    End Class
End Namespace
