﻿Namespace SysConstants
    Public Class ReceivingProcessConstant
        Public Class Keys
            Public Const ImportFileName As String = "RPImportFileName"
            Public Const BTHTYP As String = "RPBTHTYP"
            Public Const FirstReadErrorData As String = "RPFirstReadErrorData"
        End Class



    End Class
End Namespace
