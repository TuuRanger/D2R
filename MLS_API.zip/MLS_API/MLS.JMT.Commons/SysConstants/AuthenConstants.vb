﻿Public Class AuthenConstants
    Public Const UserLogin As String = "AUTUserLogin"
End Class
