﻿Public Class TestMode
    Public Class NameSurName
        Public Property Name As String
        Public Property Surname As String
    End Class
    Public Shared listNameSurname As New List(Of NameSurName)
    Public Shared Sub Initial()

        listNameSurname.Add(New NameSurName() With {.Name = "กกกรณ์", .Surname = "ดวงทับจันทร์ "})
        listNameSurname.Add(New NameSurName() With {.Name = "กกกรณ์", .Surname = "ประเสริฐทองสุก "})
        listNameSurname.Add(New NameSurName() With {.Name = "ฟขกฤตยชญ์", .Surname = "แจ่มศรี  "})
        listNameSurname.Add(New NameSurName() With {.Name = "ฟขกฤตยชญ์", .Surname = "แจ่มศรี  "})
        listNameSurname.Add(New NameSurName() With {.Name = "คคนัมพร   ", .Surname = " พระเอก "})
        listNameSurname.Add(New NameSurName() With {.Name = "คคนัมพร   ", .Surname = "มงคลเกษตร  "})
        listNameSurname.Add(New NameSurName() With {.Name = "คคนัมพร   ", .Surname = "อินกระทึก "})
        listNameSurname.Add(New NameSurName() With {.Name = "คคนัมพร   ", .Surname = "โทณผลิน "})
        listNameSurname.Add(New NameSurName() With {.Name = "คคนัมพร   ", .Surname = "มงคลเกษตร "})
        listNameSurname.Add(New NameSurName() With {.Name = "คคนัมพร   ", .Surname = "หงษ์ใจสี "})
        listNameSurname.Add(New NameSurName() With {.Name = "คคนัมพร   ", .Surname = "เดชะศิริ "})
        listNameSurname.Add(New NameSurName() With {.Name = "ฉกรรณ์      ", .Surname = "คชรินทร์      "})
        listNameSurname.Add(New NameSurName() With {.Name = "ฉกาจพล    ", .Surname = "สราญรมย์ "})
        listNameSurname.Add(New NameSurName() With {.Name = "พกรณ์       ", .Surname = "สิทธินามสุวรรณ "})
        listNameSurname.Add(New NameSurName() With {.Name = "พกาทิพย์    ", .Surname = "วุฒิรักษ์ "})
        listNameSurname.Add(New NameSurName() With {.Name = "พกาวรรณ  ", .Surname = "ขวัญยืน "})
        listNameSurname.Add(New NameSurName() With {.Name = "พงค์ตะวัน  ", .Surname = "นันทกิจไพศาล "})
        listNameSurname.Add(New NameSurName() With {.Name = "พกาวรรณ  ", .Surname = "ขวัญยืน "})
        listNameSurname.Add(New NameSurName() With {.Name = "ภคพันธ์     ", .Surname = "ตั้งนภากร "})
        listNameSurname.Add(New NameSurName() With {.Name = "ภคพันธ์     ", .Surname = "ภัทรนันทกานต์ "})

    End Sub


    Public Shared Function GetRandom(ByVal Min As Integer, ByVal Max As Integer) As Integer
        Dim Generator As System.Random = New System.Random()
        Return Generator.Next(Min, Max)
    End Function
End Class
