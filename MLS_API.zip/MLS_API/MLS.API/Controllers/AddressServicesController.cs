﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp.Implement;
using MLS.Imp.Interface;
using MLS.Models;

namespace MLS.API.Controllers
{
    public class AddressServicesController : ApiController
    {
        IAddressSvc _service = new AddressSvc();

        [HttpGet]
        public List<CustomerAddressResult> GetCustomerAddress(String CUSCOD)
        {
            return _service.GetCustomerAddress(CUSCOD);
        }

        

        [HttpPost,Route("api/AddressServices/InsertOrUpdateAddress/{CUSCOD}/{username}")]
        public void InsertOrUpdateAddress(List<CustomerAddressResult> listAddress, string CUSCOD, string userName)
        {
            _service.InsertOrUpdateAddress(listAddress, CUSCOD, userName); 
        }
    }
}
