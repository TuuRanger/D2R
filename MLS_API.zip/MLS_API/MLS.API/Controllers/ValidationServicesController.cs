﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp.Implement;
using MLS.Imp.Interface;
using MLS.Models;
using MLS.Models.MockModel;

namespace MLS.API.Controllers
{
    public class ValidationServicesController : ApiController
    {
        IValidationSvc _svc = null;

        public ValidationServicesController()
        {
            _svc = new ValidationSvc();
        }

        [HttpPost]
        public List<FieldValidateResult> GetFieldValidation([FromBody]List<String> listValidateID)
        {
            return _svc.GetFieldValidation(listValidateID);


        }

        [HttpPost]
        public RejectResult GetContractAutoRejectResult([FromBody]ContractDetailResult contractDetail)
        {
            return _svc.GetContractAutoRejectResult(contractDetail);
        }

        [HttpGet]
        public bool CheckAccountMaxCreditLine(String ACCBUSTYP, decimal sourceValue)
        {
            return _svc.CheckAccountMaxCreditLine(ACCBUSTYP, sourceValue);
        }

        [HttpGet]
        public bool CheckAccountMaxCreditPerTime(String ACCBUSTYP, decimal sourceValue)
        {
            return _svc.CheckAccountMaxCreditPerTime(ACCBUSTYP, sourceValue);
        }

        [HttpGet]
        public bool CheckAccountMinCreditPerTime(String ACCBUSTYP, decimal sourceValue)
        {
            return _svc.CheckAccountMinCreditPerTime(ACCBUSTYP, sourceValue);
        }

        [HttpGet]
        public bool CheckAccountMinAdvanceRate(decimal sourceValue)
        {
            return _svc.CheckAccountMinAdvanceRate(sourceValue);
        }

        [HttpGet]
        public bool CheckAccountMinMaxAdvanceRate(decimal sourceValue)
        {
             return _svc.CheckAccountMaxAdvanceRate(sourceValue) && _svc.CheckAccountMinAdvanceRate(sourceValue);
        }
    }
}
