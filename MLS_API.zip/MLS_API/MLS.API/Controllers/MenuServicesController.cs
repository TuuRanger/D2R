﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp.Implement;
using MLS.Models;
using MLS.Imp.Interface;
using MLS.Helper;
namespace MLS.API.Controllers
{
    public class MenuServicesController : ApiController
    {
        IMenuSvc _service = null;

        public MenuServicesController()
        {
            _service = new MenuSvc();
        }

        public List<MenuViewModel> GetMenus(String token)
        {
            return _service.GetMenus(token);
        }
    }
}
