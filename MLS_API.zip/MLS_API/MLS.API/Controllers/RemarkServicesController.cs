﻿using MLS.Imp.Implement;
using MLS.Imp.Interface;
using MLS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MLS.API.Controllers
{
    public class RemarkServicesController : ApiController
    {
        IRemarkSvc _service = null;

        public RemarkServicesController()
        {
            _service = new RemarkSvc();
        }

        [HttpPost,Route("api/RemarkServices/InsertOrUpdateRemark/{CPNCOD}/{CPNBRNCOD}/{ACCBUSTYP}/{CONNUM}/{username}")]
        public void InsertOrUpdateRemark([FromBody]List<RemarkModel> listRemark,
            string CPNCOD,
            string CPNBRNCOD,
            string ACCBUSTYP,
            string CONNUM,
            string username)
        {
            _service.InsertOrUpdateRemark(listRemark,
                                          CPNCOD,
                                          CPNBRNCOD,
                                          ACCBUSTYP,
                                          CONNUM,
                                          username);
        }

    }
}
