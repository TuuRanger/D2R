﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp.Implement;
using MLS.Imp.Interface;
using MLS.Models;
using System.Collections;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;

namespace MLS.API.Controllers
{

    public class FollowUpServicesController : ApiController
    {
        IFollowUpSvc _svc = new FollowUpSvc();

        [HttpGet]
        public List<FollowUpHeaderResult> GetFollowUpHeader(string CPNCOD,
                                                            string CPNBRNCOD_FROM,
                                                            string CPNBRNCOD_TO,
                                                            string FOLSTATE,
                                                            Nullable<int> OVDDAY_FROM,
                                                            Nullable<int> OVDDAY_TO,
                                                            string ADRSPCARA_FROM,
                                                            string ADRSPCARA_TO)
        {
            return _svc.GetFollowUpHeader(CPNCOD,
                                          CPNBRNCOD_FROM,
                                          CPNBRNCOD_TO,
                                          FOLSTATE,
                                          OVDDAY_FROM,
                                          OVDDAY_TO,
                                          ADRSPCARA_FROM,
                                          ADRSPCARA_TO);
        }

        [HttpGet]
        public Dictionary<String, List<vwFollowUpHeader>> GetWorkLoadByUser(String FOLWERCOD)
        { 
            List<vwFollowUpHeader> workLoad = _svc.GetWorkLoadByUser(FOLWERCOD);
            Dictionary<String, List<vwFollowUpHeader>> result = new Dictionary<string, List<vwFollowUpHeader>>();
            result.Add("AllWorkLoad", workLoad.ToList());
            result.Add("InProgress", workLoad.Where(x => x.RECSTSCOD == "2").ToList());
            result.Add("SuccessAppointment", workLoad.Where(x => x.RECSTSCOD == "8").ToList());
            result.Add("FailAppointment", workLoad.Where(x => x.RECSTSCOD == "5").ToList());
            result.Add("Broke", workLoad.Where(x => x.RECSTSCOD == "7").ToList());
            return result;
        }



        [HttpPost,Route("api/FollowUpServices/AssignJob/{JobSetp}/{JobFunction}/{FOLWERCOD}/{username}")]
        public void AssignJob(string JobSetp,
                              string JobFunction,
                              string FOLWERCOD,
                              List<FollowUpHeaderResult> jobList,
                              string username)
        {
            _svc.AssignJob(JobSetp, JobFunction, FOLWERCOD, jobList, username);
        }

        [HttpPost, Route("api/FollowUpServices/DeassignJob/{JobSetp}/{JobFunction}/{FOLWERCOD}/{username}")]
        public void DeassignJob(string JobSetp,
                             string JobFunction,
                             string FOLWERCOD,
                             List<FollowUpHeaderResult> jobList,
                             string username)
        {
            _svc.DeassignJob(JobSetp, JobFunction, FOLWERCOD, jobList, username);
        }

        //[HttpPost, Route("api/FollowUpServices/GetFollowUpByContract/{CONNUM}/{CPNCOD}/{CPNBRNCOD}/{ACCBUSTYP}")]
        [HttpGet]
        public List<vwFollowUpHeader> GetFollowUpByContract(string CONNUM,
                             string CPNCOD,
                             string CPNBRNCOD,
                             String ACCBUSTYP)
        {
           return _svc.GetFollowUpByContract(CONNUM,CPNCOD,CPNBRNCOD,ACCBUSTYP);
        }

        [HttpGet]
        public List<vwFollowUpAlarm> GetFollowUpAlarm(String FOLWERCOD)
        {
            return _svc.GetFollowUpAlarm(FOLWERCOD);
        }

        [HttpPost , Route("api/FollowUpServices/InsertOrUpdateFollowUpDetail/{username}")]
        public void InsertOrUpdateFollowUpDetail([FromBody]Dictionary<String, String> dic, String username)
        {
            List<MLTFLH> jobHeader = JsonConvert.DeserializeObject< List < MLTFLH >>( dic["header"]);
            List<vwFollowUpDetail> jobDetail = JsonConvert.DeserializeObject<List<vwFollowUpDetail>>(dic["detail"]);
            _svc.InsertOrUpdateFollowUpDetail(jobHeader, jobDetail, username);

        }


        [HttpPost, Route("api/FollowUpServices/InsertOrUpdateAlarm/{username}")]
        public void InsertOrUpdateAlarm(List<vwFollowUpAlarm> listAlarm, string username)
        {
            _svc.InsertOrUpdateAlarm(listAlarm, username);
        }

        [HttpGet]
        public List<vwFollowUpDetail> GetFollowUpDetail(String JOBASGNUM, String CPNCOD, String CPNBRNCOD, String ACCBUSTYP)
        {
           return _svc.GetFollowUpDetail( JOBASGNUM,  CPNCOD,  CPNBRNCOD,  ACCBUSTYP);
        }
        [HttpGet]
        public List<vwUserSection> GetChildFollower(String GroupID)
        {
            return _svc.GetChildFollower(GroupID);
        }
    }
}
