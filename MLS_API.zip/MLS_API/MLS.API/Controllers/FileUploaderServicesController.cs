﻿using MLS.API.REQUEST_FILTERS;
using MLS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using MLS.Helper;
using System.IO;

namespace MLS.API.Controllers
{
    public class FileUploaderServicesController : ApiController
    {
        [HttpPost, Route("api/FileUploaderServices/UploadFile/{username}")]
        [ValidateMimeMultipartContentFilter]
        public async Task<FileResult> UploadFile(String username)
        {
            List<String> fileNames = new List<String>();
            var streamProvider = new MultipartFormDataStreamProvider(Path.Combine(Constants.UPLOAD_PATH, "RAW"));
            await Request.Content.ReadAsMultipartAsync(streamProvider);
            foreach (MultipartFileData fileData in streamProvider.FileData)
            {
                string fileName = fileData.Headers.ContentDisposition.FileName;
                String fileSuffix = DateTime.Now.ToString("yyyyHHmmssfff");
                if (fileData.Headers.ContentDisposition.FileName.IsEmpty())
                {
                    throw new Exception("Some file(s) does not have a name");
                }
                else
                {
                    if (fileName.StartsWith("\"") && fileName.EndsWith("\""))
                    {
                        fileName = fileName.Trim('"');
                    }
                    if (fileName.Contains(@"/") || fileName.Contains(@"\"))
                    {
                        fileName = Path.GetFileName(fileName);
                    }

                    String saveFileName = String.Format("{0}_{1}{2}", Path.GetFileNameWithoutExtension(fileName), fileSuffix, Path.GetExtension(fileName));
                    String savePath = Path.Combine(Constants.UPLOAD_PATH, saveFileName);
                    File.Move(fileData.LocalFileName, savePath);
                    fileNames.Add(savePath);
                }
            }

            return new FileResult
            {
                FileNames = fileNames
            /*FileNames = streamProvider.FileData.Select(entry => entry.LocalFileName),
            Names = streamProvider.FileData.Select(entry => entry.Headers.ContentDisposition.FileName),
            ContentTypes = streamProvider.FileData.Select(entry => entry.Headers.ContentType.MediaType),
            Description = streamProvider.FormData["description"],
            CreatedTimestamp = DateTime.UtcNow,
            UpdatedTimestamp = DateTime.UtcNow,
            DownloadLink = "TODO, will implement when file is persisited"*/
        };
    }
}
}
