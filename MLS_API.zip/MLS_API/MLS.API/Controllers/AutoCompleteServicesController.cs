﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Models;
using MLS.Imp.Implement;
namespace MLS.API.Controllers
{
    public class AutoCompleteServicesController : ApiController
    {
        AutoCompleteSvc _service = new AutoCompleteSvc();
        public List<TabkeyOneAutoCompleteResult> GetAutoCompleteTabKeyOne(String input)
        {
            return _service.GetAutoCompleteTabkeyOne(input);
        }
    }
}
