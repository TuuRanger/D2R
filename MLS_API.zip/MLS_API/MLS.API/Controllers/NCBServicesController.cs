﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Xml.Linq;
using MLS.Imp.Implement;
using MLS.Imp.Interface;
using MLS.Models;
namespace MLS.API.Controllers
{
    public class NCBServicesController : ApiController
    {
        INCBSvc _service = null;

        public NCBServicesController()
        {
            _service = new NCBSvc();
        }

        public NCBResult GetNCBResult(String firstName, String middleName, string lastName, DateTime birthDate, String IDCard, String userID)
        {
           return  _service.GetNCBResult(firstName, middleName, lastName, birthDate, IDCard, userID);
        }

        [HttpPost,Route("api/NCBServices/InsertNCBResult/{username}")]
        public void InsertNCBResult(NCBResult ncbResult, String username)
        {
            _service.InsertNCBResult(ncbResult, username);
        }


    }
}
