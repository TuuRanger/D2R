﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MLS_API.Controllers
{
    public class BlackListController : ApiController
    {
        public BlackListController()
        {
            //this.applicationReporsitory = new ApplicationRepository();
        }

        [HttpGet]
        public object GetNCBTUDF(string asOfDate)
        {
            return "";
        }

        [HttpGet]
        public object GetNCBTUEFResult(string tuefText)
        {
            return "";
        }

        [HttpGet]
        public object GetInternalBlackList(string idNumber)
        {
            return "";
        }

        [HttpGet]
        public object GetAMLOBlackList(string idNumber)
        {
            return "";
        }
    }
}
