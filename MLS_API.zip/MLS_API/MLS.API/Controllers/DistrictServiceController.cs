﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp.Implement;
using MLS.Models;
namespace MLS.API.Controllers
{

    public class DistrictServiceController : ApiController
    {
        DistrictSvc _svc = new DistrictSvc();

        [HttpGet]
        public List<DistrictByNameResult> GetDistrictByName(string districtName)
        {
            return _svc.GetDistrictyName(districtName);
        }

    }
}
