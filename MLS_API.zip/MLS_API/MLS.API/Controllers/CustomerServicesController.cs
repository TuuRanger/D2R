﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;
using MLS.Imp.Implement;
using MLS.Models;
using MLS.Helper;
using System.IO;
using MLS.Imp.Interface;

namespace MLS.API.Controllers
{
    public class CustomerServicesController : ApiController
    {
        ICustomerSvc _service;

        public CustomerServicesController()
        {
            _service = new CustomerSvc();
        }

        [HttpGet]
        public vwCUSINFO GetCustomerInfoWithAccount(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string ID,string CUSTYPCOD)
        {
            return _service.GetCustomerInfoWithAccount(  CPNCOD,   CPNBRNCOD,   ACCBUSTYP,   ID, CUSTYPCOD);
        }

        [HttpGet]
        public List<SearchCustomerWithPagingResult> GetCustomerList(String name, String surname, String ID,String customerType, int pageNo, int pageSize)
        {

            List<SearchCustomerWithPagingResult> result = _service.SearchCustomerPaging(name, surname, ID,customerType, pageNo, pageSize);
            return result; 
        }


        [HttpPost,Route("api/CustomerServices/InsertOrUpdateCustomer/{username}")]
        public void InsertOrUpdateCustomer(List<vwCUSINFO> customers,String username)
        {
            FileHelper.writeTextFile("C://temp/customer.json", Newtonsoft.Json.JsonConvert.SerializeObject(customers, Newtonsoft.Json.Formatting.Indented));
            _service.InsertOrUpdateCustomer(customers, username);
        }

        [HttpGet]
        public vwCustomerSearch GetCustomerInfo(String ID, String CUSTYPCOD)
        {
            return _service.GetCustomerInfo(ID,CUSTYPCOD);
        }
    }
}
