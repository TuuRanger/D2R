﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp.Implement;
using MLS.Models;

namespace MLS.API.Controllers
{
    public class FeeServicesController : ApiController
    {
        FeeSvc _svc = new FeeSvc();

        [HttpGet]
        public List<FeeConfigResult> GetFeeList(
           string CPNCOD,
           string CPNBRNCOD,
           string ACCBUSTYP,
           string CONNUM,
           Nullable<decimal> CREDIT_APPROVE,
           Nullable<decimal> CONDWNAMT,
           string CONAPPLY_PROJEC)
        {
            return _svc.GetFeeList(
             CPNCOD,
             CPNBRNCOD,
             ACCBUSTYP,
             CONNUM,
             CREDIT_APPROVE,
             CONDWNAMT,
             CONAPPLY_PROJEC);
        }

        //[HttpGet]
        //public List<FeeConfigResult> GetFeeConfig(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP)
        //{
        //    return _svc.GetFeeConfig(CPNCOD, CPNBRNCOD, ACCBUSTYP);
        //}

        [HttpPost, Route("api/FeeServices/InsertOrUpdateFee/{username}")]
        public void InsertOrUpdateFee([FromBody]List<FeeConfigResult> listFee, String username)
        {
            _svc.InsertOrUpdateFee(listFee, username);
        }
    }
}
