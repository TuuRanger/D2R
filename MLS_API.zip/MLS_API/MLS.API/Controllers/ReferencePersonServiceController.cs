﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp.Implement;
using MLS.Models;
namespace MLS.API.Controllers
{
    public class ReferencePersonServiceController : ApiController
    {
        ReferencePersonSvc _service = new ReferencePersonSvc();

        [HttpGet]
        public List<RefListResult> GetReferencePersonList(String CONNUM)
        {
            return _service.GetRefList(CONNUM);
        }

        [HttpPost, Route("api/ReferencePersonService/InsertOrUpdateReferencePerson/{CPNCOD}/{CPNBRNCOD}/{ACCBUSTYP}/{CONNUM}/{username}")]
        public void InsertOrUpdateReferencePerson(
            [FromBody]List<RefListResult> refPersonList,
            String CPNCOD,
            String CPNBRNCOD,
            String ACCBUSTYP,
            String CONNUM, 
            String username
            )
        {
            _service.InsertOrUpdateReferencePerson(refPersonList,
           CPNCOD,
           CPNBRNCOD,
           ACCBUSTYP,
           CONNUM,
           username);
        }
    }
}
