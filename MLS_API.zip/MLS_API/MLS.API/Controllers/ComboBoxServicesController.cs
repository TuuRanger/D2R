﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp.Implement;
using MLS.Models;

namespace MLS.API.Controllers
{
    public class ComboBoxServicesController : ApiController
    {
        ComboBoxSvc _service = new ComboBoxSvc();

        [HttpGet]
        public List<DropDownDealerResult> GetDropDownDealer(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string PROJECTCODE)
        {
            return _service.GetDropDownDealer(CPNCOD, CPNBRNCOD, ACCBUSTYP, PROJECTCODE);
        }

        [HttpGet]
        public List<AccountResult> SearchAccount(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string ACCDEAWTH, string SEARCH_STR)
        {
            return _service.SearchAccount(  CPNCOD,   CPNBRNCOD,   ACCBUSTYP,   ACCDEAWTH,   SEARCH_STR);
        }

        [HttpGet]
        public List<DropDownProductBrandResult> GetDropDownProductBrand(string PRDGRPCOD, string PRDSUBCOD, string CONAPPLY_PROJEC, string BrandInput)
        {
            return _service.GetDropDownProductBrand( PRDGRPCOD,  PRDSUBCOD,  CONAPPLY_PROJEC,  BrandInput);
        }

        [HttpGet]
        public List<DropDownProductModelResult> GetDropDownProductModel(string PRDGRPCOD, string PRDSUBCOD, string Brnad, string CONAPPLY_PROJEC, string ModelInput)
        {
            return _service.GetDropDownProductModel( PRDGRPCOD,  PRDSUBCOD,  Brnad,  CONAPPLY_PROJEC,  ModelInput);
        }

        [HttpGet]
        public List<DroDownCompanyResult> GetDropDownCompany()
        {
            return _service.GetDropDownCompany();
        }

        [HttpGet]
        public List<vwUserSection> GetUserInSectionGroup(String SectionID, String GroupID )
        {
            return _service.GetUserInSectionGroup(SectionID, GroupID);
        }



    }
}
