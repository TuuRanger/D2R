﻿using MLS_API.Models;
using MLS_API.Services;
using MLS.JMT.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.JMT.Models.DTO;
using System.Web.Http.Cors;

namespace MLS_API.Controllers
{
    //[EnableCors(origins: "http://localhost:3454/", headers: "*", methods: "*")]
    public class ApplicationController : ApiController
    {
        private ApplicationRepository applicationReporsitory;

        public ApplicationController()
        {
            this.applicationReporsitory = new ApplicationRepository();
        }

        private void InitProcess()
        {
            // WebAPI_Filtering
            // Version Param
            // initDBAccess;            
            // Data Validation & Hashing Process;            
            // Step Decision;
            // Select Related Store Procedure;
            // Saving Process;


            //JSON Data Type
            // 1. Primary Info
            // Display Language                
            // UserName
            // ip
            // mac-address
            // Version Param (??)
            // Etc.

            // 2. Funtionality Info (Database Realted)
            // Customer Data
            // Contract Data

            // 3. Temp Data (Non-Database Related)
            // Interest Calculation
            // Installment Calculation      
        }

        [HttpGet]
        public object GetContractList(string CONAPPLY_PROJEC, string VENDOR, string CPNBRNCOD, string CRDSTPFROM, string CRDSTPTO, string PSNREGIDN, string CUSNAMTHA, string CUSSURTHA)
        {
            return applicationReporsitory.GetContractList(CONAPPLY_PROJEC, VENDOR, CPNBRNCOD, CRDSTPFROM, CRDSTPTO, PSNREGIDN, CUSNAMTHA, CUSSURTHA);
        }

        [HttpGet]
        public object GetContractDetails(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string GENAPPNUM)
        {
            return applicationReporsitory.GetContractDetail(CPNCOD, CPNBRNCOD, ACCBUSTYP, GENAPPNUM);
        }

        [HttpGet]
        public object GetApplication()
        {
            //JavaScriptSerializer js = new JavaScriptSerializer();
            //string returnstring = js.Serialize(data);
            //return returnstring;

            return applicationReporsitory.GetAllApplications();
        }


        [HttpPost]
        public object Save(ContractDetailResult application)
        {
            this.applicationReporsitory.SaveApplication(application);

            var response = Request.CreateResponse<ContractDetailResult>(System.Net.HttpStatusCode.Created, application);

            return response;
        }

        [HttpPost]
        public InsertOrUpdateContractResult InsertOrUpdateContract([FromUri]ContractDetailResult contractDetail,[FromUri]ReferencePersonListResult refList)
        {
            //FileHelper.writeTextFile(Path.Combine(Constants.LOG_PATH, "contractDetail.JSON"), JSONHelper.ConvertToJsonString(contractDetail));
           // return _svc.InsertOrUpdateContract(contractDetail);
            
            //var response = Request.CreateResponse<ContractDetailResult>(System.Net.HttpStatusCode.Created, contractDetail);
            
            return this.applicationReporsitory.SaveApplication(contractDetail); 
            

        }


        [HttpGet]
        public object GetInstallmentInformation()
        {
            //Get Installment Info from .net lib
            return "";
        }

    }
}
