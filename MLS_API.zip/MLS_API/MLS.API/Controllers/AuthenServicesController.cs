﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp.Implement;
using MLS.Models;
using MLS.Imp.Interface;

namespace MLS.API.Controllers
{
    public class AuthenServicesController : ApiController
    {
        IAuthenSvc _service = null;

        public AuthenServicesController()
        {
            _service = new AuthenSvc();
        }

        [HttpGet]
        public String Login(String Username,String Password)
        {
            return _service.Login(Username, Password);
        }

        [HttpGet]
        public UserDataResult GetUserDataByToken(String Token)
        {
            return _service.GetUserDataByToken(Token);
        }

        [HttpGet]
        public UserToken IsTokenValid(String Username, String Token)
        {
            return _service.IsTokenValid(Username,Token);
        }
    }
}
