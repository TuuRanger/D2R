﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp.Implement;
using MLS.Models;

namespace MLS.API.Controllers
{
    public class TelLogServicesController : ApiController
    {
        TelLogSvc _service = new TelLogSvc();

        [HttpGet]
        public List<TelListResult> GetTelList(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string CONNUM)
        {
            return _service.GetTelList(CPNCOD, CPNBRNCOD, ACCBUSTYP, CONNUM);
        }

        [HttpPost, Route("api/TelLogServices/InsertOrUpDateTelLog/{CPNCOD}/{CPNBRNCOD}/{ACCBUSTYP}/{CONNUM}/{username}")]
        public void InsertOrUpDateTelLog(
            [FromBody]List<TelListResult> telList,
            String CPNCOD,
            String CPNBRNCOD,
            String ACCBUSTYP,
            String CONNUM,
            String username)
        {
              _service.InsertOrUpDateTelLog( telList,
             CPNCOD,
             CPNBRNCOD,
             ACCBUSTYP,
             CONNUM,
             username);
        }
    }
}
