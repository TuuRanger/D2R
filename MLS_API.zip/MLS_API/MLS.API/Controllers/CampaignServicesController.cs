﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;  
using MLS.Imp.Implement;
using MLS.Imp.Interface;
using MLS.Models;

namespace MLS.API.Controllers
{
    public class CampaignServicesController : ApiController
    {
        private ICampaignSvc _service = new CampaignSvc();

        [HttpGet]
        public MLMCampaignResult GetMLMCampaignByProjectCode(String CONAPPLY_PROJEC) 
        {
            return _service.GetMLMCampaignByProjectCode(CONAPPLY_PROJEC);
        }
         
    }
}
