﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http; 
using MLS.Imp.Implement;
using MLS.Models;
namespace MLS.API.Controllers
{
    public class AumphurServicesController : ApiController
    {
        AumphurSvc _svc = new AumphurSvc();

        public List<AumphurByNameResult> GetAumphurByName(String aumphurName)
        {
            return _svc.GetAumphurByName(aumphurName);
        }

        public List<AmphurByIDResult> GetAumphurByID(int amhurId)
        {
            return _svc.GetAumphurByID(amhurId);
        }
    }
}
