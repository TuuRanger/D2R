﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;
using MLS.Imp.Implement;
using MLS.Models;
using MLS.Helper;
using System.IO;

namespace MLS.API.Controllers
{
    public class ContractServicesController : ApiController
    { 
        ContractSvc _svc = new ContractSvc();
        // GET: Application
        [HttpGet]
        public List<ContractListResult> GetContractList(string CONAPPLY_PROJEC,
            string VENDOR,
            string CPNBRNCOD,
            string CRDSTPFROM,
            string CRDSTPTO,
            string PSNREGIDN,
            string CUSNAMTHA,
            string CUSSURTHA,
            string GENAPPNUM)
        {
            return _svc.GetContractList(CONAPPLY_PROJEC, VENDOR, CPNBRNCOD, CRDSTPFROM, CRDSTPTO, PSNREGIDN, CUSNAMTHA, CUSSURTHA, GENAPPNUM);
        }

        [HttpGet]
        public ContractDetailResult GetContractDetail(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string GENAPPNUM)
        {
            
            return _svc.GetContractDetail(CPNCOD, CPNBRNCOD, ACCBUSTYP, GENAPPNUM);
        }

  

        [HttpPost]
        public ContractDetailResult InsertOrUpdateContract([FromBody]ContractDetailResult contractDetail)
        {
            
            return _svc.InsertOrUpdateContract(contractDetail); 
        }


        [HttpPost,Route("api/ContractServices/InsertOrUpdateContractFactoring/{username}")]
        public ContractDetailResult InsertOrUpdateContractFactoring([FromBody]ContractDetailResult contractDetail,String username)
        {

            return _svc.InsertOrUpdateContractFactoring(contractDetail, username);
        }

        public List<ContractListFactoringWithPagingResult> GetContractListFactoringWithPaging(string sponsorName, string CONNUM, string GENAPPNUM, string stepFrom, string stepTo, int pageSize, int pageNo)
        {
            return _svc.GetContractListFactoringWithPaging( sponsorName,  CONNUM, GENAPPNUM,  stepFrom,  stepTo,  pageSize, pageNo);
        }

    }
}