﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MLS_API.Controllers
{
    public class DayEndController : ApiController
    {
        public DayEndController()
        {
            //this.applicationReporsitory = new ApplicationRepository();
        }

        
        private void GenerateFinanceData()
        {
            //return "";
        }

        private void TransferDataToOtherSystem()
        { }

        private void GenerateDailyReport()
        { }

        [HttpGet]
        public object DayEndProcess()
        {
            return "";
        }
    }
}
