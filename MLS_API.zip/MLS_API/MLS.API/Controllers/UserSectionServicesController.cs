﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;
using MLS.Imp.Implement;
using MLS.Models;
using MLS.Helper;
using System.IO;
using MLS.Imp.Interface;

namespace MLS.API.Controllers
{
    public class UserSectionServicesController : ApiController
    {
        IUserSectionSvc _service = null;
        public UserSectionServicesController()
        {
            _service = new UserSectionSvc();
        }
       

        [HttpGet]
        public List<vwUserSection> GetUserSection(String USERID)
        {
           return _service.GetUserSection(USERID);
        }
    }
}
