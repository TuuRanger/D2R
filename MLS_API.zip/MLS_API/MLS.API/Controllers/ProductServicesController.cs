﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Xml.Linq;
using MLS.Imp.Implement;
using MLS.Models;
namespace MLS.API.Controllers
{
    public class ProductServicesController : ApiController
    {
        private ProductSvc _service = new ProductSvc();

        public List<ProductSpecInputFieldResult> GetProductSpecInputField(string PRDGRPCOD, string PRDSUBCOD)
        {
            return _service.GetProductSpecInputField(PRDGRPCOD, PRDSUBCOD);  
        }

        [HttpPost,Route("api/ProductServices/InsertOrUpdateProductSepc/{CPNCOD}/{CPNBRNCOD}/{ACCBUSTYP}/{CONNUM}")]
        public void InsertOrUpdateProductSepc( String CPNCOD,String CPNBRNCOD,String ACCBUSTYP,String CONNUM, [FromBody]Dictionary<String, String> ProductSepc)
        {
            _service.InsertOrUpdateProductSepc(CPNCOD, CPNBRNCOD, ACCBUSTYP, CONNUM, ProductSepc);
        }

        public Dictionary<String, String> GetProductDetail(String CPNCOD, String CPNBRNCOD, String ACCBUSTYP, String CONNUM)
        {
            return _service.GetProductDetail( CPNCOD,  CPNBRNCOD,  ACCBUSTYP,  CONNUM); 
        }


        [HttpGet]
        public List<vwCDMPRD> GetProduct(String CPNCOD, String CPNBRNCOD, String ACCBUSTYP, String CONNUM)
        {
            return _service.GetProduct(CPNCOD, CPNBRNCOD, ACCBUSTYP, CONNUM);
        }


    }
}
