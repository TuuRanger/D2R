﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MLS_API.Controllers
{
    public class ClosingController : ApiController
    {
        public ClosingController()
        {
            //this.applicationReporsitory = new ApplicationRepository();
        }

        [HttpGet]
        public object ClosingProcess()
        {
            return "";
        }

        [HttpGet]
        public object ClosingConfirmation()
        {
            return "";
        }

        [HttpGet]
        public object GenerateClosingReport()
        {
            return "";
        }

        [HttpGet]
        public object ClosingSimulation()
        {
            return "";
        }

    }
}
