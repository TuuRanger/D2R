﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp.Implement;
using MLS.Models;
using MLS.Imp.Interface;
using MLS.Helper;

namespace MLS.API.Controllers
{
    public class AccountServicesController : ApiController
    {
        IAccountSvc _service = null;
        public AccountServicesController()
        {
            _service = new AccountSvc();
        }
        [HttpGet]
        public List<AccountResult> SearchAccount(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string ACCDEAWTH, string SEARCH_STR)
        { 
            return _service.SearchAccount(CPNCOD, CPNBRNCOD, ACCBUSTYP, ACCDEAWTH, SEARCH_STR).ToList();
        }

        [HttpGet]
        public List<vwAccountContract> GetContractByAccount(String ACCCOD, String CPNCOD, String CPNBRNCOD, String ACCBUSTYP)
        {
            return _service.GetContractByAccount(ACCCOD, CPNCOD, CPNBRNCOD, ACCBUSTYP);
        }

        [HttpPost, Route("api/AccountServices/InsertOrUpdateAccount/{username}")]
        public InsertOrUpdateCDMACCResult InsertOrUpdateAccount([FromBody]AccountProcessViewModel entity, String username)
        {
            FileHelper.writeTextFile("C://temp/accountViewModel.json", Newtonsoft.Json.JsonConvert.SerializeObject(entity, Newtonsoft.Json.Formatting.Indented));
            return _service.InsertOrUpdateAccount(entity, username);
        }

        [HttpPost, Route("api/AccountServices/VerifyAccount/{username}")]
        public void VerifyAccount([FromBody]AccountProcessViewModel entity, String username)
        {
              _service.VerifyAccount(entity, username); 
        }

        [HttpPost, Route("api/AccountServices/SendBackAccount/{username}")]
        public void SendBackAccount([FromBody]AccountProcessViewModel entity, String username)
        {
            _service.SendBackAccount(entity, username);
        }

        [HttpPost, Route("api/AccountServices/GenAccount/{username}")]
        public GenAccountResult GenAccount([FromBody]AccountProcessViewModel entity, String username)
        {
          return  _service.GenAccount(entity, username);
        }

        [HttpGet]
        public List<SearchAccountWithPagingResult> SearchAccountWithPaging(String ACCBUSTYP,string ACCCOD, String GENAPPNUM,string ACCNAMTHA, string ACCDEAWTH, string RECSTSCOD_FROM, string RECSTSCOD_TO, int pageNo, int pageSize)
        {
            return _service.SearchAccountWithPaging(ACCBUSTYP, ACCCOD, GENAPPNUM,ACCNAMTHA, ACCDEAWTH, RECSTSCOD_FROM, RECSTSCOD_TO, pageNo, pageSize);
        }

        [HttpGet]
        public AccountDetailResult GetAccountDetail(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string GENAPPNUM)
        {
            return _service.GetAccountDetail(CPNCOD, CPNBRNCOD, ACCBUSTYP, GENAPPNUM);
        }

        [HttpGet]
        public List<AccountCustomerResult> GetAccountCustomers(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string GENAPPNUM)
        {
            return _service.GetAccountCustomers(CPNCOD,CPNBRNCOD,ACCBUSTYP,GENAPPNUM);
        }

        [HttpGet]
        public CDSACCCFG GetAccountConfig(String ACCBUSTYP, String ACCDEAWTH, String CPNBRNCOD)
        {
           return _service.GetAccountConfig(  ACCBUSTYP,   ACCDEAWTH,   CPNBRNCOD);
        }

        [HttpGet]
        public CustomerInAccountResult CheckCustomerInAccount(String CUSCOD, String ACCCOD)
        {
            return _service.CheckCustomerInAccount(CUSCOD, ACCCOD);
        }

        [HttpGet]
        public bool CheckAccountExistsBeforeGen(String GENAPPNUM, String ACCCOD)
        {
            return _service.CheckAccountExistsBeforeGen(GENAPPNUM, ACCCOD) <= 0 ;
        }
    }
}
