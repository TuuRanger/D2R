﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp.Implement;
using MLS.Models;
namespace MLS.API.Controllers
{
    public class ZipCodeServicesController : ApiController
    {
        ZipCodeSvc _svc = new ZipCodeSvc();

        public List<ZipCodeResult> GetZipCode(int districtID, int amphurID, int provinceID)
        {
            return _svc.GetZipCode(districtID, amphurID, provinceID);
        }

        public List<ZipCodeByZipCodeResult> GetZipCodeByZipCode(string zipCode)
        {
            return _svc.GetZipCodeByZipCode(zipCode);
        }
    }
}
