﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp.Implement;
using MLS.Imp.Interface;
using MLS.Models;


namespace MLS.API.Controllers
{
    public class FinanceCalcServicesController : ApiController
    {
        IFinanceCalSvc _service = new FinanceCalSvc();

        [HttpGet]
        public FinanceAmountCalcResult FinanceAmountCalc(
                                         double CONINSAMTx,
                                         int CONLNDTRMx,
                                         double CONINTRTEx,
                                         string CONINTTYPx,
                                         string CONINSPERx,
                                         string CONINTCALx,
                                         string CONINTPERx,
                                         string CONIRATEx,
                                         double CONFRATEx,
                                         string CONIRATEBNKREFx,
                                         double CONBLNAMTx,
                                         double SUBSDYAMTx,
                                         double ROUND_UPx,
                                         double ROUND_FACTORx,
                                         string INS_EQUAx,
                                         double LND_RoundUP,
                                         double LND_RoundFactor)
        { 
            FinanceAmountCalcResult result =  _service.FinanceAmountCalc(CONINSAMTx,
                                                CONLNDTRMx,
                                                CONINTRTEx,
                                                CONINTTYPx,
                                                CONINSPERx,
                                                CONINTCALx,
                                                CONINTPERx,
                                                CONIRATEx,
                                                CONFRATEx,
                                                CONIRATEBNKREFx,
                                                CONBLNAMTx,
                                                SUBSDYAMTx,
                                                ROUND_UPx,
                                                ROUND_FACTORx,
                                                INS_EQUAx,
                                                LND_RoundUP,
                                                LND_RoundFactor);
            return result;
        }
        
        [HttpGet]
        public InstallmentCalcResult InstallmentCalc(double CONFINAMTx,
            int CONLNDTRMx,
            double CONINTRTEx,
            string CONINTTYPx,
            string CONINSPERx,
            string CONINTCALx,
            string CONINTPERx,
            string CONIRATEx,
            double CONFRATEx,
            string CONIRATEBNKREFx,
            double CONBLNAMTx,
            double SUBSDYAMTx,
            double ROUND_UPx,
            double ROUND_FACTORx,
            string INS_EQUAx,
            double LND_RoundUP,
            double LND_RoundFactor)
        {
            InstallmentCalcResult result =  _service.InstallmentCalc(
                                        CONFINAMTx,
                                        CONLNDTRMx,
                                        CONINTRTEx,
                                        CONINTTYPx,
                                        CONINSPERx,
                                        CONINTCALx,
                                        CONINTPERx,
                                        CONIRATEx,
                                        CONFRATEx,
                                        CONIRATEBNKREFx,
                                        CONBLNAMTx,
                                        SUBSDYAMTx,
                                        ROUND_UPx,
                                        ROUND_FACTORx,
                                        INS_EQUAx,
                                        LND_RoundUP,
                                        LND_RoundFactor);
            return result;
        }

        [HttpGet]
        public TermCalcResult TermCalc(double CONFINAMTx,
                                 double CONINSAMTx,
                                 double CONINTRTEx,
                                 string CONINTTYPx,
                                 string CONINSPERx,
                                 string CONINTCALx,
                                 string CONINTPERx,
                                 string CONIRATEx,
                                 double CONFRATEx,
                                 string CONIRATEBNKREFx,
                                 double CONBLNAMTx,
                                 double SUBSDYAMTx,
                                 double TRMSTEPUPx,
                                 double ROUND_UPx,
                                 double ROUND_FACTORx,
                                 string INS_EQUAx,
                                 double LND_RoundUP,
                                 double LND_RoundFactor)
        {
            TermCalcResult result = _service.TermCalc(
                                     CONFINAMTx,
                                     CONINSAMTx,
                                     CONINTRTEx,
                                     CONINTTYPx,
                                     CONINSPERx,
                                     CONINTCALx,
                                     CONINTPERx,
                                     CONIRATEx,
                                     CONFRATEx,
                                     CONIRATEBNKREFx,
                                     CONBLNAMTx,
                                     SUBSDYAMTx,
                                     TRMSTEPUPx,
                                     ROUND_UPx,
                                     ROUND_FACTORx,
                                     INS_EQUAx,
                                     LND_RoundUP,
                                     LND_RoundFactor);
            return result;
        }

        [HttpPost]
        public CreditLimitResult GetCreditLimit(ContractDetailResult contractDetail)
        { 
            
            return _service.GetCreditLimit(contractDetail);
        }

        [HttpGet] 
        public List<InstallmentTableResult> GetInstallmentTable(string ACCBUSTYP,
                                                         Nullable<int> CONDUEDAY,
                                                         Nullable<decimal> CONFINAMT,
                                                         Nullable<int> CONLNDTRM,
                                                         Nullable<decimal> CONLNDAMT,
                                                         Nullable<decimal> CONINSAMT,
                                                         Nullable<decimal> CONEFFRTE,
                                                         Nullable<decimal> CONINTRTE,
                                                         Nullable<decimal> INCOMERTE,
                                                         Nullable<decimal> CRUSGRTE,
                                                         Nullable<System.DateTime> CONEFFDTE,
                                                         Nullable<System.DateTime> CONSTRINS,
                                                         Nullable<System.DateTime> CONSECINS,
                                                         string CONINTPER,
                                                         Nullable<decimal> SUBSDYAMT,
                                                         string CONINTCAL)
        {
            return _service.GetInstallmentTable(ACCBUSTYP,
                                                CONDUEDAY,
                                                CONFINAMT,
                                                CONLNDTRM,
                                                CONLNDAMT,
                                                CONINSAMT,
                                                CONEFFRTE,
                                                CONINTRTE,
                                                INCOMERTE,
                                                CRUSGRTE,
                                                CONEFFDTE,
                                                CONSTRINS,
                                                CONSECINS,
                                                CONINTPER,
                                                SUBSDYAMT,
                                                CONINTCAL);
        }

    }
}
