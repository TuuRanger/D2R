﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;
using MLS.Models.MockModel;
using MLS.Imp.Interface;
using MLS.Imp.Implement;
using MLS.Models;

namespace MLS.API.Controllers
{
    public class UIServicesController : ApiController
    {
        IUISvc _service = null;

        public UIServicesController()
        {
            _service = new UISvc();
        }

        [HttpGet]
        public HttpResponseMessage getScreenLabelTextList(String screenID, String language)
        {
            Dictionary<String, String> listFieldLabel = new Dictionary<string, string>();
            List<ScreenLabelTextResult> result = null;
            if (screenID == "_LoginLayout")
            {
                if (language == "en-EN")
                {
                    listFieldLabel.Add("txtUsername", "Username");
                    listFieldLabel.Add("txtPassword", "Password");
                    listFieldLabel.Add("btnSubmit", "Login");
                }
                else if (language == "th-TH")
                {
                    listFieldLabel.Add("txtUsername", "ชื่อผู้ใช้");
                    listFieldLabel.Add("txtPassword", "รหัสผ่าน");
                    listFieldLabel.Add("btnSubmit", "เข้าสู่ระบบ");

                }
            }
            else if (screenID == "APP001NewApp")
            {
                if (language == "en-EN")
                {
                    listFieldLabel.Add("txtCreditLine", "Credit Line");
                    listFieldLabel.Add("txtCreditAvailable", "Credit Available");
                    listFieldLabel.Add("cboConApplyProjec", "Apply Project");
                    listFieldLabel.Add("cboAccBusTyp", "Business Type");
                    listFieldLabel.Add("cboACCLNDTYP", "Credit Type");
                    listFieldLabel.Add("cboConTaxTyp", "Tax Type");
                    listFieldLabel.Add("cboCusTypCod", "Customer Type");
                    listFieldLabel.Add("txtMobile1", "Mobile1");
                    listFieldLabel.Add("txtMobile2", "Mobile2");
                    listFieldLabel.Add("txtMobile3", "Mobile3");
                    listFieldLabel.Add("txtJPRNo", "JP. Reg No.");
                    listFieldLabel.Add("txtIncPerYea", "Income Per Year");
                    listFieldLabel.Add("txtProfitPerYea", "Profit Per Year");
                    listFieldLabel.Add("txtJprRegDte", "JP. Reg. Date");
                    listFieldLabel.Add("txtJprCerDte", "JP. Cer. Date");

                    listFieldLabel.Add("cboPrdGrpCod", "Product Group");
                    listFieldLabel.Add("cboPrdSubCod", "Product Sub Group");
                    listFieldLabel.Add("cboPrdBrnCod", "Brand");
                    listFieldLabel.Add("cboPrdMdlCod", "Model");
                    listFieldLabel.Add("txtPrdSrlNo", "Serail No.");
                    listFieldLabel.Add("cboPrdTyp", "Produt Type");
                    listFieldLabel.Add("txtPRDLISPRC", "List Price");
                    listFieldLabel.Add("txtPRDCSTAMT", "Product Cost");
                    listFieldLabel.Add("txtPrdSalPrc", "Sale Price");

                    listFieldLabel.Add("txtPSNREGIDN", "ID");
                    listFieldLabel.Add("txtPSNREGIDN2", "Confirm ID");
                    listFieldLabel.Add("cboCusTtlTha", "Title name");
                    listFieldLabel.Add("txtCUSNAMTHA", "Name");
                    listFieldLabel.Add("txtCUSSURTHA", "Surname");
                    listFieldLabel.Add("txtPSNBTHDTE", "Birth date");
                    listFieldLabel.Add("cboPsnBthDay", "Birth day");
                    listFieldLabel.Add("txtCUSNICNAM", "Nick name");
                    listFieldLabel.Add("cboAccCodDlr", "Vendor");
                    listFieldLabel.Add("txtPSNMTHINC", "Gross income");
                    listFieldLabel.Add("txtPSNNETINC", "Net income");
                    listFieldLabel.Add("cboConApplyType", "Apply type");
                    listFieldLabel.Add("cboConApplyVia", "Apply via");
                    listFieldLabel.Add("cboConApplyViaBranch", "Apply via branch");
                    listFieldLabel.Add("cboConObjCod", "Business Type");
                    listFieldLabel.Add("cboConApplyPromotion", "Apply promotion");

                    listFieldLabel.Add("txtAddressLine1", "Address");
                    listFieldLabel.Add("txtAddressDistrict", "District");
                    listFieldLabel.Add("txtAddressAmphur", "Amphur");
                    listFieldLabel.Add("txtAddressProvince", "Province");
                    listFieldLabel.Add("txtAddressZipCode", "Zip Code");
                    listFieldLabel.Add("txtAddressPhoneNo", "Phone No.");
                    listFieldLabel.Add("txtAddressPhoneExtNo", "Ext No.");
                    listFieldLabel.Add("txtAddressPhoneEndNo", "End No.");
                    listFieldLabel.Add("txtAddressPhoneFromNo", "From No.");
                    listFieldLabel.Add("cboAddressReferenceAddress", "Ref. address");
                    listFieldLabel.Add("cboAddressTypeCode", "Address type");

                    listFieldLabel.Add("txtRefPersonName", "Name");
                    listFieldLabel.Add("txtRefPersonLastName", "Lastname");
                    listFieldLabel.Add("cboRefRelation", "Relation");
                    listFieldLabel.Add("txtTeRefPersonTelNo", "Tel No.");
                    listFieldLabel.Add("txtRefTitleName", "Title");
                    listFieldLabel.Add("txtAge", "Age");
                    listFieldLabel.Add("txtFullBirthDate", "Full birth date");

                    listFieldLabel.Add("cboPsnMarSts", "Marriage Status");
                    listFieldLabel.Add("txtPsnChdNum", "No. of children");
                    listFieldLabel.Add("cboPsnSexCod", "Gender");
                    listFieldLabel.Add("txtLivInHomYea", "Period of live in home (Year)");
                    listFieldLabel.Add("txtLivInHomMon", "Period of live in home (Month)");

                    listFieldLabel.Add("txtAdrMember", "No. of home member");
                    listFieldLabel.Add("cboAdrOwnerCod", "Home type");
                    listFieldLabel.Add("cboPsnCpnTyp", "Business Type");
                    listFieldLabel.Add("cboPsnOccCod", "Occupation");
                    listFieldLabel.Add("cboPsnPosIn", "Position");
                    listFieldLabel.Add("txtPsnCpnStf", "No. of staff");
                    listFieldLabel.Add("txtPsnWrkPrdYea", "Period of work (Year)");
                    listFieldLabel.Add("txtPsnWrkPrdMon", "Period of work (Month)");
                    listFieldLabel.Add("cboPsnEmployTyp", "Employment type");
                    listFieldLabel.Add("cboPsnSalRcvTyp", "Salary receiving type");
                    listFieldLabel.Add("cboCoOperateType", "Co-operate type");
                    listFieldLabel.Add("txtCrdReqAmt", "Credit request amount");
                    listFieldLabel.Add("txtCrdReqTrm", "Term request amount");
                    listFieldLabel.Add("cboFinBnkCodCr", "Bank");
                    listFieldLabel.Add("cboFinBrnCodCr", "Bank branch");
                    listFieldLabel.Add("txtFinBnkNumCr", "Bank account No.");
                    listFieldLabel.Add("txtCrdLimAmt", "Credit limit");
                    listFieldLabel.Add("txtCrdLimTrm", "Term limit");
                    listFieldLabel.Add("txtConFinAmt", "Loan approve");
                    listFieldLabel.Add("txtConLndTrm", "Term approve");
                    listFieldLabel.Add("txtConIntRte", "Flat rate");
                    listFieldLabel.Add("txtConEffRte", "Effective rate");
                    listFieldLabel.Add("txtConInsAmt", "Calc. Installment");
                    listFieldLabel.Add("txtMaxInstallment", "Max installment");
                    listFieldLabel.Add("txtConLndAmt", "Finance amount");
                    listFieldLabel.Add("txtTotIntAmt", "Total Interest amount");
                    listFieldLabel.Add("txtIntAmt", "Interest amount");
                    listFieldLabel.Add("txtCrUsgAmt", "Credit usage amount");
                    listFieldLabel.Add("chbCheckHomeNameRslt", "Valid name");
                    listFieldLabel.Add("chbCheckHomeAdrRslt", "Valid address");
                    listFieldLabel.Add("chbCheckOffcNameRslt", "Valid name");
                    listFieldLabel.Add("chbChecjOffcAdrRslt", "Valid address");
                    listFieldLabel.Add("txtCheckHomeNameRemark", "Remark name");
                    listFieldLabel.Add("txtCheckHomeAdrRemark", "Remark address");
                    listFieldLabel.Add("txtCheckOffcNameRemark", "Remark name");
                    listFieldLabel.Add("txtCheckOffcAdrRemark", "Remark address");

                    listFieldLabel.Add("tblFeeInfoCol1", "No.");
                    listFieldLabel.Add("tblFeeInfoCol2", "Desc");
                    listFieldLabel.Add("tblFeeInfoCol3", "Total amount");
                    listFieldLabel.Add("tblFeeInfoCol4", "Net amount");
                    listFieldLabel.Add("tblFeeInfoCol5", "Vat");
                    listFieldLabel.Add("tblFeeInfoCol6", "Waiver");

                    listFieldLabel.Add("tblFeeInfoRow1Cell1", "Duty stamp");
                    listFieldLabel.Add("tblFeeInfoRow2Cell1", "NCB");

                    listFieldLabel.Add("txtRelationYear", "Relation(Year)");

                    listFieldLabel.Add("txtCONFINAMT", "Loan approve");
                    listFieldLabel.Add("txtCONLNDTRM", "Term approve");
                    listFieldLabel.Add("txtCONLNDAMT", "Lending amount");
                    listFieldLabel.Add("txtGENAPPNUM", "App No.");
                    listFieldLabel.Add("txtCUSCOD", "Customer No.");
                    listFieldLabel.Add("txtCONBLNGRS", "Balloon amount");
                    listFieldLabel.Add("txtSUBSDYGRS", "Subsidy amount");
                    listFieldLabel.Add("cboACCCODSDY", "Subsidy");
                    listFieldLabel.Add("cboACCCODMKT", "Marketing");
                    listFieldLabel.Add("cboRejectReason", "Reason");
                    listFieldLabel.Add("txtRejectRemark", "Remark");

                    listFieldLabel.Add("txtGENAPPDTE", "App. Date");
                    listFieldLabel.Add("txtACCCOD", "Acc No.");
                }
                else if (language == "th-TH")
                {
                    listFieldLabel.Add("txtCreditLine", "วงเงินทั้งหมด");
                    listFieldLabel.Add("txtCreditAvailable", "วงเงินคงเหลือ");
                    listFieldLabel.Add("cboConApplyProjec", "โปรเจค");

                    listFieldLabel.Add("txtPSNREGIDN", "เลขบัตรประชาชน");
                    listFieldLabel.Add("txtPSNREGIDN2", "ยืนยันเลขบัตรประชาชน");
                    listFieldLabel.Add("cboCusTtlTha", "คำนำหน้าชื่อ");
                    listFieldLabel.Add("txtCUSNAMTHA", "ชื่อ");
                    listFieldLabel.Add("txtCUSSURTHA", "นามสกุล");
                    listFieldLabel.Add("txtPSNBTHDTE", "วันที่เกิด");
                    listFieldLabel.Add("cboPsnBthDay", "วันเกิด");
                    listFieldLabel.Add("txtCUSNICNAM", "ชื่อเล่น");
                    listFieldLabel.Add("cboAccCodDlr", "เวนเดอร์");
                    listFieldLabel.Add("txtPSNMTHINC", "รายได้พื้นฐานต่อเดือน");
                    listFieldLabel.Add("txtPSNNETINC", "รายได้สุทธิ");
                    listFieldLabel.Add("cboConApplyType", "ขอโดย");
                    listFieldLabel.Add("cboConApplyVia", "ขอผ่าน");
                    listFieldLabel.Add("cboConApplyViaBranch", "สาขา");
                    listFieldLabel.Add("cboConObjCod", "ประเภทธุรกิจ");
                    listFieldLabel.Add("cboConApplyPromotion", "โปรโมชั่น");


                    listFieldLabel.Add("txtAddressLine1", "ที่อยู่");
                    listFieldLabel.Add("txtAddressDistrict", "ตำบล");
                    listFieldLabel.Add("txtAddressAmphur", "อำเถอ");
                    listFieldLabel.Add("txtAddressProvince", "จังหวัด");
                    listFieldLabel.Add("txtAddressZipCode", "รหัสไปรษณี");
                    listFieldLabel.Add("txtAddressPhoneNo", "โทรศัพท์");
                    listFieldLabel.Add("txtAddressPhoneExtNo", "เบอร์ต่อ");
                    listFieldLabel.Add("txtAddressPhoneEndNo", "ถึง");
                    listFieldLabel.Add("txtRefPersonName", "ชื่อ");
                    listFieldLabel.Add("txtRefPersonLastName", "นามสกุล");
                    listFieldLabel.Add("cboRefRelation", "ความสัมพันธ์");
                    listFieldLabel.Add("txtTeRefPersonTelNo", "เบอร์โทร");
                    listFieldLabel.Add("txtRefTitleName", "คำนำหน้าชื่อ");
                    listFieldLabel.Add("tblFeeInfoCol1", "อธิบาย");
                    listFieldLabel.Add("tblFeeInfoCol2", "จำนวนเงิน");
                    listFieldLabel.Add("tblFeeInfoCol3", "เวฟ");
                    listFieldLabel.Add("tblFeeInfoRow1Cell1", "อาการแสตมป์");
                    listFieldLabel.Add("tblFeeInfoRow2Cell1", "NCB");
                    listFieldLabel.Add("cboAdrReference", "ที่อยู่เดียวกับ");
                    listFieldLabel.Add("cboRejectReason", "เหตุผล");
                }
                else
                {
                    throw new Exception(String.Format("language {0} is not supported"));
                }

            }
            else if (screenID == "APP002AppList")
            {
                if (language == "en-EN")
                {
                    listFieldLabel.Add("txtPSNREGIDN", "ID");
                    listFieldLabel.Add("txtCUSNAMTHA", "Name");
                    listFieldLabel.Add("txtCUSSURTHA", "Surname");
                    listFieldLabel.Add("cboConApplyProjec", "Project");
                    listFieldLabel.Add("txtGenAppNum", "App. No.");
                }
                else if (language == "th-TH")
                {
                    listFieldLabel.Add("txtPSNREGIDN", "เลขบัตรประชาชน");
                    listFieldLabel.Add("txtCUSNAMTHA", "ชื่อ");
                    listFieldLabel.Add("txtCUSSURTHA", "นามสกุล");
                }
            }
            else if (screenID == "SYSCFG_MASMTN001")
            {
                if (language == "en-EN")
                {
                    listFieldLabel.Add("txtTabKeyOne", "Key1");
                    listFieldLabel.Add("txtTabKeyTwo", "Key2");
                }

            }
            else if (screenID == "COL001DeptManagement")
            {
                if (language == "en-EN")
                {
                    listFieldLabel.Add("cpnCodLabelText", "Company");
                    listFieldLabel.Add("cpnBrnCodLabelText", "Branch code");
                    listFieldLabel.Add("folStateLabelText", "Follow status");
                    listFieldLabel.Add("overDueDayLabelText", "Overdue(day)");
                    listFieldLabel.Add("areaLabelText", "Area");
                    listFieldLabel.Add("ToLabelText", "To");
                    listFieldLabel.Add("cboFOLLOWER", "Follower");
                    listFieldLabel.Add("txtAssignNum", "Selected/Click");
                    listFieldLabel.Add("cboFOLWERGRPCOD", "Follwer group");


                }

            }
            else if (screenID == "COL002FollowUp")
            {
                if (language == "en-EN")
                {
                    listFieldLabel.Add("txtRefPersonName", "Name");
                    listFieldLabel.Add("txtRefPersonLastName", "Lastname");
                    listFieldLabel.Add("cboRefRelation", "Relation");
                    listFieldLabel.Add("txtTeRefPersonTelNo", "Tel No.");
                    listFieldLabel.Add("txtRefTitleName", "Title");
                    listFieldLabel.Add("txtAddressLine1", "Address");
                    listFieldLabel.Add("txtAddressDistrict", "District");
                    listFieldLabel.Add("txtAddressAmphur", "Amphur");
                    listFieldLabel.Add("txtAddressProvince", "Province");
                    listFieldLabel.Add("txtAddressZipCode", "Zip Code");
                    listFieldLabel.Add("txtAddressPhoneNo", "Phone No.");
                    listFieldLabel.Add("txtAddressPhoneExtNo", "Ext No.");
                    listFieldLabel.Add("txtAddressPhoneEndNo", "End No.");
                    listFieldLabel.Add("txtAddressPhoneFromNo", "From No.");
                    listFieldLabel.Add("cboAddressReferenceAddress", "Ref. address");
                    listFieldLabel.Add("cboAddressTypeCode", "Address type");
                    listFieldLabel.Add("txtACCCOD", "Account No.");
                    listFieldLabel.Add("txtACCNAMTHA", "Customer name");

                }

            }
            else if (screenID == "ACC001NewEntry")
            {
                if (language == "en-EN")
                {
                    listFieldLabel.Add("cboACCDEAWTH", "Deal Type");
                    listFieldLabel.Add("cboACCBUSTYP", "Business Type");
                    listFieldLabel.Add("cboCPNBRNCOD", "Branch");
                    listFieldLabel.Add("txtGENAPPNUM", "App. No.");
                    listFieldLabel.Add("txtGENAPPDTE", "App. Date");
                    listFieldLabel.Add("txtACCNAMTHA", "Acc. Name (in Thai)");
                    listFieldLabel.Add("txtACCNAMENG", "Acc. Name (in English)");
                    listFieldLabel.Add("cboACCLNDTYP", "Credit Type");
                    listFieldLabel.Add("cboACCCNTTYP", "Contract Type");
                    listFieldLabel.Add("txtGENEFFDTE", "Effective Date");
                    listFieldLabel.Add("txtACCCOD", "Acc. No.");
                    listFieldLabel.Add("idLabelText", "ID");
                    listFieldLabel.Add("nameLabelText", "Name");
                    listFieldLabel.Add("lastNameLabelText", "Surname");
                    listFieldLabel.Add("nickNameLabelText", "Nick");
                    listFieldLabel.Add("birthDateLabelText", "Birth date");
                    listFieldLabel.Add("birthDayLabelText", "Birth day");
                    listFieldLabel.Add("monthIncomeLabelText", "Salary");
                    listFieldLabel.Add("netIncomeLabelText", "Net income");
                    listFieldLabel.Add("mobileLabelText", "Mobile");
                    listFieldLabel.Add("titleNameLabelText", "Title");
                    listFieldLabel.Add("addressLine1LabelText", "Address");
                    listFieldLabel.Add("districtLabelText", "District");
                    listFieldLabel.Add("amphurLabelText", "Amphur");
                    listFieldLabel.Add("provinceLabelText", "Province");
                    listFieldLabel.Add("zipCodeLabelText", "Zipcode");
                    listFieldLabel.Add("phoneNoLabelText", "Phone No.");
                    listFieldLabel.Add("phoneExtNoLabelText", "Ext No.");
                    listFieldLabel.Add("phoneFromNoLabelText", "From");
                    listFieldLabel.Add("phoneEndNoLabelText", "To");
                    listFieldLabel.Add("referenceAddressLabelText", "Ref. Address");
                    listFieldLabel.Add("addressTypeCodeLabelText", "Address Type");
                    listFieldLabel.Add("customerTypeLabelText", "Customer Type");
                    listFieldLabel.Add("yearIncomeLabelText", "Income/Year");
                    listFieldLabel.Add("profitIncomeLabelText", "Prodit/Year");
                    listFieldLabel.Add("companyRegisDateLabelText", "Company Reg. Date");
                    listFieldLabel.Add("refDocDateLabelText", "Company Ref. Doc Date");
                    listFieldLabel.Add("companyRegisNoLabelText", "Company Reg. No.");
                    listFieldLabel.Add("customerRelation", "Relation");
                    listFieldLabel.Add("customerRelationYear", "Relation(Year)");
                    listFieldLabel.Add("creditLine1LabelText", "Credit Line");
                    listFieldLabel.Add("irRateLabelText", "Interest Rate Ref.");
                    listFieldLabel.Add("bankReferenceLabelText", "Bank Reference");
                    listFieldLabel.Add("maxCreditPerTimeLabelText", "Max Credit / Time");
                    listFieldLabel.Add("minCreditPerTimeLabelText", "Min Credit / Time");
                    listFieldLabel.Add("maxCreditPerDocLabelText", "Max Credit / Doc");
                    listFieldLabel.Add("interestConditionLabelText", "Interest Condition");
                    listFieldLabel.Add("termLabelText", "Term");
                    listFieldLabel.Add("creditTimeLabelText", "Credit Time");

                    listFieldLabel.Add("isSendTaxInvoiceLabelText", "Send Tax invoce?");
                    listFieldLabel.Add("parentCompanyLabelText", "Parent Company");
                    listFieldLabel.Add("interestRateLabelText", "Interest Rate");
                    listFieldLabel.Add("creditLine2LabelText", "Credit Line2");
                    listFieldLabel.Add("odInterestRateLabelText", "OD Interest Rate");
                    listFieldLabel.Add("overDrafLineLabelText", "Over Draf Line");
                    listFieldLabel.Add("advanceRatioLabelText", "Advance Ratio");
                    listFieldLabel.Add("agianstChequeLabelText", "Agianst Cheque");
                    listFieldLabel.Add("maxTenorLabelText", "Max Tenor");
                    listFieldLabel.Add("maxTenorPeriodLabelText", "Max Tenor Period");
                    listFieldLabel.Add("fixFeeAmountPerTimeLabelText", "Fix Fee Amount / Time");
                    listFieldLabel.Add("fixFeeTypeLabelText", "Fix Fee Type");
                    listFieldLabel.Add("collectionFeeRateLabelText", "Collection Fee Rate");
                    listFieldLabel.Add("collectionFeeTypeLabelText", "Collection Fee Type");
                    listFieldLabel.Add("operationFeeRateLabelText", "Operation Fee Rate");
                    listFieldLabel.Add("operationFeeTypeLabelText", "Operation Fee Type");
                    listFieldLabel.Add("retentionAmountLabelText", "Retention Amount");
                    listFieldLabel.Add("retentionRateLabelText", "Retention Rate");
                    listFieldLabel.Add("retentionTypeLabelText", "Retention Type");

                    listFieldLabel.Add("accountGradeLabelText", "Account Grade");
                    listFieldLabel.Add("accountLevelLabelText", "Account Level");
                    listFieldLabel.Add("approveDateLabelText", "Approve Date");
                    listFieldLabel.Add("creditScoreLabelText", "Credit Score");
                    listFieldLabel.Add("remarkLabelText", "Remark");

                    listFieldLabel.Add("payableToLabelText", "Payable To");
                    listFieldLabel.Add("accountDueTermLabelText", "Due Term");
                    listFieldLabel.Add("receiveByLabelText", "Receive By");
                    listFieldLabel.Add("payByLabelText", "Pay By");
                    listFieldLabel.Add("creditTermLabelText", "Credit Term");
                    listFieldLabel.Add("bankCodeLabelText", "Bank");
                    listFieldLabel.Add("bankBranchLabelText", "Bank Branch");
                    listFieldLabel.Add("bankAccNoLabelText", "Bank ACC. No.");

                    listFieldLabel.Add("interestTypeLabelText", "Interest Type");
                    listFieldLabel.Add("interestPeriodLabelText", "Interest Rate Period");
                    listFieldLabel.Add("termPeriodLabelText", "Term Period");
                    listFieldLabel.Add("totalCreditLabelText", "Total Credit");
                    listFieldLabel.Add("verifierLabelText", "Verifier");
                    listFieldLabel.Add("approverLabelText", "Approver");
                    listFieldLabel.Add("isPassedLabelText", "Verify Result");
                    listFieldLabel.Add("passLabelText", "Pass");
                    listFieldLabel.Add("notPassLabelText", "Not Pass");
                    listFieldLabel.Add("creditDeviateLabelText", "Not Pass Reason");
                    listFieldLabel.Add("preFinanceRateLabelText", "Prefinance Rate");
                    listFieldLabel.Add("txtRemark", "Remark");
                    listFieldLabel.Add("advanceRateLabelText", "Advance Rate");
                    
                }

            }
            else if (screenID == "ACC002AccountList")
            {
                if (language == "en-EN")
                {
                    listFieldLabel.Add("accountCodeLabelText", "Account No.");
                    listFieldLabel.Add("genAppNumLabelText", "App No.");
                    listFieldLabel.Add("accountNameLabelText", "Account Name");
                    listFieldLabel.Add("accountDealWithLabelText", "Deal Type");
                    listFieldLabel.Add("businessTypeLabelText", "Business Type");

                }

            }
            else
            {
                result = _service.GetScreenLabelText(screenID, language);
            }

            if (result != null)
            {
                foreach (ScreenLabelTextResult labelText in result)
                {
                    listFieldLabel.Add(labelText.Alias, labelText.FULL_TEXT);
                }
            }


            var returnObject = new
            {
                listLabelText = listFieldLabel,
            };

            return ControllerContext.Request.CreateResponse(HttpStatusCode.OK, returnObject);
        }

        [HttpGet]
        public HttpResponseMessage GetGlobalMessage(  String language)
        {

            List<GlobalMessageResult> result = _service.GetGlobalMessage(language);

            List<GlobalMessageResult> validateMessageResult = result.Where(x => x.MSG_CD.Contains("VLD")).ToList();
            List<GlobalMessageResult> dialogMessageResult =   result.Where(x => x.MSG_CD.Contains("DLG")).ToList();

            Dictionary<String, String> listDialogMsg = new Dictionary<string, string>();
            Dictionary<String, String> listValidateMsg = new Dictionary<string, string>();

            foreach (GlobalMessageResult item in validateMessageResult)
            {
                listValidateMsg.Add(item.MSG_CD, item.FULL_TEXT);
            }

            foreach (GlobalMessageResult item in dialogMessageResult)
            {
                listDialogMsg.Add(item.MSG_CD, item.FULL_TEXT);
            }

            var returnObject = new
            {
                listDialogMsg = listDialogMsg,
                listValidateMsg = listValidateMsg
            };

            return ControllerContext.Request.CreateResponse(HttpStatusCode.OK, returnObject);
        }

        [HttpGet]
        public List<MLS.Models.MockModel.SetupResult> getSysLanguageList()
        {
            List<MLS.Models.MockModel.SetupResult> sysLang = new List<MLS.Models.MockModel.SetupResult>();
            sysLang.Add(new MLS.Models.MockModel.SetupResult { TABKEYTWO = "en-EN", TABDSCTHA = "en-EN", TABSETVAL1 = "us" });
            sysLang.Add(new MLS.Models.MockModel.SetupResult { TABKEYTWO = "th-TH", TABDSCTHA = "th-TH", TABSETVAL1 = "th" });

            return sysLang;
        }

    }
}