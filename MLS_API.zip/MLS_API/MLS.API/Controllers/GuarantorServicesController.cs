﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp.Implement;
using MLS.Imp.Interface;
using MLS.Models;
namespace MLS.API.Controllers
{
    public class GuarantorServicesController : ApiController
    {
        IGuarantorSvc _service = new GuarantorSvc();

        [HttpGet]
        public List<GuarantorListResult> GetGuarantorList(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string CONNUM)
        {
            return _service.GetGuarantorList( CPNCOD,  CPNBRNCOD,  ACCBUSTYP,  CONNUM);
        }

        [HttpPost, Route("api/GuarantorServices/InsertOrUpdateGuarantor/{CPNCOD}/{CPNBRNCOD}/{ACCBUSTYP}/{GENAPPNUM}/{username}")]
        public void InsertOrUpdateGuarantor(
            [FromBody]List<GuarantorListResult> gurantorList,
            String CPNCOD,
            String CPNBRNCOD,
            String ACCBUSTYP,
            String GENAPPNUM, 
            String username
            )
        {
            _service.InsertOrUpdateGuarantor(gurantorList,
           CPNCOD,
           CPNBRNCOD,
           ACCBUSTYP,
           GENAPPNUM, 
           username);
        }
    }
}
