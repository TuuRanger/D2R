﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MLS_API.Controllers
{
    public class RepaymentController : ApiController
    {
        public RepaymentController()
        {
            //this.applicationReporsitory = new ApplicationRepository();
        }

        [HttpGet]
        public object RepaymentProcess()
        {
            return "";
        }

        [HttpGet]
        public object CheckReceive() // รับเช็คล่วงหน้าเป็นชุด
        {
            return "";
        }

        [HttpGet]
        public object GenerateRepaymentReport()
        {
            return "";
        }

        [HttpGet]
        public object VoidRepaymentProcess()
        {
            return "";
        }
    }
}
