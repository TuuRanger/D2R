﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MLS_API.Controllers
{
    public class PaymentController : ApiController
    {
        public PaymentController()
        {
            //this.applicationReporsitory = new ApplicationRepository();
        }

        [HttpGet]
        public object GetDirectCreditList()
        {
            return "";
        }

        [HttpGet]
        public object GetDirectCreditApproveList()
        {
            return "";
        }

        [HttpPost]
        public object DirectCreditListUpdate()
        {
            return "";
        }

        [HttpPost]
        public object DirectCreditApproveListUpdate()
        {
            return "";
        }

    }
}
