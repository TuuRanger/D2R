﻿using MLS.Helper;
using MLS.Imp.Implement;
using MLS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MLS.API.Controllers
{
    public class FactoringServicesController : ApiController
    {
        IFactorySvc _service = null;

        public FactoringServicesController()
        {
            _service = new FactorySvc();
        }

        [HttpPost,Route("api/FactoringServices/InvoiceVerifying/{username}")]
        public List<InvoiceResult> InvoiceVerifying([FromBody] List<String> fileNames,String username)
        { 
            return _service.InvoiceVerifying(fileNames, username);
        }


        public List<InvoiceListResult> GetInvoiceList(String productType, DateTime? InvoiceDateFrom, DateTime? invoiceDateTo, DateTime? dueDateFrom, DateTime? dueDateTo)
        {
            return _service.GetInvoiceList( productType, InvoiceDateFrom, invoiceDateTo, dueDateFrom,  dueDateTo);
        }
         

        [HttpGet]
        public List<InvoiceListResult> OnAssignCredit(String productType, DateTime? InvoiceDateFrom, DateTime? invoiceDateTo, DateTime? dueDateFrom, DateTime? dueDateTo, Decimal creditRequest)
        {
            List<InvoiceListResult> invoiceList = _service.GetInvoiceList(productType, InvoiceDateFrom, invoiceDateTo, dueDateFrom, dueDateTo);
            if (invoiceList.Count > 0)
            {
                List<InvoiceListResult> invoiceAssigned = new List<InvoiceListResult>();
                foreach (InvoiceListResult invoice in invoiceList.Where(x => x.CreditAvailableAmount > 0).OrderBy(x => x.INVDUEDTE).ToList())
                {
                    if (creditRequest > 0)
                    {
                        decimal creditAvailable = invoice.CreditAvailableAmount.ToDecimalOrZero();
                        if (creditAvailable > creditRequest) /*Available > request*/
                        {
                            invoice.CreditRequestAmount = creditRequest;
                            creditRequest = 0;
                        }
                        else
                        {
                            invoice.CreditRequestAmount = creditAvailable; /*Use full available*/
                            creditRequest -= creditAvailable;
                        }
                        invoice.CreditAvailableAmount = invoice.CreditAvailableAmount.ToDecimalOrZero() - invoice.CreditRequestAmount;
                    }
                    invoiceAssigned.Add(invoice);

                }
                return invoiceAssigned;
            }
            return null;
        }
        
        [HttpPost,Route("api/FactoringServices/InsertInvoiceTransaction/{username}")]
        public void InsertInvoiceTransaction([FromBody]List<InvoiceListResult> selectedInvoices, string username)
        {
            _service.InsertInvoiceTransaction(selectedInvoices,username);
        }

        [HttpGet]
        public InvoiceCreditInfoResult GetInvoiceCreditInfo()
        {
            return _service.GetInvoiceCreditInfo();
        }

    }
}
