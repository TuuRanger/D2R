if exists(Select 1 FROM sys.objects WHERE object_id = object_id(N'[dbo].[spInsertOrUpdateMessageText]'))
begin
	drop procedure  [dbo].[spInsertOrUpdateMessageText]
end

GO

CREATE PROCEDURE [dbo].[spInsertOrUpdateMessageText]
	 @messagePrefix varchar(100), 
	 @messageText nvarchar(max), 
	 @abbrText nvarchar(max), 
	 @lang varchar(20)
AS
BEGIN
	Declare @MSG_CD varchar(100)

	Select @MSG_CD = FORMAT(CAST(ISNULL(MAX(REPLACE ( MSG_CD , @messagePrefix , '' ) ),0) as int) +1 ,'0000')   FROM CDS_TXT_DISPLAY_LANG
	WHERE MSG_CD like '%' + @messagePrefix +'%'

  

INSERT INTO [dbo].[CDS_TXT_DISPLAY_LANG]
           ([MSG_CD]
           ,[LANG_CD]
           ,[ABBR_TEXT]
           ,[FULL_TEXT])
     VALUES
           (@messagePrefix + @MSG_CD
           ,@lang
           ,@abbrText
           ,@messageText) 
END
GO
  