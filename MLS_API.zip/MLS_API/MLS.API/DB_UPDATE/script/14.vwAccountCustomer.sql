 if exists(Select 1 FROM sys.objects where object_id = object_id(N'[dbo].[vwAccountCustomer]'))
 begin
	Drop view [dbo].[vwAccountCustomer]
 end

 GO 
CREATE view [dbo].[vwAccountCustomer] as
Select  
ISNULL(ROW_NUMBER() OVER (ORDER BY acc.ACCCOD),-1) RowNo,
 acc.*
FROM
 CDMACC acc 

