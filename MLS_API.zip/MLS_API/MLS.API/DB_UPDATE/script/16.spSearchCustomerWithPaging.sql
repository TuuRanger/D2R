 if exists(Select 1 FROM sys.objects WHERE object_id = object_id(N'[dbo].[spSearchCustomerWithPaging]'))
 begin
	drop procedure spSearchCustomerWithPaging
 end

 GO

CREATE PROCEDURE  spSearchCustomerWithPaging
	 @ID varchar(20),
	 @CUSNAMTHA varchar(255),
	 @CUSSURTHA varchar(255), 
	 @CUSTYPCOD varchar(5),
	 @PageNo int,
	 @PageSize int
AS
BEGIN

  

DECLARE @LocalID varchar(20) = @ID
DECLARE @LocalCUSNAMTHA varchar(255) = @CUSNAMTHA
DECLARE @LocalCUSSURTHA varchar(255) = @CUSSURTHA 
DECLARE @LocalCUSTYPCOD varchar(5) = @CUSTYPCOD
DECLARE @LocalPageNo int = @PageNo
DECLARE @LocalPageSize int = @PageSize

 
;WITH tbl AS 
(
	 SELECT
	ISNULL(ROW_NUMBER() OVER (Order by vw.CUSCOD),-1) rowno, *
    FROM  [vwCustomerSearch] vw  
	  WHERE
	   (NULLIF(LTRIM(RTRIM(@LocalID)),'') IS NULL OR vw.ID like '%' + @LocalID  + '%')
	   AND (NULLIF(LTRIM(RTRIM(@LocalCUSNAMTHA)),'') IS NULL OR vw.CUSNAMTHA like '%' + @LocalCUSNAMTHA  + '%' )
	   AND (NULLIF(LTRIM(RTRIM(@LocalCUSSURTHA)),'') IS NULL OR vw.CUSSURTHA like '%' + @LocalCUSSURTHA  + '%' ) 
	   AND  (NULLIF(LTRIM(RTRIM(@LocalCUSTYPCOD)),'') IS NULL OR vw.CUSTYPCOD = @LocalCUSTYPCOD) 
  )   
   

  Select * ,(SELECT MAX(rowno) FROM tbl) TotalRecords  FROM tbl
  WHERE tbl.rowno between (@LocalPageSize * (@LocalPageNo - 1)) +1 AND (@LocalPageNo * @LocalPageSize)  

END
GO
