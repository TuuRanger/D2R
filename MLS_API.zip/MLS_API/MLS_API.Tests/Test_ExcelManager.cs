﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Helper;
using MLS.Models;

namespace MLS_API.Tests
{
    [TestClass]
    public class Test_ExcelManager
    {
        [TestMethod]
        public void Test_ReadExcel()
        {
            String fileName = "C:/temp/Invoice Upload File.xlsx";
            List<InvoiceResult> result =  ExcelManager.ReadExcel<InvoiceResult>(fileName, 1, 2); 
        }
    }
}
