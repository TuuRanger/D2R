﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Helper;
using System.Xml.Linq;
using System.Xml;
using System.Dynamic;

namespace MLS_API.Tests
{
    [TestClass]
    public class DynamicHelperTest
    {
        [TestMethod]
        public void TestParseXMLStringToDynamic()
        {
            String xml = "<Root><Item><Key>PRDOPT1</Key><Value>1</Value></Item><Item><Key>PRDOPT2</Key><Value>2</Value></Item><Item><Key>PRDOPT3</Key><Value>3</Value></Item><Item><Key>PRDOPT4</Key><Value>4</Value></Item><Item><Key>PRDOPT5</Key><Value>5</Value></Item><Item><Key>PRDOPT6</Key><Value>6</Value></Item><Item><Key>PRDOPT7</Key><Value>7</Value></Item><Item><Key>PRDOPT8</Key><Value>8</Value></Item><Item><Key>PRDOPT9</Key><Value>9</Value></Item><Item><Key>PRDOPT10</Key><Value>10</Value></Item><Item><Key>PRDOPT11</Key><Value>11</Value></Item><Item><Key>PRDOPT12</Key><Value>12</Value></Item><Item><Key>PRDOPT13</Key><Value>13</Value></Item><Item><Key>PRDOPT14</Key><Value>14</Value></Item><Item><Key>PRDOPT15</Key><Value>15</Value></Item><Item><Key>PRDOPT16</Key><Value>16</Value></Item><Item><Key>PRDOPT17</Key><Value>17</Value></Item><Item><Key>PRDOPT18</Key><Value>18</Value></Item><Item><Key>PRDOPT19</Key><Value>19</Value></Item><Item><Key>PRDOPT20</Key><Value>20</Value></Item><Item><Key>PRDOPT21</Key><Value>21</Value></Item></Root>";
       
            XElement elem = XElement.Parse(xml);
            dynamic root = new ExpandoObject();
            DynamicHelper.ParseDynamic(root, elem);
            Dictionary<String, String> result = new Dictionary<string, string>();
            foreach (var v in root.Root.Item)
            {
                result.Add(v.Key, v.Value);
            }
            

        }
    }
}
