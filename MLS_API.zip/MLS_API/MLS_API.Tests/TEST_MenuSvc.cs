﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Helper;
using System.Xml.Linq;
using System.Xml;
using System.Dynamic;
using MLS.Imp.Interface;
using MLS.Imp.Implement;
using MLS.Models;

namespace MLS_API.Tests
{
    [TestClass]
    public class TEST_MenuSvc
    {
        IMenuSvc _service = null;

        [TestInitialize]
        public void Initial()
        {
            _service = new MenuSvc();
        }

        [TestMethod]
        public void GetAllMenuAndSubMenu()
        {
            List<MenuViewModel> result = _service.GetMenus("admin");
           String MenuJson =  Newtonsoft.Json.JsonConvert.SerializeObject(result);
        }
    }
}
