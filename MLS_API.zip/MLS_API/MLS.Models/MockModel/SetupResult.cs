﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Models.MockModel
{
    public class SetupResult
    {
        public string TABKEYTWO { get; set; }
        public string TABSETVAL1 { get; set; }
        public String TABDSCTHA { get; set; }

    }
}
