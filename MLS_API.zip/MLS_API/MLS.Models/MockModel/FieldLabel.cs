﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MLS.Models.MockModel
{
    public class FieldLabel
    {
        public String FieldId { get; set; }
        public String LabelText { get; set; }
    }
}