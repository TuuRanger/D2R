﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Models
{
    public class CreditLimitResult
    {
        public decimal CreditLimit { get; set; }
        public int TermLimit { get; set; }
        public decimal MaxInstallment { get; set; }
        //public decimal FinanceAmount { get; set; }
        //public decimal LendingAmount { get; set; }
        public bool IsPaymentAbilityNotFound { get; set; }
    }
}
