﻿
namespace MLS.Models
{
    public class InstallmentCalcResult
    {
        public double CONLNDAMT;
        public double CONINSAMT;
        public double CONEFFRTE; 
    }
}
