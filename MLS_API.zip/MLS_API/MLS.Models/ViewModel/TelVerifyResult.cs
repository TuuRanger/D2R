﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Models
{
    public class TelVerifyResult
    {
        public String HasTM { get; set; }
        public String HasTH { get; set; }
        public String HasTO { get; set; } 
        public String HasTF { get; set; }
        public String HasTR { get; set; }
    }
}
