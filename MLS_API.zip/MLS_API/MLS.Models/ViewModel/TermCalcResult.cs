﻿namespace MLS.Models
{
    public class TermCalcResult
    { 
        public double CONFINAMT;
        public double CONLNDAMT;
        public int CONLNDTRM;
        public double CONINSAMT;
        public double CONEFFRTE;
    }
}
