﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Models
{
    public partial class vwUserSection  
    {
        public int FollowUpWorkLoadCount {
            get
            {
                if (this.FollowUpWorkLoad != null)
                    return this.FollowUpWorkLoad.Count;
                else
                    return 0;
            }
        }
        public List<vwFollowUpHeader> FollowUpWorkLoad { get; set; }
    }
}
