﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Models
{
    public class AccountProcessViewModel : AccountDetailResult
    {
        public List<vwCUSINFO> CustomerList { get; set; }
        public List<CustomerAddressResult> AddressList { get; set; }
        public List<RefListResult> ReferencePersonList { get; set; }
        public List<GuarantorListResult> GuarantorList { get; set; }
        public String GENREMARK { get; set; }
    }
}
