﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Models
{
    public partial class SearchCustomerWithPagingResult
    {
        public List<CustomerAddressResult> AddressList;
        public  String FullName
        {
            get
            {
                if (this.CUSTYPCOD == Helper.Constants.CustomerType.Jurictic)
                {
                    return this.CUSTTLTHA + " " + this.CUSNAMTHA +  " " + this.CUSSURTHA;
                }
                else
                {
                    return this.CUSTTLTHA + " " + this.CUSNAMTHA + " " + this.CUSSURTHA;
                }

            }
        }
    }
}
