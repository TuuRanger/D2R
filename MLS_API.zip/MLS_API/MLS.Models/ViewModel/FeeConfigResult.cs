﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Models
{
    public partial class FeeConfigResult
    {
        public String FEETYP { get {
                return this.TRNCOD;
            } }
        public decimal FEEGRS { get; set; }
        public decimal FEENET { get; set; }
        public decimal FEETAX { get; set; }
        public String FEEWAIVER { get; set; }
        public string CONNUM { get; set; }
        public string CPNCOD { get; set; }
        public string CPNBRNCOD { get; set; }
        public string ACCBUSTYP { get; set; }
    }
}
