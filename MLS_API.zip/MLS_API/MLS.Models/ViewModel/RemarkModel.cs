﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Models
{
    public class RemarkModel
    {
        public Nullable<int> REMARK_ID { get; set; }
        //public string CPNCOD { get; set; }
        //public string CPNBRNCOD { get; set; }
        //public string ACCBUSTYP { get; set; }
        //public string CONNUM { get; set; }
        public string RMKLEVRSL { get; set; }
        public string GENREMARK { get; set; }
        public string USRCOD { get; set; }
        public string GENPROGRM { get; set; }
    }
}
