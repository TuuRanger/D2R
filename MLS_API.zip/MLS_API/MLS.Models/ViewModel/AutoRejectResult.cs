﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Models
{
    public class RejectResult
    {
        public string RejectReasonID { get; set; } 
        public bool IsReject { get; set; }
    }
}
