﻿using MLS.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Models
{
    public class MenuViewModel : MenuResult
    {
        public MenuViewModel ParentMenu { get; set; }
        public bool IsParent {
            get
            {
                return this.Parent.IsEmpty();
            }
        }
        public List<MenuViewModel> ChildMenus { get; set; }
    }
}
