﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Models
{
    public partial class vwCUSINFO
    {
      public List<CustomerAddressResult> AddressList { get; set; }
      public String RECACTCOD {get; set;}
      public bool ADDNEW_FLAG { get; set; }
    }
}
