﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Models
{
    public class UserToken
    {
        public String TokenString { get; set; }
        public String Username { get; set; }
        public DateTime LoginDateTime { get; set; }
        public Int64 TTL { get; set; } 
    }
}
