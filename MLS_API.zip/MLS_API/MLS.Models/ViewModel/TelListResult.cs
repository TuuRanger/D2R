﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Models
{
    public partial class TelListResult
    {
        public String PaymentAbilityResult { get; set; } 
    }
}
