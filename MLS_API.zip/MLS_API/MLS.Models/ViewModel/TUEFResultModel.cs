﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Models
{
    public class NCBResult
    {
        public bool IsPassed { get; set; }
        public String Reason { get; set; }
        public String TUEF_Text { get; set; }
        public String inquiryResult { get; set; }
        public String Action { get; set; }
        public String PSNREGIDN { get; set; }
        public String CUSCOD { get; set; }
        public String GENAPPNUM { get; set; }
        public String CONAPPLY_PROJEC { get; set; } 
    }

}
