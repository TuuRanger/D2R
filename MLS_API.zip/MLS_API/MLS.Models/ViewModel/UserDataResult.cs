﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Models
{
    public class UserDataResult
    {
        public String Username { get; set; }
        public DateTime LoginDateTime {get; set;}
        public Int64 TimeToLive {get; set;} 
        public String SectionLevel { get; set; }
        public List<vwUserSection> Sections { get; set; } 
        public vwUserProfile UserProfile { get; set; }
    }
}
