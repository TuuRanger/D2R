﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Models.CustomModels
{
    public class ComboBoxDataSource
    {
        public String DisplayMember { get; set; }
        public String ValueMember { get; set; }
    }
}
