﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Helper.CustomAttribute;
namespace MLS.Models
{
    public class InvoiceResult
    {
        [ExcelReadColumnMapping("A")]
        public String InvoiceNo { get; set; }

        [ExcelReadColumnMapping("B")]
        public DateTime InvoiceDate { get; set; }

        [ExcelReadColumnMapping("C")]
        public String ContractNo { get; set; }

        [ExcelReadColumnMapping("D")]
        public Decimal InvoiceAmount { get; set; }

        [ExcelReadColumnMapping("E")]
        public DateTime DueDate { get; set; }

        public bool IsComplete {get;set;}
    }
}
