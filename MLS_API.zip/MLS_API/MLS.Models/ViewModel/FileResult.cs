﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLS.Models
{
    public class FileResult
    {
        public List<string> FileNames { get; set; }
        //public string Description { get; set; }
        //public DateTime CreatedTimestamp { get; set; }
        //public DateTime UpdatedTimestamp { get; set; }
        //public string DownloadLink { get; set; }
        //public IEnumerable<string> ContentTypes { get; set; }
        //public IEnumerable<string> Names { get; set; }
    }
}
