﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Helper;

namespace MLS.Models
{
    public partial class ContractDetailResult
    {
        public int ActualStep {
            get {

                if (this.CRDNXTSTP.IsNotEmpty())
                {
                    return Convert.ToInt32(this.CRDNXTSTP);
                }
                return 1;
            }
        }

        public bool IsRecalculateCreditLimit { get; set; }

        public decimal MaxInstallment { get; set; }

        public List<CustomerAddressResult> AddressList { get; set; }

        public List<GuarantorListResult> GuarantorList { get; set; }

        public List<RefListResult> ReferencePersonList { get; set; }

        public List<FeeConfigResult> FeeList { get; set; }
    }
}
