﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MLS.Models;
using MLS.Models.CustomModels;
namespace MLS.Models
{
    public partial class ProductSpecInputFieldResult
    {
        public List<ComboBoxDataSource> ComboBoxDataSource { get; set; }
    }
}
