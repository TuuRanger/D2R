﻿using MLS.Helper;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace MLS.Models
{
    public partial class vwCDMPRD
    {
        public dynamic ProductDetailParsed {
            get
            {
                return this.ParseProductDetail();
            }
        }

        private Dictionary<String, String> ParseProductDetail()
        {
            String xml = this.PRDDETAIL;

            XElement elem = XElement.Parse(xml);
            dynamic root = new ExpandoObject();
            DynamicHelper.ParseDynamic(root, elem);
            Dictionary<String, String> result = new Dictionary<string, string>();
            foreach (var v in root.Root.Item)
            {
                result.Add(v.Key, v.Value);
            }
            return result;
        }
    }
}
