﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp.Implement;
using MLS.Models;
namespace MLS.Services.Controllers
{
    public class SetupServicesController : ApiController
    {
        [HttpGet]
        public List<SetupResult> GetSetup(string TABKEYONE, string TABKEYTWO, string SHOWALL)
        {
            SetupSvc svcSetup = new SetupSvc();
            return svcSetup.GetSetup(TABKEYONE, TABKEYTWO, SHOWALL).ToList();
        }
    }
}
