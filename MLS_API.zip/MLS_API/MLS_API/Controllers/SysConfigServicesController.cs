﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Models;
using MLS.Imp.Implement;
namespace MLS.Services.Controllers
{
    public class SysConfigServicesController : ApiController
    {
        SysConfigSvc _service = new SysConfigSvc();
        public List<CDMTABListResult> GetCDMTABList(String tabKeyOne, String tabKeyTwo)
        {
            return _service.GetCDMTABList(tabKeyOne, tabKeyTwo);
        }
    }
}
