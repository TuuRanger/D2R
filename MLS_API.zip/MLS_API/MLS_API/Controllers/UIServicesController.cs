﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;
using MLS.Models.MockModel;

namespace MLS.Services.Controllers
{
    public class UIServicesController : ApiController
    {
        [HttpGet]
        public HttpResponseMessage getScreenLabelTextList(String screenID , String language)
        { 
            Dictionary<String, String> listFieldLabel = new Dictionary<string, string>();

            if (screenID == "_LoginLayout")
            {
                if (language == "en-EN")
                {
                    listFieldLabel.Add("txtUsername", "Username");
                    listFieldLabel.Add("txtPassword", "Password");
                    listFieldLabel.Add("btnSubmit", "Login");
                }
                else if (language == "th-TH")
                {
                    listFieldLabel.Add("txtUsername", "ชื่อผู้ใช้");
                    listFieldLabel.Add("txtPassword", "รหัสผ่าน");
                    listFieldLabel.Add("btnSubmit", "เข้าสู่ระบบ");

                }
            }
            else if (screenID == "APP001NewApp")
            {
                if (language == "en-EN")
                {
                    listFieldLabel.Add("txtCreditLine", "Credit Line");
                    listFieldLabel.Add("txtCreditAvailable", "Credit Available");
                    listFieldLabel.Add("cboConApplyProjec", "Apply Project");
                    listFieldLabel.Add("cboAccBusTyp", "Business Type");
                    listFieldLabel.Add("cboConCrdTyp", "Credit Type");
                    listFieldLabel.Add("cboConTaxTyp", "Vat Type");
                    listFieldLabel.Add("cboCusTypCod", "Customer Type");
                    listFieldLabel.Add("txtMobile1", "Mobile1");
                    listFieldLabel.Add("txtMobile2", "Mobile2");
                    listFieldLabel.Add("txtMobile3", "Mobile3");
                    listFieldLabel.Add("txtJPRNo", "JP. Reg No.");
                    listFieldLabel.Add("txtIncPerYea", "Income Per Year");
                    listFieldLabel.Add("txtProfitPerYea", "Profit Per Year");
                    listFieldLabel.Add("txtJprRegDte", "JP. Reg. Date");
                    listFieldLabel.Add("txtJprCerDte", "JP. Cer. Date");

                    listFieldLabel.Add("cboPrdGrpCod", "Product Group");
                    listFieldLabel.Add("cboPrdSubCod", "Product Sub Group");
                    listFieldLabel.Add("cboPrdBrnCod", "Brand");
                    listFieldLabel.Add("cboPrdMdlCod", "Model");
                    listFieldLabel.Add("txtPrdSrlNo", "Serail No.");
                    listFieldLabel.Add("cboPrdTyp", "Produt Type");
                    listFieldLabel.Add("txtPrdLstPrc", "List Price");
                    listFieldLabel.Add("txtPrdCost", "Product Cost");
                    listFieldLabel.Add("txtPrdSalPrc", "Sale Price");

                    listFieldLabel.Add("txtPSNREGIDN", "ID");
                    listFieldLabel.Add("txtPSNREGIDN2", "Confirm ID");
                    listFieldLabel.Add("cboCusTtlTha", "Title name");
                    listFieldLabel.Add("txtCUSNAMTHA", "Name");
                    listFieldLabel.Add("txtCUSSURTHA", "Surname");
                    listFieldLabel.Add("txtPSNBTHDTE", "Birth date");
                    listFieldLabel.Add("cboPsnBthDay", "Birth day");
                    listFieldLabel.Add("txtCUSNICNAM", "Nick name");
                    listFieldLabel.Add("cboAccCodDlr", "Vendor");
                    listFieldLabel.Add("txtPSNMTHINC", "Gross income");
                    listFieldLabel.Add("txtPSNNETINC", "Net income");
                    listFieldLabel.Add("cboConApplyType", "Apply type");
                    listFieldLabel.Add("cboConApplyVia", "Apply via");
                    listFieldLabel.Add("cboConApplyViaBranch", "Apply via branch");
                    listFieldLabel.Add("cboConObjCod", "Business Type");
                    listFieldLabel.Add("cboConApplyPromotion", "Apply promotion");

                    listFieldLabel.Add("txtAddressLine1", "Address");
                    listFieldLabel.Add("txtAddressDistrict", "District");
                    listFieldLabel.Add("txtAddressAmphur", "Amphur");
                    listFieldLabel.Add("txtAddressProvince", "Province");
                    listFieldLabel.Add("txtAddressZipCode", "Zip Code");
                    listFieldLabel.Add("txtAddressPhoneNo", "Phone No.");
                    listFieldLabel.Add("txtAddressPhoneExtNo", "Ext No.");
                    listFieldLabel.Add("txtAddressPhoneEndNo", "End No.");

                    listFieldLabel.Add("txtRefPersonName", "Name");
                    listFieldLabel.Add("txtRefPersonLastName", "Lastname");
                    listFieldLabel.Add("cboRefRelation", "Relation");
                    listFieldLabel.Add("txtTeRefPersonTelNo", "Tel No.");
                    listFieldLabel.Add("txtRefTitleName", "Title");
                    listFieldLabel.Add("txtAge", "Age");
                    listFieldLabel.Add("txtFullBirthDate", "Full birth date");

                    listFieldLabel.Add("cboPsnMarSts", "Marriage Status");
                    listFieldLabel.Add("txtPsnChdNum", "No. of children");
                    listFieldLabel.Add("cboPsnSexCod", "Gender");
                    listFieldLabel.Add("txtLivInHomYea", "Period of live in home (Year)");
                    listFieldLabel.Add("txtLivInHomMon", "Period of live in home (Month)");

                    listFieldLabel.Add("txtAdrMember", "No. of home member");
                    listFieldLabel.Add("cboAdrOwnerCod", "Home type");
                    listFieldLabel.Add("cboPsnCpnTyp", "Business Type");
                    listFieldLabel.Add("cboPsnOccCod", "Occupation");
                    listFieldLabel.Add("cboPsnPosIn", "Position");
                    listFieldLabel.Add("txtPsnCpnStf", "No. of staff");
                    listFieldLabel.Add("txtPsnWrkPrdYea", "Period of work (Year)");
                    listFieldLabel.Add("txtPsnWrkPrdMon", "Period of work (Month)");
                    listFieldLabel.Add("cboPsnEmployTyp", "Employment type");
                    listFieldLabel.Add("cboPsnSalRcvTyp", "Salary receiving type");
                    listFieldLabel.Add("cboCoOperateType", "Co-operate type");
                    listFieldLabel.Add("txtCrdReqAmt", "Credit request amount");
                    listFieldLabel.Add("txtCrdReqTrm", "Term request amount");
                    listFieldLabel.Add("cboFinBnkCodCr", "Bank");
                    listFieldLabel.Add("cboFinBrnCodCr", "Bank branch");
                    listFieldLabel.Add("txtFinBnkNumCr", "Bank account No.");
                    listFieldLabel.Add("txtCrdLimAmt", "Credit limit");
                    listFieldLabel.Add("txtCrdLimTrm", "Term limit");
                    listFieldLabel.Add("txtConFinAmt", "Loan approve");
                    listFieldLabel.Add("txtConLndTrm", "Term approve");
                    listFieldLabel.Add("txtConIntRte", "Flat rate");
                    listFieldLabel.Add("txtConEffRte", "Effective rate");
                    listFieldLabel.Add("txtConInsAmt", "Calc. Installment");
                    listFieldLabel.Add("txtMaxInstallment", "Max installment");
                    listFieldLabel.Add("txtConLndAmt", "Finance amount");
                    listFieldLabel.Add("txtTotIntAmt", "Total Interest amount");
                    listFieldLabel.Add("txtIntAmt", "Interest amount");
                    listFieldLabel.Add("txtCrUsgAmt", "Credit usage amount");
                    listFieldLabel.Add("chbCheckHomeNameRslt", "Valid name");
                    listFieldLabel.Add("chbCheckHomeAdrRslt", "Valid address");
                    listFieldLabel.Add("chbCheckOffcNameRslt", "Valid name");
                    listFieldLabel.Add("chbChecjOffcAdrRslt", "Valid address");
                    listFieldLabel.Add("txtCheckHomeNameRemark", "Remark name");
                    listFieldLabel.Add("txtCheckHomeAdrRemark", "Remark address");
                    listFieldLabel.Add("txtCheckOffcNameRemark", "Remark name");
                    listFieldLabel.Add("txtCheckOffcAdrRemark", "Remark address");

                    listFieldLabel.Add("tblFeeInfoCol1", "No.");
                    listFieldLabel.Add("tblFeeInfoCol2", "Desc");
                    listFieldLabel.Add("tblFeeInfoCol3", "Total amount");
                    listFieldLabel.Add("tblFeeInfoCol4", "Net amount");
                    listFieldLabel.Add("tblFeeInfoCol5", "Vat");
                    listFieldLabel.Add("tblFeeInfoCol6", "Waiver");

                    listFieldLabel.Add("tblFeeInfoRow1Cell1", "Duty stamp");
                    listFieldLabel.Add("tblFeeInfoRow2Cell1", "NCB");

                    listFieldLabel.Add("txtRelationYear", "Relation(Year)");
                }
                else if (language == "th-TH")
                {
                    listFieldLabel.Add("txtCreditLine", "วงเงินทั้งหมด");
                    listFieldLabel.Add("txtCreditAvailable", "วงเงินคงเหลือ");
                    listFieldLabel.Add("cboConApplyProjec", "โปรเจค");

                    listFieldLabel.Add("txtPSNREGIDN", "เลขบัตรประชาชน");
                    listFieldLabel.Add("txtPSNREGIDN2", "ยืนยันเลขบัตรประชาชน");
                    listFieldLabel.Add("cboCusTtlTha", "คำนำหน้าชื่อ");
                    listFieldLabel.Add("txtCUSNAMTHA", "ชื่อ");
                    listFieldLabel.Add("txtCUSSURTHA", "นามสกุล");
                    listFieldLabel.Add("txtPSNBTHDTE", "วันที่เกิด");
                    listFieldLabel.Add("cboPsnBthDay", "วันเกิด");
                    listFieldLabel.Add("txtCUSNICNAM", "ชื่อเล่น");
                    listFieldLabel.Add("cboAccCodDlr", "เวนเดอร์");
                    listFieldLabel.Add("txtPSNMTHINC", "รายได้พื้นฐานต่อเดือน");
                    listFieldLabel.Add("txtPSNNETINC", "รายได้สุทธิ");
                    listFieldLabel.Add("cboConApplyType", "ขอโดย");
                    listFieldLabel.Add("cboConApplyVia", "ขอผ่าน");
                    listFieldLabel.Add("cboConApplyViaBranch", "สาขา");
                    listFieldLabel.Add("cboConObjCod", "ประเภทธุรกิจ");
                    listFieldLabel.Add("cboConApplyPromotion", "โปรโมชั่น");


                    listFieldLabel.Add("txtAddressLine1", "ที่อยู่");
                    listFieldLabel.Add("txtAddressDistrict", "ตำบล");
                    listFieldLabel.Add("txtAddressAmphur", "อำเถอ");
                    listFieldLabel.Add("txtAddressProvince", "จังหวัด");
                    listFieldLabel.Add("txtAddressZipCode", "รหัสไปรษณี");
                    listFieldLabel.Add("txtAddressPhoneNo", "โทรศัพท์");
                    listFieldLabel.Add("txtAddressPhoneExtNo", "เบอร์ต่อ");
                    listFieldLabel.Add("txtAddressPhoneEndNo", "ถึง");
                    listFieldLabel.Add("txtRefPersonName", "ชื่อ");
                    listFieldLabel.Add("txtRefPersonLastName", "นามสกุล");
                    listFieldLabel.Add("cboRefRelation", "ความสัมพันธ์");
                    listFieldLabel.Add("txtTeRefPersonTelNo", "เบอร์โทร");
                    listFieldLabel.Add("txtRefTitleName", "คำนำหน้าชื่อ");
                    listFieldLabel.Add("tblFeeInfoCol1", "อธิบาย");
                    listFieldLabel.Add("tblFeeInfoCol2", "จำนวนเงิน");
                    listFieldLabel.Add("tblFeeInfoCol3", "เวฟ");
                    listFieldLabel.Add("tblFeeInfoRow1Cell1", "อาการแสตมป์");
                    listFieldLabel.Add("tblFeeInfoRow2Cell1", "NCB");
                }
                else
                {
                    throw new Exception(String.Format("language {0} is not supported"));
                }

            }
            else if (screenID == "APP002AppList")
            {
                if (language == "en-EN")
                {
                    listFieldLabel.Add("txtPSNREGIDN", "ID");
                    listFieldLabel.Add("txtCUSNAMTHA", "Name");
                    listFieldLabel.Add("txtCUSSURTHA", "Surname");
                    listFieldLabel.Add("cboConApplyProjec", "Project");
                    listFieldLabel.Add("txtGenAppNum", "App. No.");
                }
                else if (language == "th-TH")
                {
                    listFieldLabel.Add("txtPSNREGIDN", "เลขบัตรประชาชน");
                    listFieldLabel.Add("txtCUSNAMTHA", "ชื่อ");
                    listFieldLabel.Add("txtCUSSURTHA", "นามสกุล");
                }
            }
            else if (screenID == "SYSCFG_MASMTN001")
            {
                if (language == "en-EN")
                {
                    listFieldLabel.Add("txtTabKeyOne", "Key1");
                    listFieldLabel.Add("txtTabKeyTwo", "Key2"); 
                }

            }

                var returnObject = new {
                listLabelText = listFieldLabel, 
            };

            return ControllerContext.Request.CreateResponse(HttpStatusCode.OK, returnObject);
        }
        
        [HttpGet]
        public HttpResponseMessage getValidateMessageTextList(String LayoutID, String language)
        { 
            Dictionary<String, String> listDialogMsg = new Dictionary<string, string>();
            Dictionary<String, String> listValidateMsg = new Dictionary<string, string>();
            if (language == "en-EN")
            {
                listDialogMsg.Add("DLGQUES0001", "Do you want to save data ?");
                listValidateMsg.Add("VLD001", "This field is required.");
            }
            else if (language == "th-TH")
            {
                listDialogMsg.Add("DLGQUES0001", "คุณต้องการบันทึกข้อมูล?");
                listValidateMsg.Add("VLD001", "กรุณากรอกข้อมูล");
            }
            else
            {
                throw new Exception(String.Format("language {0} is not supported"));
            }


            var returnObject = new
            {
                listDialogMsg = listDialogMsg,
                listValidateMsg = listValidateMsg
            };

            return ControllerContext.Request.CreateResponse(HttpStatusCode.OK, returnObject);
        }

        [HttpGet]
        public List<MLS.Models.MockModel.SetupResult> getSysLanguageList()
        {
            List<SetupResult> sysLang = new List<SetupResult>();
            sysLang.Add(new SetupResult { TABKEYTWO = "en-EN", TABDSCTHA = "en-EN" , TABSETVAL1 = "us"});
            sysLang.Add(new SetupResult { TABKEYTWO = "th-TH", TABDSCTHA = "th-TH" , TABSETVAL1 = "th" });

            return sysLang;
        }

    }
}