﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp;
using MLS.Imp.Interface;
using MLS.Imp.Implement;
using MLS.Models;
namespace MLS.Services.Controllers
{
    public class CommonsController : ApiController
    {
        ISetupSvc svcCommons = null;
        public CommonsController()
        {
            svcCommons = new SetupSvc();
        }

    

        [HttpGet]
        public List<SetupResult> GetSysLanguageList()
        {
            //if (ShowAll.Trim() == "")
            //{
            //    ShowAll = null; 
            //}

            return svcCommons.GetSetup("SYS_LANG", null, "N");
        }
         

    }
}