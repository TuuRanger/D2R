﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;
using MLS.Imp.Implement;
using MLS.Models;
using MLS.Helper;
using System.IO;

namespace MLS.Services.Controllers
{
    public class ContractServicesController : ApiController
    {

        ContractSvc _svc = new ContractSvc();
        // GET: Application
        [HttpGet]
        public List<ContractListResult> GetContractList(string CONAPPLY_PROJEC,
            string VENDOR,
            string CPNBRNCOD,
            string CRDSTPFROM,
            string CRDSTPTO,
            string PSNREGIDN,
            string CUSNAMTHA,
            string CUSSURTHA)
        {
            
            return _svc.GetContractList(CONAPPLY_PROJEC, VENDOR, CPNBRNCOD, CRDSTPFROM, CRDSTPTO, PSNREGIDN, CUSNAMTHA, CUSSURTHA);
        }

        [HttpGet]
        public ContractDetailResult GetContractDetail(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string GENAPPNUM)
        {
            
            return _svc.GetContractDetail(CPNCOD, CPNBRNCOD, ACCBUSTYP, GENAPPNUM);
        }


        [HttpGet]
        public List<TelListResult> GetTelList(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string GENAPPNUM)
        {
            
            return _svc.GetTelList(CPNCOD, CPNBRNCOD, ACCBUSTYP, GENAPPNUM);
        }

        [HttpGet]
        public List<RefListResult> GetRefList(String GENAPPNUM)
        { 
            return _svc.GetRefList(GENAPPNUM);
        }

        [HttpGet]
        public FeeListResult GetFeeList(string CPNCOD,
            string CPNBRNCOD,
            string ACCBUSTYP,
            string CONNUM,
            Nullable<decimal> CREDIT_APPROVE,
            Nullable<decimal> CONDWNAMT,
            string CONAPPLY_PROJEC)
        {
            return _svc.GetFeeList(CPNCOD, CPNBRNCOD, ACCBUSTYP, CONNUM, CREDIT_APPROVE, CONDWNAMT, CONAPPLY_PROJEC);
        }

        [HttpPost]
        public InsertOrUpdateContractResult InsertOrUpdateContract([FromUri]ContractDetailResult contractDetail)
        { 
            FileHelper.writeTextFile(Path.Combine(Constants.LOG_PATH, "contractDetail.JSON"), JSONHelper.ConvertToJsonString(contractDetail)); 
            return _svc.InsertOrUpdateContract(contractDetail);
        }
    }
}