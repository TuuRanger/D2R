﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp.Implement;
using MLS.Models;

namespace MLS.Services.Controllers
{
    public class ComboBoxServicesController : ApiController
    {
        ComboBoxSvc _service = new ComboBoxSvc();
        public List<DropDownDealerResult> GetDropDownDealer(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string PROJECTCODE)
        {
            return _service.GetDropDownDealer(CPNCOD, CPNBRNCOD, ACCBUSTYP, PROJECTCODE);
        }

        public List<DropDownProductBrandResult> GetDropDownProductBrand(string PRDGRPCOD, string PRDSUBCOD, string CONAPPLY_PROJEC, string BrandInput)
        {
            return _service.GetDropDownProductBrand( PRDGRPCOD,  PRDSUBCOD,  CONAPPLY_PROJEC,  BrandInput);
        }

        public List<DropDownProductModelResult> GetDropDownProductModel(string PRDGRPCOD, string PRDSUBCOD, string Brnad, string CONAPPLY_PROJEC, string ModelInput)
        {
            return _service.GetDropDownProductModel( PRDGRPCOD,  PRDSUBCOD,  Brnad,  CONAPPLY_PROJEC,  ModelInput);
        }
         

    }
}
