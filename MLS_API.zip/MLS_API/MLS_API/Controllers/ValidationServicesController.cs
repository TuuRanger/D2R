﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp.Implement;
using MLS.Models.MockModel;

namespace MLS.Services.Controllers
{
    public class ValidationServicesController : ApiController
    {
        ValidationSvc _svc = new ValidationSvc();

        [HttpGet]
        public List<FieldValidation> GetFieldValidation(String validationID)
        {
            List<FieldValidation> result = new List<FieldValidation>();

            if (validationID == "VLD001")
            {
                setVLD001(result);
            }
            else if (validationID == "VLD002")
            {
                setVLD001(result);
                setVLD002(result);
            }
            
            return result;
        }

        private void setVLD002(List<FieldValidation> result)
        {
            result.Add(new FieldValidation()
            {
                FieldID = "txtPSNREGIDN",
                Condition = new Dictionary<string, string>() { { "required", "true" } },
                Message = new Dictionary<string, string>() { { "required", "VLD001"  } }
            });

            result.Add(new FieldValidation()
            {
                FieldID = "txtPSNREGIDN2",
                Condition = new Dictionary<string, string>() { { "required", "true" } },
                Message = new Dictionary<string, string>() { { "required", "VLD001" } }
            });

            result.Add(new FieldValidation()
            {
                FieldID = "cboCusTtlTha",
                Condition = new Dictionary<string, string>() { { "required", "true" } },
                Message = new Dictionary<string, string>() { { "required", "VLD001" } }
            });

            result.Add(new FieldValidation()
            {
                FieldID = "txtCUSNAMTHA",
                Condition = new Dictionary<string, string>() { { "required", "true" } },
                Message = new Dictionary<string, string>() { { "required", "VLD001" } }
            });

            result.Add(new FieldValidation()
            {
                FieldID = "txtCUSSURTHA",
                Condition = new Dictionary<string, string>() { { "required", "true" } },
                Message = new Dictionary<string, string>() { { "required", "VLD001" } }
            });

            result.Add(new FieldValidation()
            {
                FieldID = "txtPSNBTHDTE",
                Condition = new Dictionary<string, string>() { { "required", "true" } },
                Message = new Dictionary<string, string>() { { "required", "VLD001" } }
            });

            result.Add(new FieldValidation()
            {
                FieldID = "cboPsnBthDay",
                Condition = new Dictionary<string, string>() { { "required", "true" } },
                Message = new Dictionary<string, string>() { { "required", "VLD001" } }
            });

            result.Add(new FieldValidation()
            {
                FieldID = "cboAccCodDlr",
                Condition = new Dictionary<string, string>() { { "required", "true" } },
                Message = new Dictionary<string, string>() { { "required", "VLD001" } }
            });

            result.Add(new FieldValidation()
            {
                FieldID = "cboConApplyType",
                Condition = new Dictionary<string, string>() { { "required", "true" } },
                Message = new Dictionary<string, string>() { { "required", "VLD001" } }
            });

            result.Add(new FieldValidation()
            {
                FieldID = "cboConApplyVia",
                Condition = new Dictionary<string, string>() { { "required", "true" } },
                Message = new Dictionary<string, string>() { { "required", "VLD001" } }
            });

            result.Add(new FieldValidation()
            {
                FieldID = "cboConApplyViaBranch",
                Condition = new Dictionary<string, string>() { { "required", "true" } },
                Message = new Dictionary<string, string>() { { "required", "VLD001" } }
            });

            result.Add(new FieldValidation()
            {
                FieldID = "cboConObjCod",
                Condition = new Dictionary<string, string>() { { "required", "true" } },
                Message = new Dictionary<string, string>() { { "required", "VLD001" } }
            });

            result.Add(new FieldValidation()
            {
                FieldID = "txtPSNMTHINC",
                Condition = new Dictionary<string, string>() { { "required", "true" } },
                Message = new Dictionary<string, string>() { { "required", "VLD001" } }
            });

            result.Add(new FieldValidation()
            {
                FieldID = "txtPSNNETINC",
                Condition = new Dictionary<string, string>() { { "required", "true" } },
                Message = new Dictionary<string, string>() { { "required", "VLD001" } }
            });

             
        }

        private void setVLD001(List<FieldValidation>  result)
        {
            FieldValidation cboConApplyProjec = new FieldValidation()
            {
                FieldID = "cboConApplyProjec",
                Condition = new Dictionary<string, string>() { { "required", "true" } },
                Message = new Dictionary<string, string>() { { "required", "VLD001" } }
            };

            FieldValidation cboAccBusTyp = new FieldValidation()
            {
                FieldID = "cboAccBusTyp",
                Condition = new Dictionary<string, string>() { { "required", "true" } },
                Message = new Dictionary<string, string>() { { "required", "VLD001" } }
            };

            FieldValidation cboConTaxTyp = new FieldValidation()
            {
                FieldID = "cboConTaxTyp",
                Condition = new Dictionary<string, string>() { { "required", "true" } },
                Message = new Dictionary<string, string>() { { "required", "VLD001" } }
            };

            FieldValidation cboConCrdTyp = new FieldValidation()
            {
                FieldID = "cboConCrdTyp",
                Condition = new Dictionary<string, string>() { { "required", "true" } },
                Message = new Dictionary<string, string>() { { "required", "VLD001" } }
            };

            FieldValidation cboCusTypCod = new FieldValidation()
            {
                FieldID = "cboCusTypCod",
                Condition = new Dictionary<string, string>() { { "required", "true" } },
                Message = new Dictionary<string, string>() { { "required", "VLD001" } }
            };

            result.Add(cboConApplyProjec);
            result.Add(cboAccBusTyp);
            result.Add(cboConTaxTyp);
            result.Add(cboConCrdTyp);
            result.Add(cboCusTypCod);
        }
    }
}
