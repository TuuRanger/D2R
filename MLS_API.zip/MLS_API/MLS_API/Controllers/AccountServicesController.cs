﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp.Implement;
using MLS.Models;

namespace MLS.Services.Controllers
{
    public class AccountServicesController : ApiController
    {
        [HttpGet]
        public List<AccountResult> SearchAccount(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string ACCDEAWTH, string SEARCH_STR)
        {
            AccountSvc svcAccount = new AccountSvc();
            return svcAccount.SearchAccount(CPNCOD, CPNBRNCOD, ACCBUSTYP, ACCDEAWTH, SEARCH_STR).ToList();
        }
    }
}
