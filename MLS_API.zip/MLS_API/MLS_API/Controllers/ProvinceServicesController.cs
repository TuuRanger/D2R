﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp.Implement;
using MLS.Models;

namespace MLS.Services.Controllers
{
    public class ProvinceServicesController : ApiController
    {
        ProvinceSvc _svc = new ProvinceSvc();

        public List<ProvinceByIDResult> GetProvinceByID(int provinceID)
        {
          return  _svc.GetProvinceByID(provinceID);
        }

        public List<ProvinceByNameResult> GetProvinceByName(String provinceName)
        {
            return _svc.GetProvinceByName(provinceName);
        }


    }
}
