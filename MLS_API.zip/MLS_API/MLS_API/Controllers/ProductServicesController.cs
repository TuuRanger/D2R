﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MLS.Imp.Implement;
using MLS.Models;
namespace MLS.Services.Controllers
{
    public class ProductServicesController : ApiController
    {
        private ProductSvc _service = new ProductSvc();

        public List<ProductSpecInputFieldResult> GetProductSpecInputField(string PRDGRPCOD, string PRDSUBCOD)
        {
            return _service.GetProductSpecInputField(PRDGRPCOD, PRDSUBCOD);  
        }
    }
}
