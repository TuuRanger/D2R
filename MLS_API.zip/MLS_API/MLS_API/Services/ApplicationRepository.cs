﻿using MLS.Models;
using MLS.Models.DTO;
using MLS.JMT.Commons.SysConstants;
using MLS.JMT.Commons;
using MLS_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MLS_API.Services
{
    public class ApplicationRepository
    {
        private const string CacheKey = "ApplicationStore";

        public ApplicationRepository()
        {
            var ctx = HttpContext.Current;

            if (ctx != null)
            {
                if (ctx.Cache[CacheKey] == null)
                {
                    var applications = new Application[]
                     {
                        new Application
                        {
                            Id = 1, Name = "Glenn Block"
                        },
                        new Application
                        {
                            Id = 2, Name = "Dan Roth"
                        }
                         };

                    ctx.Cache[CacheKey] = applications;
                }
            }
        }

        public List<ContractListResult> GetContractList(string CONAPPLY_PROJEC, string VENDOR, string CPNBRNCOD, string CRDSTPFROM, string CRDSTPTO, string PSNREGIDN, string CUSNAMTHA, string CUSSURTHA)
        {
            using (JMTModels db = new JMTModels())
            {

                return db.GetContractlist(CONAPPLY_PROJEC, VENDOR, CPNBRNCOD, CRDSTPFROM, CRDSTPTO, PSNREGIDN, CUSNAMTHA, CUSSURTHA).ToList();
            }
        }

        public Application[] GetAllApplications()
        {
            var ctx = HttpContext.Current;

            if (ctx != null)
            {
                return (Application[])ctx.Cache[CacheKey];
            }

            return new Application[]
            {
                new Application
                {
                    Id = 0,
                    Name = "Placeholder"
                }
            };
        }

    //    Public Function GetTelNoList2(CPNCOD As String, CPNBRNCOD As String, ACCBUSTYP As String, GENAPPNUM As String) As List(Of TelNoList2Result)
    //    Using db As New JMTModels

    //        Return db.GetTelNoList2(CPNCOD, CPNBRNCOD, ACCBUSTYP, GENAPPNUM).ToList()
    //    End Using
    //End Function

        public List<TelNoList2Result> GetTelNoList2(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string GENAPPNUM)
        {
            using (JMTModels db = new JMTModels())
            {
                return db.GetTelNoList2(CPNCOD, CPNBRNCOD, ACCBUSTYP, GENAPPNUM).ToList();
            }
        }

        public ContractDetailResult GetContractDetail(string CPNCOD, string CPNBRNCOD, string ACCBUSTYP, string GENAPPNUM)
        {
            using (JMTModels db = new JMTModels())
            {
                ContractDetailResult dto = db.GetContractDetail(CPNCOD, CPNBRNCOD, ACCBUSTYP, GENAPPNUM).FirstOrDefault();

                List<TelNoList2Result> telList2 = GetTelNoList2(dto.CPNCOD, dto.CPNBRNCOD, dto.ACCBUSTYP, dto.GENAPPNUM);
                if ((telList2 != null))
                {
                    telList2 = telList2.Where(x => x.TELSEQNUM != null & x.TELSEQNUM.GetValueOrDefault(0) != dto.CUSPHNNUM_TELSEQNUM.GetValueOrDefault(0) & x.TELPHNTYP == "M").OrderBy(x => x.TELSEQNUM).ToList();
                    if ((telList2.Count > 0))
                    {
                        if ((telList2.ElementAtOrDefault(0) != null))
                        {
                            dto.TELNO2 = telList2.ElementAt(0).TELPRFCOD.ToTelNoFormat();
                            dto.CUSPHNNUM_TELSEQ2 = telList2.ElementAt(0).TELSEQNUM.ToString();
                        }

                        if ((telList2.ElementAtOrDefault(1) != null))
                        {
                            dto.TELNO3 = telList2.ElementAt(1).TELPRFCOD.ToTelNoFormat();
                            dto.CUSPHNNUM_TELSEQ3 = telList2.ElementAt(1).TELSEQNUM.ToString();
                        }

                    }
                }


                dto.PSNREGIDN2 = dto.PSNREGIDN;
                dto.ADR1_ADRMOBILE_OFSTEP_3 = dto.ADR1_ADRMOBILE.ToTelNoFormat();
                dto.ADR1_ADRMOBILE_OFSTEP_2 = dto.ADR1_ADRMOBILE.ToTelNoFormat();

                dto.CONAPPLY_TYP_OFSTEP_1 = dto.CONAPPLY_TYP;
                dto.CONAPPLY_PROMOT_OFSTEP_1 = dto.CONAPPLY_PROMOT;
                dto.CONAPPLY_TYP_OFSTEP_3 = dto.CONAPPLY_TYP;
                dto.CONAPPLY_VIA_OFSTEP_3 = dto.CONAPPLY_VIA;
                dto.CONAPPLY_PROMOT_OFSTEP_3 = dto.CONAPPLY_PROMOT;
                dto.CONAPPLY_VIA_OFSTEP_1 = dto.CONAPPLY_VIA;
                dto.ADR1_ADRZIPCOD_OFSTEP_2 = dto.ADR1_ADRZIPCOD;
                dto.ADR2_ADRZIPCOD_OFSTEP_2 = dto.ADR2_ADRZIPCOD;
                dto.ADR1_ADRZIPCOD_OFSTEP_3 = dto.ADR1_ADRZIPCOD;
                dto.ADR2_ADRZIPCOD_OFSTEP_3 = dto.ADR2_ADRZIPCOD;
                dto.DISMTHINC = dto.PSNMTHINC.GetValueOrDefault(0).ToMoneyFormat();
                dto.DISNETINC_OFSTEP_1 = dto.PSNNETINC.ToMoneyFormat();
                dto.DISNETINC_OFSTEP_3 = dto.PSNNETINC.ToMoneyFormat();
                dto.DISCONLNDAMT_OF_PRODUCT = dto.CONLNDAMT.GetValueOrDefault(0).ToString();
                dto.CONEFFRTE_OF_PRODUCT = dto.CONEFFRTE.GetValueOrDefault(0).ToString();
                dto.ADR2_ADRTELNUM = dto.ADR2_ADRTELNUM.ToTelNoFormat();
                dto.ADR1_ADRTELNUM = dto.ADR1_ADRTELNUM.ToTelNoFormat();
                dto.ADR3_ADRTELNUM = dto.ADR3_ADRTELNUM.ToTelNoFormat();
                dto.ADR4_ADRTELNUM = dto.ADR4_ADRTELNUM.ToTelNoFormat();
                if ((dto.CRDLIMAMT != null))
                {
                    dto.DISCRDLIMAMT = dto.CRDLIMAMT.ToString();

                }

                if ((dto.CRDREQTRM != null))
                {
                    dto.CRDREQTRM_OFSTEP_3 = dto.CRDREQTRM.ToString();
                    dto.CRDREQTRM_OFSTEP_4 = dto.CRDREQTRM.ToString();
                    dto.CRDREQTRM_OFSTEP_5 = dto.CRDREQTRM.ToString();
                }

                if ((dto.CRDREQAMT != null))
                {
                    dto.DISCRDREQAMT_OFSTEP_3 = dto.CRDREQAMT.GetValueOrDefault(0).ToMoneyFormat();
                    dto.DISCRDREQAMT_OFSTEP_4 = dto.CRDREQAMT.GetValueOrDefault(0).ToMoneyFormat();
                    dto.DISCRDREQAMT_OFSTEP_5 = dto.CRDREQAMT.GetValueOrDefault(0).ToMoneyFormat();
                }

                if ((dto.CONLNDTRM != null))
                {
                    dto.CONLNDTRM_OFSTEP_1 = dto.CONLNDTRM.ToString();
                    dto.CONLNDTRM_OFSTEP_4 = dto.CONLNDTRM.ToString();
                    dto.CONLNDTRM_OFSTEP_5 = dto.CONLNDTRM.ToString();

                }

                if ((dto.CONFINAMT != null))
                {
                    dto.CONFINAMT_OFSTEP_1 = dto.CONFINAMT.GetValueOrDefault(0).ToMoneyFormat();
                    dto.CONFINAMT_OFSTEP_4 = dto.CONFINAMT.GetValueOrDefault(0).ToMoneyFormat();
                    dto.CONFINAMT_OFSTEP_5 = dto.CONFINAMT.GetValueOrDefault(0).ToMoneyFormat();
                }

                if ((dto.CONINSAMT != null))
                {
                    dto.DISCONINSAMT_OFSTEP_1 = dto.CONINSAMT.GetValueOrDefault(0).ToMoneyFormat();
                    dto.DISCONINSAMT_OFSTEP_4 = dto.CONINSAMT.GetValueOrDefault(0).ToMoneyFormat();

                }

                if ((dto.CONDWNAMT != null))
                {
                    dto.DISCONDWNAMT = dto.CONDWNAMT.ToMoneyFormat();
                }

                dto.DISPRDSALPRC = dto.PRDSALPRC.GetValueOrDefault(0).ToMoneyFormat();

                return dto;
            }
        }


        public InsertOrUpdateContractResult SaveApplication(ContractDetailResult dto)
        {
            // data validation
            // store procedure selection

            // inherit library and store procedure

            

            using (JMTModels db = new JMTModels())
            {                
                //            Using trans = New TransactionScope(TransactionScopeOption.Required, New TransactionOptions() With { _
                //	.IsolationLevel = IsolationLevel.Snapshot _
                //})
                InsertOrUpdateContractResult result = null;
                var _with1 = dto;

                dto.CONFRATE = 0;

                string USRCOD = "admin";


                if ((_with1.CONOBJCOD == MLS.JMT.Commons.SysConstants.AppProcessConstants.CONOBJCOD.COLLABORATE | _with1.CONOBJCOD == MLS.JMT.Commons.SysConstants.AppProcessConstants.CONOBJCOD.CAR4CASH))
                {
                    _with1.CONLNDAMT = Convert.ToDecimal(_with1.DISCONLNDAMT);
                }

                _with1.CONEFFRTE = Convert.ToDouble(_with1.DISCONEFFRTE);

                MLMCampaignResult camPaignResult = db.GetMLMCampaignByProjectCode(_with1.CONAPPLY_PROJEC).FirstOrDefault();


                if (camPaignResult != null)
                {
                    _with1.CONINTRTE = Convert.ToDouble(_with1.DISCONINTRTE);
                    if ((camPaignResult.INCOMERTE + camPaignResult.CRDUSGRTE > 0))
                    {
                        _with1.INCOMERTE = (camPaignResult.INCOMERTE * Convert.ToDecimal(_with1.CONINTRTE)) / (camPaignResult.INCOMERTE + camPaignResult.CRDUSGRTE);
                        _with1.CRUSGRTE = (camPaignResult.CRDUSGRTE * Convert.ToDecimal(_with1.CONINTRTE)) / (camPaignResult.INCOMERTE + camPaignResult.CRDUSGRTE);
                    }
                    else
                    {
                        _with1.INCOMERTE = 0;
                        _with1.CRUSGRTE = 0;
                    }

                    _with1.CONINTCAL = camPaignResult.CONINTCAL;
                    _with1.CONDUEDAY = Convert.ToInt16(camPaignResult.CONDUEDAY);
                    //.CONINTRTE = camPaignResult.TOTALRTE

                    //- INCOMERATE = MLMCAMPGN.INCOMERATE * CONINTRTE / (MLMCAMPGN.INCOMERATE + MLMCAMPGN.CRUSAGERTE)
                    //- CRUSGRTE = MLMCAMPGN.CRUSGRTE * CONINTRTE / (MLMCAMPGN.INCOMERATE + MLMCAMPGN.CRUSGRTE)
                }



                //already exists customer and entry new application

                _with1.ADR1_ADRZIPCOD = _with1.ADR1_ADRZIPCOD_OFSTEP_2;
                _with1.ADR2_ADRZIPCOD = _with1.ADR2_ADRZIPCOD_OFSTEP_2;
                //-------------------------------------------------

                if ((Convert.ToInt32(_with1.EditStepNo) >= 1 || Convert.ToInt32(_with1.ActualStep) >= 1))
                {
                    _with1.PSNNETINC = Convert.ToDecimal(_with1.DISNETINC_OFSTEP_1);
                    _with1.CONAPPLY_TYP = _with1.CONAPPLY_TYP_OFSTEP_1;
                    _with1.CONAPPLY_VIA = _with1.CONAPPLY_VIA_OFSTEP_1;
                    _with1.CONAPPLY_PROMOT = _with1.CONAPPLY_PROMOT_OFSTEP_1;
                    _with1.PSNMTHINC = Convert.ToDecimal(_with1.DISMTHINC);
                    _with1.CONINSAMT = Convert.ToDecimal(_with1.DISCONINSAMT_OFSTEP_1);
                    _with1.PRDSALPRC = Convert.ToDecimal(_with1.DISPRDSALPRC);
                    _with1.CONLNDTRM = Convert.ToInt32(_with1.CONLNDTRM_OFSTEP_1);

                    _with1.CONPRDAMT = _with1.PRDSALPRC;
                    _with1.CONPRDGRS = _with1.PRDSALPRC;
                    _with1.ADR1_ADRMOBILE = _with1.ADR1_ADRMOBILE_OFSTEP_2;

                    if ((_with1.CONOBJCOD == MLS.JMT.Commons.SysConstants.AppProcessConstants.CONOBJCOD.COLLABORATE))
                    {
                        _with1.CONFINAMT = Convert.ToDecimal(_with1.PRDSALPRC) - Convert.ToDecimal(_with1.DISCONDWNAMT);
                        _with1.CONAPPLY_PROMOT_OFSTEP_3 = _with1.CONAPPLY_PROMOT_OFSTEP_1;
                        _with1.CONAPPLY_TYP_OFSTEP_3 = _with1.CONAPPLY_TYP_OFSTEP_1;
                        _with1.CONAPPLY_VIA_OFSTEP_3 = _with1.CONAPPLY_VIA_OFSTEP_1;

                        _with1.ADR1_ADRMOBILE_OFSTEP_3 = _with1.ADR1_ADRMOBILE_OFSTEP_2;
                        _with1.DISNETINC_OFSTEP_3 = _with1.DISNETINC_OFSTEP_1;
                        _with1.CONLNDTRM_OFSTEP_4 = _with1.CONLNDTRM_OFSTEP_1;
                        _with1.DISCONINSAMT_OFSTEP_4 = _with1.DISCONINSAMT_OFSTEP_1;
                    }
                    else if ((_with1.CONOBJCOD == MLS.JMT.Commons.SysConstants.AppProcessConstants.CONOBJCOD.CAR4CASH))
                    {
                        _with1.CONFINAMT = Convert.ToDecimal(_with1.PRDSALPRC) - Convert.ToDecimal(_with1.DISCONDWNAMT);
                    }

                    //If (.ACCBUSTYP = SysConstants.AppProcessConstants.ACCBUSTYP._2060 Or
                    //    .ACCBUSTYP = SysConstants.AppProcessConstants.ACCBUSTYP.CAR4CASH) Then
                    //    .CONINTRTE = .DISCONINTRTE.ToDecimalOrZero()
                    //End If

                }

                if ((Convert.ToInt32(_with1.EditStepNo) >= 2 || Convert.ToInt32(_with1.ActualStep) >= 2))
                {
                    _with1.ADR1_ADRZIPCOD = _with1.ADR1_ADRZIPCOD_OFSTEP_2;
                    _with1.ADR2_ADRZIPCOD = _with1.ADR2_ADRZIPCOD_OFSTEP_2;
                }

                if ((Convert.ToInt32(_with1.EditStepNo) >= 3 || Convert.ToInt32(_with1.ActualStep) >= 3))
                {
                    _with1.PSNNETINC = Convert.ToDecimal(_with1.DISNETINC_OFSTEP_3);
                    _with1.CRDREQAMT = Convert.ToDecimal(_with1.DISCRDREQAMT_OFSTEP_3);
                    _with1.CRDREQTRM = Convert.ToInt32(_with1.CRDREQTRM_OFSTEP_3);
                    _with1.ADR1_ADRMOBILE = _with1.ADR1_ADRMOBILE_OFSTEP_3;


                    _with1.ADR1_ADRZIPCOD = _with1.ADR1_ADRZIPCOD_OFSTEP_3;
                    _with1.ADR2_ADRZIPCOD = _with1.ADR2_ADRZIPCOD_OFSTEP_3;

                    _with1.CONAPPLY_TYP = _with1.CONAPPLY_TYP_OFSTEP_3;
                    _with1.CONAPPLY_VIA = _with1.CONAPPLY_VIA_OFSTEP_3;
                    _with1.CONAPPLY_PROMOT = _with1.CONAPPLY_PROMOT_OFSTEP_3;
                }

                if ((Convert.ToInt32(_with1.EditStepNo) >= 4 || Convert.ToInt32(_with1.ActualStep) >= 4))
                {
                    _with1.CRDREQAMT = Convert.ToDecimal(_with1.DISCRDREQAMT_OFSTEP_4);
                    //.CRDREQTRM = .CRDREQTRM_OFSTEP_4.ToIntOrNull
                    if ((_with1.CONOBJCOD != MLS.JMT.Commons.SysConstants.AppProcessConstants.CONOBJCOD.COLLABORATE))
                    {
                        _with1.CONFINAMT = Convert.ToDecimal(_with1.CONFINAMT_OFSTEP_4);
                    }

                    _with1.CONLNDTRM = Convert.ToInt32(_with1.CONLNDTRM_OFSTEP_4);
                    _with1.CONINSAMT = Convert.ToDecimal(_with1.DISCONINSAMT_OFSTEP_4);
                }

                if ((Convert.ToInt32(_with1.EditStepNo) == 1))
                {
                    _with1.CONINTTYP = null;
                    _with1.CONINSPER = null;
                    _with1.CONINTPER = null;
                    _with1.CONSTSCOD = null;
                }

                _with1.ADR1_ADRREFCOD = null;
                _with1.ADR2_ADRREFCOD = null;

                _with1.ADR1_ADRMOBILE = _with1.ADR1_ADRMOBILE.UnformatTelNo();
                _with1.ADR1_ADRTELNUM = _with1.ADR1_ADRTELNUM.UnformatTelNo();
                _with1.ADR2_ADRTELNUM = _with1.ADR2_ADRTELNUM.UnformatTelNo();
                _with1.ADR3_ADRTELNUM = _with1.ADR3_ADRTELNUM.UnformatTelNo();

                if ((_with1.GENAPPDTE == null))
                {
                    _with1.GENAPPDTE = DateTime.Now;
                }

                _with1.OLD_CREDIT_LINE = Convert.ToDecimal(_with1.DIS_OLD_CREDIT_LINE);
                _with1.LAST_OUTSTD_AMT = Convert.ToDecimal(_with1.DIS_LAST_OUTSTD_AMT);
                _with1.CONDWNAMT = Convert.ToDecimal(_with1.DISCONDWNAMT);

                if ((Convert.ToInt32(_with1.CRDNXTSTP) == 9))
                {
                    if (_with1.GENAPRDTE == null)
                    {
                        _with1.GENAPRDTE = DateTime.Now;
                    }
                }

                if (Convert.ToDecimal(_with1.CONDWNAMT) > 0)
                {
                    _with1.CONDWNCND = "8";
                }

                if (_with1.R_FLAG.IsEmpty())
                {
                    _with1.R_FLAG = MLS.JMT.Commons.SysConstants.AppProcessConstants.R_FLAG.JMTPLUS;
                }
                if (_with1.R_FLAG == MLS.JMT.Commons.SysConstants.AppProcessConstants.R_FLAG.JMTNETWORK)
                {
                    _with1.CONDUEDAY = 2;
                }
                else if (_with1.R_FLAG == MLS.JMT.Commons.SysConstants.AppProcessConstants.R_FLAG.JMTPLUS)
                {
                    _with1.CONDUEDAY = 1;
                }

                if ((_with1.ACCBUSTYP == MLS.JMT.Commons.SysConstants.AppProcessConstants.ACCBUSTYP._2050))
                {
                    dynamic objTCLMultiplier = db.GetSetupList("MLSVALUE", "TCL", "N");
                    if ((objTCLMultiplier != null))
                    {
                        _with1.ACCCRDLIN = _with1.PSNMTHINC * objTCLMultiplier.FirstOrDefault().TABSETRTE1.GetValueOrDefault(0);
                    }
                }
                else if ((_with1.ACCBUSTYP == MLS.JMT.Commons.SysConstants.AppProcessConstants.ACCBUSTYP._2060))
                {
                    dynamic objTCLMultiplier = db.GetSetupList("MLSVALUE", "SW_CONTRACT_LIMIT", "N");
                    if ((objTCLMultiplier != null))
                    {
                        _with1.ACCCRDLIN = objTCLMultiplier.FirstOrDefault().TABSETAMT1.GetValueOrDefault(0);
                    }
                }
                else if ((_with1.ACCBUSTYP == MLS.JMT.Commons.SysConstants.AppProcessConstants.ACCBUSTYP.CAR4CASH))
                {
                    dynamic objTCLMultiplier = db.GetSetupList("MLSVALUE", "CAR4CASH_CONTRACT_LIMIT", "N");
                    if ((objTCLMultiplier != null))
                    {
                        _with1.ACCCRDLIN = objTCLMultiplier.FirstOrDefault().TABSETAMT1.GetValueOrDefault(0);
                    }
                }

                result = db.InsertOrUpdateContract(_with1.CPNCOD, _with1.CPNBRNCOD, _with1.CPNBRNCOD, _with1.ACCBUSTYP, _with1.GENAPPNUM, _with1.CONNUM, _with1.GENAPPDTE, _with1.GENEFFDTE, _with1.GENAPRDTE, _with1.ACCCOD,
                _with1.CONOBJCOD, _with1.ACCCODRCV1, _with1.CUSCOD, _with1.CUSTTLTHA, _with1.CUSNAMTHA, _with1.CUSSURTHA, _with1.CUSNICNAM, _with1.ADR1_ADRMOBILE.UnformatTelNo(), _with1.PSNREGIDN, _with1.PSNBTHDTE,
                _with1.PSNMTHINC, _with1.PSNOTHINC, _with1.PSNMARSTS, _with1.PSNCHDNUM, _with1.PSNSEXCOD, _with1.PSNOCCCOD, _with1.PSNPOSITN, _with1.CONAPPLY_TYP, _with1.CONAPPLY_VIA, _with1.CONAPPLY_PROJEC,
                _with1.CONAPPLY_PROMOT, _with1.PSNNETINC, _with1.PSNGRSINC, _with1.PSNCPNSTF, _with1.PSNWRKPLCCCP, _with1.PSNWRKPLC, _with1.PSNWRKPRD, _with1.PSNWRKPRD_MON, _with1.PSNCPNTYP, _with1.PSNBTHDAY,
                _with1.PSNEMPLOY_TYP, _with1.PSNSALRCVTYP, _with1.CRDREQAMT, _with1.CRDREQTRM, _with1.CRDLIMAMT, _with1.CRDLIMTRM, _with1.CRDLIMRSL, _with1.FINBNKCODCR, _with1.FINBRNCODCR, _with1.FINBNKNUMCR,
                _with1.CRDCURSTP, _with1.CRDNXTSTP, _with1.CRDRSLSTP, _with1.CRDDEVIAT, _with1.ADRMEMBER, _with1.ADRLIVSIN, _with1.ADRLIVSIN_CNV, _with1.ADRLIVSIN_CNV_MON, _with1.TELPHNTYP, _with1.ADR1_ADRCOD,
                _with1.ADR1_ADRREFCOD, _with1.ADR1_OWNERCOD, _with1.ADR1_ADRDTLLN1, _with1.ADR1_ADRDISTRICT, _with1.ADR1_ADRAMPHUR, _with1.ADR1_ADRPROVINCE, _with1.ADR1_ADRZIPCOD, _with1.ADR1_ADRTELNUM.UnformatTelNo(), _with1.ADR1_TELFRMNUM, _with1.ADR1_TELENDNUM,
                _with1.ADR1_TELEXTNUM, _with1.ADR1_ADRMOBILE.UnformatTelNo(), _with1.ADR1_ADREMAIL, _with1.ADR2_ADRCOD, _with1.ADR2_ADRREFCOD, _with1.ADR2_ADRDTLLN1, _with1.ADR2_ADRDISTRICT, _with1.ADR2_ADRAMPHUR, _with1.ADR2_ADRPROVINCE, _with1.ADR2_ADRZIPCOD,
                _with1.ADR2_ADRTELNUM.UnformatTelNo(), _with1.ADR2_TELFRMNUM, _with1.ADR2_TELENDNUM, _with1.ADR2_TELEXTNUM, _with1.ADR3_ADRCOD, _with1.ADR3_ADRREFCOD, _with1.ADR3_ADRDTLLN1, _with1.ADR3_ADRDISTRICT, _with1.ADR3_ADRAMPHUR, _with1.ADR3_ADRPROVINCE,
                _with1.ADR3_ADRZIPCOD, _with1.ADR3_ADRTELNUM.UnformatTelNo(), _with1.ADR3_TELFRMNUM, _with1.ADR3_TELENDNUM, _with1.ADR3_TELEXTNUM, _with1.ADR4_ADRCOD, _with1.ADR4_ADRDTLLN1, _with1.ADR4_ADRDISTRICT, _with1.ADR4_ADRAMPHUR, _with1.ADR4_ADRPROVINCE,
                _with1.ADR4_ADRZIPCOD, _with1.ADR4_ADRTELNUM.UnformatTelNo(), _with1.ADR4_TELFRMNUM, _with1.ADR4_TELENDNUM, _with1.ADR4_TELEXTNUM, _with1.ADR4_ADRFAXNUM, _with1.GENREMARK, _with1.CONINTTYP, _with1.CONINTCAL, Convert.ToDecimal(_with1.CONINTRTE),
                Convert.ToDecimal(_with1.CONEFFRTE), _with1.CONINSPER, _with1.CONLNDTRM, _with1.CONINTPER, _with1.CONIRATE, Convert.ToDecimal(_with1.CONFRATE), _with1.IRATEBNKREF, _with1.PRDCSTGRS, _with1.PRDCSTAMT, _with1.PRDCSTTAX,
                _with1.CONPRDGRS, _with1.CONPRDAMT, _with1.CONPRDTAX, _with1.CONDWNGRS, _with1.CONDWNAMT, _with1.CONDWNTAX, _with1.CONFINGRS, _with1.CONFINAMT, _with1.CONFINTAX, _with1.CONBLNGRS,
                _with1.CONBLNAMT, _with1.CONBLNTAX, _with1.PCOPTGRS, _with1.PCOPTAMT, _with1.PCOPTTAX, _with1.CONDEPGRS, _with1.CONDEPAMT, _with1.CONDEPTAX, _with1.CONINSGRS, _with1.CONINSAMT,
                _with1.CONINSTAX, _with1.CONLNDGRS, _with1.CONLNDAMT, _with1.CONLNDTAX, _with1.SUBSDYGRS, _with1.SUBSDYAMT, _with1.SUBSDYTAX, _with1.CONDEFINC, _with1.CONSTSCOD, _with1.CONDWNCND,
                _with1.CONPAYTYP, _with1.CONTAXTYP, _with1.CONPRCTYP, _with1.CONDUEDAY, _with1.CRDQUESTION1, _with1.CRDQUESTION2, _with1.CRDQUESTION3, _with1.CRDANSWER1, _with1.CRDANSWER2, _with1.CRDANSWER3,
                USRCOD, _with1.ACCCODMKT, _with1.ACCCODDLR, _with1.ACCCODSDY, _with1.ACCCODBUY, _with1.PREPAIDTRM, _with1.BLNPAYMTD, _with1.DEBROLDAY, _with1.CONSTRINS, _with1.CONSECINS,
                _with1.CONENDINS, _with1.CONBLNDUE, _with1.TRNFERCOD, _with1.PNTSTDFML, _with1.PNTRTE, _with1.PNTDAY, _with1.PNTTME, _with1.PNTINCVAT, _with1.PNTAMTMIN, _with1.PNTPRNMIN,
                _with1.FLWSTDFML, _with1.FLWRTE, _with1.FLWDAY, _with1.FLWTME, _with1.FLWINCVAT, _with1.FLWAMTMIN, _with1.FLWPRNMIN, _with1.CONCOMPCN, _with1.CONCOMPAMT, _with1.CONCOMAMT,
                _with1.CONCOMEXT, _with1.ACCCODRCV2, _with1.ACCCODRCV3, _with1.COMAMTRCV00, _with1.COMAMTRCV01, _with1.COMAMTRCV02, _with1.COMAMTRCV03, _with1.COMWHTRCV00, _with1.COMVATRCV00, _with1.COMWHTRCV01,
                _with1.COMVATRCV01, _with1.COMWHTRCV02, _with1.COMVATRCV02, _with1.COMWHTRCV03, _with1.COMVATRCV03, _with1.RADIOAMT, _with1.COOPERATAMT, _with1.RADIONUM, _with1.TAXINUM, _with1.ACCCODCFF,
                _with1.CFFSTSCOD, _with1.CFFTAXTYP, _with1.CFFPRDGRS, _with1.CFFPRDAMT, _with1.CFFPRDTAX, _with1.CFFDWNGRS, _with1.CFFDWNAMT, _with1.CFFDWNTAX, _with1.CFFBLNGRS, _with1.CFFBLNAMT,
                _with1.CFFBLNTAX, _with1.CFFFINGRS, _with1.CFFFINAMT, _with1.CFFFINTAX, _with1.CFFINSGRS, _with1.CFFINSAMT, _with1.CFFINSTAX, _with1.CFFLNDGRS, _with1.CFFLNDAMT, _with1.CFFLNDTAX,
                _with1.CFFDEFINC, _with1.CFFLNDTRM, _with1.CFFBEGTRM, _with1.CFFINSPER, _with1.CFFINTTYP, _with1.CFFINTRTE, _with1.CFFEFFRTE, _with1.CFFYIELD, _with1.CFFINTPER, _with1.CFFINTCAL,
                _with1.CFFSTRINS, _with1.CFFSECINS, _with1.CFFENDINS, _with1.CFFLEGTYP, _with1.CFFPURPOS, _with1.CFFDWNCND, _with1.CFFPAYTYP, _with1.CFFDUEDAY, _with1.CFFBLNDUE, _with1.CFFCLSDTE,
                _with1.CFFIRATE, _with1.CFFFRATE, _with1.CFFLNDTYP, _with1.CFFDWNDEF, _with1.CFFCONNUM, _with1.ACCCODVER, _with1.PRDGRPCOD, _with1.PRDSUBCOD, _with1.PRDTYPE, _with1.PRDBRNCOD,
                _with1.PRDLISPRC, _with1.PRDCSTPRC, _with1.PRDSALPRC, _with1.PRDNEWUSE, _with1.PRDDETAIL, _with1.PRDREMARK, _with1.PRDMDLCOD, _with1.PRDSRLNUM, _with1.PRDINCACSOR, _with1.PRDITMNUM,
                _with1.APPRISALAMT, _with1.LOCATN, _with1.PRDCOD, _with1.PRDSTSCOD, _with1.ACCESSORYAMT, _with1.CUSTTLENG, _with1.CUSNAMENG, _with1.CUSSURENG, _with1.CUSTYPCOD, _with1.CUSCRDCOD,
                _with1.CUSLEVCOD, _with1.CUSBOTCOD, _with1.CUSCRDLNE, _with1.CUSBUSCNT, _with1.GENTAXNUM, _with1.CUS_FINBNKCOD1, _with1.CUS_FINBNKBRN1, _with1.CUS_FINBNKNUM1, _with1.CUS_FINBNKCOD2, _with1.CUS_FINBNKBRN2,
                _with1.CUS_FINBNKNUM2, _with1.CUS_FINBNKCOD3, _with1.CUS_FINBNKBRN3, _with1.CUS_FINBNKNUM3, _with1.ADRCOD01, _with1.ADRCOD02, _with1.ADRCOD03, _with1.ADRCOD04, _with1.ADRCOD05, _with1.ADRCOD06,
                _with1.ADRCOD07, _with1.ADRCOD08, _with1.ADRCOD09, _with1.ADRCOD10, _with1.CUSCITZEN, _with1.CUSNATION, _with1.VATREGISTER, _with1.CUS_ADRTELNUM, _with1.CUSEMAIL, _with1.COOPERATE_TYPE,
                _with1.OLD_LOAN_CPN, _with1.OLD_CREDIT_LINE, _with1.LAST_OUTSTD_AMT, _with1.CHECK_HOME_TEL, _with1.CHECK_HOME_NAME_RSLT, _with1.CHECK_HOME_NAME_REMARK, _with1.CHECK_HOME_ADR_RSLT, _with1.CHECK_HOME_ADR_REMARK, _with1.CHECK_OFFC_TEL, _with1.CHECK_OFFC_NAME_RSLT,
                _with1.CHECK_OFFC_NAME_REMARK, _with1.CHECK_OFFC_ADR_RSLT, _with1.CHECK_OFFC_ADR_REMARK, _with1.CHECK_SSO_RSLT, _with1.CHECK_DBD_RSLT, _with1.VENDORBRN, _with1.CONAPPLY_VIABRN, _with1.PSNREGSIN, _with1.PSNREGEXP, _with1.PSNSALDTE,
                _with1.PSNRELTME, _with1.CONPRDPRCINC, _with1.CONPRDPRCNET, _with1.CONPRDPRCTAX, _with1.INCOMERTE, _with1.CRUSGRTE, _with1.R_FLAG, _with1.CUSPHNNUM_TELSEQNUM, _with1.CRDPNDSTS, _with1.ACCCRDLIN).FirstOrDefault();

                db.InsertOrUpdateTelList2(_with1.CPNCOD, _with1.CPNBRNCOD, _with1.ACCBUSTYP, result.CUSCOD, 9, "M", _with1.CUSPHNNUM_TELSEQ2.ToIntOrNull().GetValueOrDefault(0), _with1.TELNO2.UnformatTelNo(), null, null,
                null, null, null, null, result.CONNUM, USRCOD);

                db.InsertOrUpdateTelList2(_with1.CPNCOD, _with1.CPNBRNCOD, _with1.ACCBUSTYP, result.CUSCOD, 9, "M", _with1.CUSPHNNUM_TELSEQ3.ToIntOrNull().GetValueOrDefault(0), _with1.TELNO3.UnformatTelNo(), null, null,
                null, null, null, null, result.CONNUM, USRCOD);



                //trans.Complete()
                return result;
                //End Using
            }



        }

    }
}