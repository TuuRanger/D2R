﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AngularXample.Controllers
{
    public class FactoringController : Controller
    {
        public ActionResult SponsorDashboard(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Factoring/Sponsor/vwSponsorDashboard.cshtml");
        }

        public ActionResult InvoiceUpload(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Factoring/Sponsor/vwInvoiceUpload.cshtml");
        }

        public ActionResult InvoiceApproval(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Factoring/Sponsor/vwInvoiceApproval.cshtml");
        }

        public ActionResult PaymentUpload(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Factoring/Sponsor/vwPaymentUpload.cshtml");
        }

        public ActionResult PaymentApproval(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Factoring/Sponsor/vwPaymentApproval.cshtml");
        }

        public ActionResult SupplierDashboard(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Factoring/Supplier/vwSupplierDashboard.cshtml");
        }

        public ActionResult SupplierInvoiceList(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Factoring/Supplier/vwSupplierInvoiceList.cshtml");
        }

        public ActionResult SupplierInfo(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Factoring/Supplier/vwSupplierInfo.cshtml");
        }

        public ActionResult SupplierContractList(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Factoring/Supplier/vwSupplierContractList.cshtml");
        }


        public ActionResult SupplierInvoiceInquiry(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Factoring/Supplier/vwSupplierInvoiceInquiry.cshtml");
        }

        public ActionResult SupplierStatement(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Factoring/Supplier/vwSupplierStatement.cshtml");
            
        }

        public ActionResult SupplierRequest(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Factoring/Supplier/vwSupplierRequest.cshtml");
        }

        public ActionResult SECAPImportData(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Factoring/Secap/vwSECAPImportData.cshtml");
        }

        public ActionResult SECAPRequestProcess(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Factoring/Secap/vwSECAPRequestProcess.cshtml");
        }

        //public ActionResult SECAPContractDetail(String ngController)
        //{
        //    ViewBag.ngController = ngController;
        //    return View("~/Views/Factoring/Contract/vwAppEntry.cshtml");
        //}

        //public ActionResult partial_vwAppBasicInfoDefault(String ngController)
        //{
        //    ViewBag.ngController = ngController;
        //    return View("~/Views/Factoring/Contract/vwAppCustomerInfo_JR.cshtml"); 
        //}

        //public ActionResult partial_vwAppFinancial(String ngController)
        //{
        //    ViewBag.ngController = ngController;
        //    return View("~/Views/Factoring/Contract/vwAppFinancial.cshtml");
        //}

        //public ActionResult partial_vwDetail()
        //{
        //    return View("~/Views/Factoring/Contract/vwAppDetail.cshtml");
        //}

        public ActionResult SECAPContractList(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Factoring/Contract/vwContractList.cshtml");
        }

        public ActionResult SECAPJudgmentList(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Factoring/Contract/vwJudgmentList.cshtml");
        }
        
    }


}