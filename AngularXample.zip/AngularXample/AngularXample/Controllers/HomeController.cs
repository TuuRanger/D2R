﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AngularXample.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View("~/Views/Shared/_MainLayout.cshtml");
        }

        public ActionResult Home()
        {
            return View();
        }

        public ActionResult SECAPDashboard(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Home/vwSECAPDashboard.cshtml");
        }
    }
}