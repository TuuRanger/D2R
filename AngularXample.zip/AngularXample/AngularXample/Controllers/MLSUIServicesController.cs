﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AngularXample.Controllers
{
    public class MLSUIServicesController : Controller
    {
        // GET: MLSUIServices
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult GetLanguage(String lang)
        {
            Dictionary<String, String> langList = new Dictionary<String, String>();
            
            if (lang == "en-EN")
            {
                langList.Add("txtCUSNAMTHA", "Name");
                langList.Add("txtCUSSURTHA", "Surname");
                return new JsonResult()
                {
                    Data = langList
                };
            }
            else if (lang == "th-TH")
            {
                langList.Add("txtCUSNAMTHA", "ชื่อ");
                langList.Add("txtCUSSURTHA", "นามสกุล");
                return new JsonResult()
                {
                    Data = langList
                };
            }
            throw new Exception(String.Format("Language '{0}' not support", lang));
        }
    }
    
}