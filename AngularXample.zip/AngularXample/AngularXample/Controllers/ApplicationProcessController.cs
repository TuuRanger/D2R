﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AngularXampleNew.Controllers
{
    public class ApplicationProcessController : Controller
    {
        #region Get Partial View
        // GET: ApplicationProcess
     
        public ActionResult partial_vwAppBasicInfoDefault(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/ApplicationForm/partial-view/Default/vwAppCustomerInfoDefault.cshtml");
        }

        public ActionResult partial_vwBusinessInfoDefault(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/ApplicationForm/partial-view/Default/vwBusinessInfoDefault.cshtml");
        }

        public ActionResult partial_vwProductInfoDefault(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/ApplicationForm/partial-view/Default/vwProductInfoDefault.cshtml");
        }
         
        public ActionResult partial_vwContractInfoDefault(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/ApplicationForm/partial-view/Default/vwContractInfoDefault.cshtml");
        }

        public ActionResult partial_vwCreditAnalysis(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/ApplicationForm/partial-view/Default/vwCreditAnalysisDefault.cshtml");
        }

        public ActionResult partial_vwPreviewCreditLimit(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/ApplicationForm/partial-view/Default/vwPreviewCreditLimit.cshtml");
        }

        public ActionResult partial_vwVerifyDefault(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/ApplicationForm/partial-view/Default/vwVerifyDefault.cshtml");
        }

        public ActionResult partial_vwFeeInfoDefault(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/ApplicationForm/partial-view/Default/vwFeeInfoDefault.cshtml");
        }

        public ActionResult partial_vwRepaymentCondition(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/ApplicationForm/partial-view/Default/vwRepaymentCondition.cshtml");
        }

        public ActionResult partial_vwAppBasicInfoAllInOne()
        {
            return View("~/Views/ApplicationForm/partial-view/All in one/vwAppBasicInfoAllInOne.cshtml");
        }

        public ActionResult partial_vwAppCustomerInfo_JR(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/ApplicationForm/partial-view/Default/Juristic/vwAppCustomerInfo_JR.cshtml");
        }

        public ActionResult partial_vwAppCreditAnalysis_JR(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/ApplicationForm/partial-view/Default/Juristic/vwAppCreditAnalysis_JR.cshtml");
        }

        public ActionResult partial_vwAppVerify_JR(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/ApplicationForm/partial-view/Default/Juristic/vwAppVerify_JR.cshtml");
        }
         
        public ActionResult ApplicationList()
        {
            return View("~/Views/ApplicationForm/vwApplicationList.cshtml");
        }
         
        public ActionResult JudgmentList()
        {
            return View("~/Views/ApplicationForm/vwJudgmentList.cshtml");
        }

        public ActionResult ApplicationEntry(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/ApplicationForm/vwAppEntry.cshtml");
        }
         
        public ActionResult JudgmentEntry(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/ApplicationForm/vwJudgmentEntry.cshtml"); 
        }

        public ActionResult ApplicationEntryFactoring(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/ApplicationForm/vwAppEntryFactoring.cshtml");
        }

        public ActionResult JudgmentEntryFactoring(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/ApplicationForm/vwJudgmentEntryFactoring.cshtml");
        }



        public ActionResult partial_vwAppFinancialFactoring(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/ApplicationForm/partial-view/Factoring/vwAppFinancial.cshtml");
        }

        public ActionResult partial_vwAppDetailFactoring(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/ApplicationForm/partial-view/Factoring/vwAppDetail.cshtml");
        }
        #endregion

    }
}