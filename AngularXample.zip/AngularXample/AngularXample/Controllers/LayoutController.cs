﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AngularXample.Controllers
{
    public class LayoutController : Controller
    {
        public ActionResult MainLayoutDefault()
        {
            return View("~/Views/Shared/_MainLayout.cshtml");
        }

        public ActionResult BizLayoutDefault()
        {
            return View("~/Views/Shared/_BizLayoutDefault.cshtml");
        }

        public ActionResult LoginLayoutDefault()
        {
            return View("~/Views/Shared/_LoginLayoutDefault.cshtml");
        }

        public ActionResult BlankLayout()
        {
            return View("~/Views/Shared/_BlankLayout.cshtml");
        }

        public ActionResult SearchListLayout()
        {
            return View("~/Views/Shared/_SearchListLayout.cshtml");
        }

   
    }
}