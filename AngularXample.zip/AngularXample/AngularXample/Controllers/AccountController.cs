﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AngularXample.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account
        public ActionResult AccountEntry(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Account/vwAccountEntry.cshtml");
        }

        public ActionResult AccountVerify(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Account/vwAccountVerify.cshtml");
        }

        public ActionResult AccountApproval(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Account/vwAccountApproval.cshtml");
        }

        public ActionResult AccountInquiry(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Account/vwAccountInquiry.cshtml");
        }


        public ActionResult AccountList(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Account/vwAccountList.cshtml");
        }


        public ActionResult partial_vwAccountDetailDeault()
        {
            return View("~/Views/Account/partial-view/Default/vwAccountDetailDefault.cshtml");
        }

        public ActionResult partial_vwCustomerInfo()
        {
            return View("~/Views/Account/partial-view/Default/vwCustomerInfo.cshtml");
        }

        public ActionResult partial_vwReferencePersonDefault()
        {
            return View("~/Views/Account/partial-view/Default/vwReferencePersonDefault.cshtml");
        }

        public ActionResult partial_vwFinancial1Supplier()
        {
            return View("~/Views/Account/partial-view/Default/vwFinancial1Supplier.cshtml");
        }

        public ActionResult partial_vwFinancial2Supplier()
        {
            return View("~/Views/Account/partial-view/Default/vwFinancial2Supplier.cshtml");
        }

        public ActionResult partial_vwAccountAddressDefault()
        {
            return View("~/Views/Account/partial-view/Default/vwAccountAddressDefault.cshtml");
        }



        public ActionResult partial_vwApproval()
        {
            return View("~/Views/Account/partial-view/Default/vwApproval.cshtml");
        }

        public ActionResult partial_vwPaymentConditionSponsorDLR()
        {
            return View("~/Views/Account/partial-view/Default/vwPaymentConditionSponsorDLR.cshtml");
        }

        public ActionResult partial_vwPaymentConditionSupplierCUS()
        {
            return View("~/Views/Account/partial-view/Default/vwPaymentConditionSupplierCUS.cshtml");
        }

        public ActionResult partial_vwFinancialSponsor()
        {
            return View("~/Views/Account/partial-view/Default/vwFinancialSponsor.cshtml");
        }
    }
}