﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AngularXample.Controllers
{
    public class DebtManagementController : Controller
    {
        // GET: Collection
        public ActionResult COL001_JonAssignment()
        {
            return View();
        }

        public ActionResult COL002_FollowUp()
        {
            return View();
        }

        public ActionResult COL003_FollowUpStat()
        {
            return View();
        }

        public ActionResult vwWorkLoadDetail()
        {
            return View("~/Views/DebtManagement/FollowUpPartial/vwWorkLoadDetail.cshtml"); 
        }

        public ActionResult vwSuccessAppointment()
        {
            return View("~/Views/DebtManagement/FollowUpPartial/vwSuccessAppointment.cshtml");
        }

        public ActionResult vwFailAppointment()
        {
            return View("~/Views/DebtManagement/FollowUpPartial/vwFailAppointment.cshtml");
        }

        public ActionResult vwBroke()
        {
            return View("~/Views/DebtManagement/FollowUpPartial/vwBroke.cshtml");
        }

        public ActionResult vwAlarm()
        {
            return View("~/Views/DebtManagement/FollowUpPartial/vwAlarm.cshtml");
        }

        public ActionResult vwFollowUpHistory()
        {
            return View("~/Views/DebtManagement/FollowUpPartial/vwFollowUpHistory.cshtml");
        }

        public ActionResult vwReferencePerson()
        {
            return View("~/Views/DebtManagement/FollowUpPartial/vwReferencePerson.cshtml");
        }

        public ActionResult vwProductDetail()
        {
            return View("~/Views/DebtManagement/FollowUpPartial/vwProductDetail.cshtml");
        }

        public ActionResult vwFollowUpStatGraph()
        {
            return View("~/Views/DebtManagement/FollowUpStat/vwFollowUpStatGraph.cshtml");
        }

        public ActionResult vwFollowUpStatStaff()
        {
            return View("~/Views/DebtManagement/FollowUpStat/vwFollowUpStatStaff.cshtml"); 
        }


    }
}