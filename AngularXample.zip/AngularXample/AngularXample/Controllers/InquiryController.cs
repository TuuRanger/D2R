﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AngularXample.Controllers
{
    public class InquiryController : Controller
    {
        // GET: Inquiry
        public ActionResult INQ001_InquiryAppList()
        {
            return View("~/Views/Inquiry/vwInquiryAppList.cshtml");
        }

        public ActionResult INQ002_InquiryAppDetail(String ngController)
        {
            ViewBag.ngController = ngController;
            return View("~/Views/Inquiry/vwInquiryAppDetail.cshtml");
        }
    }
}