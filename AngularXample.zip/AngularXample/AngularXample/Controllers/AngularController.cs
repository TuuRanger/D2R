﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AngularXample.Models;
namespace AngularXample.Controllers
{
    public class AngularController : Controller
    {
        // GET: Angular
        public ActionResult Directive()
        {
            return View();
        }

        public ActionResult DirectiveRouter()
        {
            return View("~/Views/Shared/_LayoutRouter.cshtml");
        }

        public ActionResult Partial()
        {
            return View("~/Views/Angular/DirectiveRouter.cshtml");
        } 

        public ActionResult Partial2()
        {
            return View("~/Views/Angular/DirectiveRouter.cshtml");
        }

        public ActionResult Partial3()
        {
            return View("~/Views/Angular/DirectiveRouter.cshtml");
        }
         

        public ActionResult Grid()
        {
            return View();
        }

        [HttpPost]
        public ActionResult GetContractList()
        {
            List<ContractListViewModel> contractList = new List<ContractListViewModel>();
            contractList.Add(new ContractListViewModel()
            {
                CONNUM = "0001158080007851",
                ACCNAMTHA = "นางสาว สุพัตรา คำปัน ",
                CONAPPLY_PROJEC_DESC = "C001",
                GENAPPDTE = DateTime.Now,
                CRDNXTSTP_DESC = "Basic Info"
            });
            contractList.Add(new ContractListViewModel() { CONNUM = "0001158080007966", ACCNAMTHA = "นางสาว สุนาวี อ้นพา  ", CONAPPLY_PROJEC_DESC = "C002", GENAPPDTE = DateTime.Now, CRDNXTSTP_DESC = "Basic Info" });
            contractList.Add(new ContractListViewModel() { CONNUM = "0001158080008016", ACCNAMTHA = "นาย การัณดร์ สิงห์กุล ", CONAPPLY_PROJEC_DESC = "C003", GENAPPDTE = DateTime.Now, CRDNXTSTP_DESC = "Basic Info" });
            contractList.Add(new ContractListViewModel() { CONNUM = "0001158080008041", ACCNAMTHA = "นางสาว สมประสงค์ ซื่อตรงสุขสิริ ", CONAPPLY_PROJEC_DESC = "P014", GENAPPDTE = DateTime.Now, CRDNXTSTP_DESC = "Basic Info" });
            contractList.Add(new ContractListViewModel() { CONNUM = "0001158080008059", ACCNAMTHA = "นาย ประสพสุข คำสุข ", CONAPPLY_PROJEC_DESC = "P001", GENAPPDTE = DateTime.Now, CRDNXTSTP_DESC = "Basic Info" });
            contractList.Add(new ContractListViewModel() { CONNUM = "0001158080008067", ACCNAMTHA = "นาย ภูมิศักดิ์ เหล่าสกุลพร ", CONAPPLY_PROJEC_DESC = "P003", GENAPPDTE = DateTime.Now, CRDNXTSTP_DESC = "Basic Info" });
            contractList.Add(new ContractListViewModel() { CONNUM = "0001158080008083", ACCNAMTHA = "นาย สมบูรณ์ ชมภู ", CONAPPLY_PROJEC_DESC = "C004", GENAPPDTE = DateTime.Now, CRDNXTSTP_DESC = "Basic Info" });
            contractList.Add(new ContractListViewModel() { CONNUM = "0001158080008091", ACCNAMTHA = "นาย ชัยสิทธิ์ ประจิตรตระกาล ", CONAPPLY_PROJEC_DESC = "C005", GENAPPDTE = DateTime.Now, CRDNXTSTP_DESC = "Basic Info" });
            contractList.Add(new ContractListViewModel() { CONNUM = "0001158080008105", ACCNAMTHA = "นาย สิริศิลป์ ถนอมศิลป์ ", CONAPPLY_PROJEC_DESC = "I003", GENAPPDTE = DateTime.Now, CRDNXTSTP_DESC = "Basic Info" });

            return new JsonResult()
            {
                Data = new { contractList = contractList },
                JsonRequestBehavior = JsonRequestBehavior.AllowGet,
                MaxJsonLength = Int32.MaxValue
            };
        }
    }
}