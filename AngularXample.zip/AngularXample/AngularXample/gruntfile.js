﻿module.exports = function (grunt)
{
    require('matchdep').filterDev('grunt-*').forEach(grunt.loadNpmTasks); 
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        karma: {
            unit: {
                configFile: 'karma.conf.js'
            }
        },
        open: {
            'unit-test-summary-chrome': {
                path: 'test-result/unit-test-summary/Chrome 49.0.2623 (Windows 10 0.0.0)/index.html',
                app: 'Chrome'
            },
            'unit-test-summary-firefox': {
                path: 'test-result/unit-test-summary/Firefox 45.0.0 (Windows 10 0.0.0)/index.html',
                app: 'Chrome'
            },
            'unit-test-coverage-chrome': {
                path: 'test-result/unit-test-coverage/Chrome 49.0.2623 (Windows 10 0.0.0)/index.html',
                app: 'Chrome'
            },
            'unit-test-coverage-firefox': {
                path: 'test-result/unit-test-coverage/Firefox 45.0.0 (Windows 10 0.0.0)/index.html',
                app: 'Chrome'
            },
        },
        clean: {
            'test-result': ['test-result']
        },
        less: {
            development: {
                options: {
                    paths: ['Styles/xx']
                },
                files: {
                    'Styles/css/StyleSheet1.css': 'Styles/less/StyleSheet1.less'
                }
            },
        },
        connect: {
            server: {
                options: {
                    port: 9001,
                    base: 'wwwroot'
                }
            }
        },
        protractor: {
            run: {
                options: {
                    configFile: "test/protractor.conf.js",
                    webdriverManagerUpdate: true
                }
            }
        }
    });
    grunt.loadNpmTasks('grunt-protractor-runner');
    grunt.loadNpmTasks('grunt-contrib-less');
    grunt.registerTask('test:e2e', [
	'connect:server',
	'protractor:run'
    ]);
    grunt.registerTask('unit-test', ['clean:test-result',
        'karma:unit',
        'open:unit-test-summary-chrome',
        'open:unit-test-summary-firefox',
        'open:unit-test-coverage-chrome',
        'open:unit-test-coverage-firefox']);
}