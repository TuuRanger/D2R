﻿describe('mls-screen-resource-provider (Scripts/mls-component/services/mls-screen-resource-provider.js)', function ()
{ 
    beforeEach(module('mls.components'));
    var mlsScreenResourceProvider;
    var httpBackend;
    var componentContext;
    beforeEach(inject(function ($rootScope, $httpBackend, _mlsScreenResourceProvider_,_componentContext_)
    { 
        mlsScreenResourceProvider = _mlsScreenResourceProvider_; 
        httpBackend = $httpBackend;
        componentContext = _componentContext_;
    }));

    describe('mlsRegExp', function ()
    { 
        it('mlsScreenResourceProvider is defined', function ()
        { 
            expect(mlsScreenResourceProvider).toBeDefined();
        });
         
        it('mlsScreenResourceProvider.getScreenLabelTextList', function ()
        {
            var promise, response, result;
            promise = mlsScreenResourceProvider.getScreenLabelTextList("_LoginLayout", "en-EN");
            promise.then(function (data)
            { 
                result = data;
            });
        
            response =  { "listLabelText": { "txtUsername": "Username", "txtPassword": "Password", "btnSubmit": "Login" } };
              
            httpBackend.expectGET(componentContext.rootUrl + '/mls.services/api/UIServices/getScreenLabelTextList/?language=en-EN&screenID=_LoginLayout').respond(200, response);
            httpBackend.flush();
            expect(result).toEqual(response); 
        });

        it('mlsScreenResourceProvider.getScreenLabelTextList fail', function ()
        {
            var promise, response, result, errorMessage;
            errorMessage = 'error message';
            promise = mlsScreenResourceProvider.getScreenLabelTextList("_LoginLayout", "en-EN");
            promise.then(function (error)
            {
                result = error;
            });
            response = { };
            httpBackend.expectGET(componentContext.rootUrl + '/mls.services/api/UIServices/getScreenLabelTextList/?language=en-EN&screenID=_LoginLayout').respond(500, response);
            httpBackend.flush();
            debugger
            expect(result.status).toEqual(500);
        });

    });


     
});
