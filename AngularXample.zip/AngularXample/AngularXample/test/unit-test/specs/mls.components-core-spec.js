﻿describe('mls-component.core (Scripts/mls-component/core/mls-component.core.js)', function ()
{ 
    beforeEach(module('mls.components'));

    beforeEach(inject(function ($rootScope, $controller, $timeout, $q, _mlsRegExp_)
    {
        // Test data
      /*  testItem = { id: 1, desc: 'test item', complete: false };
        testItems = [testItem];
        testNewItem = 'test item 2';
        testErrorMessage = 'Error message';
        testResponseSuccess = { success: true, data: { items: testItems } };
        testResponseFailure = { error: testErrorMessage };*/
        // Services
        mlsRegExp = _mlsRegExp_;
        timeout = $timeout;
        q = $q;
        // Controller setup
      /*  scope = $rootScope.$new();
        controller = $controller('ListController', {
            $scope: scope,
            TodoService: TodoService
        });*/
    }));

    describe('mlsRegExp', function ()
    { 
        it('mlsRegExp is defined', function ()
        { 
            expect(mlsRegExp).toBeDefined();
        });

        it('mlsRegExp.isTelNoFormat("02-123-4567")', function ()
        {
            expect(mlsRegExp.isTelNoFormat("02-123-4567")).toBe(true);
        });

        it('mlsRegExp.isTelNoFormat("089-123-4567")', function ()
        {
            expect(mlsRegExp.isTelNoFormat("089-123-4567")).toBe(true);
        });

        it('mlsRegExp.isTelNoFormat("xxx-xxx-xxxx")', function ()
        {
            expect(mlsRegExp.isTelNoFormat("xxx-xxx-xxxx")).toBe(false);
        });


    });


     
});
