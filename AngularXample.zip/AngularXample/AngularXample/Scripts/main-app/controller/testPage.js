﻿mainApp.controller('testPageController', ['$scope',
function ($scope)
{

}]);