﻿mainApp.controller('inquiryController',
     ['$scope', 'mlsLanguage', 'mainAppContext', 'mlsScreenResourceProvider', 'mlsDialog', '$stateParams', '$state', '$rootScope', '$stateParams', 'mlsUrlSvc', 'DTOptionsBuilder', 'DTColumnDefBuilder', 'mlsDtDefaultSetting',
function ($scope, mlsLanguage, mainAppContext, mlsScreenResourceProvider, mlsDialog, $stateParams, $state, $rootScope, $stateParams, mlsUrlSvc, DTOptionsBuilder, DTColumnDefBuilder, mlsDtDefaultSetting)
{
    $scope.InitialComponents(); 

}]);
