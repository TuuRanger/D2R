﻿angular.module('mainApp').controller('accountEntryController', ['$scope', '$stateParams', '$state', '$rootScope', '$location', 'comboBoxDataSvc', '$q', 'eBiz', 'mlsUrlSvc', 'customerDataSvc', 'mlsStringUtils', 'eScreenMode', 'mlsCustomerSearchDialog', 'addressDataSvc', 'mlsLoadingDialog', 'accountDataSvc', 'mlsDialog', 'locationHelper', 'guarantorPersonDataSvc', 'referencePersonDataSvc', 'validationDataSvc', '$timeout', 'validationHelper', 'mlsFieldValidateDialog', 'locationHelper',
    function ($scope, $stateParams, $state, $rootScope, $location, comboBoxDataSvc, $q, eBiz, mlsUrlSvc, customerDataSvc, mlsStringUtils, eScreenMode, mlsCustomerSearchDialog, addressDataSvc, mlsLoadingDialog, accountDataSvc, mlsDialog, locationHelper, guarantorPersonDataSvc, referencePersonDataSvc, validationDataSvc, $timeout, validationHelper, mlsFieldValidateDialog, locationHelper) {

        var baseController = $scope.$parent;
         
        $scope.initialComponents = function ()
        {
            var tabApproval = $scope.geTabByID('tabApproval');
            tabApproval.isDisable = function () { return true };

        }

        $scope.showNewAccountCompleteDialog = function () {
            var ok = mlsDialog.showCustomDialog({}, {
                scope: $scope,
                template: mlsUrlSvc.getUrlContent("/Template/dialog-template/newAccountCompleteTemplate.html"),
                className: 'ngdialog-theme-default dialog-large',
                closeByDocument: false,
                showClose: false,
                closeByEscape: false
            }, null);
             
            return ok;
        }
 
       
        $scope.onValidate = function () {
            var arrValidateList = $scope.getValidateID();

            var deferred = $q.defer();
            $q.all([
                validationDataSvc.getFieldValidation(arrValidateList)
            ]).then(function (response) {
                $timeout(function () {
                    var validationList = response[0];
                    var from = $("#frmEntry")
                    validationHelper.parseValidationList(from, validationList);

                    var isValid = from.valid();
                    var invalidFields = [];
                    var elementList = from.validate().errorList;

                    for (var i = 0 ; i < elementList.length ; i++) {
                        var ele = elementList[i].element;
                        var fieldLabelText = null;
                        if (angular.element("#" + ele.id).hasClass('autocomplete-control')) // auto complete
                        {
                            fieldLabelText = angular.element("#labelText_lb_" + ele.id.replace("_value", "")).text().replace(/(?:\r\n|\r|\n)/g, '').trim();
                        }
                        else {
                            fieldLabelText = angular.element("#labelText_lb_" + ele.id).text().replace(/(?:\r\n|\r|\n)/g, '').trim();
                        }


                        if (!mlsStringUtils.isStringEmpty(fieldLabelText)) {
                            invalidFields.push(fieldLabelText);
                        }
                        else {
                            console.log(ele.id + "Not have field label text");
                        }

                        console.log("Invalid : " + fieldLabelText);
                    }

                    deferred.resolve({
                        isValid: isValid,
                        invalidFields: invalidFields
                    })
                });

            })

            return deferred.promise;
        }
          
        $scope.onSave = function () {
          
            $scope.onValidate().then(function (validateResult) {
                if (validateResult.isValid) { 
                    confirm = mlsDialog.showConfirmDialog({ message: "Do you want to 'Save data'?" });
                    confirm.then(function () {
                        var dialog = mlsLoadingDialog.show();
                        baseController.onSave().then(function () {
                            dialog.close();
                            $scope.showNewAccountCompleteDialog().then(function () {
                                if ($scope.screenModel.screenMode == eScreenMode.ADD) {
                                    $state.forceReload();
                                }
                                else if ($scope.screenModel.screenMode == eScreenMode.EDIT) {
                                    locationHelper.path("/accountNewList");
                                }
                            });

                        });
                    })
                }
                else { 
                    mlsFieldValidateDialog.show({
                        message: "Please correct invalid data before save.",
                        messageCode: "inf0001",
                        invalidFields: validateResult.invalidFields
                    })
                }
            })
        }
         

      
        $scope.initialComponents();
     
    }]);