﻿angular.module('mainApp').controller('accountInquiryListController', ['$scope', '$stateParams', '$state', '$rootScope', '$location', 'comboBoxDataSvc', '$q', 'eBiz', 'mlsUrlSvc', 'customerDataSvc', 'mlsStringUtils', 'eScreenMode', 'mlsCustomerSearchDialog', 'addressDataSvc', 'mlsLoadingDialog', 'accountDataSvc',
    function ($scope, $stateParams, $state, $rootScope, $location, comboBoxDataSvc, $q, eBiz, mlsUrlSvc, customerDataSvc, mlsStringUtils, eScreenMode, mlsCustomerSearchDialog, addressDataSvc, mlsLoadingDialog, accountDataSvc) {

        $scope.$emit('on-screen-load', { screenID: "ACC002AccountList", screenTitle: "Account Verify List" });
        $scope.searchCriteria = {};
        $scope.initialComboBox = function ()
        {
            $q.all([
                comboBoxDataSvc.getComboAccountDealWith(),
                comboBoxDataSvc.getComboAccBusTyp(),
            ]).then(function (response)
            {
                $scope.accountDealWithDataSource = response[0];
                $scope.businessTypeDataSource = response[1]
            }) 
        }
        
        $scope.gridOptions = {
            enableSelectAll: true,
            enableRowSelection: true,
            multiSelect: false,
            enableRowHeaderSelection: false,
            useExternalPagination: true,
            paginationPageSize: 50,
            paginationPageSizes: [50, 100],
            noUnselect: false,
            enableSorting: true,
            enableColumnResizing: true,
            showGridFooter: true,
            rowHeight: 40,
            columnDefs: [
              {
                  name: 'Action', width: "100",
                  //cellTemplate: '<a href="{{\'#/accountVerify?GENAPPNUM=\' + row.entity.GENAPPNUM + \'&ACCBUSTYP=\'+ row.entity.ACCBUSTYP     + \'&CPNCOD=\' + row.entity.CPNCOD + \'&CPNBRNCOD=\' + row.entity.CPNBRNCOD + \'&ACCCOD=\' + row.entity.ACCCOD}}"' + ' class="btn btn-sm btn-warning"><i class="fa fa-pencil fa-2x"></i></a>',
                  cellTemplate: '<a id="btn{{row.entity.GENAPPNUM}}" ui-sref="accountInquiry({ GENAPPNUM: row.entity.GENAPPNUM ,CPNCOD :row.entity.CPNCOD,CPNBRNCOD : row.entity.CPNBRNCOD, ACCBUSTYP : row.entity.ACCBUSTYP })"  class="btn btn-sm btn-warning"><i class="fa fa-pencil fa-2x"></i></a>',
                  cellClass: 'cell-aligh-center',
                  enableSorting: false
              },
              { name: 'Branch', field: 'CPNBRNCOD', width: "200", }, 
              { name: 'Account No.', field: 'ACCCOD', width: "200", },
              { name: 'App No.', field: 'GENAPPNUM', width: "200", }, 
              { name: 'Business Type', field: 'ACCBUSTYP_DESC', width: "200", },
              { name: 'Deal Type', field: 'ACCDEAWTH_DESC', width: "170", },
              { name: 'Account Name', field: 'ACCNAMTHA', width: "300" },
              { name: 'Status', field: 'RECSTSCOD_DESC', width: "200" },
              { name: 'Approve Date', field: 'GENAPRDTE', cellFilter: "displaydate:'dd/MM/yyyy HH:mm':true", width: "160" },
              { name: 'Effective Date', field: 'GENEFFDTE', cellFilter: "displaydate:'dd/MM/yyyy HH:mm':true", width: "160" },
              { name: 'Last Update Date', field: 'MTNDTETME', cellFilter: "displaydate:'dd/MM/yyyy HH:mm':true", width: "160" },
              { name: 'Update Date By', field: 'MTNUSRCOD',  width: "160" },
            ],
            data: [],
            onRegisterApi: function (gridApi)
            {
                $scope.gridApi = gridApi;
 

                gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
                    $scope.searchAccount(newPage, pageSize);
                });
            }
        };

        $scope.searchAccount = function (pageNo, pageSize)
        {
            var dialog = mlsLoadingDialog.show();
            accountDataSvc.searchAccountWithPaging({
                ACCBUSTYP: $scope.searchCriteria.ACCBUSTYP,
                ACCCOD: $scope.searchCriteria.ACCCOD,
                GENAPPNUM: $scope.searchCriteria.GENAPPNUM,
                ACCNAMTHA: $scope.searchCriteria.ACCNAMTHA,
                ACCDEAWTH: $scope.searchCriteria.ACCDEAWTH,
                RECSTSCOD_FROM: 1,
                RECSTSCOD_TO: 9,
                pageNo: pageNo,
                pageSize: pageSize,
            }).then(function (data)
            {
                if (data.length > 0) {
                    $scope.gridOptions.data = data;
                    $scope.gridOptions.totalItems = data[0].TotalRecords;
                }
                else
                {
                    $scope.gridOptions.data = [];
                    $scope.gridOptions.totalItems = 0;
                }
                dialog.close();
            })
        }

        $scope.searchData = function ()
        {
            $scope.searchAccount(1, $scope.gridOptions.paginationPageSize);
        }

        $scope.clearCriteriaAndSearch = function ()
        {
            $scope.searchCriteria = {};
            $scope.searchAccount(1, $scope.gridOptions.paginationPageSize);
        }

        $scope.initialComponent = function ()
        {
            $scope.initialComboBox();
        }

        $scope.initialComponent();


    }]);