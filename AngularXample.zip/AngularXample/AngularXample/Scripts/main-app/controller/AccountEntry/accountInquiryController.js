﻿angular.module('mainApp').controller('accountInquiryController', ['$scope', '$stateParams', '$state', '$rootScope', '$location', 'comboBoxDataSvc', '$q', 'eBiz', 'mlsUrlSvc', 'customerDataSvc', 'mlsStringUtils', 'eScreenMode', 'mlsCustomerSearchDialog', 'addressDataSvc', 'mlsLoadingDialog', 'accountDataSvc', 'mlsDialog', 'locationHelper', 'guarantorPersonDataSvc', 'referencePersonDataSvc', 'validationDataSvc', '$timeout', 'validationHelper', 'mlsFieldValidateDialog', 'locationHelper', 'eScreenPurpose', 'mlsAppSendBackDialog', 'remarkDataSvc',
    function ($scope, $stateParams, $state, $rootScope, $location, comboBoxDataSvc, $q, eBiz, mlsUrlSvc, customerDataSvc, mlsStringUtils, eScreenMode, mlsCustomerSearchDialog, addressDataSvc, mlsLoadingDialog, accountDataSvc, mlsDialog, locationHelper, guarantorPersonDataSvc, referencePersonDataSvc, validationDataSvc, $timeout, validationHelper, mlsFieldValidateDialog, locationHelper, eScreenPurpose, mlsAppSendBackDialog, remarkDataSvc) {
       
        var baseController = $scope.$parent;
        baseController.screenTitle = "Account Inquiry"
        $scope.initialComponents = function ()
        {
            $scope.screenModel.screenPurpose = eScreenPurpose.VIEW
           
        }

        var onInitialData = $rootScope.$on("initial-data-complete", function (args,data)
        { 
            if (!data.accountModel.GENAPPNUM)
            {
                locationHelper.path("/inqAccountList");
            } 
        });

 
        $scope.initialComponents();
     

        $scope.$on('$destroy', function () {

            if (typeof onInitialData == 'function') {
                onInitialData();
                console.log("unbind onInitialData complete")
            }

        })
    }]);