﻿angular.module('mainApp').controller('accountApprovalController', ['$scope', '$stateParams', '$state', '$rootScope', '$location', 'comboBoxDataSvc', '$q', 'eBiz', 'mlsUrlSvc', 'customerDataSvc', 'mlsStringUtils', 'eScreenMode', 'mlsCustomerSearchDialog', 'addressDataSvc', 'mlsLoadingDialog', 'accountDataSvc', 'mlsDialog', 'locationHelper', 'guarantorPersonDataSvc', 'referencePersonDataSvc', 'validationDataSvc', '$timeout', 'validationHelper', 'mlsFieldValidateDialog', 'locationHelper', 'eScreenPurpose', 'mlsAppSendBackDialog', 'remarkDataSvc',
    function ($scope, $stateParams, $state, $rootScope, $location, comboBoxDataSvc, $q, eBiz, mlsUrlSvc, customerDataSvc, mlsStringUtils, eScreenMode, mlsCustomerSearchDialog, addressDataSvc, mlsLoadingDialog, accountDataSvc, mlsDialog, locationHelper, guarantorPersonDataSvc, referencePersonDataSvc, validationDataSvc, $timeout, validationHelper, mlsFieldValidateDialog, locationHelper, eScreenPurpose, mlsAppSendBackDialog, remarkDataSvc) {
       
        var baseController = $scope.$parent;
        baseController.screenTitle = "Account Approval"
        $scope.initialComponents = function ()
        {
            $scope.screenModel.screenPurpose = eScreenPurpose.APPROVAL
           
        }

        var onInitialData = $rootScope.$on("initial-data-complete", function (args,data)
        { 
            if (!data.accountModel.GENAPPNUM)
            {
                locationHelper.path("/accountJudgmentList");
            }
            $scope.accountModel.RECSTSCOD = 3;
        });

        $scope.showNewAccountCompleteDialog = function () {
            var ok = mlsDialog.showCustomDialog({}, {
                scope: $scope,
                template: mlsUrlSvc.getUrlContent("/Template/dialog-template/newAccountCompleteTemplate.html"),
                className: 'ngdialog-theme-default dialog-large',
                closeByDocument: false,
                showClose: false,
                closeByEscape: false
            }, null);


            return ok;
        }
   
        $scope.onSendBack = function ()
        {
            $scope.onValidate().then(function (validateResult) {
                if (validateResult.isValid) {
                    confirm = mlsAppSendBackDialog.show({
                        txtRemarkLabelText: $scope.listLabelText.txtRemark,
                    });

                    confirm.then(function (data) {
                        var dialogModel = data.dialogModel;
                        var remark = dialogModel.remark;
                        $scope.accountModel.RECSTSCOD = 1;

                        var remarkModel = {
                            REMARK_ID: null,
                            RMKLEVRSL: 3,
                            GENREMARK: "(Sendback in accountJudgmentList) " + mlsStringUtils.toStringOrEmpty(remark),
                            GENPROGRM : "ACC"
                        }

                        var dialog = mlsLoadingDialog.show();
                        baseController.onSendBack().then(function () {

                            remarkDataSvc.insertOrUpdateRemark(
                               [remarkModel],
                               $scope.accountModel.CPNCOD,
                               $scope.accountModel.CPNBRNCOD,
                               $scope.accountModel.ACCBUSTYP,
                               $scope.accountModel.GENAPPNUM,
                               $rootScope.Username).then(function () {
                                   var ok = mlsDialog.showInfoDialog({ message: "Send back complete", messaeCode: "INF004" }, {
                                       closeByDocument: false,
                                       showClose: false,
                                       closeByEscape: false
                                   });

                                   ok.then(function () {
                                       locationHelper.path("/accountJudgmentList");
                                   })

                                   dialog.close();
                               }) 
                        });
                    })
                }
                else {
                    mlsFieldValidateDialog.show({
                        message: "Please correct invalid data before save.",
                        messageCode: "inf0001",
                        invalidFields: validateResult.invalidFields
                    })
                }
            }) 
        }

        $scope.onSave = function () {
            $scope.onValidate().then(function (validateResult) {
                if (validateResult.isValid) { 
                    confirm = mlsDialog.showConfirmDialog({ message: "Do you want to 'Save data' ?" });
                    confirm.then(function () {
                        var dialog = mlsLoadingDialog.show();
                        $scope.accountModel.RECSTSCOD = 3;
                        baseController.onGenAccount().then(function () {
                            dialog.close(); 
                            $scope.showNewAccountCompleteDialog().then(function () {
                                locationHelper.path("/accountJudgmentList");
                            }); 
                        });
                    })
                }
                else { 
                    mlsFieldValidateDialog.show({
                        message: "Please correct invalid data before save.",
                        messageCode: "inf0001",
                        invalidFields: validateResult.invalidFields
                    })
                }
            })
        }
         
        $scope.initialComponents();

        $scope.$on('$destroy', function () {
             
            if (typeof onInitialData == 'function')
            {
                onInitialData();
                console.log("unbind onInitialData complete")
            }
            
        })

    }]);