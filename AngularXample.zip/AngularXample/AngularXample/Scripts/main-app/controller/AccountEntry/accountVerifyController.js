﻿angular.module('mainApp').controller('accountVerifyController', ['$scope', '$stateParams', '$state', '$rootScope', '$location', 'comboBoxDataSvc', '$q', 'eBiz', 'mlsUrlSvc', 'customerDataSvc', 'mlsStringUtils', 'eScreenMode', 'mlsCustomerSearchDialog', 'addressDataSvc', 'mlsLoadingDialog', 'accountDataSvc', 'mlsDialog', 'locationHelper', 'guarantorPersonDataSvc', 'referencePersonDataSvc', 'validationDataSvc', '$timeout', 'validationHelper', 'mlsFieldValidateDialog', 'locationHelper','eScreenPurpose',
    function ($scope, $stateParams, $state, $rootScope, $location, comboBoxDataSvc, $q, eBiz, mlsUrlSvc, customerDataSvc, mlsStringUtils, eScreenMode, mlsCustomerSearchDialog, addressDataSvc, mlsLoadingDialog, accountDataSvc, mlsDialog, locationHelper, guarantorPersonDataSvc, referencePersonDataSvc, validationDataSvc, $timeout, validationHelper, mlsFieldValidateDialog, locationHelper,eScreenPurpose) {
       
        var baseController = $scope.$parent;
        baseController.screenTitle = "Account Verify"
        $scope.initialComponents = function ()
        {
            $scope.screenModel.screenPurpose = eScreenPurpose.VERIFY
           
        }

        var onInitialData = $rootScope.$on("initial-data-complete", function (args,data)
        {
            if (!data.accountModel.GENAPPNUM)
            {
                locationHelper.path("/accountVerifyList");
            }
            $scope.accountModel.RECSTSCOD = 2;
        });

        $scope.showNewAccountCompleteDialog = function () {
            var ok = mlsDialog.showCustomDialog({}, {
                scope: $scope,
                template: mlsUrlSvc.getUrlContent("/Template/dialog-template/newAccountCompleteTemplate.html"),
                className: 'ngdialog-theme-default dialog-large',
                closeByDocument: false,
                showClose: false,
                closeByEscape: false
            }, null);


            return ok;
        }
   
        $scope.onSave = function () { 
            $scope.onValidate().then(function (validateResult) {
                if (validateResult.isValid) { 
                    confirm = mlsDialog.showConfirmDialog({ message: "Do you want to 'Save data'?" });
                    confirm.then(function () {
                        var dialog = mlsLoadingDialog.show(); 
                        baseController.onVerify().then(function () {
                            dialog.close();
                            $scope.showNewAccountCompleteDialog().then(function () {
                                locationHelper.path("/accountVerifyList");
                            });

                        });
                    })
                }
                else { 
                    mlsFieldValidateDialog.show({
                        message: "Please correct invalid data before save.",
                        messageCode: "inf0001",
                        invalidFields: validateResult.invalidFields
                    })
                }
            })
        }
         
        $scope.initialComponents();




        $scope.$on('$destroy', function () {

            if (typeof onInitialData == 'function') {
                onInitialData();
                console.log("unbind onInitialData complete")
            }

        })
     
    }]);