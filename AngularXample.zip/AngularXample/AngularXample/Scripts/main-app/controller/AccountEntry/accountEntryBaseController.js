﻿angular.module('mainApp').controller('accountEntryBaseController', ['$scope', '$stateParams', '$state', '$rootScope', '$location', 'comboBoxDataSvc', '$q', 'eBiz', 'mlsUrlSvc', 'customerDataSvc', 'mlsStringUtils', 'eScreenMode', 'mlsCustomerSearchDialog', 'addressDataSvc', 'mlsLoadingDialog', 'accountDataSvc', 'mlsDialog', 'locationHelper', 'guarantorPersonDataSvc', 'referencePersonDataSvc', 'validationDataSvc', '$timeout', 'validationHelper', 'mlsFieldValidateDialog', 'locationHelper', 'eAccountConfig',
    function ($scope, $stateParams, $state, $rootScope, $location, comboBoxDataSvc, $q, eBiz, mlsUrlSvc, customerDataSvc, mlsStringUtils, eScreenMode, mlsCustomerSearchDialog, addressDataSvc, mlsLoadingDialog, accountDataSvc, mlsDialog, locationHelper, guarantorPersonDataSvc, referencePersonDataSvc, validationDataSvc, $timeout, validationHelper, mlsFieldValidateDialog, locationHelper, eAccountConfig) {

        $scope.screenTitle = "Account Entry"
        $scope.$emit('on-screen-load', { screenID: "ACC001NewEntry", screenTitle: $scope.screenTitle });
        $scope.accountConfig = {};
        $scope.accountModel = {};
        $scope.accountCriteria = {};
        $scope.tabs = [
            {
                id: 'tabCustomerInfo',
                url: mlsUrlSvc.getUrlContent("/Account/partial_vwCustomerInfo"), 
                title: 'Customer',
                isShown: function () { return true /*return $scope.accountModel.ACCDEAWTH == eBiz.ACCDEAWTH.Customer */ },
                RECSTSCOD: 1,
                isDisable: function () {
                    return $scope.accountModel.RECSTSCOD < 1
                },
                SEQ: 1
            },
            {
                id: 'tabAccountDetail',
                url: mlsUrlSvc.getUrlContent('/Account/partial_vwAccountDetailDeault'),
                
                title: 'Account detail',
                isShown: function () { return true },
                RECSTSCOD: 1,
                SEQ: 2,
                isDisable: function () {
                    return $scope.accountModel.RECSTSCOD < 1
                }
            },
            {
                id: 'tabAccountAddress',
                url: mlsUrlSvc.getUrlContent('/Account/partial_vwAccountAddressDefault'),

                title: 'Account Address',
                isShown: function () { return true },
                RECSTSCOD: 1,
                SEQ: 3,
                isDisable: function () {
                    return $scope.accountModel.RECSTSCOD < 1
                }
            },
            {
                id: 'tabReferencePerson',
                url: mlsUrlSvc.getUrlContent("/Account/partial_vwReferencePersonDefault"),
                
                title: 'Reference Person/Guarantor',
                isShown: function () { return $scope.accountModel.ACCDEAWTH == eBiz.ACCDEAWTH.Customer || $scope.accountModel.ACCDEAWTH == eBiz.ACCDEAWTH.Dealer },
                RECSTSCOD: 1,
                SEQ: 4,
                isDisable: function () {
                    return $scope.accountModel.RECSTSCOD < 1
                }
            },
            {
                id: 'tabFinancialSponsor',
                url: mlsUrlSvc.getUrlContent("/Account/partial_vwFinancialSponsor"), 
                title: 'Financial',
                isShown: function () { return $scope.accountModel.ACCDEAWTH == eBiz.ACCDEAWTH.Dealer },
                RECSTSCOD: 1,
                SEQ: 5,
                isDisable: function () {
                    return $scope.accountModel.RECSTSCOD < 1
                }
            },
            {
                id: 'tabFinancial1Supplier',
                url: mlsUrlSvc.getUrlContent("/Account/partial_vwFinancial1Supplier"), 
                title: 'Financial 1',
                isShown: function () { return $scope.accountModel.ACCDEAWTH == eBiz.ACCDEAWTH.Customer },
                RECSTSCOD: 1,
                SEQ: 5,
                isDisable: function () {
                    return $scope.accountModel.RECSTSCOD < 1
                }
            },
            {
                id: 'tabFinancial2Supplier',
                url: mlsUrlSvc.getUrlContent("/Account/partial_vwFinancial2Supplier"), 
                title: 'Financial 2',
                isShown: function () { return $scope.accountModel.ACCDEAWTH == eBiz.ACCDEAWTH.Customer },
                RECSTSCOD: 1,
                SEQ: 6,
                isDisable: function () {
                    return $scope.accountModel.RECSTSCOD < 1
                }
            },
            {
                id: 'tabPaymentConditionSupplier',
                url: mlsUrlSvc.getUrlContent("/Account/partial_vwPaymentConditionSupplierCUS"),
                
                title: 'Payment Confdition',
                isShown: function () { return $scope.accountModel.ACCDEAWTH == eBiz.ACCDEAWTH.Customer },
                RECSTSCOD: 1,
                SEQ: 7,
                isDisable: function () {
                    return $scope.accountModel.RECSTSCOD < 1
                }
            },
            {
                id: 'tabPaymentConditionSponsor',
                url: mlsUrlSvc.getUrlContent("/Account/partial_vwPaymentConditionSponsorDLR"),
                
                title: 'Payment Confdition',
                isShown: function () { return $scope.accountModel.ACCDEAWTH == eBiz.ACCDEAWTH.Dealer },
                RECSTSCOD: 1,
                SEQ: 6,
                isDisable: function () {
                    return $scope.accountModel.RECSTSCOD < 1
                }
            },
            {
                id: 'tabApproval',
                url: mlsUrlSvc.getUrlContent("/Account/partial_vwApproval"), 
                title: 'Approval',
                isShown: function () { return true},
                RECSTSCOD: function () {
                    if ($scope.accountModel.RECSTSCOD <= 1) {
                        return 2
                    }
                    else {
                        return 3
                    }
                },
                SEQ: 8,
                isDisable: function () {
                    return $scope.accountModel.RECSTSCOD < 1
                }
            }
        ];

        $scope.validationModels = [
            {
                RECSTSCOD: 1,
                validationList: [
                    {
                        condition: function () { return true },
                        validateID: "VLD0014"
                    },
                    {
                        condition: function () { return $scope.accountModel.ACCDEAWTH == eBiz.ACCDEAWTH.Customer },
                        validateID: "VLD0015"
                    },
                    {
                        condition: function () { return $scope.accountModel.ACCDEAWTH == eBiz.ACCDEAWTH.Dealer},
                        validateID: "VLD0016"
                    }
                ]
            },
            {
                RECSTSCOD: 2,
                validationList: [
                {
                    condition: function () { return true },
                    validateID: "VLD0017"
                },
                ]
            },
            {
                RECSTSCOD: 3,
                validationList: [
                    {
                        condition: function () { return true },
                        validateID: "VLD0018"
                    },
                    
                ]
            },
        ]
        $scope.usedTabs = $scope.tabs;
        $scope.usedTabs[0].active = true;
        $scope.customerDataSource = null;
        $scope.referencePersonList = [];
        $scope.guarantorList = null;
        $scope.referencePersonListModel = {};
        $scope.guarantorListModel = {};
        $scope.showNewAccountCompleteDialog = function () {
            var ok = mlsDialog.showCustomDialog({}, {
                scope: $scope,
                template: mlsUrlSvc.getUrlContent("/Template/dialog-template/newAccountCompleteTemplate.html"),
                className: 'ngdialog-theme-default dialog-large',
                closeByDocument: false,
                showClose: false,
                closeByEscape: false
            }, null);


            return ok;
        }
        $scope.assignAccountCodeText = "Assign";
        $scope.getAccountDetail = function () {
            var defered = $q.defer();
            accountDataSvc.getAccountDetail($scope.accountCriteria).then(function (data) {
                $scope.accountModel = data; 
                //if (!$scope.accountModel.RECSTSCOD == 1) {
                //    $scope.accountModel.RECSTSCOD = 2;
                //}
                //else if ($scope.accountModel.RECSTSCOD == 2) {
                //    $scope.accountModel.RECSTSCOD = 3;
                //}
                defered.resolve();
            })
            return defered.promise;
        }

        $scope.setReadonly = function (customer)
        {
            var defered = $q.defer();
            accountDataSvc.checkCustomerInAccount({
                CUSCOD: customer.CUSCOD,
                ACCCOD : customer.ACCCOD
            }).then(function (data)
            {
                if (data.CustomerCount > 0) {
                    customer.readonly = true
                }
                else
                {
                    customer.readonly = false;
                }
               
                defered.resolve();
            })
            return defered.promise;

        }

        $scope.getAccountCustomers = function () {
            var defered = $q.defer();
            accountDataSvc.getAccountCustomers($scope.accountCriteria).then(function (data) {
                $scope.customerDataSource = data;

                var promisArray = [];
                angular.forEach($scope.customerDataSource, function (cus, index) {
                    promisArray.push($scope.setCustomerAddress(cus));
                    promisArray.push($scope.setReadonly(cus));
                })


                $q.all(promisArray).then(function () {
                    defered.resolve();
                })

            })
            return defered.promise;
        }

        $scope.getGuarantor = function () {
            var derfered = $q.defer();
            guarantorPersonDataSvc.getGuarantorPersonList($scope.accountCriteria).then(function (data) {
                $scope.guarantorList = data;
                derfered.resolve();
            })

            return derfered.promise;
        }

        $scope.getAccountConfig = function ()
        {

            var defered = $q.defer();

            if ((mlsStringUtils.isStringEmpty($scope.accountModel.ACCBUSTYP) ||
                mlsStringUtils.isStringEmpty($scope.accountModel.ACCDEAWTH) ||
                mlsStringUtils.isStringEmpty($scope.accountModel.CPNBRNCOD)) == false) {

                accountDataSvc.getAccountConfig({
                    ACCBUSTYP: $scope.accountModel.ACCBUSTYP,
                    ACCDEAWTH: $scope.accountModel.ACCDEAWTH,
                    CPNBRNCOD: $scope.accountModel.CPNBRNCOD
                }).then(function (data) {
                    $scope.accountConfig = data;
                    defered.resolve();
                })
            }
            else
            {
                defered.resolve();
            }
          

            return defered.promise;

        }

        $scope.getReferencePerson = function () {
            var derfered = $q.defer();
            referencePersonDataSvc.getReferencePersonList($scope.accountCriteria).then(function (data) {
                $scope.referencePersonList = data;
                derfered.resolve();
            })

            return derfered.promise;
        }
        
        $scope.initialScreenMode = function () {
             
            if (!mlsStringUtils.isStringEmpty($stateParams.GENAPPNUM) &&
                !mlsStringUtils.isStringEmpty($stateParams.CPNCOD) &&
                !mlsStringUtils.isStringEmpty($stateParams.CPNBRNCOD) &&
                !mlsStringUtils.isStringEmpty($stateParams.ACCBUSTYP)
                ) {

                $scope.accountCriteria = {
                    "GENAPPNUM": $stateParams.GENAPPNUM,
                    "CONNUM": $stateParams.GENAPPNUM, /*for get guarantorlist*/
                    "ACCCOD": $stateParams.ACCCOD,
                    "CPNCOD": $stateParams.CPNCOD,
                    "CPNBRNCOD": $stateParams.CPNBRNCOD,
                    "ACCBUSTYP": $stateParams.ACCBUSTYP,
                };

                $scope.screenModel.screenMode = eScreenMode.EDIT;
            }
            else {
                $scope.screenModel.screenMode = eScreenMode.ADD;
            }
        }

        $scope.customerListModel = null;

        $scope.getActiveTab = function () {
            var arrTab = $scope.usedTabs.whereAnd([{ 'active': true }]);
            if (arrTab.length > 0) {
                $scope.activeTab = arrTab[0];
                return $scope.activeTab;
            }
            return null;
        }
         
        $scope.geTabByID = function (tabID) {
            var arrTab = $scope.usedTabs.whereAnd([{ 'id': tabID }]);
            if (arrTab.length > 0) {
                return arrTab[0]
            }
            return null;
        }
         
        $scope.getValidateID = function () {
            var arrValidateList = [];
            for (var i = 0 ; i < $scope.validationModels.length ; i++) {
                var validateModel = $scope.validationModels[i];
                if (validateModel.RECSTSCOD <= ($scope.accountModel.RECSTSCOD || 1)) {

                    for (var j = 0 ; j < validateModel.validationList.length ; j++)
                    {
                        var validation = validateModel.validationList[j];
                        if (validation.condition())
                        {
                            if (validation.validateID) {
                                arrValidateList.push(validation.validateID);
                            }
                        }
                    }
                  

                }
            }
            return arrValidateList;
        }

        $scope.onValidate = function () {
            var arrValidateList = $scope.getValidateID();
             
            var deferred = $q.defer();
            $q.all([
                validationDataSvc.getFieldValidation(arrValidateList)
            ]).then(function (response) {
                $timeout(function () {
                    var validationList = response[0];
                    var from = $("#frmEntry")
                    validationHelper.parseValidationList(from, validationList);

                    var isValid = from.valid();
                    var invalidFields = [];
                    var elementList = from.validate().errorList;

                    for (var i = 0 ; i < elementList.length ; i++) {
                        var ele = elementList[i].element;
                        var fieldLabelText = null;
                        if (angular.element("#" + ele.id).hasClass('autocomplete-control')) // auto complete
                        {
                            fieldLabelText = angular.element("#labelText_lb_" + ele.id.replace("_value", "")).text().replace(/(?:\r\n|\r|\n)/g, '').trim();
                        }
                        else {
                            fieldLabelText = angular.element("#labelText_lb_" + ele.id).text().replace(/(?:\r\n|\r|\n)/g, '').trim();
                        }


                        if (!mlsStringUtils.isStringEmpty(fieldLabelText)) {
                            invalidFields.push(fieldLabelText);
                        }
                        else {
                            console.log(ele.id + "Not have field label text");
                        }

                        console.log("Invalid : " + fieldLabelText);
                    }

                    deferred.resolve({
                        isValid: isValid,
                        invalidFields: invalidFields
                    })
                });

            })

            return deferred.promise;
        }
         
        $scope.onEditMode = function () {
            var defered = $q.defer();
            $scope.customerListModel = {};
            $q.all([
                $scope.getAccountDetail(),
                $scope.getAccountCustomers(),
                $scope.getGuarantor(),
                $scope.getReferencePerson(),
                $scope.setAccountAddress()
            ]).then(function () {

                angular.forEach($scope.guarantorList, function (gua, index)
                {
                    gua.readonlyCustomerInfo = true;
                })

                angular.forEach($scope.referencePersonList, function (ref, index) {
                    ref.readonlyCustomerInfo = true;
                })
                 
                defered.resolve();
            })


            return defered.promise;
        }

        $scope.onAddMode = function () {

            var defered = $q.defer();
            $scope.customerDataSource = [
                {
                    RECACTCOD: 'A',
                    open: true,
                    readonly : false,
                    AddressList: [
                        {
                            RECACTCOD: 'A',
                            open: true
                        }
                    ],
                    ADDNEW_FLAG: true
                }
            ];

            $scope.customerListModel = {};
            $scope.referencePersonList = [
                {
                    RECACTCOD: 'A',
                    open: true,
                    CUSTYPCOD: '02'
                }
            ];

            $scope.guarantorList = [
                 {
                     RECACTCOD: 'A',
                     open: true,
                     CUSTYPCOD: '02',
                     AddressList: [
                      {
                          RECACTCOD: 'A',
                          open: true
                      }
                     ]
                 }
            ];

            $scope.accountModel.RECACTCOD = "A";
            $scope.accountModel.RECSTSCOD = 1;
            $scope.accountModel.CPNCOD = "0001";

            $scope.accountAddressList = [
                        {
                            RECACTCOD: 'A',
                            open: true,
                            readonly: false,
                            ADRTYPCOD : 3
                        }
            ]

            $scope.accountAddressListModel = {};

            defered.resolve();

            return defered.promise;
        }

        $scope.initialComboBox = function () {
            var defered = $q.defer();

            $q.all([
                comboBoxDataSvc.getComboAccountDealWith(), // 0
                comboBoxDataSvc.getComboAccBusTyp(), // 1
                comboBoxDataSvc.getComboCompanyBranch(), // 2
                comboBoxDataSvc.getComboCreditType(), // 3
                comboBoxDataSvc.getComboAccountContractType(), //4
                comboBoxDataSvc.getComboCusTypCod(), //5
                comboBoxDataSvc.getComboCusTtlPsn(), //6
                comboBoxDataSvc.getComboDayOfWeek(), //7
                comboBoxDataSvc.getComboCusTtlCcp(), //8
                comboBoxDataSvc.getComboAdressTypeCode({ CUSTYPCOD: "01" }), //9
                comboBoxDataSvc.getComboAdressTypeCode({ CUSTYPCOD: "02" }), //10
                comboBoxDataSvc.getComboCocCusRel(), // 11  
                comboBoxDataSvc.getComboRejectAppReason(), // 12
                comboBoxDataSvc.getComboIRate(), // 13,
                comboBoxDataSvc.getComboFinBnkCod(), //14
                comboBoxDataSvc.getComboPayBy(), //15,
                comboBoxDataSvc.getComboAccountGrade(), //16,
                comboBoxDataSvc.getComboLendingPeriod(), //17,
                comboBoxDataSvc.getComboAccountLevel(), //18,
                comboBoxDataSvc.getComboAccountDueTerm(), //19
                comboBoxDataSvc.getComboAccountCreditTerm()//20
            ]).then(function (response) {
                $scope.listAccountDealWith = response[0];
                $scope.listAccountBusinessType = response[1];
                $scope.listBranch = response[2];
                $scope.listACCLNDTYP = response[3];
                $scope.listAccountContractType = response[4];
                $scope.customerTypeDataSource = response[5];
                $scope.titleNameIndividualDataSource = response[6];
                $scope.dayOfWeekDataSource = response[7];
                $scope.titleNameJuristicDataSource = response[8];
                $scope.addressTypeCodeJuristicDataSource = response[9];
                $scope.addressTypeCodeIndividualDataSource = response[10];
                $scope.customerRelationDataSource = response[11]
                $scope.creditDeviateDataSource = response[12]
                $scope.irRateDataSource = response[13]
                $scope.bankDataSource = response[14]
                $scope.payByDataSource = response[15]

                $scope.accountGradeDataSource = response[16]
                $scope.lendingPeriodDataSource = response[17]
                $scope.accountLevelDataSource = response[18]
                $scope.accountDueTermDataSource = response[19]
                $scope.accountCreditTermDataSource = response[20]
                defered.resolve();
            });

            return defered.promise;
        }

        $scope.$watch('accountModel.ACCDEAWTH', function (newVal, oldVal, scope) { 
            $scope.switchTab();
            $scope.getAccountConfig();
        }, true)

        $scope.$watch('accountModel.FINBNKCODCR', function (newValue, oldValue, scope) {
            if ($scope.accountModel.ACCDEAWTH == eBiz.ACCDEAWTH.Dealer)
            {
                comboBoxDataSvc.getComboFinBnkBrn({ FINBNKCOD: newValue }).then(function (data) {
                    $scope.bankBranchDataSource = data;
                })
            } 
        })

        $scope.$watch('accountModel.FINBNKCODDR', function (newValue, oldValue, scope) {
            comboBoxDataSvc.getComboFinBnkBrn({ FINBNKCOD: newValue }).then(function (data) {
                $scope.bankBranchDataSource = data;
            })
        })
         
        $scope.$watch('accountModel.ACCBUSTYP', function (value) {
             
            $q.all([
                comboBoxDataSvc.getComboAccount({
                    CPNCOD: $scope.accountModel.CPNCOD,
                    CPNBRNCOD: $scope.accountModel.CPNBRNCOD,
                    ACCBUSTYP: $scope.accountModel.ACCBUSTYP,
                    ACCDEAWTH: "VER",
                }),
                $scope.getAccountConfig()
            ]).then(function (response) {

                $scope.verifierDataSource = response[0];
            })

        }, true)
         
        $scope.$watch('accountModel.CPNBRNCOD', function (newVal, oldVal, scope) {
             
            $scope.getAccountConfig()
        }, true)
          

        $scope.$watch('customerDataSource[0]', function (newValue, oldValue, scope1) {

            if ($scope.screenModel.screenMode == eScreenMode.ADD) {
                if (newValue) {
                    var accountName = mlsStringUtils.toStringOrEmpty(newValue.CUSTTLTHA) + " " +
                                               mlsStringUtils.toStringOrEmpty(newValue.CUSNAMTHA) + " " +
                                               mlsStringUtils.toStringOrEmpty(newValue.CUSSURTHA).trim();

                    $scope.accountModel.ACCNAMTHA = accountName.trim();
                }

            }
        }, true)

        $scope.switchTab = function () {
            $scope.usedTabs = [];
            angular.forEach($scope.tabs, function (tab, idx) {
                var isShown = false;
                if (tab.isShown) {
                    if (typeof tab.isShown == 'function') {
                        isShown = tab.isShown();
                    }
                    else {
                        isShown = tab.isShown;
                    }

                    if (isShown) {

                        this.push(tab);
                    }
                }
            }, $scope.usedTabs);

            $scope.usedTabs[0].active = true;
        }

        $scope.initialComponent = function () {
            var dialog = mlsLoadingDialog.show();
            var defered = null;
            $scope.initialScreenMode();
            $scope.initialComboBox().then(function () {
                if ($scope.screenModel.screenMode == eScreenMode.ADD) {
                    defered = $scope.onAddMode();
                }
                else if ($scope.screenModel.screenMode == eScreenMode.EDIT) {

                    defered = $scope.onEditMode();
                }

                defered.then(function () {
                    dialog.close();
                    $rootScope.$broadcast("initial-data-complete", { accountModel: $scope.accountModel });
                })
            });
             
        }
         
        $scope.screenModel = {
            purpose: $stateParams.purpose,
            isReadonly: false
        }

        $scope.showProcessCompleteDialog = function () {
            var ok = mlsDialog.showInfoDialog({ message: "Process complete", messaeCode: "INF002" }, {
                closeByDocument: false,
                showClose: false,
                closeByEscape: false
            });

            return ok;
        }
         
        $scope.onSave = function () {
            var defered = $q.defer();

            var customerList = angular.copy($scope.customerDataSource);
            var customerListModel = angular.copy($scope.customerListModel);
            if (customerListModel.deleteList)
            {
                customerList = customerList.concat(customerListModel.deleteList)
            }
          
            angular.forEach(customerList, function (cus, index) {
                if (cus.RECACTCOD != 'I') {
                    if (cus.AddressList) {
                        cus.AddressList = cus.AddressList.concat(cus.AddressListModel.deleteList); // contact array of delete list , for inactive deleted addresss
                    }

                }
            })

            $scope.accountModel.ReferencePersonList = $scope.referencePersonList.concat($scope.referencePersonListModel.deleteList);
            $scope.accountModel.GuarantorList = $scope.guarantorList.concat($scope.guarantorListModel.deleteList);
        
            if ($scope.accountConfig.ShowRefType == eAccountConfig.ShowRefType.NONE)
            {
                $scope.accountModel.ReferencePersonList = [];
                $scope.accountModel.GuarantorList = [];
            }
            else if ($scope.accountConfig.ShowRefType == eAccountConfig.ShowRefType.GUA)
            {
                $scope.accountModel.ReferencePersonList = [];
            }
            else if ($scope.accountConfig.ShowRefType == eAccountConfig.ShowRefType.REF)
            {
                $scope.accountModel.GuarantorList = [];
            } 


            $scope.accountModel.CustomerList = customerList;
            $scope.accountModel.AddressList = $scope.accountAddressList.concat($scope.accountAddressListModel.deleteList);
            //if ($scope.screenModel.screenMode == eScreenMode.ADD)
            //{
            //    if (customerList.length > 0) {
            //        $scope.accountModel.ACCNAMTHA = mlsStringUtils.toStringOrEmpty(customerList[0].CUSTTLTHA) + " " + mlsStringUtils.toStringOrEmpty(customerList[0].CUSNAMTHA) + " " + mlsStringUtils.toStringOrEmpty(customerList[0].CUSSURTHA)
            //        $scope.accountModel.ACCNAMTHA = $scope.accountModel.ACCNAMTHA.trim();
            //    }

            //}

            accountDataSvc.InsertOrUpdateAccount($scope.accountModel, $rootScope.Username).then(function (data) {

                angular.forEach(data, function (val, key) {
                    $scope.accountModel[key] = val;
                })
                $scope.screenModel.screenMode = eScreenMode.EDIT;
                defered.resolve();

            });

            return defered.promise;

        }

        $scope.onVerify = function ()
        {
            var defered = $q.defer();
            accountDataSvc.verifyAccount($scope.accountModel, $rootScope.Username).then(function (data) {
                defered.resolve();
            });

            return defered.promise;
        }

        $scope.onSendBack = function ()
        {
            var defered = $q.defer();
            accountDataSvc.sendBackAccount($scope.accountModel, $rootScope.Username).then(function (data) {
                defered.resolve();
            });

            return defered.promise;
        }

        $scope.onGenAccount = function()
        {
            var defered = $q.defer();
            accountDataSvc.genAccount($scope.accountModel, $rootScope.Username).then(function (data) {
                defered.resolve();
            });

            return defered.promise; 
        }

        $scope.showSearchCustomerDialog = function (dialogParam) {
              
            var entity = dialogParam.currentCustomer;
            var oldCustomer = angular.copy(entity);
            var index = dialogParam.customerDataSource.indexOf(entity);

            var confirm = mlsCustomerSearchDialog.show({
                dialogParam: {
                    listLabelText: {
                        idLabelText: $scope.listLabelText.idLabelText,
                        nameLabelText: $scope.listLabelText.nameLabelText,
                        surnameLabelText: $scope.listLabelText.lastNameLabelText,
                        customerTypeLabelText: $scope.listLabelText.customerTypeLabelText,
                    },
                    customerTypeDataSource: $scope.customerTypeDataSource,
                    customerDisplayMembers: 'DISTHA',
                    customerValueMembers: 'TABKEYTWO',
                    staticCriteria: dialogParam.staticCriteria
                }
            });

            confirm.then(function (data) {
                var selectedCustomer = data.dialogModel.selectedCustomer;
                entity = angular.copy(data.dialogModel.selectedCustomer);
                if (index != -1) {
                    entity.open = true;
                    dialogParam.customerDataSource[index] = {};
                    dialogParam.customerDataSource[index] = entity;
                    $scope.setCustomerAddress(dialogParam.customerDataSource[index]);
                    if (dialogParam.purpose == "CUSTOMER") {
                        $scope.setReadonly(dialogParam.customerDataSource[index]);
                    }
                    else if (dialogParam.purpose == "GUARANTOR" || dialogParam.purpose == "REFERENCE_PERSON") {
                        dialogParam.customerDataSource[index].readonlyCustomerInfo = true;
                    } 
                    dialogParam.customerDataSource[index].ADDNEW_FLAG = true;
                }

                oldCustomer.RECACTCOD = "I";
                dialogParam.customerListModel.deleteList.push(oldCustomer) 
            })
        }

        $scope.setAccountAddress = function () {
            var defered = $q.defer();
             
            addressDataSvc.getCustomerAddress({ CUSCOD: $scope.accountCriteria.GENAPPNUM }).then(function (addressList) {
                $scope.accountAddressListModel = {}; // clear addresslist model
                $scope.accountAddressList = addressList;
                defered.resolve();
            })

            return defered.promise;
        }


        $scope.setCustomerAddress = function (customer) {
            var defered = $q.defer();
            addressDataSvc.getCustomerAddress({ CUSCOD: customer.CUSCOD }).then(function (addressList) {
                customer.AddressListModel = {}; // clear addresslist model
                customer.AddressList = addressList;
                defered.resolve();
            })

            return defered.promise;
        }

        $scope.clearCustomerInfo = function (customer) {
            angular.forEach(customerDataSvc.customerInfoField, function (value, key) {
                customer[value] = null;
            })
        }

        $scope.getCustomerInfo = function (params) {
            var currentCustomer = params.currentCustomer;
            debugger
            var purpose = params.purpose;
            var dialog = mlsLoadingDialog.show();
            var oldCustomer = angular.copy(currentCustomer);
            var defered = $q.defer();

            var ID = currentCustomer.CUSTYPCOD == eBiz.CUSTYPCOD.JuristicPerson ? currentCustomer.CPNREGNUM : currentCustomer.PSNREGIDN;

            customerDataSvc.getCustomerInfo({
                ID: ID,
                CUSTYPCOD: currentCustomer.CUSTYPCOD
            }).then(function (cusInfo) {
                $scope.clearCustomerInfo(currentCustomer);
                if (cusInfo) {
                    if (cusInfo) {
                        angular.forEach(customerDataSvc.customerInfoField, function (value, key) {
                            currentCustomer[value] = cusInfo[value];
                        })
                        currentCustomer.ADDNEW_FLAG = true;
                    }

                    $scope.setCustomerAddress(currentCustomer);
                    if (purpose == "CUSTOMER")
                    {
                        $scope.setReadonly(currentCustomer);
                        $scope.customerListModel.deleteList.push(oldCustomer);
                    }
                    else if (purpose == "GUARANTOR")
                    {
                        currentCustomer.readonlyCustomerInfo = true;
                        $scope.guarantorListModel.deleteList.push(oldCustomer);
                    }
                   
                    oldCustomer.RECACTCOD = "I";
                  


                }
                defered.resolve();
                dialog.close();
            }, function ()
            {
                dialog.close();
                defered.reject();
            })

            return defered.promise;
        }

        $scope.changeAccountCode = function () {
            if ($scope.assignManual) {
                $scope.assignManual = false;
                $scope.assignAccountCodeText = "Assign";
            }
            else
            {
                $scope.assignManual = true;
                $scope.assignAccountCodeText = "OK";
            }
            
        }

        $scope.initialComponent(); 
    }]);