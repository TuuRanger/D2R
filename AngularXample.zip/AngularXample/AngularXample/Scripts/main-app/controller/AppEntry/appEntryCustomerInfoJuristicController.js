﻿angular.module('mainApp').controller('appEntryCustomerInfoJuristicController', ['$scope', '$rootScope', 'telLogDataSvc', function ($scope, $rootScope, telLogDataSvc)
{



}]);