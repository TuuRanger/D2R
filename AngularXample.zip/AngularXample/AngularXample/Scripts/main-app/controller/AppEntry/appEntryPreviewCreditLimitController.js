﻿angular.module('mainApp').controller('appEntryPreviewCreditLimitController', [
    '$scope', 'comboBoxDataSvc', '$rootScope', 'mlsStringUtils', 'financeCalcDataSvc', '$q', '$timeout', 'numberHelper', 'eBiz', 'setupDataSvc',
    function ($scope, comboBoxDataSvc, $rootScope, mlsStringUtils, financeCalcDataSvc, $q, $timeout, numberHelper, eBiz, setupDataSvc)
    {
        $scope.AppEntrybase = $("[ng-controller=appEntryController]").scope()
        $scope.tempRoundByProduct = {};

        $scope.$watch('AppEntrybase.campaignDetail.ShowInterestType', function (newVal, oldVal, scope)
        {
            if (newVal == "DD")
            {
                comboBoxDataSvc.getComboInterestRate({ CONAPPLY_PROJEC: $scope.contractDetail.CONAPPLY_PROJEC }).then(function (data)
                {
                    $scope.listInserestRte = data
                })
            }

        })

        $scope.$watch('contractDetail.CONINTRTE', function (newVal, oldVal, scope)
        {
            var CONINTRTE = newVal;
            if ($scope.AppEntrybase.campaignDetail.INCOMERTE + $scope.AppEntrybase.campaignDetail.CRDUSGRTE > 0)
            {
                var divider = $scope.AppEntrybase.campaignDetail.INCOMERTE + $scope.AppEntrybase.campaignDetail.CRDUSGRTE
                $scope.contractDetail.INCOMERTE = ($scope.AppEntrybase.campaignDetail.INCOMERTE * CONINTRTE) / divider
                $scope.contractDetail.CRUSGRTE = ($scope.AppEntrybase.campaignDetail.CRDUSGRTE * CONINTRTE) / divider
                //$scope.contractDetail.INCOMERTE = (($scope.AppEntrybase.campaignDetail.INCOMERTE * CONINTRTE) / divider).round(2)
                //$scope.contractDetail.CRUSGRTE = (($scope.AppEntrybase.campaignDetail.CRDUSGRTE * CONINTRTE) / divider).round(2)
            }
        })

        var onInitialData = $rootScope.$on("initial-contract-data-complete", function (event, args)
        { 
            $scope.reCalcInstallment();
        })

        $scope.initialComboBox = function ()
        {
            comboBoxDataSvc.getComboDownCondition().then(function (data)
            {
                $scope.listDownCondition = data
            })

        }

        $scope.$watch('AppEntrybase.campaignDetail.CONINTCAL', function (newVal, oldVal, scope)
        {
            comboBoxDataSvc.getComboInserestCalcCondtion({ TABKEYTWO: $scope.AppEntrybase.campaignDetail.CONINTCAL == "*" ? "" : $scope.AppEntrybase.campaignDetail.CONINTCAL }).then(function (data)
            {
                $scope.listInserestCalcCondtion = data
            })
        })

        $scope.$watch('AppEntrybase.campaignDetail.CONINTTYP', function (newVal, oldVal, scope)
        {
            comboBoxDataSvc.getComboInterestType({ TABKEYTWO: $scope.AppEntrybase.campaignDetail.CONINTTYP == "*" ? "" : $scope.AppEntrybase.campaignDetail.CONINTTYP }).then(function (data)
            {
                $scope.listInterestType = data
            })
        })

        $scope.initialComponents = function ()
        {
            $scope.initialComboBox();
        }


        $scope.getInstallmentRounding = function ()
        { 
            var defered = $q.defer();
            if ($scope.AppEntrybase.campaignDetail.InstallmentRoundBy == eBiz.InstallmentRoundBy.PROJECT)
            {
                defered.resolve({
                    RountTo: $scope.AppEntrybase.campaignDetail.InstallmentAmountRoundTo,
                    RountFactor: $scope.AppEntrybase.campaignDetail.InstallmentAmountRoundFactor
                });
            }
            else if ($scope.AppEntrybase.campaignDetail.InstallmentRoundBy == eBiz.InstallmentRoundBy.PRODUCT)
            {
                if ($scope.tempRoundByProduct.TABKEYTWO != $scope.contractDetail.PRDMDLCOD)
                {
                    setupDataSvc.getSetup({ TABKEYONE: "ROUNDUP" + $scope.contractDetail.CONAPPLY_PROJEC, TABKEYTWO: $scope.contractDetail.PRDMDLCOD }).then(function (data)
                    {
                        $scope.tempRoundByProduct = data[0];
                        defered.resolve({
                            RountTo: data[0].TABSETAMT1,
                            RountFactor: data[0].TABSETAMT2
                        });
                    })
                }
                else
                {
                    defered.resolve({
                        RountTo: $scope.tempRoundByProduct.TABSETAMT1,
                        RountFactor: $scope.tempRoundByProduct.TABSETAMT2
                    });
                }
            }
            return defered.promise;
        }

        $scope.reCalcInstallment = function ()
        { 
            if ($scope.contractDetail)
            { 
                if ($scope.contractDetail.CRDNXTSTP >= $scope.getTabByID("tabPreviewCredit").CRDNXTSTP || $scope.getActiveTab().id == "tabPreviewCredit")
                {
                    var promiseInstallmentRound = $scope.getInstallmentRounding();
                    promiseInstallmentRound.then(function (installmentRound)
                    { 
                        financeCalcDataSvc.installmentCalc(
                                                 $scope.contractDetail.CONFINAMT,
                                                 $scope.contractDetail.CONLNDTRM,
                                                 $scope.contractDetail.CONINTRTE,
                                                 $scope.contractDetail.CONINTTYP,
                                                 $scope.contractDetail.CONINSPER,
                                                 $scope.contractDetail.CONINTCAL,
                                                 $scope.contractDetail.CONINTPER,
                                                 $scope.contractDetail.CONIRATE,
                                                 $scope.contractDetail.CONFRATE,
                                                 $scope.contractDetail.CONIRATEBNKREF,
                                                 $scope.contractDetail.CONBLNAMT,
                                                 $scope.contractDetail.SUBSDYAMT,
                                                 installmentRound.RountTo,
                                                 installmentRound.RountFactor,
                                                 $scope.contractDetail.IsInstallmentEquals,
                                                 $scope.contractDetail.LoanAmountRoundTo,
                                                 $scope.contractDetail.LoanAmountRoundFactor).then(function (installmentCalcResult)
                                                 {
                                                     $scope.contractDetail.CONLNDAMT = installmentCalcResult.CONLNDAMT
                                                     $scope.contractDetail.CONINSAMT = installmentCalcResult.CONINSAMT
                                                     $scope.contractDetail.CONEFFRTE = installmentCalcResult.CONEFFRTE
                                                     $scope.calculateInstallmentGross();
                                                     $scope.calculateLendindGross();
                                                     $scope.getInstallmentTable();
                                                 });
                    })

                }
            }
        }

        $scope.reCalTerm = function ()
        {

            if ($scope.contractDetail)
            {
                if ($scope.getActiveTab().id == "tabPreviewCredit")
                {
                    var promiseInstallmentRound = $scope.getInstallmentRounding();
                    promiseInstallmentRound.then(function (installmentRound)
                    {
                        financeCalcDataSvc.termCalc(
                                         $scope.contractDetail.CONFINAMT,
                                         $scope.contractDetail.CONINSAMT,
                                         $scope.contractDetail.CONINTRTE,
                                         $scope.contractDetail.CONINTTYP,
                                         $scope.contractDetail.CONINSPER,
                                         $scope.contractDetail.CONINTCAL,
                                         $scope.contractDetail.CONINTPER,
                                         $scope.contractDetail.CONIRATE,
                                         $scope.contractDetail.CONFRATE,
                                         $scope.contractDetail.CONIRATEBNKREF,
                                         $scope.contractDetail.CONBLNAMT,
                                         $scope.contractDetail.SUBSDYAMT,
                                         installmentRound.RountTo,
                                         installmentRound.RountFactor,
                                         $scope.contractDetail.IsInstallmentEquals,
                                         $scope.contractDetail.LoanAmountRoundTo,
                                         $scope.contractDetail.LoanAmountRoundFactor).then(function (data)
                                         {
                                             $scope.contractDetail.CONEFFRTE = data.CONEFFRTE
                                             $scope.contractDetail.CONLNDAMT = data.CONLNDAMT
                                             $scope.contractDetail.CONINSAMT = data.CONINSAMT
                                             $scope.contractDetail.CONLNDTRM = data.CONLNDTRM
                                             $scope.calculateInstallmentGross();
                                             $scope.calculateLendindGross();
                                             $scope.getInstallmentTable();
                                         })
                    })

                }
            }
        }

        $scope.getInstallmentTable = function ()
        {
            financeCalcDataSvc.getInstallmentTable($scope.contractDetail.ACCBUSTYP,
                                                                                $scope.contractDetail.CONDUEDAY,
                                                                                $scope.contractDetail.CONFINAMT,
                                                                                $scope.contractDetail.CONLNDTRM,
                                                                                $scope.contractDetail.CONLNDAMT,
                                                                                $scope.contractDetail.CONINSAMT,
                                                                                $scope.contractDetail.CONEFFRTE,
                                                                                $scope.contractDetail.CONINTRTE,
                                                                                $scope.contractDetail.INCOMERTE,
                                                                                $scope.contractDetail.CRUSGRTE,
                                                                                $scope.contractDetail.CONEFFDTE,
                                                                                $scope.contractDetail.CONSTRINS,
                                                                                $scope.contractDetail.CONSECINS,
                                                                                $scope.contractDetail.CONINTPER,
                                                                                $scope.contractDetail.SUBSDYAMT,
                                                                                $scope.contractDetail.CONINTCAL).then(function (data)
                                                                                {
                                                                                    $timeout(function ()
                                                                                    {
                                                                                        $scope.listInstallmentTableResult = data;
                                                                                    })

                                                                                })
        }

        $scope.initialComponents();

        $scope.calcCONFINAMT = function ()
        {
            $scope.contractDetail.CONFINGRS = $scope.contractDetail.CONPRDGRS - $scope.contractDetail.CONDWNGRS
            $scope.contractDetail.CONFINAMT = $scope.contractDetail.CONPRDAMT - $scope.contractDetail.CONDWNAMT
            $scope.contractDetail.CONFINTAX = $scope.contractDetail.CONPRDTAX - $scope.contractDetail.CONDWNTAX
            $scope.reCalcInstallment();
        }

        /*Product Gross*/
        $scope.txtCONPRDGRS_Changed = function ()
        {
            var CONPRDGRS = numberHelper.toDecimalOrZero($scope.contractDetail.CONPRDGRS)
            var taxPercent = numberHelper.toDecimalOrZero($scope.contractDetail.ContractTaxPercent)
            var tax = CONPRDGRS.getTaxByGross(taxPercent);
            $scope.contractDetail.CONPRDTAX = tax;
            $scope.contractDetail.CONPRDAMT = CONPRDGRS - tax;
            $scope.calcCONFINAMT();
        }


        /*Product Amount*/
        $scope.txtCONPRDAMT_Changed = function ()
        {
            var CONPRDAMT = numberHelper.toDecimalOrZero($scope.contractDetail.CONPRDAMT)
            var taxPercent = numberHelper.toDecimalOrZero($scope.contractDetail.ContractTaxPercent)
            var tax = CONPRDAMT.getTaxByNet(taxPercent);
            $scope.contractDetail.CONPRDTAX = tax;
            $scope.contractDetail.CONPRDGRS = CONPRDAMT + tax;
            $scope.calcCONFINAMT();
        }

        /*Down gross*/
        $scope.txtCONDWNGRS_Changed = function ()
        {
            var CONDWNGRS = numberHelper.toDecimalOrZero($scope.contractDetail.CONDWNGRS)
            var taxPercent = numberHelper.toDecimalOrZero($scope.contractDetail.ContractTaxPercent)
            var tax = CONDWNGRS.getTaxByGross(taxPercent);
            $scope.contractDetail.CONDWNTAX = tax;
            $scope.contractDetail.CONDWNAMT = CONDWNGRS - tax;
            $scope.calcCONFINAMT();
        }

        /*Down amount*/
        $scope.txtCONDWNAMT_Changed = function ()
        {
            var CONDWNAMT = numberHelper.toDecimalOrZero($scope.contractDetail.CONDWNAMT)
            var taxPercent = numberHelper.toDecimalOrZero($scope.contractDetail.ContractTaxPercent)
            var tax = CONDWNAMT.getTaxByNet(taxPercent);
            $scope.contractDetail.CONDWNTAX = tax;
            $scope.contractDetail.CONDWNGRS = CONDWNAMT + tax;
            $scope.calcCONFINAMT();
        }

        /*Installment Gross*/
        $scope.txtCONINSGRS_Changed = function ()
        {
            var CONINSGRS = numberHelper.toDecimalOrZero($scope.contractDetail.CONINSGRS)
            var taxPercent = numberHelper.toDecimalOrZero($scope.contractDetail.ContractTaxPercent)
            var tax = CONINSGRS.getTaxByGross(taxPercent);
            $scope.contractDetail.CONINSTAX = tax;
            $scope.contractDetail.CONINSNAMT = CONINSGRS - tax;
            $scope.reCalTerm();
        }

        /*InstallmentAmount Gross*/
        $scope.txtCONINSAMT_Changed = function ()
        {
            $scope.calculateInstallmentGross();
            $scope.reCalTerm();
        }

        $scope.txtCONBLNGRS_Changed = function ()
        {
            var CONBLNGRS = numberHelper.toDecimalOrZero($scope.contractDetail.CONBLNGRS)
            var taxPercent = numberHelper.toDecimalOrZero($scope.contractDetail.ContractTaxPercent)
            var tax = CONBLNGRS.getTaxByGross(taxPercent);
            $scope.contractDetail.CONBLNTAX = tax;
            $scope.contractDetail.CONBLNAMT = CONBLNGRS - tax;
        }


        $scope.txtCONBLNAMT_Changed = function ()
        {
            var CONBLNAMT = numberHelper.toDecimalOrZero($scope.contractDetail.CONBLNAMT)
            var taxPercent = numberHelper.toDecimalOrZero($scope.contractDetail.ContractTaxPercent)
            var tax = CONBLNAMT.getTaxByNet(taxPercent);
            $scope.contractDetail.CONBLNTAX = tax;
            $scope.contractDetail.CONBLNGRS = CONBLNAMT + tax;
        }



        $scope.txtSUBSDYGRS_Changed = function ()
        {
            var SUBSDYGRS = numberHelper.toDecimalOrZero($scope.contractDetail.SUBSDYGRS)
            var taxPercent = numberHelper.toDecimalOrZero($scope.contractDetail.ContractTaxPercent)
            var tax = SUBSDYGRS.getTaxByGross(taxPercent);
            $scope.contractDetail.SUBSDYTAX = tax;
            $scope.contractDetail.SUBSDYAMT = SUBSDYGRS - tax;
        }


        $scope.txtSUBSDYAMT_Changed = function ()
        {
            var SUBSDYAMT = numberHelper.toDecimalOrZero($scope.contractDetail.SUBSDYAMT)
            var taxPercent = numberHelper.toDecimalOrZero($scope.contractDetail.ContractTaxPercent)
            var tax = SUBSDYAMT.getTaxByNet(taxPercent);
            $scope.contractDetail.SUBSDYTAX = tax;
            $scope.contractDetail.SUBSDYGRS = SUBSDYAMT + tax;
        }


        /*this function create for multiple place in controller*/
        $scope.calculateInstallmentGross = function ()
        {
            var CONINSAMT = numberHelper.toDecimalOrZero($scope.contractDetail.CONINSAMT)
            var taxPercent = numberHelper.toDecimalOrZero($scope.contractDetail.ContractTaxPercent)
            var tax = CONINSAMT.getTaxByNet(taxPercent);
            $scope.contractDetail.CONINSTAX = tax;
            $scope.contractDetail.CONINSGRS = tax + CONINSAMT;
        }

        $scope.calculateLendindGross = function ()
        {
            var CONLNDAMT = numberHelper.toDecimalOrZero($scope.contractDetail.CONLNDAMT)
            var taxPercent = numberHelper.toDecimalOrZero($scope.contractDetail.ContractTaxPercent)
            var tax = CONLNDAMT.getTaxByNet(taxPercent);
            $scope.contractDetail.CONLNDTAX = tax;
            $scope.contractDetail.CONLNDGRS = tax + CONLNDAMT;
        }

        $scope.txtCONLNDTRM_Change = function ()
        {
            $scope.reCalcInstallment();
        }

        $scope.$watch('contractDetail.CONINTCAL', function (newVal, oldVal, scope)
        {
            if (newVal && (newVal != oldVal))
            {
                $scope.reCalcInstallment();
            }

        })

        $scope.$on('$destroy', function () {
            if (typeof onInitialData == 'function') {
                onInitialData();
                console.log("unbind onInitialData complete")
            }
        })

    }]);