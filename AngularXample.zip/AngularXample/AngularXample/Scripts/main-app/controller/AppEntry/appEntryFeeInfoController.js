﻿angular.module('mainApp').controller('appEntryFeeInfoController',
    ['$scope', '$rootScope', 'feeDataSvc', 'numberHelper',
    function ($scope, $rootScope, feeDataSvc, numberHelper)
    {
        var appEntryScope = null;
        var onInitialData = $rootScope.$on("initial-contract-data-complete", function (event, args)
        {
            appEntryScope = args.scope; 
            if ($scope.nextStepTab.id == 'tabFeeInfo' || $scope.isCanGetData('tabFeeInfo')) // get data when tab active or first load
            {
                $scope.loadFeeList(appEntryScope.contractCriteria);
            } 
        })

        $scope.loadFeeList = function (criteria)
        {
            feeDataSvc.getFeeList(criteria).then(function (data)
            { 
                appEntryScope.feeList = data;
            })
        }

        $scope.recalculateFee = function ()
        {
            /*footer Total Fee*/
            $scope.feeSummary.feeTotalNet = 0;
            $scope.feeSummary.feeTotalGrs = 0;
            $scope.feeSummary.feeTotalTax = 0;

            /*footer Pay Fee*/
            $scope.feeSummary.feePayNet = 0;
            $scope.feeSummary.feePayGrs = 0;
            $scope.feeSummary.feePayTax = 0;

            /*footer Waiver Fee*/
            $scope.feeSummary.feeWaiverNet = 0;
            $scope.feeSummary.feeWaiverGrs = 0;
            $scope.feeSummary.feeWaiverTax = 0;

            var feeList = $scope.feeList;
             
            if (feeList)
            {
                for(var i = 0 ; i < feeList.length ; i ++)
                {
                    var fee = feeList[i];
                    fee.FEETAX = fee.FEEGRS.getTaxByGross(fee.TAXPCN);
                    fee.FEENET = fee.FEEGRS - fee.FEETAX
                    $scope.feeSummary.feeTotalNet += numberHelper.toDecimalOrZero(fee.FEENET);
                    $scope.feeSummary.feeTotalGrs += numberHelper.toDecimalOrZero(fee.FEEGRS);
                    $scope.feeSummary.feeTotalTax += numberHelper.toDecimalOrZero(fee.FEETAX);

                    if (fee.FEEWAIVER != "Y")
                    {
                        $scope.feeSummary.feePayNet += numberHelper.toDecimalOrZero(fee.FEENET);
                        $scope.feeSummary.feePayGrs += numberHelper.toDecimalOrZero(fee.FEEGRS);
                        $scope.feeSummary.feePayTax += numberHelper.toDecimalOrZero(fee.FEETAX);
                    }
                    else
                    {
                        $scope.feeSummary.feeWaiverNet += numberHelper.toDecimalOrZero(fee.FEENET)
                        $scope.feeSummary.feeWaiverGrs += numberHelper.toDecimalOrZero(fee.FEEGRS)
                        $scope.feeSummary.feeWaiverTax += numberHelper.toDecimalOrZero(fee.FEETAX)
                    }

                    feeList[i] = fee;
                } 
            }
        }

        $scope.$watch('feeList', function (newVal, oldVal)
        { 
            $scope.recalculateFee();
        },
        true);

        $scope.$on('$destroy', function () {
            if (typeof onInitialData == 'function') {
                onInitialData();
                console.log("unbind onInitialData complete")
            }
        })

    }]);