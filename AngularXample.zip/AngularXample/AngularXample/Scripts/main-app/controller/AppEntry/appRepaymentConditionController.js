﻿mainApp.controller('appRepaymentConditionController', ['$scope', '$rootScope', 'referencePersonDataSvc', 'comboBoxDataSvc', 'addressDataSvc', '$q', 'guarantorPersonDataSvc',
    function ($scope, $rootScope, referencePersonDataSvc, comboBoxDataSvc, addressDataSvc, $q, guarantorPersonDataSvc) {
        var appEntryScope = null;
       
        $q.all([
            comboBoxDataSvc.getComboPayType(),
            comboBoxDataSvc.getComboCONDUEDAY(),
            comboBoxDataSvc.getComboDownCondition()
        ]).then(function (response)
        {
            $scope.listPayType = response[0]
            $scope.listCONDUEDAY = response[1]
            $scope.listDownCondition = response[2] 

        })
    }]);