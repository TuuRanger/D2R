﻿angular.module('mainApp').controller('appEntryCustomerInfoController', ['$scope', 'mlsStringUtils', 'comboBoxDataSvc', '$q', function ($scope, mlsStringUtils, comboBoxDataSvc, $q)
{
    $scope.$watch('contractDetail.PSNBTHDTE', function (newValue, oldValue, scope)
    {
        if (newValue)
        {
            if (newValue)
            { 
                //if (typeof newValue.getDay == 'function')
                //{
                    $scope.contractDetail.PSNBTHDAY = newValue.toDate().getDay();
                //}
            }
        }
    })



    $scope.$watch('contractDetail.CONAPPLY_VIA', function (newValue, oldValue, scope)
    {
        comboBoxDataSvc.getComboConApplyViaBrn({ CONAPPLY_VIA: $scope.contractDetail.CONAPPLY_VIA }).then(function (data)
        {
            $scope.listConApplyViaBrn = data;
        })
    });
     
    $scope.$watch('contractDetail.ACCBUSTYP', function (newValue, oldValue, scope)
    {
        comboBoxDataSvc.getComboMarketing({
            CPNCOD: $scope.contractDetail.CPNCOD,
            CPNBRNCOD: $scope.contractDetail.CPNBRNCOD,
            ACCBUSTYP: $scope.contractDetail.ACCBUSTYP,
            ACCDEAWTH: 'MKT'
        }).then(function (data)
        {
            $scope.listcboACCCODMKT = data;
        })
    });
     

    

}]);