﻿angular.module('mainApp').controller('appEntryProductInfoController', ['$scope', '$rootScope', 'comboBoxDataSvc', 'mlsStringUtils', 'productDataSvc', '$q', 'eBiz','$timeout',
    function ($scope, $rootScope, comboBoxDataSvc, mlsStringUtils, productDataSvc, $q, eBiz, $timeout) {
        $scope.AppEntrybase = $("[ng-controller=appEntryController]").scope()
        $scope.productSpec = {};
        $scope.inputListDataSource = [];
         

        var onInitialData =  $rootScope.$on("initial-contract-data-complete", function (event, args)
        { 
            $scope.loadProductSpecInputField(args.contractDetail.PRDSUBCOD).then(function () { 
                productDataSvc.getProductDetail($scope.contractCriteria).then(function (data) {
                    $scope.AppEntrybase.productSpec = data;
                    $scope.productSpec = data
                })
            })

            $scope.$watch('contractDetail.PRDGRPCOD', function (newVal, oldVal, scope) {
                if (mlsStringUtils.isStringEmpty(newVal)) {
                    $scope.listPrdSubCod = [];
                }
                else {
                    comboBoxDataSvc.getComboProductSubCode({ PRDGRPCOD: newVal }).then(function (data) {
                        $scope.listPrdSubCod = data;
                    })
                }
            })

            $scope.$watch('contractDetail.PRDSUBCOD', function (newVal, oldVal, scope) {
                if (mlsStringUtils.isStringEmpty(newVal)) {
                    $scope.listPrdBrnCod = [];
                    $scope.inputListDataSource = [];
                }
                else {
                    comboBoxDataSvc.getComboProductBrand({
                        PRDGRPCOD: $scope.contractDetail.PRDGRPCOD,
                        PRDSUBCOD: newVal,
                        CONAPPLY_PROJEC: $scope.contractDetail.CONAPPLY_PROJEC
                    }).then(function (data) {
                        $scope.listPrdBrnCod = data;
                    })

                    $scope.loadProductSpecInputField(newVal).then(function (result) { 
                        productDataSvc.getProductDetail($scope.contractCriteria).then(function (data) {
                            $scope.AppEntrybase.productSpec = data;
                            $scope.productSpec = data
                        })
                    })
                }

            })

            $scope.$watch('productSpec', function (newVal, oldVal, scope) {
                $scope.AppEntrybase.productSpec = newVal;
            }, true)

            $scope.$watch('contractDetail.PRDBRNCOD', function (newVal, oldVal, scope) {
                if (mlsStringUtils.isStringEmpty(newVal)) {
                    $scope.listPrdMdlCod = [];
                }
                else {
                    comboBoxDataSvc.getComboProductModel({
                        PRDGRPCOD: $scope.contractDetail.PRDGRPCOD,
                        PRDSUBCOD: $scope.contractDetail.PRDSUBCOD,
                        Brnad: newVal,
                        CONAPPLY_PROJEC: $scope.contractDetail.CONAPPLY_PROJEC
                    }).then(function (data) {
                        $scope.listPrdMdlCod = data;
                    })
                }
            })

            $scope.cboPrdMdlCod_Change = function ()
            { 
                comboBoxDataSvc.getComboProductModel({
                    PRDGRPCOD: $scope.contractDetail.PRDGRPCOD,
                    PRDSUBCOD: $scope.contractDetail.PRDSUBCOD,
                    Brnad: $scope.contractDetail.PRDBRNCOD,
                    CONAPPLY_PROJEC: $scope.contractDetail.CONAPPLY_PROJEC,
                    ModelInput: $scope.contractDetail.PRDMDLCOD
                }).then(function (data) {
                    if (data.length > 0) {

                        $scope.contractDetail.PRDSALPRC = data[0].PRDSALPRC;
                    }

                })
            }

            $scope.cboPRDGRPCOD_Change = function ()
            {
                 
                $scope.contractDetail.PRDSUBCOD = null;

            }

            /*$scope.$watch('contractDetail.PRDMDLCOD', function (newVal, oldVal, scope) {
                if (!$scope.isFirstInit)
                {
                    comboBoxDataSvc.getComboProductModel({
                        PRDGRPCOD: $scope.contractDetail.PRDGRPCOD,
                        PRDSUBCOD: $scope.contractDetail.PRDSUBCOD,
                        Brnad: $scope.contractDetail.PRDBRNCOD,
                        CONAPPLY_PROJEC: $scope.contractDetail.CONAPPLY_PROJEC,
                        ModelInput: newVal
                    }).then(function (data) {
                        if (data.length > 0) {

                            $scope.contractDetail.PRDSALPRC = data[0].PRDSALPRC;
                        }

                    })
                } 
            })*/


            $scope.$watch('contractDetail.CONOBJCOD', function (newValue, oldValue, scope) {
                $scope.initialComboBoxData();
            }, true)




        })

        $scope.initialComboBoxData = function () {
            $q.all([
                comboBoxDataSvc.getComboProductGroupCode(),
                comboBoxDataSvc.getComboProductType()
            ]).then(function (response) {
                $scope.listPrdGrpCod = response[0];
                $scope.listPRDTYPE = response[1]
            })

        }

        $scope.loadProductSpecInputField = function (ProductSubCode) {
            var defer = $q.defer();
            if (mlsStringUtils.isStringEmpty(ProductSubCode)) {
                defer.reject();
            }
            else {
                productDataSvc.getProductSpecInputField({
                    PRDGRPCOD: $scope.contractDetail.PRDGRPCOD,
                    PRDSUBCOD: ProductSubCode
                }).then(function (items) {
                    $scope.inputListDataSource = items;
                   
                    defer.resolve();
                })
            }

            return defer.promise;
        }

        $scope.$on('$destroy', function () {
            if (typeof onInitialData == 'function') {
                onInitialData();
                console.log("unbind onInitialData complete")
            }
        })

        
    }]);