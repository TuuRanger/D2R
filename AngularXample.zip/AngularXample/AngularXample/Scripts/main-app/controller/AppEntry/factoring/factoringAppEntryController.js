﻿angular.module('mainApp').controller('factoringAppEntryController', ['$scope', '$stateParams', '$state', '$rootScope', '$location', 'comboBoxDataSvc', '$q', 'eBiz', 'mlsUrlSvc', 'mlsStringUtils', 'eScreenMode', 'mlsLoadingDialog', 'mlsDialog', 'locationHelper', 'validationDataSvc', '$timeout', 'validationHelper', 'mlsFieldValidateDialog', 'locationHelper', 'eScreenPurpose', 'FileUploader', 'localStorageService', 'campaignDataSvc', 'contractDataSvc', 'accountDataSvc', 'feeDataSvc', 'setupDataSvc',
function ($scope, $stateParams, $state, $rootScope, $location, comboBoxDataSvc, $q, eBiz, mlsUrlSvc, mlsStringUtils, eScreenMode, mlsLoadingDialog, mlsDialog, locationHelper, validationDataSvc, $timeout, validationHelper, mlsFieldValidateDialog, locationHelper, eScreenPurpose, FileUploader, localStorageService, campaignDataSvc, contractDataSvc, accountDataSvc, feeDataSvc, setupDataSvc) {

    $scope.$emit('on-screen-load', { screenID: "Factoring002_SecapContractDetail", screenTitle: "Contract Detail" });
    $scope.campaignDetail = {};
    $scope.feeSummary = {};
    $scope.validateValue = {};
    $scope.tabs = [
      {
          title: "Detail",
          url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwAppDetailFactoring"),
          id: 'tabContractDetail',
          validateID: "VLD0019",
          CRDNXTSTP: 1,
          disabled : true
      },
      {
          title: "Financial",
          url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwAppFinancialFactoring"),
          id: 'tabFinancial',
          validateID: "VLD0020",
          CRDNXTSTP: 2, 
          disabled: true
      },
       {
           title: "Fee info",
           url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwFeeInfoDefault?ngController=appEntryFeeInfoController"),
           id: 'tabFeeInfo',
           validateID: "VLD0021",
           CRDNXTSTP: 3, 
           disabled: true
       },
    ]

    $scope.screenModel = {
        screenMode: eScreenMode.ADD,
        screenPurpose : eScreenPurpose.ENTRY
    }


    $scope.getValidateID = function () {
        var validationID = null;
        var currentTab = $scope.getActiveTab() 
        var arrValidateList = []; 
        if (currentTab == null) {
            return arrValidateList
        }
        else {

            for (var i = 0 ; i < $scope.tabs.length ; i++) {
                var tab = $scope.tabs[i];
                if (tab.CRDNXTSTP <= currentTab.CRDNXTSTP) {
                    arrValidateList.push(tab.validateID);
                }
            }
            return arrValidateList;
        }
    }


    $scope.contractDetail = {
        CONAPPLY_PROJEC: "FC01"
    };

    $scope.feeList = [];
    $scope.getCampaignDetail = function ()
    {
        var defered = $q.defer();

        campaignDataSvc.getMLMCampaignByProjectCode($scope.contractDetail.CONAPPLY_PROJEC).then(function (data) {
            $scope.campaignDetail = data; 
            defered.resolve();
        })

        return defered.promise;
    }

    $scope.initialComboxBox = function ()
    {
        var defered = $q.defer();
        $q.all([
           comboBoxDataSvc.getComboAccBusTyp({ TABKEYTWO: $scope.contractDetail.ACCBUSTYP }), //0
           comboBoxDataSvc.getComboVendor({
               CPNCOD: $scope.contractDetail.CPNCOD,
               CPNBRNCOD: $scope.contractDetail.CPNBRNCOD,
               ACCBUSTYP: $scope.contractDetail.ACCBUSTYP,
               PROJECTCODE: $scope.contractDetail.CONAPPLY_PROJEC
           }), //1
           comboBoxDataSvc.getComboAccountCustomer({
               CPNCOD: $scope.contractDetail.CPNCOD,
               CPNBRNCOD: $scope.contractDetail.CPNBRNCOD,
               ACCBUSTYP: $scope.contractDetail.ACCBUSTYP, 
           }), // 2
           comboBoxDataSvc.getComboMarketing({
               CPNCOD: $scope.contractDetail.CPNCOD,
               CPNBRNCOD: $scope.contractDetail.CPNBRNCOD,
               ACCBUSTYP: $scope.contractDetail.ACCBUSTYP,
           }), // 3
           comboBoxDataSvc.getComboCompanyBranch(), //4 
           comboBoxDataSvc.getComboConTaxTyp({ TABKEYTWO: $scope.contractDetail.CONTAXTYP }) ,//5
           comboBoxDataSvc.getComboInterestType({ TABKEYTWO: $scope.contractDetail.CONINTTYP }), // 6
           comboBoxDataSvc.getComboLendingPeriod(), // 7
           comboBoxDataSvc.getComboPayType(),//8   
           comboBoxDataSvc.getComboAccountDueTerm(), // 9 
           comboBoxDataSvc.getComboAccountCreditTerm() // 10
        ]).then(function (responses)
        {
            $scope.businessTypeDataSource = responses[0]
            $scope.sponsorDataSource = responses[1]
            $scope.supplierDataSource = responses[2]
            $scope.marketingDataSource = responses[3]
            $scope.branchDataSource = responses[4]
            $scope.taxTypeDataSource = responses[5]
            $scope.interestTypeDataSource = responses[6]
            $scope.lendingPeriodDataSource = responses[7]
            $scope.payTypeDataSource = responses[8]
            $scope.dueTypeDataSource = responses[9]
            $scope.creditTermDataSource = responses[10]
            defered.resolve()
        });

        return defered.promise 
    }

    $scope.loadFeeList = function (criteria) {
        feeDataSvc.getFeeList(criteria).then(function (data) {
            $scope.feeList = data;
        })
    }

    $scope.initialScreenMode = function () {
         
        if (!mlsStringUtils.isStringEmpty($stateParams.GENAPPNUM) &&
            !mlsStringUtils.isStringEmpty($stateParams.CPNCOD) &&
            !mlsStringUtils.isStringEmpty($stateParams.CPNBRNCOD) &&
            !mlsStringUtils.isStringEmpty($stateParams.ACCBUSTYP)
            ) {

            $scope.contractDetailCriteria = {
                "GENAPPNUM": $stateParams.GENAPPNUM,  
                "CPNCOD": $stateParams.CPNCOD,
                "CPNBRNCOD": $stateParams.CPNBRNCOD,
                "ACCBUSTYP": $stateParams.ACCBUSTYP,
            };

            $scope.screenModel.screenMode = eScreenMode.EDIT; 
        }
        else {
             
            $scope.screenModel.screenMode = eScreenMode.ADD;
        }

        $scope.screenModel.screenPurpose = $stateParams.purpose;
    }
     
    $scope.getActiveTab = function () {
        var arrTab = $scope.tabs.whereAnd([{ 'active': true }]);
        if (arrTab.length > 0) {
            $scope.activeTab = arrTab[0];
            return $scope.activeTab;
        }
        return {};
    }

    $scope.initialComponents = function ()
    {
        $scope.initialScreenMode();
        var defer = $q.defer();
        if ($scope.screenModel.screenMode == eScreenMode.EDIT) {
            contractDataSvc.getContractDetail($scope.contractDetailCriteria).then(function (contractDetail) {
                $scope.contractDetail = contractDetail;
                $scope.enableTabByStep($scope.contractDetail.CRDNXTSTP);
                if ($scope.screenModel.screenPurpose == 'ENTRY')
                {
                    var currentStepTab = $scope.getTabByStep($scope.contractDetail.CRDNXTSTP);
                    if (currentStepTab) {
                        currentStepTab.active = true
                    }
                }
               
                
                defer.resolve();
            })
        }
        else
        {
            defer.resolve();
        }


        defer.promise.then(function ()
        {
            var campaignPromise = $scope.getCampaignDetail();

            campaignPromise.then(function () {

                if ($scope.screenModel.screenMode == eScreenMode.ADD)
                {
                    $scope.contractDetail.ACCBUSTYP = $scope.campaignDetail.ACCBUSTYP;
                    $scope.contractDetail.CONTAXTYP = $scope.campaignDetail.CONTAXTYP;
                    $scope.contractDetail.CONINTTYP = $scope.campaignDetail.CONINTTYP;
                    $scope.contractDetail.CPNBRNCOD = "0001"
                    $scope.contractDetail.CPNCOD = "0001"
                }
              

                $scope.initialComboxBox();

                $scope.loadFeeList({
                    CPNCOD: $scope.contractDetail.CPNCOD,
                    CPNBRNCOD: $scope.contractDetail.CPNBRNCOD,
                    ACCBUSTYP: $scope.contractDetail.ACCBUSTYP,
                    CONNUM: $scope.contractDetail.CONNUM,
                    CREDIT_APPROVE: $scope.contractDetail.CONFINAMT,
                    CONDWNAMT: $scope.contractDetail.CONDWNAMT,
                    CONAPPLY_PROJEC: $scope.contractDetail.CONAPPLY_PROJEC
                });


            })
        }) 
    }

    $scope.getContractCurrentStep = function () {
        var arrActiveTab = $scope.tabs.whereAnd([{ 'active': true }])
        if (arrActiveTab.length > 0) {
            $scope.activeTab = arrActiveTab[0];
            return $scope.activeTab.CRDNXTSTP;
        }
        return 0;
    }

    $scope.$watch('contractDetail.ACCCODDLR', function (value,old)
    {
        if (value) { 
            accountDataSvc.getAccountDetail({
                ACCBUSTYP: $scope.contractDetail.ACCBUSTYP,
                GENAPPNUM: value,
                CPNCOD: $scope.contractDetail.CPNCOD,
                CPNBRNCOD: $scope.contractDetail.CPNBRNCOD,
            }).then(function (sponsorDetail) {
                 
                if (sponsorDetail.FACADVRTE == null) {
                    setupDataSvc.getSetup({
                        TABKEYONE: "MLSVALUE",
                        TABKEYTWO: "FACADVRTE",
                        SHOWALL: "N"
                    }).then(function (setupResult) {
                        if (setupResult.length > 0)
                        { 
                            $scope.validateValue.maxAdvanceRate = setupResult[0].TABSETRTE1.toDecimalOrZero() * 100;
                            debugger
                        }
                        
                    })
                }
                else {
                    
                    $scope.validateValue.maxAdvanceRate = sponsorDetail.FACADVRTE.toDecimalOrZero();
                    debugger
                } 
            })

            /*Use only validate maximum advance rate*/
        
        }
    })

    $scope.showApproveCompleteDialog = function () {
        var ok = mlsDialog.showCustomDialog({}, {
            scope: $scope,
            template: mlsUrlSvc.getUrlContent("/Template/dialog-template/ContractApprovedTemplate.html"),
            className: 'ngdialog-theme-default dialog-large',
            closeByDocument: false,
            showClose: false,
            closeByEscape: false
        }, null);


        return ok;
    }
     
    $scope.showAppEntryCompleteDialog = function () {
        var ok = mlsDialog.showInfoDialog({ message: "Application entry complete", messaeCode: "INF002" }, {
            closeByDocument: false,
            showClose: false,
            closeByEscape: false
        });

        return ok;
    }

    $scope.nextStep = function () {
        if ($scope.contractDetail.CRDNXTSTP <= $scope.tabs.last().CRDNXTSTP) // Can be next step
        {
            // go to next step
            //debugger 
            var nextTab = $scope.getTabByStep($scope.contractDetail.CRDNXTSTP); // get next step's tab  
            nextTab.active = true;   // active next step tab
        }
        else {
            if ($scope.contractDetail.RECSTSCOD == 4) {
                $scope.showApproveCompleteDialog().then(function () {
                    locationHelper.path("/secapContractList");
                })
            }
            else {
                $scope.showAppEntryCompleteDialog({ message: "Application process complete." }).then(function () {
                    locationHelper.path("/secapContractList");
                })

                // show dialog "Finish application entry ,this application will be go to judgment step."
                // GENAPPNUM , CUSCOD ,ACCNAMTHA
                // when modal close redirect to application list page
            }

        }
    }

    $scope.getTabByStep = function (step) {
        var arrNextTab = $scope.tabs.whereAnd([{ 'CRDNXTSTP': step || 1 }]);
        if (arrNextTab.length > 0) {
            $scope.nextStepTab = arrNextTab[0];
            return $scope.nextStepTab;
        }
    }

    $scope.onValidate = function()
    {
        var defered = $q.defer();
        var arrValidateList = $scope.getValidateID();

        validationHelper.processValidation(arrValidateList,$("#frmAppEntry")).then(function (valudateResult)
        { 
            defered.resolve(valudateResult);
        })
          
        return defered.promise;
    }

    $scope.onSave = function ()
    { 
        var deferred = $q.defer();
         
        $scope.onValidate().then(function (validateResult) {
            if (validateResult.isValid) { 
                confirm = mlsDialog.showConfirmDialog({ message: "Do you want to 'Save data'?" });

                confirm.then(function () {


                    $scope.contractDetail.CRDRSLSTP = eBiz.CRDRSLSTP.Approve;
                    $scope.contractDetail.CRDCURSTP = $scope.contractDetail.CRDNXTSTP;
                    $scope.contractDetail.CRDNXTSTP = $scope.getContractCurrentStep() + 1;
                 

                    if ($scope.contractDetail.CRDNXTSTP > $scope.tabs.last().CRDNXTSTP) /*if approve and last tabe go to judgment*/ {
                        $scope.contractDetail.CRDNXTSTP = 10;
                    }
                      
                    $scope.saveContractData().then(function () {
             
                        $scope.nextStep();
                        $scope.enableTabByStep($scope.contractDetail.CRDNXTSTP);
                  
                        $scope.screenMode = eScreenMode.EDIT;
                        $scope.screenModel.screenMode = eScreenMode.EDIT;
                       
                        deferred.resolve();
                    });

                })
            }
            else {
                mlsFieldValidateDialog.show({
                    message: "Please correct invalid data before save.",
                    messageCode: "inf0001",
                    invalidFields: validateResult.invalidFields
                })
            }
        })

      

        return deferred.promise;

    }
      
    $scope.saveContractData = function () {
        var defered = $q.defer();
        $scope.contractDetail.FeeList = $scope.feeList;
        contractDataSvc.InsertOrUpdateContractFactoring($scope.contractDetail,$rootScope.Username).then(function (newContractDetail) {
            $scope.contractDetail = {};
            $scope.contractDetail = newContractDetail; 
            defered.resolve();

        }, function () {
            defered.reject('error occur from server')
        });
      

        return defered.promise;
    }
     
    $scope.onConfirm = function () {
        var tab = $scope.getActiveTab()
        if (!tab) {
            $scope.tabs[0].active = true;
        }
        else {

            var activeTabIndex = $scope.tabs.indexOf(tab);
            if (tab.CRDNXTSTP == $scope.tabs.last().CRDNXTSTP) {
                // show dialog Contract no , cuscod , GENAPRDTE, ACCNAMTHA
                var confirm = mlsDialog.showConfirmDialog({ message: "Do you want to approve this case ?", messageCode: "CFM002" });
                confirm.then(function () {
                    $scope.contractDetail.CRDNXTSTP = 20;
                    $scope.contractDetail.CRDRSLSTP = eBiz.CRDRSLSTP.Approve;
                    $scope.saveContractData().then(function () {
                        $scope.showApproveCompleteDialog().then(function () {
                            locationHelper.path("/secapJudgmentList");
                        })

                    });

                }, function () {

                })
            }
            else {
                $scope.getTabByStep(tab.CRDNXTSTP + 1);
                $scope.nextStepTab.active = true;
            }
        }
    }

    $scope.enableTabByStep = function (CRDNXTSTP) {
        angular.forEach($scope.tabs, function (tab, index) {
            tab.disabled = (CRDNXTSTP < tab.CRDNXTSTP); 
        })
    }

    $scope.initialComponents();

}]);