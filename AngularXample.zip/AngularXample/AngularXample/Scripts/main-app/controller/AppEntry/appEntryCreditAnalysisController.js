﻿angular.module('mainApp').controller('appEntryCreditAnalysisController', ['$scope', function ($scope)
{
   

}]);