﻿mainApp.controller('appEntryController',
 ['$scope', 'mainAppContext', 'mlsDialog', '$stateParams', 'mlsUrlSvc', 'DTOptionsBuilder', 'DTColumnDefBuilder', 'mlsDtDefaultSetting', 'mlsStringUtils', 'eScreenMode', 'contractDataSvc', 'referencePersonDataSvc', 'eBiz', 'comboBoxDataSvc', 'validationDataSvc', '$q', 'validationHelper', '$timeout', '$rootScope', 'telLogDataSvc', 'campaignDataSvc', 'addressDataSvc', 'feeDataSvc', 'locationHelper', 'guarantorPersonDataSvc', 'productDataSvc', 'mlsAppRejectDialog', 'mlsAppCancelDialog', 'remarkDataSvc', 'ncbDataSvc', 'customerDataSvc', 'mlsLoadingDialog', 'eScreenPurpose', 'mlsAppSendBackDialog',
function ($scope, mainAppContext, mlsDialog, $stateParams, mlsUrlSvc, DTOptionsBuilder, DTColumnDefBuilder, mlsDtDefaultSetting, mlsStringUtils, eScreenMode, contractDataSvc, referencePersonDataSvc, eBiz, comboBoxDataSvc, validationDataSvc, $q, validationHelper, $timeout, $rootScope, telLogDataSvc, campaignDataSvc, addressDataSvc, feeDataSvc, locationHelper, guarantorPersonDataSvc, productDataSvc, mlsAppRejectDialog, mlsAppCancelDialog, remarkDataSvc, ncbDataSvc, customerDataSvc, mlsLoadingDialog, eScreenPurpose, mlsAppSendBackDialog)
{ 
    $scope.telLogList = []; 
    $scope.refPersonList = [{ open: true, RECACTCOD: 'A' }];
    $scope.guarantorList = [{ open: true,RECACTCOD : 'A' ,AddressList: [{ open: true, RECACTCOD: 'A' }] }];
    $scope.addressList = [{ open: true ,RECACTCOD : 'A'}];
    $scope.addressListModel = {};
    $scope.refListModel = {};
    $scope.guaListModel = {};
    $scope.guaAddressListModel = {};
    $scope.feeList = [];
    $scope.productSpec = {};
    $scope.contractDetail = {};
    $scope.contractCriteria = {};
    $scope.campaignDetail = {};
    $scope.activeTab = {};
    $scope.nextStepTab = {};
    $scope.isFirstInit = false;
    var $parent = $scope.$parent; /*_AppEntryLayout*/
    $scope.validationOptions = {};
    $scope.contractDetail.CPNCOD = "0001";
    $scope.contractDetail.CPNBRNCOD = "0001"; 
    $scope.$emit('on-screen-load', { screenID: "APP001NewApp", screenTitle: "New application" });
    $scope.screenModel = {};
    $scope.ncbModel = {
        isCheckNCB : null
    };

    $scope.validateRequireMsg = {
        required: function ()
        {
            return mainAppContext.getValidateMessage("VLD001").Message
        }
    }
     
    $scope.feeSummary = {};

    $scope.loanEvdList = [
       {
           "DESC": "ทะเบียนบ้าน",
           "REQUIRE_DESC": "จำเป็น",
           "IS_RECEIVED": "Y",
       },
       {
           "DESC": "สลิปเงินเดือน",
           "REQUIRE_DESC": "จำเป็น",
           "IS_RECEIVED": "N",
       },
       {
           "DESC": "รายได้อื่น",
           "REQUIRE_DESC": "เพิ่มเติม",
           "IS_RECEIVED": "Y",
       },
       {
           "DESC": "สมุดทะเบียนขนส่ง",
           "REQUIRE_DESC": "จำเป็น",
           "IS_RECEIVED": "Y",
       },
    ];

    $scope.initialScreenMode = function ()
    {
        if (mlsStringUtils.isStringEmpty($stateParams.CPNCOD) ||
            mlsStringUtils.isStringEmpty($stateParams.CPNBRNCOD) ||
            mlsStringUtils.isStringEmpty($stateParams.GENAPPNUM) ||
            mlsStringUtils.isStringEmpty($stateParams.ACCBUSTYP))
        {
            $scope.screenMode = eScreenMode.ADD;
            $scope.screenModel.screenMode = eScreenMode.ADD;
        }   
        else
        {
            $scope.screenMode = eScreenMode.EDIT;
            $scope.screenModel.screenMode = eScreenMode.EDIT; 
        }
         
        $scope.screenModel.screenPurpose = $stateParams.purpose;
        $scope.screenModel.isReadonly = ($scope.screenModel.screenPurpose == eScreenPurpose.VERIFY || $scope.screenModel.screenPurpose == eScreenPurpose.VIEW);
        
    }

    $scope.broadcastContractComplete = function (isFirstInit)
    {
        $timeout(function ()
        { 
            $scope.contractCriteria = {
                CPNCOD: $scope.contractDetail.CPNCOD,
                CPNBRNCOD: $scope.contractDetail.CPNBRNCOD,
                GENAPPNUM: $scope.contractDetail.GENAPPNUM,
                ACCBUSTYP: $scope.contractDetail.ACCBUSTYP,
                CONNUM: $scope.contractDetail.CONNUM,
                CONFINAMT: $scope.contractDetail.CONFINAMT,
                CONDWNAMT: $scope.contractDetail.CONDWNAMT,
                CONAPPLY_PROJEC: $scope.contractDetail.CONAPPLY_PROJEC,
                CUSCOD : $scope.contractDetail.CUSCOD
            }

            $rootScope.$broadcast("initial-contract-data-complete", {
                contractDetail: $scope.contractDetail,
                screenMode: $scope.screenMode,
                contractCriteria: $scope.contractCriteria,
                isFirstInit : isFirstInit,
                scope: $scope
            });

        })
    }

    $scope.clearCustomerInfo = function()
    {
        angular.forEach(customerDataSvc.customerInfoField, function (value, key)
        {
            $scope.contractDetail[value] = null;
        })
    }

    $scope.fillCustomerInfo = function ()
    {
        var defered = $q.defer();
        var ID = null;
        if ($scope.contractDetail.CUSTYPCOD == eBiz.CUSTYPCOD.JuristicPerson)
        {
            ID = $scope.contractDetail.CPNREGNUM
        }
        else if ($scope.contractDetail.CUSTYPCOD == eBiz.CUSTYPCOD.NaturalPerson)
        {
            ID = $scope.contractDetail.PSNREGIDN
        }

        customerDataSvc.getCustomerInfoWithAccount({
            ID: ID,
            CPNCOD: $scope.contractDetail.CPNCOD,
            CPNBRNCOD: $scope.contractDetail.CPNBRNCOD,
            ACCBUSTYP: $scope.contractDetail.ACCBUSTYP,
            CUSTYPCOD: $scope.contractDetail.CUSTYPCOD
        }).then(function (cusInfo)
        { 
            if (cusInfo)
            {
                angular.forEach(customerDataSvc.customerInfoField, function (value, key)
                {
                    $scope.contractDetail[value] = cusInfo[value];
                })

                if ($scope.contractDetail.ACCBUSTYP != cusInfo.ACCBUSTYP)
                {
                    $scope.contractDetail.ACCCOD = null;
                }
            }
            defered.resolve();
        })
        return defered.promise;
    }

    $scope.txtPSNREGIDN_Changed = function()
    {  
        if ($scope.contractDetail.PSNREGIDN && $scope.contractDetail.ACCBUSTYP && (!$scope.contractDetail.GENAPPNUM))
        {
            $scope.clearCustomerInfo();
            var dialog = mlsLoadingDialog.show({});
            $scope.fillCustomerInfo().then(function () {
                dialog.close()
            });
        }
    }

    $scope.txtCPNREGNUM_Changed = function ()
    {
        if ($scope.contractDetail.CPNREGNUM && $scope.contractDetail.ACCBUSTYP && (!$scope.contractDetail.GENAPPNUM))
        {
            $scope.clearCustomerInfo()
            var dialog = mlsLoadingDialog.show({});;
            $scope.fillCustomerInfo().then(function () {
                dialog.close()
            });
        }
    }

    $scope.$watch('contractDetail.ACCBUSTYP', function (newVal, oldVal, scope)
    { 
        if ($scope.contractDetail.CUSTYPCOD == eBiz.CUSTYPCOD.JuristicPerson)
        {
            if ($scope.contractDetail.CPNREGNUM && $scope.contractDetail.ACCBUSTYP && (!$scope.contractDetail.GENAPPNUM))
            {
                $scope.clearCustomerInfo();
                var dialog = mlsLoadingDialog.show({});
                $scope.fillCustomerInfo().then(function () {
                    dialog.close()
                });
            }
        }
        else if ($scope.contractDetail.CUSTYPCOD == eBiz.CUSTYPCOD.NaturalPerson)
        {
            if ($scope.contractDetail.PSNREGIDN && $scope.contractDetail.ACCBUSTYP && (!$scope.contractDetail.GENAPPNUM))
            {
                $scope.clearCustomerInfo();
                var dialog = mlsLoadingDialog.show({});
                $scope.fillCustomerInfo().then(function () {
                    dialog.close()
                });
            }
        }
        
    })
     
    $scope.isCanGetData = function (tabID)
    { 
        var tab = $scope.findTabByID(tabID);
        var CRDNXTSTP = 0;
        if (tab)
        {
            CRDNXTSTP = tab.CRDNXTSTP;
        }
        return $scope.contractDetail.CRDNXTSTP >= CRDNXTSTP
    }

    $scope.findTabByID = function(tabID)
    {
        var tabs = $scope.tabs.whereAnd([{ id: tabID }]);
        if(tabs.length > 0)
        {
            return tabs[0];
        }
        return null;
    }

    $scope.onEditMode = function ()
    {
        var defered = $q.defer();

        $scope.contractDetailCriteria = {
            CPNCOD: $stateParams.CPNCOD,
            CPNBRNCOD: $stateParams.CPNBRNCOD,
            GENAPPNUM: $stateParams.GENAPPNUM,
            ACCBUSTYP: $stateParams.ACCBUSTYP
        }
        
        $q.all([
            contractDataSvc.getContractDetail($scope.contractDetailCriteria),
         
        ]).then(function (response)
        {
            $scope.contractDetail = response[0];
             
            $scope.contractDetail.PSNREGIDN2 = $scope.contractDetail.PSNREGIDN;
            var CPNCOD = $scope.contractDetail.CPNCOD;
            var CPNBRNCOD = $scope.contractDetail.CPNBRNCOD;
            var ACCBUSTYP = $scope.contractDetail.ACCBUSTYP;
            var GENAPPNUM = $scope.contractDetail.GENAPPNUM;
            var CONNUM = $scope.contractDetail.CONNUM;
            var CONAPPLY_PROJEC = $scope.contractDetail.CONAPPLY_PROJEC
            var CONFINAMT = $scope.contractDetail.CONFINAMT;
            var CONDWNAMT = $scope.contractDetail.CONDWNAMT;
            $scope.isFirstInit = true;
            $scope.InitialComboProjectDepenend();
             
            campaignDataSvc.getMLMCampaignByProjectCode($scope.contractDetail.CONAPPLY_PROJEC).then(function (data)
            {
                $scope.campaignDetail = data;
                $scope.broadcastContractComplete(true);
                $scope.entryOnceReadonly = true;

              

                defered.resolve();
            })
            
        })

        return defered.promise;

    }

    $scope.initialScreenData = function ()
    {
        var defered = $q.defer();
        if ($scope.screenMode == eScreenMode.ADD)
        {
            //$scope.initialValidation();
            defered.resolve();
            
        }
        else if ($scope.screenMode == eScreenMode.EDIT)
        {
            $scope.onEditMode().then(function () {
                $scope.activTabByStep($scope.contractDetail.CRDNXTSTP);
                //$scope.enableTabByStep($scope.contractDetail.CRDNXTSTP);
                defered.resolve();
            })
        }
        return defered.promise;
    }

    $scope.enableTabByStep = function (CRDNXTSTP)
    {
        angular.forEach($scope.tabs, function (tab, index) {  
            tab.disabled = (CRDNXTSTP < tab.CRDNXTSTP);
            
        }) 
    }

    $scope.activTabByStep = function (CRDNXTSTP)
    {
        var tab = $scope.getTabByStep(CRDNXTSTP)
        if (tab) {
            tab.active = true;
        }
    }
     
    $scope.InitialComponents = function ()
    {
        $scope.tabs = [];
        var dteNow = new Date()

        $scope.initialScreenMode();
        $scope.initialScreenData()
        $scope.initialComboBoxData();

    }
     
    $scope.$watch('contractDetail.CONAPPLY_PROJEC', function (newValue, oldValue, scope)
    {
        if (newValue)
        {
            if ($scope.screenMode == eScreenMode.ADD ||  mlsStringUtils.isStringEmpty($scope.contractDetail.GENAPPNUM))

            {
                var dialog = mlsLoadingDialog.show({});
                campaignDataSvc.getMLMCampaignByProjectCode(newValue).then(function (data)
                {
                    $scope.campaignDetail = data;
                    $scope.contractDetail.CONINTCAL = data.CONINTCAL;
                    $scope.contractDetail.CONINTRTE = data.TOTALRTE;
                    $scope.contractDetail.CRUSGRTE = data.CRDUSGRTE
                    $scope.contractDetail.INCOMERTE = data.INCOMERTE
                    $scope.contractDetail.CONINTTYP = data.CONINTTYP
                    $scope.contractDetail.ACCBUSTYP = data.ACCBUSTYP
                    $scope.contractDetail.CONOBJCOD = data.CONOBJCOD
                    $scope.contractDetail.CUSTYPCOD = data.CUSTYPCOD
                    $scope.contractDetail.CONTAXTYP = data.CONTAXTYP
                    $scope.contractDetail.ACCLNDTYP = data.ACCLNDTYP
                    $scope.contractDetail.DeviateAge = data.DeviateAge
                    $scope.contractDetail.DeviateSalary = data.DeviateSalary
                    $scope.contractDetail.DeviateNetIncome = data.DeviateNetIncome
                    $scope.contractDetail.DeviateSalaryAction = data.DeviateSalaryAction
                    $scope.InitialComboProjectDepenend().then(function ()
                    {
                        dialog.close();
                    });
                })
                //CONINTRTE, INCOMERTE, CRUSGRTE
            }
        }

    }, true);

    $scope.switchTab = function()
    {
        if ($scope.contractDetail.CONOBJCOD == eBiz.CONOBJCOD.Collaborate)
        {
            $scope.tabs = $parent.tabs1;
        }
        else if ($scope.contractDetail.CONOBJCOD == eBiz.CONOBJCOD.HirePurchase)
        {
            if ($scope.contractDetail.CUSTYPCOD == eBiz.CUSTYPCOD.NaturalPerson)
            {
                $scope.tabs = $parent.tabs4;
            }
            else if ($scope.contractDetail.CUSTYPCOD == eBiz.CUSTYPCOD.JuristicPerson)
            {
                $scope.tabs = $parent.tabs5;
            }
        }
        else
        {
            $scope.tabs = $parent.tabs2;
        }
    }

    $scope.$watch('contractDetail.CONOBJCOD', function (newValue, oldValue, scope)
    {
        $scope.switchTab();
         
        $scope.enableTabByStep($scope.contractDetail.CRDNXTSTP || 0);

    }, true);

    $scope.$watch('contractDetail.CUSTYPCOD', function (newValue, oldValue, scope)
    {
        if (newValue)
        {
            $scope.switchTab();
             

            $q.all([comboBoxDataSvc.getComboCustomerTitleByCustomerType(newValue)]).then(function (response)
            {
                $scope.listCusTtlTha = response[0];
            })

            if ($scope.contractDetail.CUSTYPCOD == eBiz.CUSTYPCOD.JuristicPerson) {
                if ($scope.contractDetail.CPNREGNUM && $scope.contractDetail.ACCBUSTYP && (!$scope.contractDetail.GENAPPNUM)) {
                    $scope.clearCustomerInfo();
                    var dialog = mlsLoadingDialog.show({});
                    $scope.fillCustomerInfo().then(function () {
                        dialog.close()
                    });
                }
            }
            else if ($scope.contractDetail.CUSTYPCOD == eBiz.CUSTYPCOD.NaturalPerson) {
                if ($scope.contractDetail.PSNREGIDN && $scope.contractDetail.ACCBUSTYP && (!$scope.contractDetail.GENAPPNUM)) {
                    $scope.clearCustomerInfo();
                    var dialog = mlsLoadingDialog.show({});
                    $scope.fillCustomerInfo().then(function () {
                        dialog.close()
                    });
                }
            }

        } 
    }, true);

    $scope.$watch('contractDetail.GENAPPNUM', function (newVal, oldVal, scope)
    {
        if (mlsStringUtils.isStringEmpty(newVal) == false)
        {
            $scope.entryOnceReadonly = true;
        } 
    },true)

    $scope.$watch('contractDetail.FINBNKCODCR', function (newValue, oldValue, scope)
    {
        comboBoxDataSvc.getComboFinBnkBrn({ FINBNKCOD: newValue }).then(function (data)
        { 
            $scope.listFinBnkBrn = data;
        })
    })
  
    $scope.getContractCurrentStep = function ()
    {
        var arrActiveTab = $scope.tabs.whereAnd([{ 'active': true }])
        if (arrActiveTab.length > 0)
        {
            $scope.activeTab = arrActiveTab[0];
            return $scope.activeTab.CRDNXTSTP;
        }
        return 0;
    }

    $scope.getTabByStep = function (currentStep)
    {
        var arrNextTab = $scope.tabs.whereAnd([{ 'CRDNXTSTP': currentStep || 1 }]);
        if (arrNextTab.length > 0)
        {
            $scope.nextStepTab = arrNextTab[0];
            return $scope.nextStepTab;
        } 
    }

    $scope.getTabByID = function (id)
    {
        var arrTab = $scope.tabs.whereAnd([{ 'id': id }]);
        if (arrTab.length > 0) {
            $scope.activeTab = arrTab[0];
            return $scope.activeTab;
        }
        return {};
    }

    $scope.getActiveTab = function()
    {
        var arrTab = $scope.tabs.whereAnd([{ 'active': true }]);
        if (arrTab.length > 0)
        {
            $scope.activeTab = arrTab[0];
            return $scope.activeTab;
        }
        return {};
    }
    
    $scope.getAutoRejectResult = function ()
    {
        var defered = $q.defer();
        $scope.contractDetail.AddressList = $scope.addressList;
        validationDataSvc.getContractAutoRejectResult($scope.contractDetail).then(function (data)
        {
            defered.resolve(data)
        })
        return defered.promise;
    }

    $scope.saveContractData = function ()
    {
        var defered = $q.defer();
    

        contractDataSvc.InsertOrUpdateContract($scope.contractDetail).then(function (newContractDetail)
        {  
            $scope.contractDetail = {};
            $scope.contractDetail = newContractDetail;
            $scope.contractDetail.PSNREGIDN2 = $scope.contractDetail.PSNREGIDN; 
        
            var promiseRef = null;
            var promiseGua = null;
            var promiseTelLog = null;
            var promiseAddress = null;
            var promiseFee = null;
            

            if ($scope.refPersonList.length > 0 && $scope.activeTab.id == 'tabContractInfo' && ($scope.campaignDetail.ShowRefType == "*" || $scope.campaignDetail.ShowRefType == "REF"))
            {
                var data = $scope.refPersonList.concat($scope.refListModel.deleteList);

                angular.forEach(data, function (ref, index)
                {
                    ref.COCRELTYP = "CON";
                })

                promiseRef = referencePersonDataSvc.insertOrUpdateReferencePerson(
                    data,
                    $scope.contractDetail.CPNCOD,
                    $scope.contractDetail.CPNBRNCOD,
                    $scope.contractDetail.ACCBUSTYP,
                    $scope.contractDetail.CONNUM, 
                    $rootScope.Username)
            }

            if ($scope.guarantorList.length > 0 && $scope.activeTab.id == 'tabContractInfo' && ($scope.campaignDetail.ShowRefType == "*" || $scope.campaignDetail.ShowRefType == "GUA" ))
            {

                angular.forEach($scope.guarantorList, function (obj, index)
                {
                    obj.COCRELTYP = "CON";
                    obj.AddressList = obj.AddressList.concat(obj.addressListModel.deleteList); 
                })

                var data = $scope.guarantorList.concat($scope.guaListModel.deleteList);

                promiseGua = guarantorPersonDataSvc.insertOrUpdateGuarantorPerson(
                           data,
                           $scope.contractDetail.CPNCOD,
                           $scope.contractDetail.CPNBRNCOD,
                           $scope.contractDetail.ACCBUSTYP,
                           $scope.contractDetail.CONNUM, 
                           $rootScope.Username) 
            }



            if ($scope.addressList.length > 0 && $scope.activeTab.id == 'tabContractInfo') /*if current is contract info*/
            {
                var data = $scope.addressList.concat($scope.addressListModel.deleteList)
                promiseAddress = addressDataSvc.insertOrUpdateAddress(data, $scope.contractDetail.CUSCOD, $rootScope.Username)
            }

            if ($scope.telLogList.length > 0 && $scope.activeTab.id == 'tabVerify')
            {
                promiseTelLog = telLogDataSvc.insertOrUpdateTelLog(
                    $scope.telLogList,
                    $scope.contractDetail.CPNCOD,
                    $scope.contractDetail.CPNBRNCOD,
                    $scope.contractDetail.ACCBUSTYP,
                    $scope.contractDetail.CONNUM,
                    $rootScope.Username)
            }

            if ($scope.feeList.length > 0 && $scope.activeTab.id == 'tabFeeInfo')
            {
                promiseFee = feeDataSvc.insertOrUpdateFee($scope.feeList, $rootScope.Username);
            }

            
            if ($scope.activeTab.id == 'tabProductInfo')
            {
                productDataSvc.InsertOrUpdateProductSepc(
                    $scope.contractDetail.CPNCOD,
                    $scope.contractDetail.CPNBRNCOD,
                    $scope.contractDetail.ACCBUSTYP,
                    $scope.contractDetail.CONNUM,
                    $scope.productSpec)
            }

            var arrPromise = [];
            if (promiseRef) arrPromise.push(promiseRef)
            if (promiseTelLog) arrPromise.push(promiseTelLog)
            if (promiseAddress) arrPromise.push(promiseAddress)
            if (promiseFee) arrPromise.push(promiseFee)
            if (promiseGua) arrPromise.push(promiseGua)

            if (arrPromise.length > 0)
            { 
                $q.all(arrPromise).then(function (data)
                { 
                    defered.resolve();
                })
            }
            else
            {
                defered.resolve();
            } 


        }, function ()
        {
            defered.reject('error occur from server')
        });

        return defered.promise;
    }

    $scope.showApproveCompleteDialog = function ()
    { 
        var ok = mlsDialog.showCustomDialog({}, {
            scope: $scope,
            template: mlsUrlSvc.getUrlContent("/Template/dialog-template/ContractApprovedTemplate.html"),
            className: 'ngdialog-theme-default dialog-large',
            closeByDocument: false,
            showClose: false,
            closeByEscape : false
        }, null);
         

        return ok; 
    }

    $scope.showAppEntryCompleteDialog = function ()
    {
        var ok = mlsDialog.showInfoDialog({ message: "Application entry complete", messaeCode: "INF002" }, {
            closeByDocument: false,
            showClose: false,
            closeByEscape: false
        });

        return ok; 
    }
     
  
    /*OnSave AppEntry*/
    $scope.onSave = function () {

        var deferred = $q.defer();
        if ($scope.screenModel.screenMode == eScreenMode.ADD || $scope.contractDetail.CRDNXTSTP == 1) {
            $scope.tabs[0].active = true // Customer info
            $scope.contractDetail.CRDCURSTP = 1;
            $scope.contractDetail.CRDNXTSTP = 1;
            deferred.resolve();
        }
        else if ($scope.screenModel.screenMode == eScreenMode.EDIT) {

            $scope.isFirstInit = false;
            $scope.saveContractData().then(function () {
                deferred.resolve();
            }); 
           
        } 

        $scope.screenMode = eScreenMode.EDIT;
        $scope.screenModel.screenMode = eScreenMode.EDIT;
        return deferred.promise;

    }
     
    $scope.checkNCB = function ()
    {
        var middleName = '';
        return ncbDataSvc.getNCBResult($scope.contractDetail.CUSNAMTHA,
            middleName,
            $scope.contractDetail.CUSSURNAM,
            $scope.contractDetail.PSNBTHDTE,
            $scope.contractDetail.PSNREGIDN,
            $rootScope.Username)
    }

    /*Approve or SubmitNext*/
    $scope.onApprove = function () {
        $scope.contractDetail.CRDRSLSTP = eBiz.CRDRSLSTP.Approve;
        $scope.contractDetail.CRDCURSTP = $scope.contractDetail.CRDNXTSTP;
        $scope.contractDetail.CRDNXTSTP = $scope.getContractCurrentStep() + 1;
        
        var nextStepTab = $scope.getTabByStep($scope.contractDetail.CRDNXTSTP);
        if (nextStepTab) {
            $scope.contractDetail.IsRecalculateCreditLimit = nextStepTab.id == 'tabPreviewCredit';
        }

        if ($scope.contractDetail.CRDNXTSTP > $scope.tabs.last().CRDNXTSTP) /*if approve and last tabe go to judgment*/ {
            $scope.contractDetail.CRDNXTSTP = 10;
        }

       

        $scope.onValidate().then(function (data) {
            if (data.isValid) {
                $scope.getAutoRejectResult().then(function (autoRejectResult)
                {
                    if (autoRejectResult.IsReject)
                    {
                        $scope.showRejectDialog(autoRejectResult.RejectReasonID, null);
                    }
                    else
                    {
                        var confirm = null; 
                        if ($scope.ncbModel.isCheckNCB) {
                            confirm = mlsDialog.showConfirmDialog({ message: "Do you want to 'Check NCB' and 'Save data'?" });
                        }
                        else
                        {
                            confirm = mlsDialog.showConfirmDialog({ message: "Do you want to 'Save data'?" });
                        }

                        confirm.then(function () {
                            var deferCheckNCB = $q.defer();

                            if ($scope.ncbModel.isCheckNCB)
                            {
                                /*Check NCB Before save data*/
                                $scope.checkNCB().then(function (NCBResult) {
                                    deferCheckNCB.resolve(NCBResult);
                                })
                            }
                            else
                            {
                                deferCheckNCB.resolve(null);
                            }


                            deferCheckNCB.promise.then(function (NCBResult)
                            {
                                 
                                var deferSaveData = $q.defer();
                                if (NCBResult != null)
                                {
                                    $scope.onSave().then(function () {
                                        $scope.ncbModel = {};
                                        NCBResult.CUSCOD = $scope.contractDetail.CUSCOD;
                                        NCBResult.GENAPPNUM = $scope.contractDetail.GENAPPNUM;
                                        NCBResult.CONAPPLY_PROJEC = $scope.contractDetail.CONAPPLY_PROJEC;
                                        ncbDataSvc.insertNCBResult(NCBResult, $rootScope.Username).then(function () { 
                                          

                                            deferSaveData.resolve(false)
                                            var ok = mlsDialog.showInfoDialog({ message: NCBResult.Reason, messaeCode: "NCB_REASON" }, {
                                                closeByDocument: false,
                                                showClose: false,
                                                closeByEscape: false
                                            });

                                            ok.then(function () {
                                                if (!NCBResult.IsPassed) {
                                                    $scope.showRejectDialog("B03", null);
                                                }
                                                else {
                                                    $scope.nextStep();
                                                    $scope.broadcastContractComplete(false);
                                                }
                                            })
                                        })
                                    }) 
                                }
                                else if (NCBResult == null)
                                {
                                    deferSaveData.resolve(true)
                                } 
                                  
                                deferSaveData.promise.then(function (canSaveData)
                                {
                                    if (canSaveData)
                                    {
                                        $scope.onSave().then(function () {
                                            $scope.nextStep();
                                            $scope.enableTabByStep($scope.contractDetail.CRDNXTSTP);
                                            $scope.broadcastContractComplete(false);
                                            $scope.ncbModel = {};
                                        })
                                    }
                                  
                                }) 
                            }) 
                        })
                    }
                }) 
            }
            else {
                mlsDialog.showWarningDialog({ message: "Please correct invalid data before save.", messageCode: "inf0001" })
            }
        })

    }

    $scope.showRejectDialog = function (rejectReasonID, rejectRemark)
    {
        /*Get Reason datasource*/
        var deferred = $q.defer();
        if (!$scope.rejectReason) {
            comboBoxDataSvc.getComboRejectAppReason().then(function (data) {
                $scope.rejectReason = data
                deferred.resolve($scope.rejectReason)
            })
        }
        else {
            deferred.resolve($scope.rejectReason)
        }
        /*-------------------------*/

        deferred.promise.then(function (dataSource) {
            var confirmed = mlsAppRejectDialog.show({
                cboRejectReasonLabelText: $scope.listLabelText.cboRejectReason,
                txtRejectRemarkLabelText: $scope.listLabelText.txtRejectRemark,
                rejectReasonDataSource: dataSource,
                rejectReasonID: rejectReasonID,
                rejectRemark: rejectRemark,
            });

            confirmed.then(function (data) {

                var dialogModel = data.dialogModel;
                var rejectReasonID = dialogModel.rejectReasonID;
                var rejectRemark = dialogModel.rejectRemark;
                var isFirstEntry = (!$scope.contractDetail.GENAPPNUM)
                $scope.contractDetail.CRDRSLSTP = eBiz.CRDRSLSTP.Reject;
                $scope.contractDetail.CRDCURSTP = $scope.contractDetail.CRDNXTSTP;
                $scope.contractDetail.CRDNXTSTP = 20;
                $scope.contractDetail.CRDDEVIAT = rejectReasonID;

                $scope.onSave().then(function () {
                    var remarkModel = {
                        REMARK_ID: null,
                        RMKLEVRSL: 3,
                        GENREMARK: "(Reject in application) " + mlsStringUtils.toStringOrEmpty(rejectRemark),
                        GENPROGRM: "CON"
                    }

                    remarkDataSvc.insertOrUpdateRemark(
                        [remarkModel],
                        $scope.contractDetail.CPNCOD,
                        $scope.contractDetail.CPNBRNCOD,
                        $scope.contractDetail.ACCBUSTYP,
                        $scope.contractDetail.CONNUM,
                        $rootScope.Username).then(function () {
                            var ok = mlsDialog.showCustomDialog({}, {
                                scope: $scope,
                                template: mlsUrlSvc.getUrlContent("/Template/dialog-template/ApplicationRejectTemplate.html"),
                                className: 'ngdialog-theme-default dialog-large',
                                closeByDocument: false,
                                showClose: false,
                                closeByEscape: false
                            }, null);



                            ok.then(function () {
                                locationHelper.path("/appList");
                            })
                        })
                });


            })
        })

    }
     

    $scope.onReject = function ()
    {
        $scope.onValidate().then(function (data) {
            if (data.isValid) {
                /*Get Reason datasource*/
                $scope.showRejectDialog();
            /*    var deferred = $q.defer();
                if (!$scope.rejectReason) {
                    comboBoxDataSvc.getComboRejectAppReason().then(function (data) {
                        $scope.rejectReason = data
                        deferred.resolve($scope.rejectReason)
                    })
                }
                else {
                    deferred.resolve($scope.rejectReason)
                }
              

                deferred.promise.then(function (dataSource) {
                    var confirmed = mlsAppRejectDialog.show({
                        cboRejectReasonLabelText: $scope.listLabelText.cboRejectReason,
                        txtRejectRemarkLabelText: $scope.listLabelText.txtRejectRemark,
                        rejectReasonDataSource: dataSource
                    });

                    confirmed.then(function (data) {
                         
                        var dialogModel = data.dialogModel;
                        var rejectReasonID = dialogModel.rejectReasonID;
                        var rejectRemark = dialogModel.rejectRemark;
                        var isFirstEntry = (!$scope.contractDetail.GENAPPNUM)
                        $scope.contractDetail.CRDRSLSTP = eBiz.CRDRSLSTP.Reject;
                        $scope.contractDetail.CRDCURSTP = $scope.contractDetail.CRDNXTSTP;
                        $scope.contractDetail.CRDNXTSTP = 20;
                        $scope.contractDetail.CRDDEVIAT = rejectReasonID;
                       
                        $scope.onSave().then(function () {
                            var remarkModel = {
                                 REMARK_ID : null , 
                                 RMKLEVRSL : 3,
                                 GENREMARK : "(Reject in application) " + mlsStringUtils.toStringOrEmpty(rejectRemark) 
                            }

                            remarkDataSvc.insertOrUpdateRemark(
                                [remarkModel],
                                $scope.contractDetail.CPNCOD,
                                $scope.contractDetail.CPNBRNCOD,
                                $scope.contractDetail.ACCBUSTYP,
                                $scope.contractDetail.CONNUM,
                                $rootScope.Username).then(function ()
                                {
                                    var ok = mlsDialog.showCustomDialog({}, {
                                        scope: $scope,
                                        template: mlsUrlSvc.getUrlContent("/Template/dialog-template/ApplicationRejectTemplate.html"),
                                        className: 'ngdialog-theme-default dialog-large',
                                        closeByDocument: false,
                                        showClose: false,
                                        closeByEscape: false
                                    }, null);



                                    ok.then(function () {
                                        locationHelper.path("/appList");
                                    })
                                }) 
                        });


                    })
                })*/
            }
            else {
                mlsDialog.showWarningDialog({ message: "Please correct invalid data before save.", messageCode: "inf0001" })
            }
        })

    
       
    }

    $scope.onCancel = function ()
    {
        $scope.onValidate().then(function (data) {
            if (data.isValid) {
                /*Get Reason datasource*/
                var deferred = $q.defer();
                if (!$scope.cancelReason) {
                    comboBoxDataSvc.getComboCancelAppReason().then(function (data) {
                        $scope.cancelReason = data
                        deferred.resolve($scope.cancelReason)
                    })
                }
                else {
                    deferred.resolve($scope.cancelReason)
                }
                /*-------------------------*/

                deferred.promise.then(function (dataSource) {
                    var confirmed = mlsAppCancelDialog.show({
                        cboCancelReasonLabelText: $scope.listLabelText.cboRejectReason,
                        txtCancelRemarkLabelText: $scope.listLabelText.txtRejectRemark,
                        cancelReasonDataSource: dataSource
                    });

                    confirmed.then(function (data) {

                        var dialogModel = data.dialogModel;
                        var cancelReasonID = dialogModel.cancelReasonID;
                        var cancelRemark = dialogModel.cancelRemark;
                        var isFirstEntry = (!$scope.contractDetail.GENAPPNUM)
                        $scope.contractDetail.CRDRSLSTP = eBiz.CRDRSLSTP.Cancel;
                        $scope.contractDetail.CRDCURSTP = $scope.contractDetail.CRDNXTSTP;
                        $scope.contractDetail.CRDNXTSTP = 20;
                        $scope.contractDetail.CRDDEVIAT = cancelReasonID;

                        $scope.onSave().then(function () {
                            var remarkModel = {
                                REMARK_ID: null,
                                RMKLEVRSL: 3,
                                GENREMARK: "(Cancel in application) " + mlsStringUtils.toStringOrEmpty(cancelRemark),
                                GENPROGRM: "CON"
                            }

                            remarkDataSvc.insertOrUpdateRemark(
                                [remarkModel],
                                $scope.contractDetail.CPNCOD,
                                $scope.contractDetail.CPNBRNCOD,
                                $scope.contractDetail.ACCBUSTYP,
                                $scope.contractDetail.CONNUM,
                                $rootScope.Username).then(function () {
                                    var ok = mlsDialog.showCustomDialog({}, {
                                        scope: $scope,
                                        template: mlsUrlSvc.getUrlContent("/Template/dialog-template/ApplicationRejectTemplate.html"),
                                        className: 'ngdialog-theme-default dialog-large',
                                        closeByDocument: false,
                                        showClose: false,
                                        closeByEscape: false
                                    }, null);



                                    ok.then(function () {
                                        locationHelper.path("/appList");
                                    })
                                })
                        });


                    })
                })
            }
            else {
                mlsDialog.showWarningDialog({ message: "Please correct invalid data before save.", messageCode: "inf0001" })
            }
        }) 
    }
     
    $scope.onSendBack = function () {
        $scope.onValidate().then(function (data) {
            if (data.isValid) {
                /*Get Reason datasource*/
                var deferred = $q.defer();

                deferred.resolve();
                /*-------------------------*/

                deferred.promise.then(function (dataSource) {
                    var confirmed = mlsAppSendBackDialog.show({ 
                        txtRemarkLabelText: $scope.listLabelText.txtRejectRemark,
                    });

                    confirmed.then(function (data) {

                        var dialogModel = data.dialogModel; 
                        var remark = dialogModel.remark;
                        $scope.contractDetail.CRDRSLSTP = eBiz.CRDRSLSTP.SendBack; 
                        $scope.contractDetail.CRDNXTSTP = $scope.contractDetail.CRDCURSTP; 

                        $scope.onSave().then(function () {
                            var remarkModel = {
                                REMARK_ID: null,
                                RMKLEVRSL: 3,
                                GENREMARK: "(Sendback in jugdment) " + mlsStringUtils.toStringOrEmpty(remark),
                                GENPROGRM: "CON"
                            }

                            remarkDataSvc.insertOrUpdateRemark(
                                [remarkModel],
                                $scope.contractDetail.CPNCOD,
                                $scope.contractDetail.CPNBRNCOD,
                                $scope.contractDetail.ACCBUSTYP,
                                $scope.contractDetail.CONNUM,
                                $rootScope.Username).then(function () {
                                    var ok = mlsDialog.showInfoDialog({ message: "Send back complete", messaeCode: "INF004" }, {
                                        closeByDocument: false,
                                        showClose: false,
                                        closeByEscape: false
                                    }); 

                                    ok.then(function () {
                                        locationHelper.path("/judgmentList");
                                    })
                                })
                        });


                    })
                })
            }
            else {
                mlsDialog.showWarningDialog({ message: "Please correct invalid data before save.", messageCode: "inf0001" })
            }
        })
    }

    /*OnConfirm Judgment*/
    $scope.onConfirm = function ()
    { 
        var tab = $scope.getActiveTab() 
        if(!tab)
        {
            $scope.tabs[0].active = true;
        }
        else
        {
            if ($scope.nextStepTab.CRDNXTSTP == $scope.tabs.last().CRDNXTSTP)
            {
                // show dialog Contract no , cuscod , GENAPRDTE, ACCNAMTHA
                var confirm = mlsDialog.showConfirmDialog({ message: "Do you want to approve this case ?", messageCode: "CFM002" });
                confirm.then(function ()
                {
                    $scope.contractDetail.CRDNXTSTP = 20;
                    $scope.contractDetail.CRDRSLSTP = eBiz.CRDRSLSTP.Approve;
                    $scope.saveContractData().then(function ()
                    { 
                        $scope.showApproveCompleteDialog().then(function ()
                        { 
                            locationHelper.path("/judgmentList");
                        })

                    });

                }, function ()
                {
                
                })
            }
            else
            { 
                $scope.getTabByStep(tab.CRDNXTSTP + 1);
                $scope.nextStepTab.active = true;
            }
        }
    } 
    
    $scope.nextStep = function ()
    { 
        if ($scope.contractDetail.CRDNXTSTP <= $scope.tabs.last().CRDNXTSTP) // Cant be next step
        {
            // go to next step
            //debugger 
            var nextTab = $scope.getTabByStep($scope.contractDetail.CRDNXTSTP); // get next step's tab  
            nextTab.active = true;   // active next step tab
        }
        else
        {
            if($scope.contractDetail.RECSTSCOD == 4)
            {
                $scope.showApproveCompleteDialog().then(function ()
                {
                    locationHelper.path("/appList");
                }) 
            }
            else
            {
                $scope.showAppEntryCompleteDialog({message : "Application process complete."}).then(function ()
                {
                    locationHelper.path("/appList");
                })

                // show dialog "Finish application entry ,this application will be go to judgment step."
                // GENAPPNUM , CUSCOD ,ACCNAMTHA
                // when modal close redirect to application list page
            }
           
        }
    }

    $scope.clicked = function ()
    {
        alert($scope.PSNREGIDN);
    }
      
    $scope.getValidateID = function ()
    { 
        var validationID = null;
        var currentTab = $scope.getActiveTab()
        var VLD0001 = "VLD0001"
        var arrValidateList = [];
        arrValidateList.push(VLD0001);
        if (currentTab == null)
        { 
            return arrValidateList
        }
        else
        {
           
            for (var i = 0 ; i < $scope.tabs.length ; i++)
            {
                var tab = $scope.tabs[i];
                if (tab.CRDNXTSTP <= currentTab.CRDNXTSTP)
                {
                    arrValidateList.push(tab.validateID);
                }
            }
            return arrValidateList;
        }
    }

    $scope.onValidate = function ()
    {
        var arrValidateList = $scope.getValidateID();
        var deferred = $q.defer();

        $q.all([
            validationDataSvc.getFieldValidation(arrValidateList)
        ]).then(function (response)
        {
            $timeout(function ()
            {
                var validationList = response[0];
                var from = $("#frmAppEntry")
                validationHelper.parseValidationList(from, validationList);

                var isValid = from.valid();
                var elementList = from.validate().errorList;

                for (var i = 0 ; i < elementList.length ; i++)
                {
                    var ele = elementList[i].element; 
                    console.log("Invalid : " + ele.id);
                }

                deferred.resolve({ isValid: isValid })
            });
         
        })

        return deferred.promise;

    }

    $scope.listCusTtlTha = [];
    $scope.listNaturalPersonTitleName = []
    $scope.listCocCusRel = [];
    $scope.InitialComboProjectDepenend = function ()
    {
        var criteria1 = { CONAPPLY_PROJEC: $scope.contractDetail.CONAPPLY_PROJEC };
        var defered = $q.defer();
        $q.all([
            comboBoxDataSvc.getComboAccBusTyp({ TABKEYTWO: $scope.contractDetail.ACCBUSTYP }),
            comboBoxDataSvc.getComboVendor({
                CPNCOD: $scope.contractDetail.CPNCOD,
                CPNBRNCOD: $scope.contractDetail.CPNBRNCOD,
                ACCBUSTYP: $scope.contractDetail.ACCBUSTYP,
                PROJECTCODE: $scope.contractDetail.CONAPPLY_PROJEC
            }),
            comboBoxDataSvc.getComboConApplyTyp(criteria1),
            comboBoxDataSvc.getComboConApplyVia(criteria1),
            comboBoxDataSvc.getComboConObjCod({ TABKEYTWO: $scope.contractDetail.CONOBJCOD }),
            comboBoxDataSvc.getComboConApplyProMot(criteria1),
            comboBoxDataSvc.getComboCreditType({ TABKEYTWO: $scope.contractDetail.ACCLNDTYP }),
            comboBoxDataSvc.getComboCusTypCod({ TABKEYTWO: $scope.contractDetail.CUSTYPCOD }),
            comboBoxDataSvc.getComboConTaxTyp({ TABKEYTWO: $scope.contractDetail.CONTAXTYP })
        ]).then(function (response)
        {

            $scope.listAccBusType = response[0];
            //$scope.contractDetail.ACCBUSTYP = response[0][0].TABKEYTWO; 

            $scope.listAccCodDlr = response[1];
            if ($scope.listAccCodDlr.length == 1 && $scope.screenMode == eScreenMode.ADD)
            {
                $scope.contractDetail.ACCCODDLR = $scope.listAccCodDlr[0].value
            }

            $scope.listConApplyTyp = response[2];
            $scope.contractDetail.CONAPPLY_TYP = $scope.listConApplyTyp[0].TABKEYTWO

            $scope.listConApplyVia = response[3];
            $scope.contractDetail.CONAPPLY_VIA = $scope.listConApplyVia[0].TABKEYTWO

            $scope.listConObjCod = response[4];
            //$scope.contractDetail.CONOBJCOD = $scope.listConObjCod[0].TABKEYTWO

            $scope.listConApplyPromot = response[5];

            $scope.listACCLNDTYP = response[6];
            $scope.listCusTypCod = response[7];
            $scope.listConTaxTyp = response[8];

            defered.resolve()
        });

        return defered.promise
    }

    $scope.initialComboBoxData = function ()
    {
        var defered = $q.defer();

        $q.all([
            comboBoxDataSvc.getComboCusTtlPsn(),
            comboBoxDataSvc.getComboDayOfWeek(),
            comboBoxDataSvc.getComboPsnMarSts(),
            comboBoxDataSvc.getComboPsnSexCod(),
            comboBoxDataSvc.getComboAdrOwnCod(),
            comboBoxDataSvc.getComboPsnCpnTyp(),
            comboBoxDataSvc.getComboPsnOccCod(),
            comboBoxDataSvc.getComboPsnSalRcvTyp(),
            comboBoxDataSvc.getComboCoOperateTyp(),
            comboBoxDataSvc.getComboPsnPosItn(),
            comboBoxDataSvc.getComboFinBnkCod(),
            comboBoxDataSvc.getComboPsnEmployTyp(),
            comboBoxDataSvc.getTelLogResultFamily(),
            comboBoxDataSvc.getTelLogResultHome(),
            comboBoxDataSvc.getTelLogResultOffice(),
            comboBoxDataSvc.getTelLogResultMobile(),
            comboBoxDataSvc.getTelLogResultRelative(),
            comboBoxDataSvc.getComboDBDResult(),
            comboBoxDataSvc.getComboCocCusRel(),
            comboBoxDataSvc.getTelLogResultNone()
        ]).then(function (response)
        {
            $scope.listNaturalPersonTitleName = response[0];
            $scope.listPsnBthDay = response[1];
            $scope.listPsnMarSts = response[2];
            $scope.listPsnSexCod = response[3];
            $scope.listAdrOwnCod = response[4];
            $scope.listPsnCpnTyp = response[5];
            $scope.listPsnOccCod = response[6];
            $scope.listPsnSalRcvTyp = response[7];
            $scope.listCoOperateTyp = response[8];
            $scope.listPsnPosItn = response[9];
            $scope.listFinBnkCod = response[10];
            $scope.listPsnEmployTyp = response[11];
            $scope.listTelLogFamily = response[12];
            $scope.listTelLogHome = response[13];
            $scope.listTelLogOffice = response[14];
            $scope.listTelLogMobile = response[15];
            $scope.listTelLogRelative = response[16];
            $scope.listDbdRslt = response[17];
            $scope.listCocCusRel = response[18];
            $scope.listTelLogNone = response[19];
            defered.resolve
        })
    
 
        return defered.promise
    }
     
    $scope.getTelLogResult = function (telLogType)
    {
        if (telLogType == eBiz.TEL_LOG_TYPE.HOME)
        {
            return $scope.listTelLogHome;
        }
        else if (telLogType == eBiz.TEL_LOG_TYPE.OFFICE)
        {
            return $scope.listTelLogOffice;
        }
        else if (telLogType == eBiz.TEL_LOG_TYPE.RELATIVE)
        {
            return $scope.listTelLogRelative;
        }
        else if (telLogType == eBiz.TEL_LOG_TYPE.FAMILY)
        {
            return $scope.listTelLogFamily;
        }
        else if (telLogType == eBiz.TEL_LOG_TYPE.MOBILE)
        {
            return $scope.listTelLogMobile;
        }
        else
        {
            return $scope.listTelLogNone;
        }
    }
     
    $scope.$on('ngDialog.opened', function (e, $dialog)
    {
        console.log('ngDialog opened: ' + $dialog.attr('id'));
    });

    $scope.printTelLog = function ()
    {
        $.each($scope.telLogList, function ()
        {
            console.log(this);
        })
    }

    $scope.printProductSpec = function ()
    {
        console.log($scope.productSpec) 
    }


    $scope.printGuarantor = function ()
    {
        $.each($scope.guarantorList, function ()
        {
            console.log(this);
        })
    }

    $scope.printRefPerson = function ()
    {
        console.log($scope.refPersonList) 
    }

    $scope.printLoanEvd = function ()
    {
        $.each($scope.loanEvdList, function ()
        {
            console.log(this);
        })
    }
  
    $scope.printContractDetail = function ()
    {
        console.log($scope.contractDetail);
    }

    $scope.remoteUrlRequestFn = function (str)
    {
        return { aumphurName: str };
    };

    $scope.clearFormValidator = function (from)
    {
        from.removeData('validator');
    }

    $scope.setValidateBusinessInfo = function ()
    {
        $("#cboConApplyProjec").rules("add", {
            required: true,
            messages: $scope.validateRequireMsg
        })

        $("#cboAccBusTyp").rules("add", {
            required: true,
            messages: $scope.validateRequireMsg
        })

        $("#cboConCrdTyp").rules("add", {
            required: true,
            messages: $scope.validateRequireMsg
        })

        $("#cboConTaxTyp").rules("add", {
            required: true,
            messages: $scope.validateRequireMsg
        })

        $("#cboCusTypCod").rules("add", {
            required: true,
            messages: $scope.validateRequireMsg
        })

      
    }



    /*Call Area*/
    $scope.InitialComponents();
 
}]);
