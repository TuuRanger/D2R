﻿angular.module('mainApp').controller('appEntryBusinessInfoController', ['$scope', 'comboBoxDataSvc', 'mlsStringUtils','eBiz','eScreenMode','campaignDataSvc','$q','$rootScope',
function ($scope, comboBoxDataSvc, mlsStringUtils, eBiz, eScreenMode, campaignDataSvc, $q, $rootScope)
{ 
    //$scope.AppEntrybase = $("[ng-controller=appEntryController]").scope()
    //$scope.contractDetail = $scope.AppEntrybase.contractDetail;
    $scope.listConApplyTyp = [];
    $scope.initialComboBox = function ()
    {
        comboBoxDataSvc.getComboConApplyProjec().then(function (data)
        {
            $scope.listConApplyProjec = data;
        }) 
    }

    var onInitialData = $rootScope.$on("initial-contract-data-complete", function (event, args) /*OnEditMode*/
    { 
    }) 
     

    $scope.initialComponents = function ()
    {
        $scope.initialComboBox();
    }
     
    $scope.initialComponents();
     
    $scope.$on('$destroy', function () {
        if (typeof onInitialData == 'function') {
            onInitialData();
            console.log("unbind onInitialData complete")
        }
    })
}]);