﻿mainApp.controller('appEntryContractInfoController', ['$scope', '$rootScope', 'referencePersonDataSvc', 'comboBoxDataSvc', 'addressDataSvc', '$q', 'guarantorPersonDataSvc',
    function ($scope, $rootScope, referencePersonDataSvc, comboBoxDataSvc, addressDataSvc, $q, guarantorPersonDataSvc)
    {

        $scope.AppEntrybase = $("[ng-controller=appEntryController]").scope() 
        $scope.campaignDetail = $scope.AppEntrybase.campaignDetail;

        var appEntryScope = null;
        $scope.listAddressTypeCode = [];
        $scope.listNaturalPersonAddressTypeCode = [];
        $scope.listNaturalPersonAddressRefCode = [];
        $scope.loadReferencPerson = function (criteria)
        {
            referencePersonDataSvc.getReferencePersonList(criteria).then(function (data)
            {
                appEntryScope.refPersonList = data;
                 
                if (appEntryScope.refPersonList.length == 0)
                {
                    appEntryScope.refPersonList = [{ open: true ,RECACTCOD : "A" , CUSTYPCOD : "02"}];
                }
            })

        }


        $scope.loadGuarantor = function (criteria)
        {
            guarantorPersonDataSvc.getGuarantorPersonList(criteria).then(function (data)
            { 
                appEntryScope.guarantorList = data;
                if (appEntryScope.guarantorList.length == 0)
                {
                    appEntryScope.guarantorList = [{ open: true, AddressList: [{ open: true }] }];
                }
                else
                {
                    for (var i = 0 ; i < appEntryScope.guarantorList.length ; i++)
                    {
                        var gua = appEntryScope.guarantorList[i];
                        if (gua.AddressList.length == 0)
                        {
                            gua.AddressList = [{ RECACTCOD: 'A', CUSTYPCOD: "02", open: true }];
                        }
                    }
                }

            })

        }

        $scope.loadAddress = function (criteria)
        { 
            addressDataSvc.getCustomerAddress(criteria).then(function (data)
            {
                appEntryScope.addressList = data;
                if (appEntryScope.addressList.length == 0)
                {
                    appEntryScope.addressList = [{ open: true }];
                }
            })
        }

        var onInitialData =  $rootScope.$on("initial-contract-data-complete", function (event, args)
        {
            appEntryScope = args.scope
            if ($scope.isCanGetData('tabContractInfo')) // get data when next tab active or first load
            {
                $scope.loadReferencPerson(args.contractCriteria);
                $scope.loadGuarantor(args.contractCriteria);
                $scope.loadAddress(args.contractCriteria);
            }
        })

        $scope.$watch('contractDetail.CUSTYPCOD', function (newVal, oldVal, scope)
        {
            comboBoxDataSvc.getComboAdressTypeCode({ CUSTYPCOD: newVal }).then(function (data)
            {
                $scope.listAddressTypeCode = data;
            })
        })

        $scope.initialComboBox = function ()
        {
            $q.all([
                 comboBoxDataSvc.getComboAdressTypeCode({ CUSTYPCOD: "02" })
            ]).then(function (response)
            {
                $scope.listNaturalPersonAddressTypeCode = response[0];
            })
        }

        $scope.initialComponents = function ()
        {
            $scope.initialComboBox();
        }

        $scope.initialComponents();

        $scope.$on('$destroy', function () {
            if (typeof onInitialData == 'function') {
                onInitialData();
                console.log("unbind onInitialData complete")
            }
        })

    }]);