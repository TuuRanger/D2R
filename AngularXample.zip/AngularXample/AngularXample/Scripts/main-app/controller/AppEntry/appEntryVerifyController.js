﻿angular.module('mainApp').controller('appEntryVerifyController', ['$scope', '$rootScope', 'telLogDataSvc', function ($scope, $rootScope, telLogDataSvc)
{
    var appEntryScope = null;

    $scope.loadTelLog = function (criteria)
    {
        telLogDataSvc.getTelList(criteria).then(function (data)
        { 
            appEntryScope.telLogList = data 
        })
    }
     
    var onInitialData = $rootScope.$on("initial-contract-data-complete", function (event, args)
    {
        appEntryScope = args.scope; 
        if ($scope.nextStepTab.id == "tabVerify" || $scope.isCanGetData('tabVerify'))
        {
            $scope.loadTelLog(args.contractCriteria);
        }
        
    })



    $scope.$on('$destroy', function () { 
        if (typeof onInitialData == 'function') {
            onInitialData();
            console.log("unbind onInitialData complete")
        } 
    })



     

}]);