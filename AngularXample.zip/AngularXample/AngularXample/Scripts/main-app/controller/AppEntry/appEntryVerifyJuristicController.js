﻿angular.module('mainApp').controller('appEntryVerifyJuristicController', ['$scope', '$rootScope', 'telLogDataSvc', function ($scope, $rootScope, telLogDataSvc)
{
 


}]);