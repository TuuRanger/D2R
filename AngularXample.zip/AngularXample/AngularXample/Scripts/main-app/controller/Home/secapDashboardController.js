﻿angular.module('mainApp').controller('secapDashboardController', ['$scope', '$stateParams', '$state', '$rootScope', '$location', 'comboBoxDataSvc', '$q', 'eBiz', 'mlsUrlSvc', 'mlsStringUtils', 'eScreenMode', 'mlsLoadingDialog', 'mlsDialog', 'locationHelper', 'validationDataSvc', '$timeout', 'validationHelper', 'mlsFieldValidateDialog', 'locationHelper', 'eScreenPurpose', 'localStorageService', 'highchartsNG',
function ($scope, $stateParams, $state, $rootScope, $location, comboBoxDataSvc, $q, eBiz, mlsUrlSvc, mlsStringUtils, eScreenMode, mlsLoadingDialog, mlsDialog, locationHelper, validationDataSvc, $timeout, validationHelper, mlsFieldValidateDialog, locationHelper, eScreenPurpose, localStorageService, highchartsNG) {


	//This is not a highcharts object. It just looks a little like one!
	var chartColorRange = [
				[70, '#DF5353'], // red
				[50, '#DDDF0D'], // yellow
				[10, '#55BF3B'] // green
	]

	$scope.chartGaugeOverallConfig = {
		options: {
			chart: {
				type: 'solidgauge'
			},
			pane: {
				center: ['50%', '85%'],
				size: '160%',
				startAngle: -90,
				endAngle: 90,
				background: {
					backgroundColor: '#EEE',
					innerRadius: '60%',
					outerRadius: '100%',
					shape: 'arc'
				}
			},
			solidgauge: {
				dataLabels: {
					y: 0,
					borderWidth: 1,
					useHTML: true
				}
			}
		},
		series: [{
			data: [80],
			dataLabels: {
				format: 'Dnger'
			}
		}],
		title: {
			text: 'Overall Status',
			y: 30
		},
		yAxis: {
			currentMin: 0,
			currentMax: 100,
			title: {
				y: 140
			},
			stops: [
				[70, '#DF5353'], // red
				[50, '#DDDF0D'], // yellow
				[10, '#55BF3B']  // green
			],
			lineWidth: 0,
			tickInterval: 20,
			tickPixelInterval: 400,
			tickWidth: 0,
			labels: {
				y: 15
			}
		},
		loading: false
	}
	 
	$scope.chartGaugeCollateralConfig = {
		options: {
			chart: {
				type: 'solidgauge'
			},
			pane: {
				center: ['50%', '85%'],
				size: '140%',
				startAngle: -90,
				endAngle: 90,
				background: {
					backgroundColor: '#EEE',
					innerRadius: '60%',
					outerRadius: '100%',
					shape: 'arc'
				}
			},
			solidgauge: {
				dataLabels: {
					y: 0,
					borderWidth: 1,
					useHTML: true
				}
			}
		},
		series: [{
			data: [50],
			dataLabels: {
				format: 'Secure'
			}
		}],
		title: {
			text: 'Collateral Status',
			y: 30
		},
		yAxis: {
			currentMin: 0,
			currentMax: 100,
			title: {
				y: 140
			},
			stops: chartColorRange,
			lineWidth: 0,
			tickInterval: 20,
			tickPixelInterval: 400,
			tickWidth: 0,
			labels: {
				y: 15
			}
		},
		loading: false
	}

	$scope.chartGaugeProvisionConfig = {
		options: {
			chart: {
				type: 'solidgauge'
			},
			pane: {
				center: ['50%', '85%'],
				size: '140%',
				startAngle: -90,
				endAngle: 90,
				background: {
					backgroundColor: '#EEE',
					innerRadius: '60%',
					outerRadius: '100%',
					shape: 'arc'
				}
			},
			solidgauge: {
				dataLabels: {
					y: 0,
					borderWidth: 1,
					useHTML: true
				}
			}
		},
		series: [{
			data: [80],
			dataLabels: {
				format: 'Warning'
			}
		}],
		title: {
			text: 'Provision Status',
			y: 30
		},
		yAxis: {
			currentMin: 0,
			currentMax: 100,
			title: {
				y: 140
			},
			stops: chartColorRange,
			lineWidth: 0,
			tickInterval: 20,
			tickPixelInterval: 400,
			tickWidth: 0,
			labels: {
				y: 15
			}
		},
		loading: false
	}

	$scope.chartLineDotCollectionForecasting = {
		xAxis: {
			categories: [
				'Jan',
				'Feb',
				'Mar',
				'Apr',
				'May',
				'Jun',
				'Jul',
				'Aug',
				'Sep',
				'Oct',
				'Nov',
				'Dec']
		},
		title: {
			text: 'Collection Forcasting'
		}, subtitle: {
			text: document.ontouchstart === undefined ?
				'Click and drag in the plot area to zoom in' :
				'Pinch the chart to zoom in'
		},
		yAxis: { title: { text: 'yAxis Label' } },
		tooltip: { valueSuffix: ' Suffix' },
		legend: { align: 'center', verticalAlign: 'bottom', borderWidth: 0 },
		plotOptions: {
			area: {
				fillColor: {
					//stops: [
					//	[0, Highcharts.getOptions().colors[0]],
					//	[1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
					//]
				},
				marker: {
					radius: 2
				},
				lineWidth: 1,
				states: {
					hover: {
						lineWidth: 1
					}
				},
				threshold: null
			},
			compare: 'percent'
		},
		series: [
			 {
				 type : 'area',
				 name: 'Series1',
				 data: [10,20,30,40,50,60,70,80,90,100,110]
			 },
			 {
				 type: 'area',
				 name: 'Series2',
				 data: [123, 13, 2, 40, 43, 623 ,133, 80, 90, 100, 115]
			 }
		]
	};

	$scope.chartLineDotSupplier = {
	    xAxis: {
	        categories: [
				'Jan',
				'Feb',
				'Mar',
				'Apr',
				'May',
				'Jun',
				'Jul',
				'Aug',
				'Sep',
				'Oct',
				'Nov',
				'Dec']
	    },
	    title: {
	        text: 'Supplier'
	    }, subtitle: {
	        text: document.ontouchstart === undefined ?
				'Click and drag in the plot area to zoom in' :
				'Pinch the chart to zoom in'
	    },
	    yAxis: { title: { text: 'yAxis Label' } },
	    tooltip: { valueSuffix: ' Suffix' },
	    legend: { align: 'center', verticalAlign: 'bottom', borderWidth: 0 },
	    plotOptions: {
	        area: {
	            fillColor: {
	                //stops: [
	                //	[0, Highcharts.getOptions().colors[0]],
	                //	[1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
	                //]
	            },
	            marker: {
	                radius: 2
	            },
	            lineWidth: 1,
	            states: {
	                hover: {
	                    lineWidth: 1
	                }
	            },
	            threshold: null
	        },
	        compare: 'percent'
	    },
	    series: [
			 {
			     type: 'area',
			     name: 'Series1',
			     data: [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110]
			 },
			 {
			     type: 'area',
			     name: 'Series2',
			     data: [123, 13, 2, 40, 43, 623, 133, 80, 90, 100, 115]
			 }
	    ]
	};

	$scope.chartLineDotSponsor = {
	    xAxis: {
	        categories: [
				'Jan',
				'Feb',
				'Mar',
				'Apr',
				'May',
				'Jun',
				'Jul',
				'Aug',
				'Sep',
				'Oct',
				'Nov',
				'Dec']
	    },
	    title: {
	        text: 'Sponsor'
	    }, subtitle: {
	        text: document.ontouchstart === undefined ?
				'Click and drag in the plot area to zoom in' :
				'Pinch the chart to zoom in'
	    },
	    yAxis: { title: { text: 'yAxis Label' } },
	    tooltip: { valueSuffix: ' Suffix' },
	    legend: { align: 'center', verticalAlign: 'bottom', borderWidth: 0 },
	    plotOptions: {
	        area: {
	            fillColor: {
	                //stops: [
	                //	[0, Highcharts.getOptions().colors[0]],
	                //	[1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
	                //]
	            },
	            marker: {
	                radius: 2
	            },
	            lineWidth: 1,
	            states: {
	                hover: {
	                    lineWidth: 1
	                }
	            },
	            threshold: null
	        },
	        compare: 'percent'
	    },
	    series: [
			 {
			     type: 'area',
			     name: 'Series1',
			     data: [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110]
			 },
			 {
			     type: 'area',
			     name: 'Series2',
			     data: [123, 13, 2, 40, 43, 623, 133, 80, 90, 100, 115]
			 }
	    ]
	};

	$scope.chartLineDotSales = {
	    xAxis: {
	        categories: [
				'Jan',
				'Feb',
				'Mar',
				'Apr',
				'May',
				'Jun',
				'Jul',
				'Aug',
				'Sep',
				'Oct',
				'Nov',
				'Dec']
	    },
	    title: {
	        text: 'Sales'
	    }, subtitle: {
	        text: document.ontouchstart === undefined ?
				'Click and drag in the plot area to zoom in' :
				'Pinch the chart to zoom in'
	    },
	    yAxis: { title: { text: 'yAxis Label' } },
	    tooltip: { valueSuffix: ' Suffix' },
	    legend: { align: 'center', verticalAlign: 'bottom', borderWidth: 0 },
	    plotOptions: {
	        area: {
	            fillColor: {
	                //stops: [
	                //	[0, Highcharts.getOptions().colors[0]],
	                //	[1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
	                //]
	            },
	            marker: {
	                radius: 2
	            },
	            lineWidth: 1,
	            states: {
	                hover: {
	                    lineWidth: 1
	                }
	            },
	            threshold: null
	        },
	        compare: 'percent'
	    },
	    series: [
			 {
			     type: 'area',
			     name: 'Series1',
			     data: [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110]
			 },
			 {
			     type: 'area',
			     name: 'Series2',
			     data: [123, 13, 2, 40, 43, 623, 133, 80, 90, 100, 115]
			 }
	    ]
	};

	$scope.chartLineDotGain = {
	    xAxis: {
	        categories: [
				'Jan',
				'Feb',
				'Mar',
				'Apr',
				'May',
				'Jun',
				'Jul',
				'Aug',
				'Sep',
				'Oct',
				'Nov',
				'Dec']
	    },
	    title: {
	        text: 'Gain'
	    }, subtitle: {
	        text: document.ontouchstart === undefined ?
				'Click and drag in the plot area to zoom in' :
				'Pinch the chart to zoom in'
	    },
	    yAxis: { title: { text: 'yAxis Label' } },
	    tooltip: { valueSuffix: ' Suffix' },
	    legend: { align: 'center', verticalAlign: 'bottom', borderWidth: 0 },
	    plotOptions: {
	        area: {
	            fillColor: {
	                //stops: [
	                //	[0, Highcharts.getOptions().colors[0]],
	                //	[1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
	                //]
	            },
	            marker: {
	                radius: 2
	            },
	            lineWidth: 1,
	            states: {
	                hover: {
	                    lineWidth: 1
	                }
	            },
	            threshold: null
	        },
	        compare: 'percent'
	    },
	    series: [
			 {
			     type: 'area',
			     name: 'Series1',
			     data: [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110]
			 },
			 {
			     type: 'area',
			     name: 'Series2',
			     data: [123, 13, 2, 40, 43, 623, 133, 80, 90, 100, 115]
			 }
	    ]
	};
}]);