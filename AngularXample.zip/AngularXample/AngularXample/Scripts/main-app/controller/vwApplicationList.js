﻿mainApp.controller('appListController',
    ['$scope', 'mlsLanguage', 'mainAppContext', 'mlsScreenResourceProvider', 'contractDataSvc', 'setupDataSvc', '$http',
function ($scope, mlsLanguage, mainAppContext, mlsScreenResourceProvider, contractDataSvc, setupDataSvc, $http)
{
    $scope.$emit('on-screen-load', { screenID: "APP002AppList", screenTitle: "Application list" });

    $scope.searchData = function ()
    {
        $scope.searchCriteria = $scope.searchCriteria || {};
        $scope.searchCriteria.CRDSTPFROM = 1
        $scope.searchCriteria.CRDSTPTO = 9
        contractDataSvc.getContractList($scope.searchCriteria).then(function (data)
        {
            $scope.gridOptions.data = data; 
        })
    }

    $scope.initialGrid = function ()
    { 
        $scope.gridOptions = {
            enableRowSelection: true,
            multiSelect: false,
            modifierKeysToMultiSelect: false,
            enableRowHeaderSelection: false ,
            noUnselect : true,
            enableSorting: true,
            enableColumnResizing: true,
            rowHeight: 40,
            columnDefs: [
              {
                  name: 'Action', width: "100",
                  cellTemplate: '<a href="{{\'#/editApp?GENAPPNUM=\' + row.entity.GENAPPNUM + \'&ACCBUSTYP=\'+ row.entity.ACCBUSTYP     + \'&CPNCOD=\' + row.entity.CPNCOD + \'&CPNBRNCOD=\' + row.entity.CPNBRNCOD+ \'&purpose=ENTRY\'}}"' + ' class="btn btn-sm btn-warning"><i class="fa fa-pencil fa-2x"></i></a>',
                  cellClass: 'cell-aligh-center',
                  enableSorting: false
              },
              { name: 'App. No.', field: 'GENAPPNUM', width: "150" },
              { name: 'ID', field: 'PSNREGIDN', width: "120", displayName: 'ID' },
              { name: 'Customer name', field: 'ACCNAMTHA', width: "200" },
              { name: 'Project', field: 'CONAPPLY_PROJEC', width: "90" },
              { name: 'Vendor', field: 'ACCCODDLR', width: "90" },
              { name: 'Branch', field: 'CPNBRNCOD', width: "90" },
              { name: 'Status', field: 'CRDNXTSTP_DSC', width: "150" },
              { name: 'Last remark', field: 'GENREMARK', },
              { name: 'Last update by', field: 'MTNUSRCOD', width: "150" },
              { name: 'Last update time', field: 'MTNDTETME', width: "180", cellFilter: 'date : "dd/MM/yyyy HH:mm:ss"' },

            ],
            onRegisterApi : function(gridApi){
                //set gridApi on scope
                $scope.gridApi = gridApi;
                gridApi.selection.on.rowSelectionChanged($scope,function(row){
                
                }); 
            }
        }; 
    }
      
    $scope.initialComponents = function ()
    { 
        $scope.initialGrid(); 
    }
     
    $scope.initialComponents();
     
     
}]);

