﻿mainApp.controller('bizController',
    ['$scope', 'mlsLanguage', 'mainAppContext', 'mlsScreenResourceProvider', '$rootScope', 'menuDataSvc', '$timeout', '$q', 'locationHelper', 'authenDataSvc',
function ($scope, mlsLanguage, mainAppContext, mlsScreenResourceProvider, $rootScope, menuDataSvc, $timeout, $q, locationHelper, authenDataSvc) {
    $scope.changeLang = function (lang,flag) /* Broad case child screen to change language*/ {
        mainAppContext.setCurrentLanguage(lang, flag);
        $scope.getGlobalResource();
        $scope.$broadcast('sys-language-changed');
        $scope.$emit('sys-language-changed');
    }

    $scope.flag = 'us';
    $scope.layoutID = "_AppEntryLayout"

    $scope.initialDropDownLanguage = function () {
        var defered = $q.defer()
        mlsLanguage.GetSysLanguage().then(function (data) {
            $scope.sysLangList = data;
            mainAppContext.sysLanguageList = data;
            defered.resolve();
        })
        return defered.promise;
    }

    $scope.menuList = []


    $scope.initialMenus = function () {
        $scope.menuList = mainAppContext.getMenuList();
    }


    $rootScope.$on("initial-menu-complete", function () { // from login controller
        $scope.menuList = mainAppContext.getMenuList();
    });

    $rootScope.$on("initial-user-profile-complete", function () { // from login controller
        $scope.initialDropDownLanguage().then(function ()
        {
            var arrLangInfo = mainAppContext.getLaguageInfo($rootScope.userProfile.LanguageCode);

            var langInfo = null;
            if (arrLangInfo.length > 0)
            {
                langInfo = arrLangInfo[0];
            }

            $scope.flag = langInfo.TABSETVAL1
             
            mainAppContext.setCurrentLanguage($rootScope.userProfile.LanguageCode, langInfo.TABSETVAL1);
        }); 
    });


    $scope.checkUserPermission = function (permission) {
        var defered = $q.defer();
        defered.resolve({ isValid: true });
        return defered.promise;
    }

    $scope.InitialComponents = function () {
        $scope.initialDropDownLanguage();
        $scope.initialMenus(); 
    }

    $scope.InitialComponents();
}])

