﻿angular.module('mainApp').controller('factoringSupplierRequestController', ['$scope', '$stateParams', '$state', '$rootScope', '$location', 'comboBoxDataSvc', '$q', 'eBiz', 'mlsUrlSvc', 'mlsStringUtils', 'eScreenMode', 'mlsCustomerSearchDialog', 'addressDataSvc', 'mlsLoadingDialog', 'accountDataSvc', 'mlsDialog', 'locationHelper', 'validationDataSvc', '$timeout', 'validationHelper', 'mlsFieldValidateDialog', 'locationHelper', 'eScreenPurpose', 'mlsAppSendBackDialog', 'remarkDataSvc',
function ($scope, $stateParams, $state, $rootScope, $location, comboBoxDataSvc, $q, eBiz, mlsUrlSvc, mlsStringUtils, eScreenMode, mlsCustomerSearchDialog, addressDataSvc, mlsLoadingDialog, accountDataSvc, mlsDialog, locationHelper, validationDataSvc, $timeout, validationHelper, mlsFieldValidateDialog, locationHelper, eScreenPurpose, mlsAppSendBackDialog, remarkDataSvc) {

    $scope.$emit('on-screen-load', { screenID: "Factoring001_SponsorDashboard", screenTitle: "Supplier Request" });
    
    $scope.initialComponents = function () 
    { 
    }
  
    $scope.initialComponents();
}]);