﻿angular.module('mainApp').controller('factoringSupplierStatementController', ['$scope', '$stateParams', '$state', '$rootScope', '$location', 'comboBoxDataSvc', '$q', 'eBiz', 'mlsUrlSvc', 'mlsStringUtils', 'eScreenMode', 'mlsCustomerSearchDialog', 'addressDataSvc', 'mlsLoadingDialog', 'accountDataSvc', 'mlsDialog', 'locationHelper', 'validationDataSvc', '$timeout', 'validationHelper', 'mlsFieldValidateDialog', 'locationHelper', 'eScreenPurpose', 'mlsAppSendBackDialog', 'remarkDataSvc',
function ($scope, $stateParams, $state, $rootScope, $location, comboBoxDataSvc, $q, eBiz, mlsUrlSvc, mlsStringUtils, eScreenMode, mlsCustomerSearchDialog, addressDataSvc, mlsLoadingDialog, accountDataSvc, mlsDialog, locationHelper, validationDataSvc, $timeout, validationHelper, mlsFieldValidateDialog, locationHelper, eScreenPurpose, mlsAppSendBackDialog, remarkDataSvc) {

    $scope.$emit('on-screen-load', { screenID: "Factoring001_SponsorDashboard", screenTitle: "Statement" });
    $scope.initialGrid = function () {
        $scope.gridOptions = {
            enableRowSelection: true,
            multiSelect: false,
            modifierKeysToMultiSelect: false,
            enableRowHeaderSelection: false,
            noUnselect: true,
            enableSorting: true,
            enableColumnResizing: true,
            rowHeight: 40,
            columnDefs: [
              { name: 'Transaction Date', field: 'MTNDTETME', width: "180", cellFilter: 'date : "dd/MM/yyyy HH:mm:ss"' },
              { name: 'Description', field: 'PSNREGIDN', width: "200",   },
              { name: 'Credit', width: "150", field: 'OVDDAY', cellFilter: 'decimal', cellClass: 'cell-align-right text-danger' },
              { name: 'Debit', width: "150", field: 'OVDDAY', cellFilter: 'decimal', cellClass: 'cell-align-right text-success' }, 
            ],
            onRegisterApi: function (gridApi) {
                //set gridApi on scope
                $scope.gridApi = gridApi;
                gridApi.selection.on.rowSelectionChanged($scope, function (row) {

                });
            },
            data: [
                {
                    OVDDAY : 999999
                }
            ]
        };
    }


    $scope.initialComponents = function () 
    {
        $scope.initialGrid()
    }
  
    $scope.initialComponents();
}]);