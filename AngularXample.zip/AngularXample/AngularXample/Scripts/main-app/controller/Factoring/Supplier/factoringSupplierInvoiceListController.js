﻿angular.module('mainApp').controller('factoringSupplierInvoiceListController', ['$scope', '$stateParams', '$state', '$rootScope', '$location', 'comboBoxDataSvc', '$q', 'eBiz', 'mlsUrlSvc', 'mlsStringUtils', 'eScreenMode', 'mlsLoadingDialog', 'mlsDialog', 'locationHelper', '$timeout', 'locationHelper', 'eScreenPurpose', 'factoryDataSvc', 'uiGridConstants', 'mainAppContext', 'uiGridValidateService', 'mlsFieldValidateDialog', 'accountDataSvc','contractDataSvc',
function ($scope, $stateParams, $state, $rootScope, $location, comboBoxDataSvc, $q, eBiz, mlsUrlSvc, mlsStringUtils, eScreenMode, mlsLoadingDialog, mlsDialog, locationHelper, $timeout, locationHelper, eScreenPurpose, factoryDataSvc, uiGridConstants, mainAppContext, uiGridValidateService, mlsFieldValidateDialog, accountDataSvc, contractDataSvc) {

    $scope.$emit('on-screen-load', { screenID: "Factoring005_SupplierInvoiceList", screenTitle: "Invoice List" });
    $scope.searchCriteria = {}
    $scope.viewModel = {
        creditRequest : null
    }

    $scope.searchData = function ()
    {
       var dialog =  mlsLoadingDialog.show();
        factoryDataSvc.getInvoiceList({
            productType:  $scope.searchCriteria.productType,
            InvoiceDateFrom: $scope.searchCriteria.InvoiceDateFrom,
            invoiceDateTo: $scope.searchCriteria.invoiceDateTo,
            dueDateFrom: $scope.searchCriteria.dueDateFrom,
            dueDateTo: $scope.searchCriteria.dueDateTo
        }).then(function (data)
        {
            $scope.gridOptions.data = data;
            dialog.close();
        })
    }
 
    $scope.getCurrencyColumTemplate = function (name, width, field, enableCellEdit)
    {
        var cellClass = 'cell-align-right'
        if (enableCellEdit == true)
        {
            cellClass += ' editable-cell'
        }
        return angular.merge({},{
            name: name,
            width: width,
            field: field,
            enableCellEdit: enableCellEdit,
            cellFilter: 'decimal',
            cellClass: cellClass,
            aggregationType: uiGridConstants.aggregationTypes.sum,
            footerCellTemplate: mlsUrlSvc.getUrlContent(mainAppContext.template.uiGridSumFooter)
        })
    }
     
    $scope.creditRequestEditableCondition = function ($gridScope) {
        return  $gridScope.row.entity.INVAMT.toDecimalOrZero() -  $gridScope.row.entity.RSVAMT.toDecimalOrZero() - $gridScope.row.entity.FINAMT.toDecimalOrZero() > 0
    }


    uiGridValidateService.setValidator('max', function (param) {
        
        return function (oldValue,newValue, rowEntity, colDef) { 
            console.log("newValue : " + newValue);
            console.log("oldValue : " + oldValue);
             
            if (param.field)
            { 
                return newValue.toDecimalOrZero() <= rowEntity[param.field].toDecimalOrZero();
            }
            else if (typeof param.value == 'string')
            {
                eval("var value = " + param.value); 
                return newValue.toDecimalOrZero() <= value.toDecimalOrZero()
            }
            else
            {
                return newValue.toDecimalOrZero() <= param.value.toDecimalOrZero()
            }
        }
    }, function (param) {
        return ("'{0}' should not greater than '{1}'")
            .replace("{0}", param.messageParam.validateFileName)
            .replace("{1}", param.messageParam.targetFieldName)
    })

    $scope.initialGrid = function () {
        $scope.gridOptions = {
            enableRowSelection: true,
            multiSelect: false,
            modifierKeysToMultiSelect: false,
            enableRowHeaderSelection: false,
            showColumnFooter: true,
            noUnselect: true,
            enableSorting: true,
            enableColumnResizing: true,
            rowHeight: 35,
            rowEditWaitInterval: -1,
            columnDefs: [ 
              { name: 'Invoice No.', field: 'INVNUM', width: "120", enableCellEdit: false },
              { name: 'Invoice Date', field: 'INVDTE', width: "150", cellFilter: 'date : "dd/MM/yyyy"', enableCellEdit: false },
              $scope.getCurrencyColumTemplate('Credit Amount', '160', 'INVAMT', false),
              $scope.getCurrencyColumTemplate('Credit Usage', '160', 'FINAMT', false),
              angular.merge({}, $scope.getCurrencyColumTemplate('Credit Request', '160', 'CreditRequestAmount', true),
                  { 
                      validators: {
                          max: {
                              value: 'rowEntity.INVAMT.toDecimalOrZero() - rowEntity.RSVAMT.toDecimalOrZero() - rowEntity.FINAMT.toDecimalOrZero()',
                              messageParam: {
                                  validateFileName : "Credit Request",
                                  targetFieldName : "Credit Available"
                              }
                          }
                      },
                      cellTemplate: 'ui-grid/cellTitleValidator',
                      cellEditableCondition: $scope.creditRequestEditableCondition
                  }),
              $scope.getCurrencyColumTemplate('Credit Available', '160', 'CreditAvailableAmount', false),
              $scope.getCurrencyColumTemplate('Credit Reserve', '160', 'RSVAMT', false),
              { name: 'Due Date', field: 'INVDUEDTE', width: "150", cellFilter: 'date : "dd/MM/yyyy"', enableCellEdit: false }, 
            ],
            onRegisterApi: function (gridApi) {
                //set gridApi on scope
                $scope.gridApi = gridApi;
                gridApi.edit.on.afterCellEdit($scope, function (rowEntity, colDef, newValue, oldValue) {
                    $scope.viewModel.creditRequest = 0;
                    $scope.gridGroupByDueDateOptions.data = [];
                    var duedateGroup = {};
                    angular.forEach($scope.gridOptions.data, function (row, index)
                    {
                        var creditRequestAmount = row.CreditRequestAmount.toDecimalOrZero();
                        row.CreditAvailableAmount = row.INVAMT.toDecimalOrZero() - row.RSVAMT.toDecimalOrZero() - row.FINAMT.toDecimalOrZero() - creditRequestAmount;
                        $scope.viewModel.creditRequest += creditRequestAmount;

                        if (creditRequestAmount > 0)
                        {
                            if (duedateGroup[row.INVDUEDTE]) {
                                duedateGroup[row.INVDUEDTE].CreditRequestAmount += creditRequestAmount
                            }
                            else
                            {
                                duedateGroup[row.INVDUEDTE] = {
                                    CreditRequestAmount: creditRequestAmount
                                }
                            } 
                        }
                        
                    })
                    
                    angular.forEach(duedateGroup, function (duedateObj,deuDate)
                    { 
                        duedateObj.INVDUEDTE = deuDate;
                        $scope.gridGroupByDueDateOptions.data.push(duedateObj);
                    })
                     
                });
                 
            },
            data: [ ]
        };

        $scope.gridGroupBySponsorOptions = {
            enableRowSelection: true,
            multiSelect: false,
            modifierKeysToMultiSelect: false,
            enableRowHeaderSelection: true,
            noUnselect: true,
            enableSorting: true,
            enableColumnResizing: true,
            rowHeight: 35, 
            //showHeader: false,
            //enableScrollbars: false,
            //enableHorizontalScrollbar : 0,
            //enableVerticalScrollbar : 0,
            columnDefs: [
              { name: 'Sponsor Name', field: 'SponsorName', enableCellEdit: false },
              { name: 'Total Invoice', field: 'TotalInvoice', width: "180", enableCellEdit: false, cellClass: 'cell-align-right' },
              { name: 'Amount', width: "150", field: 'TotalAmount', cellFilter: 'decimal', cellClass: 'cell-align-right', enableCellEdit: false },
            ],
            onRegisterApi: function (gridApi) {
                //set gridApi on scope
                $scope.gridApiSponsor = gridApi;

                gridApi.selection.on.rowSelectionChanged($scope, function (row)
                {

                    var dialog = mlsLoadingDialog.show();
                    $scope.gridGroupByDueDateOptions.data = [];
                    $scope.loadInvoiceList(row.entity).then(function () {
                        dialog.close()
                    }) 
                });
                 

            },
            data: []
        };

        $scope.gridGroupByDueDateOptions = {
            enableRowSelection: true,
            multiSelect: false,
            modifierKeysToMultiSelect: false,
            enableRowHeaderSelection: false,
            noUnselect: true,
            enableSorting: true,
            enableColumnResizing: true,
            rowHeight: 35,
            rowEditWaitInterval: -1,
            columnDefs: [
              { name: 'Due Date', field: 'INVDUEDTE',  cellFilter: 'date : "dd/MM/yyyy"', enableCellEdit: false },
              { name: 'Total Amount', width: "150", field: 'CreditRequestAmount', cellFilter: 'decimal', cellClass: 'cell-align-right editable-cell', type: 'number' },
              { name: 'Interest', width: "150", field: 'INTAMT', cellFilter: 'decimal', cellClass: 'cell-align-right editable-cell', type: 'number' },
            ],
            data: []
        };
    }

    $scope.loadInvoiceList = function (selectedSponsor)
    {
        var defered = $q.defer();

        contractDataSvc.getContractDetail({
            CPNCOD: selectedSponsor.CPNCOD,
            CPNBRNCOD: selectedSponsor.CPNBRNCOD,
            GENAPPNUM: selectedSponsor.CONNUM,
            ACCBUSTYP: selectedSponsor.ACCBUSTYP,
        }).then(function (data) {
            $scope.viewModel.CreditLimit = data.CONFINAMT;
            $scope.viewModel.CreditUsage = selectedSponsor.TotalUsageAmount;
            $scope.viewModel.CreditAvailable = $scope.viewModel.CreditLimit - $scope.viewModel.CreditUsage;
            $scope.viewModel.InterestRate = data.CONINTRTE;

            factoryDataSvc.getContractInvoiceList({
                CPNCOD: selectedSponsor.CPNCOD,
                CPNBRNCOD: selectedSponsor.CPNBRNCOD,
                ACCBUSTYP: selectedSponsor.ACCBUSTYP,
                CONNUM: selectedSponsor.CONNUM
            }).then(function (invoiceList) {
                $scope.gridOptions.data = invoiceList;

                defered.resolve();
            })
        })

        return defered.promise;
    }

    $scope.onConfirm = function ()
    {
        var isValid = true;
        var rowsRendred = $scope.gridApi.grid.renderContainers.body.renderedRows;
        var invalidFields = [];
       
        rowsRendred.forEach(function (row) {
            row.grid.options.columnDefs.forEach(function (colDef) {
                if (colDef.validators)
                {
                    var isInvalid = $scope.gridApi.grid.validate.isInvalid(row.entity, colDef)
                    if (isInvalid === undefined)
                        isInvalid = false

                    isValid = isValid && (isInvalid == false);

                    if (isInvalid == true) 
                    {
                        invalidFields.push("Credit Request at record " + ($scope.gridOptions.data.indexOf(row.entity) + 1))
                    }
                }
            });
        });
    

        if (isValid == true) {
            confirm = mlsDialog.showConfirmDialog({ message: "Do you want to 'Save data'?" });
            confirm.then(function ()
            {
                var selectedInvoice = $scope.gridOptions.data.filter(function (item) {
                    return item.CreditRequestAmount > 0
                })
 
                factoryDataSvc.insertInvoiceTransaction(selectedInvoice, $rootScope.Username).then(function () {
                    var ok = mlsDialog.showInfoDialog({ message: "Process Complete.", messaeCode: "INF002" }, {
                        closeByDocument: false,
                        showClose: false,
                        closeByEscape: false
                    });
                     
                    ok.then(function ()
                    {
                        var selectedSponsor = $scope.gridApiSponsor.selection.getSelectedRows();
                        var dialog = mlsLoadingDialog.show();
                        $scope.loadInvoiceList(selectedSponsor[0]).then(function () {
                            dialog.close()
                        })
                        $scope.viewModel.creditRequest = null;
                    }) 
               
                }) 
            })
        }
        else
        {
            mlsFieldValidateDialog.show({
                message: "Please correct invalid data before save.",
                messageCode: "inf0001",
                invalidFields: invalidFields
            })
        } 

    }

    $scope.onAssignCredit = function ()
    {
        //var dialog = mlsLoadingDialog.show();
        var invoiceList = $scope.gridOptions.data;
        if (invoiceList.length > 0)
        {
             
            var availableInvoice = invoiceList.filter(function (item)
            {
                 
                return item.CreditAvailableAmount  > 0
            })

             
             

            /*order by due date later*/
            var creditRequest = $scope.viewModel.creditRequest.toDecimalOrZero();
            
            availableInvoice.forEach(function (invoice)
            { 
                if (creditRequest > 0)
                {
                    var creditAvailable = invoice.CreditAvailableAmount;
                    if (creditAvailable > creditRequest) {
                        invoice.CreditRequestAmount = creditRequest;
                        creditRequest = 0;
                    }
                    else
                    {
                        invoice.CreditRequestAmount = creditAvailable; /*Use full available*/
                        creditRequest -= creditAvailable;
                    }
                    invoice.CreditAvailableAmount = invoice.CreditAvailableAmount- invoice.CreditRequestAmount;
                }
            })
         



        }
        //factoryDataSvc.onAssignCredit({
        //    productType: $scope.searchCriteria.productType,
        //    InvoiceDateFrom: $scope.searchCriteria.InvoiceDateFrom,
        //    invoiceDateTo: $scope.searchCriteria.invoiceDateTo,
        //    dueDateFrom: $scope.searchCriteria.dueDateFrom,
        //    dueDateTo: $scope.searchCriteria.dueDateTo,
        //    creditRequest: $scope.viewModel.creditRequest.toDecimalOrZero()
        //}).then(function (data)
        //{
        //    $scope.gridOptions.data = data;
        //    dialog.close();
        //})

        //dialog.close();
    }

    $scope.getSponsorInvoiceList = function ()
    {
        var defered = $q.defer();
         
        factoryDataSvc.getSponsorInvoiceList({
            CPNCOD: "0001",
            CPNBRNCOD: "0001",
            ACCBUSTYP:"2210",
            ACCCOD: $rootScope.userProfile.ACCCOD
        }).then(function (result)
        { 
            $scope.gridGroupBySponsorOptions.data = result;
             
            defered.resolve();
        })

        return defered.promise;
    }

    $scope.getInvoiceCreditInfo = function ()
    {
        var defered = $q.defer();

        factoryDataSvc.getInvoiceCreditInfo().then(function (data) {
            $scope.viewModel.CreditUsage = data.CreditUsage;

            defered.resolve();
        })
        return defered.promise;
    }

    $scope.initialComponents = function () {
        $q.all([
            $scope.getSponsorInvoiceList(),
            $scope.getInvoiceCreditInfo()
        ]).then(function (response) {
            $scope.viewModel.CreditAvailable = $scope.viewModel.CreditLimit - $scope.viewModel.CreditUsage;
        })
      
        $scope.initialGrid()
    }

    $scope.initialComponents();
}]);