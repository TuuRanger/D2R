﻿angular.module('mainApp').controller('factoringSupplierInvoiceInquiryController', ['$scope', '$stateParams', '$state', '$rootScope', '$location', 'comboBoxDataSvc', '$q', 'eBiz', 'mlsUrlSvc', 'mlsStringUtils', 'eScreenMode', 'mlsCustomerSearchDialog', 'addressDataSvc', 'mlsLoadingDialog', 'accountDataSvc', 'mlsDialog', 'locationHelper', 'validationDataSvc', '$timeout', 'validationHelper', 'mlsFieldValidateDialog', 'locationHelper', 'eScreenPurpose', 'mlsAppSendBackDialog', 'remarkDataSvc',
function ($scope, $stateParams, $state, $rootScope, $location, comboBoxDataSvc, $q, eBiz, mlsUrlSvc, mlsStringUtils, eScreenMode, mlsCustomerSearchDialog, addressDataSvc, mlsLoadingDialog, accountDataSvc, mlsDialog, locationHelper, validationDataSvc, $timeout, validationHelper, mlsFieldValidateDialog, locationHelper, eScreenPurpose, mlsAppSendBackDialog, remarkDataSvc) {

    $scope.$emit('on-screen-load', { screenID: "Factoring001_SponsorDashboard", screenTitle: "Invoice Inquiry" });

    $scope.initialGrid = function () {
        $scope.gridOptions = {
            enableRowSelection: true,
            multiSelect: false,
            modifierKeysToMultiSelect: false,
            enableRowHeaderSelection: false,
            noUnselect: true,
            enableSorting: true,
            enableColumnResizing: true,
            rowHeight: 40,
            columnDefs: [
              { name: 'SEQ', field: '', width: "100" },
              { name: 'Invoice No.', field: 'PSNREGIDN', width: "120",   },
              { name: 'Sponsor name', field: 'ACCNAMTHA', width: "200" },
              { name: 'Invoice Date', field: 'MTNDTETME', width: "180", cellFilter: 'date : "dd/MM/yyyy HH:mm:ss"' },
              { name: 'Credit Amount', width: "150", field: 'OVDDAY', cellFilter: 'decimal', cellClass: 'cell-align-right' },
              { name: 'Credit Usage', width: "150", field: 'OVDDAY', cellFilter: 'decimal', cellClass: 'cell-align-right' },
              { name: 'Credit Available', width: "150", field: 'OVDDAY', cellFilter: 'decimal', cellClass: 'cell-align-right' },
              { name: 'Credit Reserve', width: "150", field: 'OVDDAY', cellFilter: 'decimal', cellClass: 'cell-align-right' },
              { name: 'Due Date', field: 'MTNDTETME', width: "180", cellFilter: 'date : "dd/MM/yyyy HH:mm:ss"' },
              { name: 'Payment Day Left', field: 'MTNDTETME', width: "180", },
              { name: 'Invoice Status', field: 'MTNDTETME', width: "180", },
            ],
            onRegisterApi: function (gridApi) {
                //set gridApi on scope
                $scope.gridApi = gridApi;
                gridApi.selection.on.rowSelectionChanged($scope, function (row) {

                });
            },
            data: []
        };
    }
     
    $scope.initialComponents = function () 
    {
        $scope.initialGrid()
    }
  
    $scope.initialComponents();
}]);