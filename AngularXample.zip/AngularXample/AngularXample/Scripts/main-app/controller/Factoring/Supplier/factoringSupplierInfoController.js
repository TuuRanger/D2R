﻿angular.module('mainApp').controller('factoringSupplierInfoController', ['$scope', '$stateParams', '$state', '$rootScope', '$location', 'comboBoxDataSvc', '$q', 'eBiz', 'mlsUrlSvc', 'mlsStringUtils', 'eScreenMode', 'mlsCustomerSearchDialog', 'addressDataSvc', 'mlsLoadingDialog', 'accountDataSvc', 'mlsDialog', 'locationHelper', 'validationDataSvc', '$timeout', 'validationHelper', 'mlsFieldValidateDialog', 'locationHelper', 'eScreenPurpose', 'mlsAppSendBackDialog', 'remarkDataSvc',
function ($scope, $stateParams, $state, $rootScope, $location, comboBoxDataSvc, $q, eBiz, mlsUrlSvc, mlsStringUtils, eScreenMode, mlsCustomerSearchDialog, addressDataSvc, mlsLoadingDialog, accountDataSvc, mlsDialog, locationHelper, validationDataSvc, $timeout, validationHelper, mlsFieldValidateDialog, locationHelper, eScreenPurpose, mlsAppSendBackDialog, remarkDataSvc) {

    $scope.$emit('on-screen-load', { screenID: "Factoring001_SponsorDashboard", screenTitle: "Supplier Info" });
    
    var baseController = $scope.$parent;
    baseController.screenTitle = "Supplier Info"
    $scope.initialComponents = function () {
        $scope.screenModel.screenPurpose = eScreenPurpose.VIEW

    }

    var onInitialData = $rootScope.$on("initial-data-complete", function (args, data) {
        if (!data.accountModel.GENAPPNUM) {
            locationHelper.path("/inqAccountList");
        }
    });


    $scope.initialComponents();


    $scope.$on('$destroy', function () {

        if (typeof onInitialData == 'function') {
            onInitialData();
            console.log("unbind onInitialData complete")
        }

    })

}]);