﻿angular.module('mainApp').controller('factoringSupplierContractListController', ['$scope', '$stateParams', '$state', '$rootScope', '$location', 'comboBoxDataSvc', '$q', 'eBiz', 'mlsUrlSvc', 'mlsStringUtils', 'eScreenMode', 'mlsCustomerSearchDialog', 'addressDataSvc', 'mlsLoadingDialog', 'accountDataSvc', 'mlsDialog', 'locationHelper', 'validationDataSvc', '$timeout', 'validationHelper', 'mlsFieldValidateDialog', 'locationHelper', 'eScreenPurpose', 'mlsAppSendBackDialog', 'remarkDataSvc',
function ($scope, $stateParams, $state, $rootScope, $location, comboBoxDataSvc, $q, eBiz, mlsUrlSvc, mlsStringUtils, eScreenMode, mlsCustomerSearchDialog, addressDataSvc, mlsLoadingDialog, accountDataSvc, mlsDialog, locationHelper, validationDataSvc, $timeout, validationHelper, mlsFieldValidateDialog, locationHelper, eScreenPurpose, mlsAppSendBackDialog, remarkDataSvc) {

    $scope.$emit('on-screen-load', { screenID: "Factoring001_SponsorDashboard", screenTitle: "Contract List" });
    $scope.initialGrid = function () {
        $scope.gridOptions = {
            enableRowSelection: true,
            multiSelect: false,
            modifierKeysToMultiSelect: false,
            enableRowHeaderSelection: false,
            noUnselect: true,
            enableSorting: true,
            enableColumnResizing: true,
            rowHeight: 40,
            columnDefs: [
              {
                  name: ' ', width: "80",
                  cellTemplate: '<a href="{{\'#/InqAppDetail?GENAPPNUM=\' + row.entity.GENAPPNUM + \'&ACCBUSTYP=\'+ row.entity.ACCBUSTYP     + \'&CPNCOD=\' + row.entity.CPNCOD + \'&CPNBRNCOD=\' + row.entity.CPNBRNCOD  +\'&purpose=VIEW\'}}"' + ' class="btn btn-sm btn-warning"><i class="fa fa-pencil fa-2x"></i></a>',
                  cellClass: 'cell-aligh-center',
                  enableSorting: false,
                  enableColumnMenu: false
              },
              { name: 'Application No.', field: '', width: "200" },
              { name: 'Contract No.', field: 'PSNREGIDN', width: "200", },
              { name: 'Supplier Name', field: 'ACCNAMTHA', width: "200" },
              { name: 'Sponsor Name', field: 'ACCNAMTHA', width: "200" },
              { name: 'Application Date', field: 'MTNDTETME', width: "200", cellFilter: 'date : "dd/MM/yyyy HH:mm:ss"' },
            ],
            onRegisterApi: function (gridApi) {
                //set gridApi on scope
                $scope.gridApi = gridApi;
                gridApi.selection.on.rowSelectionChanged($scope, function (row) {

                });
            },
            data: []
        };
    }


    $scope.initialComponents = function () {
        $scope.initialGrid()
    }

    $scope.initialComponents();
}]);