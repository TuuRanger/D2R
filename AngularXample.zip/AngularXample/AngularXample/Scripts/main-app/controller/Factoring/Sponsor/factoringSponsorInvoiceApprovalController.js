﻿angular.module('mainApp').controller('factoringSponsorInvoiceApprovalController', ['$scope', '$stateParams', '$state', '$rootScope', '$location', 'comboBoxDataSvc', '$q', 'eBiz', 'mlsUrlSvc', 'mlsStringUtils', 'eScreenMode', 'mlsLoadingDialog', 'mlsDialog', 'locationHelper', 'validationDataSvc', '$timeout', 'validationHelper', 'mlsFieldValidateDialog', 'locationHelper', 'eScreenPurpose', 'FileUploader', 'localStorageService','uiGridConstants',
function ($scope, $stateParams, $state, $rootScope, $location, comboBoxDataSvc, $q, eBiz, mlsUrlSvc, mlsStringUtils, eScreenMode, mlsLoadingDialog, mlsDialog, locationHelper, validationDataSvc, $timeout, validationHelper, mlsFieldValidateDialog, locationHelper, eScreenPurpose, FileUploader, localStorageService, uiGridConstants) {

    $scope.$emit('on-screen-load', { screenID: "Factoring003_SponsorInvoiceApproval", screenTitle: "Invoice Approval" });
    $scope.initialGrid = function () {
        $scope.gridOptions = {
            enableRowSelection: true,
            multiSelect: false,
            modifierKeysToMultiSelect: false,
            enableRowHeaderSelection: true,
            showColumnFooter: true,
            noUnselect: true,
            enableSorting: true,
            enableColumnResizing: true,
            rowHeight: 40,
            columnDefs: [
              { name: 'SEQ', field: '', width: "100" },
              { name: 'Invoice No.', field: 'PSNREGIDN', width: "120",  },
              { name: 'Supplier name', field: 'ACCNAMTHA', width: "200" },
              { name: 'Invoice Date', field: 'MTNDTETME', width: "180", cellFilter: 'date : "dd/MM/yyyy HH:mm:ss"' },
              { name: 'Invoice Amount', width: "150", field: 'INVAMT', cellFilter: 'decimal', cellClass: 'cell-align-right', aggregationType: uiGridConstants.aggregationTypes.sum },
              { name: 'Invoice Due', field: 'MTNDTETME', width: "180", cellFilter: 'date : "dd/MM/yyyy HH:mm:ss"' },
              { name: 'Product Type', field: 'MTNDTETME', width: "180",  },
            ],
            onRegisterApi: function (gridApi) {
                //set gridApi on scope
                $scope.gridApi = gridApi;
                gridApi.selection.on.rowSelectionChanged($scope, function (row) {

                });
            },
            data: [
                {
                    INVAMT  : 100
                },
                {
                    INVAMT:200
                },
            ]
        };
    }

    $scope.initialComponents = function () 
    {
        $scope.initialGrid();
    }
  
    $scope.initialComponents();
}]);