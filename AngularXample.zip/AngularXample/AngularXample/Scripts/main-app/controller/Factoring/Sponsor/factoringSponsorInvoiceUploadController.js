﻿angular.module('mainApp').controller('factoringSponsorInvoiceUploadController', ['$scope', '$stateParams', '$state', '$rootScope', '$location', 'comboBoxDataSvc', '$q', 'eBiz', 'mlsUrlSvc', 'mlsStringUtils', 'eScreenMode', 'mlsLoadingDialog', 'mlsDialog', 'locationHelper', 'validationDataSvc', '$timeout', 'validationHelper', 'mlsFieldValidateDialog', 'locationHelper', 'eScreenPurpose', 'FileUploader', 'localStorageService', 'factoryDataSvc',
function ($scope, $stateParams, $state, $rootScope, $location, comboBoxDataSvc, $q, eBiz, mlsUrlSvc, mlsStringUtils, eScreenMode, mlsLoadingDialog, mlsDialog, locationHelper, validationDataSvc, $timeout, validationHelper, mlsFieldValidateDialog, locationHelper, eScreenPurpose, FileUploader, localStorageService, factoryDataSvc) {

    $scope.$emit('on-screen-load', { screenID: "Factoring002_SponsorInvoiceUpload", screenTitle: "Invoice Upload" });
   
    $scope.uploader = new FileUploader(     );
    $scope.uploader.url = mlsUrlSvc.getApiUrlContent("/FileUploaderServices/UploadFile/" + $rootScope.Username);
    $scope.fileNames = [];
    $scope.oldQueue = [];
    var invoiceUnit = "Invoice(s)"
    var creditUnit = "Bath";
    var completeResult =  {
        seq: 1,
        desc: "Complete",
        invoiceAmount: 0,
        creditAmount: 0,
        invoiceUnit: invoiceUnit,
        creditUnit: creditUnit,
        class: 'success'
    } 
    var incompleteResult = {
        seq: 2,
        desc: "Incomplete",
        invoiceAmount: 0,
        creditAmount: 0,
        invoiceUnit: invoiceUnit,
        creditUnit: creditUnit,
        class: 'warning'
    }
    var totalResult = {
        seq: 3,
        desc: "Total",
        invoiceAmount: 0,
        creditAmount: 0,
        invoiceUnit: invoiceUnit,
        creditUnit: creditUnit,
        class: 'info'
    }

    $scope.resetSummaryResult = function ()
    {
        completeResult.invoiceAmount = 0;
        completeResult.creditAmount = 0;
        incompleteResult.invoiceAmount = 0;
        incompleteResult.creditAmount = 0;
        totalResult.invoiceAmount = 0;
        totalResult.creditAmount = 0;
    }

    $scope.uploadSummary = [completeResult, incompleteResult, totalResult];
     
    $scope.uploadAll = function ()
    {
        $scope.fileNames = [];
        $scope.resetSummaryResult();
        $scope.uploader.uploadAll(); 
    }

    $scope.uploadItem = function ($fileItem) {
        $scope.fileNames = [];
        $scope.resetSummaryResult();
        $fileItem.upload();
    }
      
    $scope.uploader.onCompleteAll = function (data)
    {
        var defered = $q.defer();
        factoryDataSvc.invoiceVerifying($scope.fileNames,$rootScope.Username).then(function (verifyResults)
        { 
            angular.forEach(verifyResults, function (verifyResult, index)
            {
                if (verifyResult.IsComplete) {
                    completeResult.invoiceAmount++;
                    completeResult.creditAmount += verifyResult.Amount;
                }
                else
                {
                    incompleteResult.invoiceAmount++;
                    incompleteResult.creditAmount += verifyResult.Amount;
                }

                totalResult.invoiceAmount++;
                totalResult.creditAmount += verifyResult.Amount;
            });
             
            $scope.oldQueue = $scope.uploader.queue;
            defered.resolve();
        })
        return defered.promise;
    }
     
    $scope.uploader.onCompleteItem = function (data) {
        var result = JSON.parse(data._xhr.response)
        $scope.fileNames.push(result.FileNames[0]); 
    }
  
    $scope.uploader.onAfterAddingAll = function (data)
    {
        angular.forEach($scope.uploader.queue, function (item) {
            if (item.isUploaded)
            {
                $timeout(function () {
                    item.remove();
                }) 
            } 
        })
      
    }
     
    $scope.initialComponents = function () 
    {
        
    }

    $scope.initialComponents();
}]);    