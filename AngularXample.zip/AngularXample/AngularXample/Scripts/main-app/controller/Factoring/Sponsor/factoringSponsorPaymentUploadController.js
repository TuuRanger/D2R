﻿angular.module('mainApp').controller('factoringSponsorPaymentUploadController', ['$scope', '$stateParams', '$state', '$rootScope', '$location', 'comboBoxDataSvc', '$q', 'eBiz', 'mlsUrlSvc', 'mlsStringUtils', 'eScreenMode', 'mlsLoadingDialog', 'mlsDialog', 'locationHelper', 'validationDataSvc', '$timeout', 'validationHelper', 'mlsFieldValidateDialog', 'locationHelper', 'eScreenPurpose', 'FileUploader', 'localStorageService',
function ($scope, $stateParams, $state, $rootScope, $location, comboBoxDataSvc, $q, eBiz, mlsUrlSvc, mlsStringUtils, eScreenMode, mlsLoadingDialog, mlsDialog, locationHelper, validationDataSvc, $timeout, validationHelper, mlsFieldValidateDialog, locationHelper, eScreenPurpose, FileUploader, localStorageService) {

    $scope.$emit('on-screen-load', { screenID: "Factoring002_SponsorInvoiceUpload", screenTitle: "Payment Upload" });
   
    $scope.uploader = new FileUploader();
    $scope.uploader.url = mlsUrlSvc.getApiUrlContent("/Factoring/PaymentUpload/" + $rootScope.Username);
  

    $scope.uploadAll = function ()
    { 
        $scope.uploader.uploadAll();
    }

    $scope.uploadItem = function($fileItem)
    {  
        $fileItem.upload();
    }

    $scope.initialComponents = function () 
    {
        
    }
  
    $scope.initialComponents();
}]);