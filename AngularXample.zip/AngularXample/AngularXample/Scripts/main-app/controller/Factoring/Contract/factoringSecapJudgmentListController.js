﻿ 

mainApp.controller('factoringSecapJudgmentListController',
    ['$scope', 'mlsLanguage', 'mainAppContext', 'mlsScreenResourceProvider', 'contractDataSvc', 'setupDataSvc', '$http','mlsLoadingDialog',
function ($scope, mlsLanguage, mainAppContext, mlsScreenResourceProvider, contractDataSvc, setupDataSvc, $http, mlsLoadingDialog) {
    $scope.$emit('on-screen-load', { screenID: "Factoring004_SecapContractList", screenTitle: "Judgment List" });


    $scope.searchContract = function (pageNo, pageSize)
    {
        var dialog = mlsLoadingDialog.show();
        $scope.searchCriteria = $scope.searchCriteria || {};
        $scope.searchCriteria.stepFrom = 10
        $scope.searchCriteria.stepTo = 10
        $scope.searchCriteria.pageSize = pageSize
        $scope.searchCriteria.pageNo = pageNo

        contractDataSvc.getContractListFactoringWithPaging($scope.searchCriteria).then(function (data) {
            $scope.gridOptions.data = data;
            dialog.close();
        })
    }

    $scope.searchData = function ()
    {
        $scope.searchContract(1, $scope.gridOptions.paginationPageSize);
    }

    $scope.clearCriteriaAndSearch = function ()
    {
        $scope.searchCriteria = {};
        $scope.searchContract(1, $scope.gridOptions.paginationPageSize);
    }
     

    $scope.initialGrid = function () {
        $scope.gridOptions = {
            enableSelectAll: true,
            enableRowSelection: true,
            multiSelect: false,
            enableRowHeaderSelection: false,
            useExternalPagination: true,
            paginationPageSize: 50,
            paginationPageSizes: [50, 100],
            noUnselect: false,
            enableSorting: true,
            enableColumnResizing: true,
            showGridFooter: true,
            rowHeight: 40,
            columnDefs: [
              {
                  name: 'Action', width: "120",
                  cellTemplate: '<a id="btn{{row.entity.GENAPPNUM}}" ui-sref="secapJudgmentEntry({ GENAPPNUM: row.entity.GENAPPNUM ,CPNCOD :row.entity.CPNCOD,CPNBRNCOD : row.entity.CPNBRNCOD, ACCBUSTYP : row.entity.ACCBUSTYP })"  class="btn btn-sm btn-warning"><i class="fa fa-pencil fa-2x"></i></a>',
                  cellClass: 'cell-aligh-center',
                  enableSorting: false
              },
              { name: 'App No.', field: 'GENAPPNUM', width: "200", },
              { name: 'Contract No.', field: 'CONNUM', width: "200", },
              { name: 'Supplier Name', field: 'ACCNAMTHA', width: "200", },
              { name: 'Sponsor Name', field: 'DEALER_NAME', width: "200", },
              { name: 'App Date', field: 'GENAPPDTE', width: "200", cellFilter: 'date : "dd/MM/yyyy HH:mm:ss"' },
            ],
            data: [],
            onRegisterApi: function (gridApi) {
                $scope.gridApi = gridApi;


                gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
                    $scope.searchAccount(newPage, pageSize);
                });
            }
        }

    }

    $scope.initialComponents = function () {
       
        $scope.initialGrid();
    }

    $scope.initialComponents();


}]);

