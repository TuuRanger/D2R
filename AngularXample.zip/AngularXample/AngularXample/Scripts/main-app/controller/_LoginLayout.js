﻿mainApp.controller('loginController',
    ['$scope', '$location','mainAppContext', 'mlsScreenResourceProvider','authenDataSvc','userDataSvc','$rootScope','mlsDialog',
function ($scope, $location, mainAppContext, mlsScreenResourceProvider, authenDataSvc, userDataSvc,$rootScope,mlsDialog)
{ 
    $scope.setScreenText = function ()
    {
        mlsScreenResourceProvider.getScreenLabelTextList($scope.screenID, mainAppContext.userProfile.selectedLang)
         .then(function (data)
         {
             $scope.screenResource = data;
             $scope.listLabelText = $scope.screenResource.listLabelText;
         });
    } 
    
    $scope.initialValidationOptions = function ()
    {
        $scope.validationOptions = {
            rules: {
                txtUsername: {
                    required: true,
                },
                txtPassword: {
                    required: true,
                }, 
            },
            messages: {
                txtUsername: {
                    required: function ()
                    {
                        return mainAppContext.getValidateMessage("VLD001").Message
                    },
                },
                txtPassword: {
                    required: function ()
                    {
                        return mainAppContext.getValidateMessage("VLD001").Message
                    },
                }
            }
        }
    }

    $scope.initialDropDownLanguage = function ()
    {
        mlsLanguage.GetSysLanguage().then(function (data)
        {
            debugger
            $scope.sysLangList = data;
            mainAppContext.sysLanguageList = data;
        }) 
    }
     
    $scope.InitialComponents = function ()
    { 
        $scope.screenID = "_LoginLayout"
         
        mainAppContext.setCurrentScreen($scope.screenID);
        mainAppContext.userProfile.selectedLang = "en-EN"
        $scope.setScreenText(); /* 1. Initial Screen resour on load*/
        $scope.initialValidationOptions();
    }

    $scope.onValidate = function ()
    {
        var from = $("#frmLogin");
        return from.valid();
    }
    

    $scope.$on("initial-user-profile-complete", function () {
     
        $scope.getGlobalResource();
    });

    $scope.onLogin = function ()
    {
        if ($scope.onValidate())
        { 
            authenDataSvc.login($scope.username, $scope.password).then(function (result) {
                if (result.isLoggenIn)
                {
                    $rootScope.$broadcast("authen-logged-in", { token: result.token }); 
                    console.log("getGlobalResource");

                    $location.path("/appList");
                    //userDataSvc.setUserData(result.token).then(function(){
                    //    $rootScope.$broadcast("authen-logged-in", { token: result.token });
                    //    //
                    //    $location.path("/appList");
                    //}); 
                }
                else
                {
                    mlsDialog.showWarningDialog({message : "Could not login, Please check your username or password", messageCode :"WRN0001"})
                }
            }) 
        } 
    } 

    $scope.isUserCookieExpire = function ()
    {
        var userData = userDataSvc.getUserData();
        if (userData)  return false 
        return false; 
    }
    /* Call Area*/
    $scope.InitialComponents();
 
}])

 