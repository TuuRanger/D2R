﻿mainApp.controller('mainController', ['$scope',
                                      'mlsLanguage',
                                      'mainAppContext',
                                      'mlsScreenResourceProvider',
                                      'userDataSvc',
                                      '$location',
                                      '$timeout',
                                      '$rootScope',
                                      'authenDataSvc',
                                      'localStorageService',
                                      'mlsDialog',
function ($scope,
    mlsLanguage,
    mainAppContext,
    mlsScreenResourceProvider,
    userDataSvc,
    $location,
    $timeout,
    $rootScope,
    authenDataSvc,
    localStorageService ,
    mlsDialog)
{
    $scope.getGlobalResource = function ()
    {
        mlsScreenResourceProvider.getGlobalMessage($rootScope.userProfile.LanguageCode).then(
           function (data)
           { 
               mainAppContext.globalResourList = data;
           });
    }
  
    $scope.$on("initial-user-profile-complete", function ()
    { 
        $scope.getGlobalResource();
    });

    $scope.InitialComponents = function ()
    {
        var userStorage = localStorageService.get('userStorage');
        
        if (userStorage)
        { 
            authenDataSvc.isTokenValid(userStorage.username, userStorage.token).then(function (data)
            { 
                $rootScope.$broadcast("authen-logged-in", { token: data.TokenString }); 
            }, function ()
            {
                $location.path("/login");
            })
        }
        else
        {
            $location.path("/login");
        } 
    }

    $scope.logout = function ()
    {
        confirm = mlsDialog.showConfirmDialog({ message: "Do you want to 'Logout'" });
        confirm.then(function () {
            $scope.$emit('authen-logged-out');
        })
       
    }

    
    $scope.InitialComponents();
}])