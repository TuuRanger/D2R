﻿mainApp.controller('followUpController', ['$scope', '$rootScope', 'referencePersonDataSvc', 'guarantorPersonDataSvc', 'comboBoxDataSvc', 'addressDataSvc', '$q', 'followUpDataSvc', 'mlsDialog', 'userSectionDataSvc', 'setupDataSvc', 'userDataSvc', 'eBiz', '$timeout', 'productDataSvc', 'mlsStringUtils', 'mlsLoadingDialog', '$interval', 'accountDataSvc', 'mlsFollowUpResultEntryDialog', 'uiGridConstants', 'mlsAlarmDialog', 'Notification',
function ($scope, $rootScope, referencePersonDataSvc, guarantorPersonDataSvc, comboBoxDataSvc, addressDataSvc, $q, followUpDataSvc, mlsDialog, userSectionDataSvc, setupDataSvc, userDataSvc, eBiz, $timeout, productDataSvc, mlsStringUtils, mlsLoadingDialog, $interval, accountDataSvc, mlsFollowUpResultEntryDialog, uiGridConstants, mlsAlarmDialog, Notification)
    { 
     
        $scope.$emit('on-screen-load', { screenID: "COL002FollowUp", screenTitle: "Follow Up" });
        $scope.productSpec = {};
        $scope.refPersonList = [];
        $scope.guarantorList = [];
        $scope.inputListDataSource = [];
        $scope.model = {};
        $scope.summaryList1 = [
            {id: "1" ,title : "ติดตามเอง"},
            {id: "2" ,title : "นัดชำระได้"},
            {id: "3" ,title : "นัดชำไรไม่ได้"},
            {id: "4" ,title : "ผิดนัด"},
        ]
        $scope.summaryList2 = [
            {id: "1" , title: "งานทั้งหมด" },
            {id: "2" , title: "ติดตามแล้ว" },
            {id: "3" , title: "คงเหลือ" }, 
        ]
        $scope.followUpResultDataSource = [];
        $scope.followUpPlaceDataSource = [];
        $scope.followUpActivityDataSource = [];
        $scope.timoutIDs = [];
        $scope.mainTabs = [
            {
                title: "รายละเอียดการติดตาม",
                url: "/DebtManagement/vwWorkLoadDetail"
            },
            {
                title: "นัดชำระเงินไม่ได้",
                url: "/DebtManagement/vwFailAppointment"

            },
            {
                title: "นัดชำระเงินได้",
                url: "/DebtManagement/vwSuccessAppointment"
            },
            {
                title: "ผิดนัด",
                url: "/DebtManagement/vwBroke"
            },
            {
                title: "ข้อความเตือน",
                url: "/DebtManagement/vwAlarm"
            }
        ]
        $scope.gridJobRowTemplate = '<div on-context-menu-open="grid.appScope.gridContextMenuOpen(grid,row)" context-menu="grid.appScope.gridJobContextOption" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name" class="ui-grid-cell" ng-class="{ \'ui-grid-row-header-cell\': col.isRowHeader }"  ui-grid-cell></div>'
        $scope.gridAlarmRowTemplate = '<div on-context-menu-open="grid.appScope.gridContextMenuOpen(grid,row)" context-menu="grid.appScope.gridAlarmContextOption" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name" class="ui-grid-cell" ng-class="{ \'ui-grid-row-header-cell\': col.isRowHeader }"  ui-grid-cell></div>'

        $scope.subGridTemplateJob = '<div ui-grid-resize-columns="true" ui-grid="row.entity.subGridOptions" style="height:400px;width:80%"></div>'
        $scope.subGridTemplateContractHistory = '<div ui-grid-resize-columns="true" ui-grid="row.entity.subGridOptions" style="height:150px"></div>'
        $scope.selectedJobs = [];
        $scope.customerTabs = [
                {
                    title: 'ประวัติการตามหนี้',
                    headerIcon: 'fa fa-history',
                    headerIconStyle: 'font-size:20px',
                    url: "/DebtManagement/vwFollowUpHistory"
                },
                {
                    title: "รายละเอียดผู้อ้างอิง",
                    headerIcon: 'fa fa-users',
                    headerIconStyle: 'font-size:20px',
                    url: "/DebtManagement/vwReferencePerson"

                },
                {
                    title: "รายละเอียดสินค้า",
                    headerIcon: 'fa fa-barcode',
                    headerIconStyle: 'font-size:20px',
                    url: "/DebtManagement/vwProductDetail"
                }
        ]
       
        $scope.gridJobContextOption = [
          ['ข้อความเตือน', function ($itemScope) {
                
              var entity = $itemScope.row.entity;
              $scope.showAlarmDialog(entity);
          }]
        ];

        $scope.gridAlarmContextOption = [

           ['ดูข้อความ', function ($itemScope) {
 
               $scope.showAlarmNotify($itemScope.row.entity);
           }],
           ['แจ้งเตือนอีกครั้ง', function ($itemScope) {
                
               var entity = $itemScope.row.entity;
                
               $scope.showAlarmDialog($itemScope.row.entity);
           }]
        ];

        $scope.gridContextMenuOpen = function (grid, row)
        { 
            grid.api.selection.selectRow(row.entity);
        }
        
        $scope.showAlarmDialog = function (entity)
        {

            var ok = mlsAlarmDialog.show({ message: entity.MESSAGE });
            ok.then(function (result) {
                var dialogModel = result.dialogModel;

                var arrAlarm = [];
                arrAlarm.push({
                    RECORD_ID: null,
                    RECSTSCOD: 0,
                    CPNCOD: entity.CPNCOD,
                    CPNBRNCOD: entity.CPNBRNCOD,
                    GROUPNAM: "",
                    CONNUM: entity.CONNUM,
                    ACCCOD: entity.ACCCOD,
                    ALMDTE: dialogModel.alarmDate,
                    MESSAGE: dialogModel.message,
                    JOBASGNUM: entity.JOBASGNUM
                });

                followUpDataSvc.InsertOrUpdateAlarm(arrAlarm, $rootScope.Username).then(function () {
                    $scope.getFollowUpAlarm($rootScope.Username)
                })
            })
        }

        $scope.getWorkLoadByUser = function (FOLWERCOD)
        {
            var defered = $q.defer();
            followUpDataSvc.getWorkLoadByUser({ FOLWERCOD: FOLWERCOD }).then(function (data)
            { 
                 //AllWorkLoad 
                 //Broke 
                 //FailAppointment 
                 //InProgress 
                //SuccessAppointment 
                 
                $scope.gridWorkLoadOptions.data = data.InProgress;
                 

                $scope.gridFailAppointmentOptions.data = data.FailAppointment;


                 $scope.gridSuccessAppointmentOptions.data = data.SuccessAppointment;
                 $scope.gridBrokeOptions.data = data.Broke;


                 var total = data.AllWorkLoad.length;
                 var selfFollowCount = data.AllWorkLoad.whereAnd([{ RECREMARK: 3 }]).length;
                 var failCount = data.FailAppointment.length;
                 var successCount = data.SuccessAppointment.length;
                 var brokeCount = data.Broke.length;

                
                 var followedCount = failCount + successCount + brokeCount;
                 var balance = total - followedCount;

                 

                 $scope.summaryList1.whereAnd([{ id: 1 }])[0].value = selfFollowCount;
                 $scope.summaryList1.whereAnd([{ id: 2 }])[0].value = successCount;
                 $scope.summaryList1.whereAnd([{ id: 3 }])[0].value = failCount
                 $scope.summaryList1.whereAnd([{ id: 4 }])[0].value = brokeCount;

                    
                 $scope.summaryList2.whereAnd([{ id: 1 }])[0].value = total;
                 $scope.summaryList2.whereAnd([{ id: 2 }])[0].value = followedCount;
                 $scope.summaryList2.whereAnd([{ id: 3 }])[0].value = balance;

                  

                 $timeout(function ()
                 {
                     $scope.gridWorkLoadApi.selection.selectRow(data.InProgress[0]);
                 })

                 $scope.refreshGrid();
                 defered.resolve();
                 //debugger
            })


             return defered.promise;
        }


        $scope.clearTimeout = function ()
        {
            angular.forEach($scope.timoutIDs, function (value, index) {
                clearTimeout(value);
            }) 
        };
        
        $scope.showAlarmNotify = function (entity)
        {
            Notification.info({ message: entity.MESSAGE, title: "Alarm message " + entity.ACCNAMTHA });
        }

        $scope.getFollowUpAlarm = function (FOLWERCOD)
        {
            var defered = $q.defer();

            followUpDataSvc.getFollowUpAlarm({ FOLWERCOD: FOLWERCOD }).then(function (data) {
                $scope.gridAlarmOptions.data = data;
                var now = new Date();
                $scope.clearTimeout();
                angular.forEach(data, function (obj, idx) {
                    if (obj.RECSTSCOD == 0)
                    { 
                        var alarmDate = obj.ALMDTE.toDate()
                        var recordID = obj.RECORD_ID;
                        var countDownSecs = (alarmDate - now)  
                         
                        var timoutID = setTimeout(function ()
                        {
                            $scope.showAlarmNotify(obj);
                            var arrAlarm = [];
                            arrAlarm.push({
                                RECORD_ID: obj.RECORD_ID,
                                RECSTSCOD: 2,
                                CPNCOD: obj.CPNCOD,
                                CPNBRNCOD: obj.CPNBRNCOD,
                                GROUPNAM: "",
                                CONNUM: obj.CONNUM,
                                ACCCOD: obj.ACCCOD,
                                JOBASGNUM: obj.JOBASGNUM
                            });
                            followUpDataSvc.InsertOrUpdateAlarm(arrAlarm, $rootScope.Username)
                            $scope.getFollowUpAlarm($rootScope.Username)
                        }, countDownSecs)

                        $scope.timoutIDs.push(timoutID);
                    } 
                });

                defered.resolve();
            });

            return defered.promise;
        }
       
        $scope.loadProductSpecInputField = function (PRDGRPCOD,PRDSUBCOD) {
            var defer = $q.defer();
            if (mlsStringUtils.isStringEmpty(PRDSUBCOD)) {
                defer.reject();
            }
            else {
                productDataSvc.getProductSpecInputField({
                    PRDGRPCOD: PRDGRPCOD,
                    PRDSUBCOD: PRDSUBCOD
                }).then(function (items) {
                    $scope.inputListDataSource = items;
                    defer.resolve();
                })
            }

            return defer.promise;
        }

        $scope.refreshGrid = function () {
            var gridIDs = [
                'gridWorkLoad',
                'gridFailAppointment',
                'gridSuccessAppointment',
                'gridBroke',
                'gridProduct',
                'gridDetailCotract',
                'gridFollowUpHistory',
                'gridAlarm'
            ]

            angular.forEach(gridIDs, function (val, key)
            {
                var element = angular.element(document.getElementById(val));
                
                element.css('width', "100%");
                element.css('height', element.css('height'));
                var gridData = element.data('$uiGridController');
                if (gridData)
                {
                    //debugger
                    gridData.grid.api.core.queueGridRefresh();
                    //gridData.grid.api.core.refresh();
                    //gridData.grid.api.core.refreshRows(); 
                }
               
            }) 
             
        }

        $scope.onTabClick = function()
        { 
            $scope.refreshGrid();
        }

        $scope.onTabJobClick = function (currentGridID) {
            $scope.gridWorkLoadApi.selection.clearSelectedRows();
            $scope.gridFailAppointmentApi.selection.clearSelectedRows();
            $scope.gridSuccessAppointmentApi.selection.clearSelectedRows();
            $scope.gridBrokeApi.selection.clearSelectedRows();
            $scope.refreshGrid();
            //var gridData = angular.element("#" + currentGridID).data('$uiGridController')



            //if (gridData) {
            //    var grid = gridData.grid;
            //    var selecteRows = grid.api.selection.getSelectedRows();
            //    if (selecteRows.length > 0) {
            //        grid.api.selection.selectRow(selecteRows[0])
            //    }
            //    else {
            //        grid.api.selection.selectRow(grid.options.data[0])
            //    }
            //}
        
        }
        
        $scope.getCustomerInfo = function (entity)
        {
            var defered = $q.defer();
            var criteria = {
                CPNCOD: '0001',
                CPNBRNCOD: '0001',
                ACCBUSTYP: '2010',
                CONNUM: '1000159060000425',
                CUSCOD: '5900000002115241'
            }
            
            var criteria2 = {
                CPNCOD: '0001',
                CPNBRNCOD: '0001',
                ACCBUSTYP: '2010',
                CONNUM: '1000159060000425',
            }

            var criteria3 = {
                CPNCOD: '0001',
                CPNBRNCOD: '0001',
                ACCBUSTYP: '2010',
                CONNUM: '1000159060000425',
            }
            $scope.model.ACCCOD = entity.ACCCOD;
            $scope.model.ACCNAMTHA = entity.ACCNAMTHA;
          
            $q.all([
                guarantorPersonDataSvc.getGuarantorPersonList(criteria2) ,
                referencePersonDataSvc.getReferencePersonList(criteria),
                addressDataSvc.getCustomerAddress(criteria),
                productDataSvc.getProduct(criteria3) 
            ]).then(function (response)
            {
                $scope.guarantorList = response[0];
                $scope.refPersonList = response[1];
                $scope.addressList = response[2];

                $scope.productList = response[3];
                $scope.gridProductOptions.data = $scope.productList;

                $timeout(function ()
                {
                    $scope.gridProductApi.selection.selectRow($scope.productList[0]);
                })
                
                $scope.refreshGrid();
                defered.resolve();

            })

            return defered.promise;

        }

        $scope.getContractByAccount = function (entity)
        {
            var defered = $q.defer()
            accountDataSvc.getContractByAccount({
                ACCCOD: entity.ACCCOD,
                ACCBUSTYP: entity.ACCBUSTYP,
                CPNCOD: entity.CPNCOD,
                CPNBRNCOD: entity.CPNBRNCOD,
            }).then(function (data)
            {
                $scope.gridDetailCotractOptions.data = data;

                //$timeout(function ()
                //{
                //    $scope.gridDetailCotractApi.selection.selectRow($scope.gridDetailCotractOptions.data[0]);
                //    defered.resolve();
                //})

              
            }) 

           return defered.promise;
        }

        $scope.getFollowUpHistory = function (entity)
        {
            var defered = $q.defer()

            followUpDataSvc.getFollowUpByContract(
                {
                    CONNUM: entity.CONNUM,
                    CPNCOD: entity.CPNCOD,
                    CPNBRNCOD: entity.CPNBRNCOD,
                    ACCBUSTYP: entity.ACCBUSTYP
                }).then(function (data)
            {
                    //$scope.gridFollowUpHistoryOptions.data = data;
                    defered.resolve(data);
            })

            return defered.promise;
        }
        
        $scope.initComboBoxFollowResult = function ()
        {
           var defered = $q.defer();

           if ($scope.followUpActivityDataSource.length > 0 &&
               $scope.followUpPlaceDataSource.length > 0 &&
               $scope.followUpResultDataSource.length > 0)
           {
               defered.resolve();
           }
           else
           {
               $q.all([
               comboBoxDataSvc.getComboFollowUpActivity(),
               comboBoxDataSvc.getComboFollowUpPlace(),
               comboBoxDataSvc.getComboFollowUpResult()
               ]).then(function (response) {
                   $scope.followUpActivityDataSource = response[0];
                   $scope.followUpPlaceDataSource = response[1];
                   $scope.followUpResultDataSource = response[2];

                   defered.resolve();
               })
           }

           
            
            return defered.promise;
        }
       
        
        $scope.showFollowUpResultDialog = function (status)
        {
            console.log("$scope.selectedJobs : " + $scope.selectedJobs.length);
            if ($scope.selectedJobs.length > 0) {
                $scope.initComboBoxFollowResult().then(function () {
                    var promise = mlsFollowUpResultEntryDialog.show({
                        "followUpResultDataSource": $scope.followUpResultDataSource,
                        "followUpPlaceDataSource": $scope.followUpPlaceDataSource,
                        "followUpActivityDataSource": $scope.followUpActivityDataSource,
                        "status": status,
                        'title': 'นัดชำระไม่ได้'
                    })

                    promise.then(function (result) {
                        var dialogModel = result.dialogModel;
                        var data = {
                            header: null,
                            detail: null
                        }

                        var arrJobHeader = $scope.selectedJobs;
                        var arrJobDetail = [];
                        angular.forEach(arrJobHeader, function (object, index) {
                            object.RECSTSCOD = dialogModel.status;
                            object.CNTSEQNUM = 1;
                            object.CNTSUBSEQ = 1;
                            object.SUBSEQNUM = 1;
                            object.PROMISDTE = dialogModel.appointmentDate;
                             
                            arrJobDetail.push({
                                RECACTCOD: "A",
                                RECSTSCOD: dialogModel.status,
                                CPNCOD: object.CPNCOD,
                                CPNBRNCOD: object.CPNBRNCOD,
                                ACCBUSTYP: object.ACCBUSTYP,
                                JOBASGNUM: object.JOBASGNUM,
                                //RECORDDTE,
                                FOLWUPRSL: dialogModel.followResult,
                                FOLWUPMRK: dialogModel.remark,
                                FOLWERGRP: null,
                                FOLWERCOD: $rootScope.Username,
                                PROMISDTE: dialogModel.appointmentDate,
                                ASGSEQNUM: 1,
                                SUBSEQNUM: null,
                                FOLACTCOD: dialogModel.followActivityCode,
                                FOLWHERE: dialogModel.followPlace,
                            })
                        })

                        data.header = JSON.stringify(arrJobHeader);
                        data.detail = JSON.stringify(arrJobDetail);
                        followUpDataSvc.insertOrUpdateFollowUpDetail(data, $rootScope.Username).then(function () {
                            $scope.selectedJobs = [];
                            $scope.getWorkLoadByUser($rootScope.Username);
                            var ok = mlsDialog.showInfoDialog({ message: "Process complete.", messaeCode: "INF002" }, {
                                closeByDocument: false,
                                showClose: false,
                                closeByEscape: false
                            });

                        })
                    })
                })
            }
            else
            {
                mlsDialog.showWarningDialog({ message: "Please select data.", messageCode: "WRN0001" })
            }
           
        }
        
        $scope.onFailAppointment = function ()
        {
            $scope.showFollowUpResultDialog(eBiz.FollowUpStatus.FailAppointment); 
        }

        $scope.onSuccessAppointment = function ()
        { 
            $scope.showFollowUpResultDialog(eBiz.FollowUpStatus.Appointment);
        }
     
        $scope.regisGridApiJobExpandable = function (gridApi)
        {
            gridApi.expandable.on.rowExpandedStateChanged($scope,
                        function (row) {
                            if (row.isExpanded && (!row.entity.subGridOptions)) {
                                row.entity.subGridOptions = {
                                    enableColumnResizing: true,
                                    columnDefs: [
                                        { name: "ครั้งที่", width: "70", field: "ASGSEQNUM" },
                                        { name: "ครั้งที่ติดตามย่อย", width: "140", field: "SUBSEQNUM" },
                                        { name: "ผู้ติดตาม", field: "FOLWERCOD", width: "140" },
                                        { name: "วันที่ติดตาม", field: "RECORDDTE", width: "140", cellFilter: "displaydate:'dd/MM/yyyy HH:mm':true" },
                                        { name: "วันที่นัดชำระ", field: "PROMISDTE", width: "140", cellFilter: "displaydate:'dd/MM/yyyy HH:mm':true" },
                                        { name: "การติดตาม", field: "FOLACTCOD_DESC", width: "120", },
                                        { name: "สถานที่พบ", field: "FOLWHERE_DESC", width: "100", },
                                        { name: "ผลการติดตาม", field: "FOLWUPRSL_DESC", width: "200", },
                                    ],
                                    data: []
                                }

                                followUpDataSvc.getFollowUpDetail({
                                    JOBASGNUM: row.entity.JOBASGNUM,
                                    CPNCOD: row.entity.CPNCOD,
                                    CPNBRNCOD: row.entity.CPNBRNCOD,
                                    ACCBUSTYP: row.entity.ACCBUSTYP
                                }).then(function (data) {
                                    row.entity.subGridOptions.data = data
                                })
                            }

                        }
                    );
            return gridApi;
        }
        
        $scope.initialGrid = function ()
        {
            $scope.gridWorkLoadOptions = {
                enableSelectAll: false,
                enableRowSelection: true,
                multiSelect: false,
                enableRowHeaderSelection: false,
                noUnselect: true,
                enableSorting: true,
                enableColumnResizing: true,
                showGridFooter: true,
                enableFiltering: true,
                rowHeight: 25, 
                rowTemplate: $scope.gridJobRowTemplate, 
                columnDefs: [
                  { name: 'ลำดับ', field: 'RECNO', width: "80" },
                  { name: 'เลขที่สัญญา', field: 'CONNUM', width: "170", },
                  { name: 'เลขที่บัญชี', field: 'ACCCOD', width: "140" },
                  { name: 'ชื่อ-นามสกุล', field: 'ACCNAMTHA', width: "180" },
                  { name: 'เลขที่งาน', field: 'JOBASGNUM', width: "140" },
                  { name: 'วันที่สร้าง', field: 'CRTDTETME', width: "100", cellFilter: "displaydate:'dd/MM/yyyy':true" },
                  { name: 'วันที่นัด', field: 'PROMISDTE', width: "140", cellFilter: "displaydate:'dd/MM/yyyy HH:mm':true" },
                  { name: 'จำนวนเงิน', field: 'DEBAMOUNT', width: "100", cellFilter: "decimal", cellClass: 'cell-align-right' },
                  { name: 'ค้างทั้งหมด(วัน)', field: 'DEBDAY', cellClass: 'cell-align-right', width: "150", },
                  { name: 'ค้างทั้งหมด(งวด)', field: 'DEBTRMACT', cellClass: 'cell-align-right', width: "150", },
                ],
                data: [],
                onRegisterApi: function (gridApi) {
                    //set gridApi on scope
                    $scope.gridWorkLoadApi = gridApi;
                     

                    gridApi.selection.on.rowSelectionChanged($scope, function (row, evt) {
                        $scope.selectedJobs = gridApi.selection.getSelectedRows();
                         
                        $q.all([
                            $scope.getCustomerInfo(row.entity),
                            $scope.getContractByAccount(row.entity)
                        ]).then(function () {
                            //dialog.close();
                        }) 
                    });

                    gridApi.selection.on.rowSelectionChangedBatch($scope, function (row, evt) {
                         
                        $scope.selectedJobs = gridApi.selection.getSelectedRows();
                       
                    });
                }
            };

            $scope.gridFailAppointmentOptions = {
                enableSelectAll: false,
                enableRowSelection: true,
                multiSelect: false,
                enableRowHeaderSelection: false,
                noUnselect: true,
                enableSorting: true,
                enableColumnResizing: true,
                showGridFooter: true,
                enableFiltering: true,
                rowHeight: 25,
                rowTemplate: $scope.gridJobRowTemplate,
                expandableRowTemplate: $scope.subGridTemplateJob,
                expandableRowHeight: 400, 
                columnDefs: [
                  { name: 'ลำดับ', field: 'RECNO', width: "80" },
                  { name: 'เลขที่สัญญา', field: 'CONNUM', width: "170", },
                  { name: 'เลขที่บัญชี', field: 'ACCCOD', width: "140" },
                  { name: 'ชื่อ-นามสกุล', field: 'ACCNAMTHA', width: "180" },
                  { name: 'เลขที่งาน', field: 'JOBASGNUM', width: "140" },
                  { name: 'วันที่สร้าง', field: 'CRTDTETME', width: "100", cellFilter: "displaydate:'dd/MM/yyyy':true" },
                  { name: 'วันที่นัด', field: 'PROMISDTE', width: "140", cellFilter: "displaydate:'dd/MM/yyyy':true" },
                  { name: 'จำนวนเงิน', field: 'DEBAMOUNT', width: "100", cellFilter: "decimal", cellClass: 'cell-align-right' },
                  { name: 'ค้างทั้งหมด(วัน)', field: 'DEBDAY', cellClass: 'cell-align-right', width: "150", },
                  { name: 'ค้างทั้งหมด(งวด)', field: 'DEBTRMACT', cellClass: 'cell-align-right', width: "150", },
                ],
                data: [],
                onRegisterApi: function (gridApi) {
                    //set gridApi on scope
                    $scope.gridFailAppointmentApi = gridApi;


                    gridApi =  $scope.regisGridApiJobExpandable(gridApi);
                    //gridApi.expandable.on.rowExpandedStateChanged($scope,
                    //    function (row)
                    //    {
                    //        if (row.isExpanded && (!row.entity.subGridOptions))
                    //        {
                    //            row.entity.subGridOptions = {
                    //                enableColumnResizing: true,
                    //                columnDefs: [
                    //                    { name: "ครั้งที่",  width: "70" ,field: "ASGSEQNUM" },
                    //                    { name: "ครั้งที่ติดตามย่อย", width: "140", field: "SUBSEQNUM" },
                    //                    { name: "ผู้ติดตาม", field: "FOLWERCOD", width: "140" },
                    //                    { name: "วันที่ติดตาม", field: "RECORDDTE", width: "140", cellFilter: "displaydate:'dd/MM/yyyy HH:mm':true" },
                    //                    { name: "วันที่นัดชำระ", field: "PROMISDTE", width: "140", cellFilter: "displaydate:'dd/MM/yyyy HH:mm':true" },
                    //                    { name: "การติดตาม", field: "FOLACTCOD_DESC", width: "120", },
                    //                    { name: "สถานที่พบ", field: "FOLWHERE_DESC", width: "100", },
                    //                    { name: "ผลการติดตาม", field: "FOLWUPRSL_DESC", width: "200", },
                    //                ],
                    //                data: []
                    //            }

                    //            followUpDataSvc.getFollowUpDetail({
                    //                JOBASGNUM: row.entity.JOBASGNUM,
                    //                CPNCOD: row.entity.CPNCOD,
                    //                CPNBRNCOD: row.entity.CPNBRNCOD,
                    //                ACCBUSTYP: row.entity.ACCBUSTYP
                    //            }).then(function (data)
                    //            {
                    //                row.entity.subGridOptions.data = data
                    //            })
                    //        }
                           
                    //    }
                    //);

                    gridApi.selection.on.rowSelectionChanged($scope, function (row, evt) {
                        $scope.selectedJobs = gridApi.selection.getSelectedRows();
                        //var dialog = mlsLoadingDialog.show();
                        $q.all([
                            $scope.getCustomerInfo(row.entity),
                            $scope.getContractByAccount(row.entity)
                        ]).then(function () {
                            //dialog.close();
                        })
                    });

                    gridApi.selection.on.rowSelectionChangedBatch($scope, function (row, evt) {

                        $scope.selectedJobs = gridApi.selection.getSelectedRows();

                    });
                }
            };

            $scope.gridSuccessAppointmentOptions = {
                enableSelectAll: false,
                enableRowSelection: true,
                multiSelect: false,
                enableRowHeaderSelection: false,
                noUnselect: true,
                enableSorting: true,
                enableColumnResizing: true,
                showGridFooter: true,
                enableFiltering: true,
                rowHeight: 25,
                rowTemplate: $scope.gridJobRowTemplate,
                expandableRowTemplate: $scope.subGridTemplateJob,
                expandableRowHeight: 400,
                columnDefs: [
                  { name: 'ลำดับ', field: 'RECNO', width: "80" },
                  { name: 'เลขที่สัญญา', field: 'CONNUM', width: "170", },
                  { name: 'เลขที่บัญชี', field: 'ACCCOD', width: "140" },
                  { name: 'ชื่อ-นามสกุล', field: 'ACCNAMTHA', width: "180" },
                  { name: 'เลขที่งาน', field: 'JOBASGNUM', width: "140" },
                  { name: 'วันที่สร้าง', field: 'CRTDTETME', width: "100", cellFilter: "displaydate:'dd/MM/yyyy':true" },
                  { name: 'วันที่นัด', field: 'PROMISDTE', width: "140", cellFilter: "displaydate:'dd/MM/yyyy HH:mm':true" },
                  { name: 'จำนวนเงิน', field: 'DEBAMOUNT', width: "100", cellFilter: "decimal", cellClass: 'cell-align-right' },
                  { name: 'ค้างทั้งหมด(วัน)', field: 'DEBDAY', cellClass: 'cell-align-right', width: "150", },
                  { name: 'ค้างทั้งหมด(งวด)', field: 'DEBTRMACT', cellClass: 'cell-align-right', width: "150", },
                ],
                data: [],
                onRegisterApi: function (gridApi) {
                    //set gridApi on scope
                    $scope.gridSuccessAppointmentApi = gridApi;

                    gridApi = $scope.regisGridApiJobExpandable(gridApi);

                    gridApi.selection.on.rowSelectionChanged($scope, function (row, evt) {
                        $scope.selectedJobs = gridApi.selection.getSelectedRows();
                        //var dialog = mlsLoadingDialog.show();
                        $q.all([
                            $scope.getCustomerInfo(row.entity),
                            $scope.getContractByAccount(row.entity)
                        ]).then(function () {
                            //dialog.close();
                        })
                    });

                    gridApi.selection.on.rowSelectionChangedBatch($scope, function (row, evt) {

                        $scope.selectedJobs = gridApi.selection.getSelectedRows();

                    });
                },

            };

            $scope.gridBrokeOptions = {
                enableSelectAll: false,
                enableRowSelection: true,
                multiSelect: false,
                enableRowHeaderSelection: false,
                noUnselect: true,
                enableSorting: true,
                enableColumnResizing: true,
                showGridFooter: true,
                enableFiltering: true,
                rowHeight: 25,
                rowTemplate: $scope.gridJobRowTemplate,
                expandableRowTemplate: $scope.subGridTemplateJob,
                expandableRowHeight: 400,
                columnDefs: [
                  { name: 'ลำดับ', field: 'RECNO', width: "80" },
                  { name: 'เลขที่สัญญา', field: 'CONNUM', width: "170", },
                  { name: 'เลขที่บัญชี', field: 'ACCCOD', width: "140" },
                  { name: 'ชื่อ-นามสกุล', field: 'ACCNAMTHA', width: "180" },
                  { name: 'เลขที่งาน', field: 'JOBASGNUM', width: "140" },
                  { name: 'วันที่สร้าง', field: 'CRTDTETME', width: "100", cellFilter: "displaydate:'dd/MM/yyyy':true" },
                  { name: 'วันที่นัด', field: 'PROMISDTE', width: "140", cellFilter: "displaydate:'dd/MM/yyyy HH:mm':true" },
                  { name: 'จำนวนเงิน', field: 'DEBAMOUNT', width: "100", cellFilter: "decimal", cellClass: 'cell-align-right' },
                  { name: 'ค้างทั้งหมด(วัน)', field: 'DEBDAY', cellClass: 'cell-align-right', width: "150", },
                  { name: 'ค้างทั้งหมด(งวด)', field: 'DEBTRMACT', cellClass: 'cell-align-right', width: "150", },
                ],
                data: [],
                onRegisterApi: function (gridApi) {
                    $scope.gridBrokeApi = gridApi;

                    gridApi = $scope.regisGridApiJobExpandable(gridApi);

                    gridApi.selection.on.rowSelectionChanged($scope, function (row, evt) {
                        $scope.selectedJobs = gridApi.selection.getSelectedRows();
                        //var dialog = mlsLoadingDialog.show();
                        $q.all([
                            $scope.getCustomerInfo(row.entity),
                            $scope.getContractByAccount(row.entity)
                        ]).then(function () {
                            //dialog.close();
                        })
                    });

                    gridApi.selection.on.rowSelectionChangedBatch($scope, function (row, evt) {

                          
                        $scope.selectedJobs = gridApi.selection.getSelectedRows();

                    });
                }
            };

            $scope.gridProductOptions = {
                enableSelectAll: false,
                enableRowSelection: true,
                multiSelect: false,
                enableRowHeaderSelection: false,
                noUnselect: true,
                enableSorting: true,
                enableColumnResizing: true,
                showGridFooter: true,
                rowHeight: 25,
                rowTemplate: $scope.gridJobRowTemplate,
                columnDefs: [
                  { name: 'ชนิดสินค้า', field: 'PRDSUBCOD_DSC', width: "150" },
                  { name: 'ยี่ห้อสินค้า', field: 'PRDBRNCOD', width: "150", },
                  { name: 'ราคาป้าย', field: 'PRDLISPRC', width: "150", cellFilter: "decimal", cellClass: 'cell-align-right' },
                  { name: 'ราคาขาย', field: 'PRDSALPRC', width: "150", cellFilter: "decimal", cellClass: 'cell-align-right' },
                  { name: 'ประเภทสินค้า', field: 'PRDNEWUSE_DSC', width: "150" },
                ],
                data: [],
                onRegisterApi: function (gridApi) {
                    $scope.gridProductApi = gridApi;
                    gridApi.selection.on.rowSelectionChanged($scope, function (row, evt) {

                        var product = row.entity;

                        $scope.loadProductSpecInputField(product.PRDGRPCOD, product.PRDSUBCOD).then(function (result) {
                            $scope.productSpec = product.ProductDetailParsed;
                        });
                    });
                }
            };

            $scope.gridDetailCotractOptions = {
                enableSelectAll: false,
                enableRowSelection: true,
                multiSelect: false,
                enableRowHeaderSelection: false,
                noUnselect: true,
                enableSorting: true,
                enableColumnResizing: true,
                showGridFooter: true,
                rowHeight: 25,
                rowTemplate: $scope.gridJobRowTemplate,
                expandableRowTemplate: $scope.subGridTemplateContractHistory,
                columnDefs: [
                   { name: 'เลขที่สัญญา', field: 'CONNUM', width: "170" },
                   { name: 'Project', field: 'CONAPPLY_PROJEC_DESC', width: "140" },
                   { name: 'Bustness type', field: 'ACCBUSTYP_DESC', width: "140" },
                   { name: '', field: 'padding', enableSorting: false, enableColumnMenu: false},
                ],
                data: [],
                onRegisterApi: function (gridApi) {
                    $scope.gridDetailCotractApi = gridApi;

                    //gridApi.selection.on.rowSelectionChanged($scope, function (row, evt) {

                    //    //var dialog = mlsLoadingDialog.show();
                    //    $scope.getFollowUpHistory(row.entity).then(function () {
                    //        //dialog.close();
                    //    })

                    //});

                    gridApi.expandable.on.rowExpandedStateChanged($scope,
                     function (row)
                     {
                         if (row.isExpanded && (!row.entity.subGridOptions))
                         {
                             row.entity.subGridOptions = {
                                 enableColumnResizing: true,
                                 columnDefs: [
                                     { name: 'เลขที่งาน', field: 'JOBASGNUM', width: "140" },
                                     { name: 'วันที่สร้าง', field: 'CRTDTETME', width: "100", cellFilter: "displaydate:'dd/MM/yyyy':true" },
                                     { name: 'วันที่ปิด', field: 'CLOSEDTE', width: "140", cellFilter: "displaydate:'dd/MM/yyyy':true" },
                                     { name: 'วันที่นัด', field: 'PROMISDTE', width: "140", cellFilter: "displaydate:'dd/MM/yyyy HH:mm':true" },
                                     { name: 'จำนวนเงิน', field: 'DEBAMOUNT', width: "100", cellFilter: "decimal", cellClass: 'cell-align-right' },
                                     { name: 'ค้างทั้งหมด(วัน)', field: 'DEBDAY', cellClass: 'cell-align-right', width: "150", },
                                     { name: 'ค้างทั้งหมด(งวด)', field: 'DEBTRMACT', cellClass: 'cell-align-right', width: "155", },
                                 ]
                             }


                             $scope.getFollowUpHistory(row.entity).then(function (data) {
                                 row.entity.subGridOptions.data = data;
                             })
                            
                         }
                           
                     }
                 );

                   
                

                }
            }

            $scope.gridFollowUpHistoryOptions = {
                enableSelectAll: false,
                enableRowSelection: true,
                multiSelect: false,
                enableRowHeaderSelection: false,
                noUnselect: true,
                enableSorting: true,
                enableColumnResizing: true,
                showGridFooter: true,
                rowHeight: 25,
                rowTemplate: $scope.gridJobRowTemplate,
                columnDefs: [
                  { name: 'เลขที่งาน', field: 'JOBASGNUM', width: "140" },
                  { name: 'วันที่สร้าง', field: 'CRTDTETME', width: "100", cellFilter: "displaydate:'dd/MM/yyyy':true" },
                  { name: 'วันที่ปิด', field: 'CLOSEDTE', width: "100", cellFilter: "displaydate:'dd/MM/yyyy':true" },
                  { name: 'วันที่นัด', field: 'PROMISDTE', width: "140", cellFilter: "displaydate:'dd/MM/yyyy HH:mm':true" },
                  { name: 'จำนวนเงิน', field: 'DEBAMOUNT', width: "100", cellFilter: "decimal", cellClass: 'cell-align-right' },
                  { name: 'ค้างทั้งหมด(วัน)', field: 'DEBDAY', cellClass: 'cell-align-right', width: "150", },
                  { name: 'ค้างทั้งหมด(งวด)', field: 'DEBTRMACT', cellClass: 'cell-align-right', width: "150", },
                ],
                data: [],
                onRegisterApi: function (gridApi) {
                    $scope.gridFollowUpHistoryApi = gridApi;
                    gridApi.selection.on.rowSelectionChanged($scope, function (row, evt) {

                    });



                }
            };


            $scope.gridAlarmOptions = {
                enableSelectAll: false,
                enableRowSelection: true,
                multiSelect: false,
                enableRowHeaderSelection: false,
                noUnselect: true,
                enableSorting: true,
                enableColumnResizing: true,
                showGridFooter: true,
                rowHeight: 25,
                rowTemplate : $scope.gridAlarmRowTemplate,
                columnDefs: [
                  { name: 'สถานะ', field: 'STATUS_DESC', width: "80" },
                  { name: 'ลำดับ', field: 'RECORD_ID', width: "80",  },
                  { name: 'เลขที่สัญญา', field: 'CONNUM', width: "170" },
                  { name: 'เลขที่บัญชี', field: 'ACCCOD', width: "150" },
                  { name: 'ชื่อ-นามสกุล', field: 'ACCNAMTHA', width: "180"},
                  { name: 'เลขที่งาน', field: 'JOBASGNUM', width: "140", },
                  { name: 'ข้อความ', field: 'MESSAGE', width: "140", },
                  { name: 'วันเวลา', field: 'ALMDTE', width: "145", cellFilter: "displaydate:'dd/MM/yyyy HH:mm:ss':true" },
                ],
                data: [],
                onRegisterApi: function (gridApi) {
                    $scope.gridAlarmApi = gridApi; 
                }
            };


            $scope.refreshGrid();
        }
        
        $scope.initialComponents = function ()
        {
            
            $scope.initialGrid(); 
            
            //var dialog = mlsLoadingDialog.show();
            $q.all([
                comboBoxDataSvc.getComboCusTtlPsn(),
                comboBoxDataSvc.getComboCocCusRel(),
                comboBoxDataSvc.getComboAdressTypeCode({ CUSTYPCOD: "01" }),
            ]).then(function (response) {
                $scope.listNaturalPersonTitleName = response[0];
                $scope.listCocCusRel = response[1]; 
                $scope.listNaturalPersonAddressTypeCode = response[2];
          
            })
          
            userDataSvc.getUserData().then(function (userData) {
                $scope.getWorkLoadByUser($rootScope.Username).then(function () {
                    //dialog.close();
                    $scope.getFollowUpAlarm($rootScope.Username);
                });

             
            }) 
        }
          
        $scope.initialComponents();
        
       

    }]);