﻿mainApp.controller('followUpStatController', ['$scope', '$rootScope', 'comboBoxDataSvc', '$q', 'followUpDataSvc', 'mlsDialog', 'userSectionDataSvc', 'setupDataSvc', 'userDataSvc', 'eBiz', '$timeout', 'mlsStringUtils', 'mlsLoadingDialog', 'uiGridHelper',
function ($scope, $rootScope, comboBoxDataSvc, $q, followUpDataSvc, mlsDialog, userSectionDataSvc, setupDataSvc, userDataSvc, eBiz, $timeout, mlsStringUtils, mlsLoadingDialog, uiGridHelper) {


    $scope.$emit('on-screen-load', { screenID: "COL003FollowUpStat", screenTitle: "Follow up statistic" });

    $scope.tabs = [
        {
            title: "สถิติการตาม",
            active: true,
            id: "tabStatGraph",
            url: "/DebtManagement/vwFollowUpStatGraph"
        },
        {
            title: "รายละเอียดการติดตาม",
            active: false,
            id: "tabStatStaff",
            url: "/DebtManagement/vwFollowUpStatStaff"
        },
        //{
        //    title: "ข้อมูลที่จะส่งกลับส่วนกลาง",
        //    active: false,
        //    id : "",
        //    url: ""
        //}
    ]

    $scope.gridFollowerOptions = {
        enableSelectAll: true,
        enableRowSelection: true,
        multiSelect: false,
        enableRowHeaderSelection: false,
        noUnselect: false,
        enableSorting: true,
        enableColumnResizing: true,
        showGridFooter: true,
        rowHeight: 25,
        columnDefs: [
          { name: 'ลำดับ', field: 'rowno', width: "80", sortingAlgorithm: uiGridHelper.sortNumberFn },
          { name: 'ผู้ตามหนี้', field: 'USRID', width: "170", }, 
          { name: 'ชื่อ-สกุล', field: 'FullName', width: "170" },
          //{ name: 'งานทั้งหมด', field: 'FollowUpWorkLoadCount', width: "170" },
        ],
        onRegisterApi: function (gridApi) {
            //set gridApi on scope
            $scope.gridHeaderApi = gridApi;

            gridApi.selection.on.rowSelectionChanged($scope, function (row, evt) {
                if (!evt)
                    return;
                var dialog = mlsLoadingDialog.show({});
                $scope.getWorkLoadByUser(row.entity.USRID).then(function () {
                    dialog.close();
                })
            });
        }
    };

     
    $scope.gridWorkLoadOptions = {
        enableSelectAll: true,
        enableRowSelection: true,
        multiSelect: false,
        enableRowHeaderSelection: false,
        noUnselect: false,
        enableSorting: true,
        enableColumnResizing: true,
        showGridFooter: true,
        rowHeight: 25,
        columnDefs: [
                  { name: 'ลำดับ', field: 'RECNO', width: "80" },
                  { name: 'เลขที่สัญญา', field: 'CONNUM', width: "170", },
                  { name: 'เลขที่บัญชี', field: 'ACCCOD', width: "140" }, 
                  { name: 'เลขที่งาน', field: 'JOBASGNUM', width: "140" },
                  { name: 'วันที่สร้าง', field: 'CRTDTETME', width: "100", cellFilter: "displaydate:'dd/MM/yyyy':true" },
                  { name: 'วันที่นัด', field: 'PROMISDTE', width: "140", cellFilter: "displaydate:'dd/MM/yyyy HH:mm':true" },
                  { name: 'จำนวนเงิน', field: 'DEBAMOUNT', width: "100", cellFilter: "decimal", cellClass: 'cell-align-right' },
                  { name: 'ค้างทั้งหมด(วัน)', field: 'DEBDAY', cellClass: 'cell-align-right', width: "150", },
                  { name: 'ค้างทั้งหมด(งวด)', field: 'DEBTRMACT', cellClass: 'cell-align-right', width: "150", },
                  { name: 'จำนวนครั้งที่ตาม', field: 'CNTSEQNUM', cellClass: 'cell-align-right', width: "150", },
                  { name: 'จำนวนครั้งที่ตามย่อย', field: 'CNTSUBSEQ', cellClass: 'cell-align-right', width: "180", },
        ],
        onRegisterApi: function (gridApi) {
            //set gridApi on scope
            $scope.gridDetailApi = gridApi; 
        }
    };


    $scope.gridWorkLoadProgressOptions = {
        enableSelectAll: true,
        enableRowSelection: true,
        multiSelect: false,
        enableRowHeaderSelection: false,
        noUnselect: false,
        enableSorting: true,
        enableColumnResizing: true,
        showGridFooter: true,
        rowHeight: 25,
        columnDefs: [   
                  { name: 'ลำดับ', field: 'RECNO', width: "80" },
                  { name: 'เลขที่สัญญา', field: 'CONNUM', width: "170", },
                  { name: 'เลขที่บัญชี', field: 'ACCCOD', width: "140" }, 
                  { name: 'เลขที่งาน', field: 'JOBASGNUM', width: "140" },
                  { name: 'วันที่สร้าง', field: 'CRTDTETME', width: "100", cellFilter: "displaydate:'dd/MM/yyyy':true" },
                  { name: 'วันที่นัด', field: 'PROMISDTE', width: "140", cellFilter: "displaydate:'dd/MM/yyyy HH:mm':true" },
                  { name: 'จำนวนเงิน', field: 'DEBAMOUNT', width: "100", cellFilter: "decimal", cellClass: 'cell-align-right' },
                  { name: 'ค้างทั้งหมด(วัน)', field: 'DEBDAY', cellClass: 'cell-align-right', width: "150", },
                  { name: 'ค้างทั้งหมด(งวด)', field: 'DEBTRMACT', cellClass: 'cell-align-right', width: "150", }, 
                  { name: 'จำนวนครั้งที่ตาม', field: 'CNTSEQNUM', cellClass: 'cell-align-right', width: "150", },
                  { name: 'จำนวนครั้งที่ตามย่อย', field: 'CNTSUBSEQ', cellClass: 'cell-align-right', width: "180", },
        ],
        onRegisterApi: function (gridApi) {
            //set gridApi on scope
            $scope.gridDetailApi = gridApi;
        }
    };


    $scope.refreshGrid = function () {
        var gridIDs = [
            'gridWorkLoad',
            'gridWorkLoadProgress',
            'gridFollower'
        ]

        angular.forEach(gridIDs, function (val, key) {
            var element = angular.element(document.getElementById(val));

            element.css('width', "100%");
            element.css('height', element.css('height'));
            

        })

    }

    $scope.getWorkLoadByUser = function (FOLWERCOD) {
        var defered = $q.defer();
        followUpDataSvc.getWorkLoadByUser({ FOLWERCOD: FOLWERCOD }).then(function (data) {
            $scope.listFollowUpDetail = data.AllWorkLoad
            $scope.gridWorkLoadOptions.data = data.InProgress;
            $scope.gridWorkLoadProgressOptions.data = data.SuccessAppointment.concat(data.FailAppointment).concat(data.Broke);
            defered.resolve();
        })
        return defered.promise;
    }

    $scope.getChildFollower = function (GROUPID)
    {
        var defered = $q.defer();
        followUpDataSvc.getChildFollower({ GROUPID: GROUPID }).then(function (data) {
                
            $scope.gridFollowerOptions.data = data;
            $scope.refreshGrid();
            defered.resolve(data);
        })
        
        return defered.promise;
    }

    $scope.initialComponents = function () {
        userDataSvc.getUserData().then(function (userData)
        { 
            var sectionLevel = userData.Sections.whereAnd([{ SECTIONID: eBiz.SECTION.DebtManager }]); /*find user have section level in Debt Manager ?*/
            if (sectionLevel.length > 0)
            {
                $scope.getChildFollower(sectionLevel[0].GROUPID);
            }
           
        })
    }




    $scope.initialComponents();
}]);