﻿mainApp.controller('jobAssignmentConroller', ['$scope', '$rootScope', 'referencePersonDataSvc', 'comboBoxDataSvc', 'addressDataSvc', '$q', 'followUpDataSvc', 'mlsDialog', 'userSectionDataSvc','setupDataSvc','userDataSvc','eBiz','uiGridHelper',
    function ($scope, $rootScope, referencePersonDataSvc, comboBoxDataSvc, addressDataSvc, $q, followUpDataSvc, mlsDialog, userSectionDataSvc, setupDataSvc, userDataSvc, eBiz,uiGridHelper)
    {
        $scope.$emit('on-screen-load', { screenID: "COL001DeptManagement", screenTitle: "Debt management" });
        $scope.assignNum = 1
        $scope.searchCriteria = {};

        $scope.isRowSelectAble = function (entity)
        {
            return (!entity.FOLWERCOD)
        }

        $scope.gridHeaderOptions = { 
            enableSelectAll: true,
            enableRowSelection: true,
            multiSelect: true, 
            enableRowHeaderSelection: true,
            noUnselect: false,
            enableSorting: true,
            enableColumnResizing: true,
            showGridFooter:true,
            rowHeight: 25,
            columnDefs: [ 
              { name: 'ลำดับ', field: 'RECORD_ID', width: "80", sortingAlgorithm:  uiGridHelper.sortNumberFn },
              { name: 'บริษัท', field: 'CPNCOD_DESC', width: "170", },
              { name: 'สาขา', field: 'CPNBRNCOD_DESC', width: "170" },
              { name: 'เลขที่สัญญา', field: 'CONNUM', width: "170" },
              { name: 'ประเภทการติดตาม', field: '', width: "170" },
              { name: 'ผู้ติดตาม', field: 'FOLWERCOD', width: "170" },
              { name: 'เลขที่งาน', field: 'JOBASGNUM', width: "170" },
              { name: 'มูลหนี้', field: 'DEBAMOUNT', width: "150", cellFilter: "decimal", cellClass: 'cell-align-right' },
              { name: 'ขาดการติดต่อ (วัน)', width: "150", field: 'OVDDAY', cellClass: 'cell-align-right' },
            ],
            onRegisterApi: function (gridApi)
            {
                //set gridApi on scope
                $scope.gridHeaderApi = gridApi;

                gridApi.selection.on.rowSelectionChanged($scope, function (row, evt)
                {
                    if (!evt)
                        return;

                    if (row.isSelected)
                    {
                        var startIndex = $scope.gridHeaderOptions.data.indexOf(row.entity);
                        var manaulSelected = 0;
                        var counter = 0
                        while (manaulSelected < $scope.assignNum)
                        { 
                            if (startIndex + counter > $scope.gridHeaderOptions.data.length - 1)
                            {
                                break;
                            }
                            var entity = $scope.gridHeaderOptions.data[startIndex + counter];
                            if ($scope.isRowSelectAble(entity))
                            {
                                $scope.gridHeaderApi.selection.selectRow(entity);
                                manaulSelected++;
                            } 
                            counter++;
                        } 
                    }
                });
            }
        };

        
        $scope.gridHeaderOptions.isRowSelectable = function (row)
        { 
            return $scope.isRowSelectAble(row.entity) /*record have no follower can selectable*/
        };

        $scope.gridDetailOptions = {
            enableSelectAll: true,
            enableRowSelection: true,
            multiSelect: true,
            enableRowHeaderSelection: true,
            noUnselect: false,
            enableSorting: true,
            enableColumnResizing: true,
            showGridFooter: true,
            rowHeight: 25, 
            columnDefs: [
              { name: 'ลำดับ', field: 'RECORD_ID', width: "80", sortingAlgorithm: uiGridHelper.sortNumberFn },
              { name: 'เลขที่งาน', field: 'JOBASGNUM', width: "150" },
              { name: 'ค้าง (งวด)', field: 'DEBTRMCAL', width: "120", cellClass: 'cell-align-right' },
            ],
            onRegisterApi: function (gridApi)
            {
                //set gridApi on scope
                $scope.gridDetailApi = gridApi;
                gridApi.selection.on.rowSelectionChanged($scope, function (row, evt)
                {
                    if (!evt)
                        return;

                    if (row.isSelected)
                    {
                        var startIndex = $scope.gridDetailOptions.data.indexOf(row.entity);
                        var manaulSelected = 0;
                        var counter = 0
                        while (manaulSelected < $scope.assignNum )
                        {
                            if (startIndex + counter > $scope.gridDetailOptions.data.length - 1)
                            {
                                break;
                            }
                            var entity = $scope.gridDetailOptions.data[startIndex + counter]; 
                            $scope.gridDetailApi.selection.selectRow(entity);
                            manaulSelected++;
                            
                            counter++;

                        }
                    }
                });
            }
        };

        $scope.initialComboBox = function ()
        { 
            $q.all([
               comboBoxDataSvc.getComboCompanyBranch(),
               comboBoxDataSvc.getComboFollowState(),
               //comboBoxDataSvc.getComboFollower(),
               comboBoxDataSvc.getComboCompany(),
               comboBoxDataSvc.getComboFollowUpArea(), 
            ]).then(function (response)
            {
                $scope.cpnBrnCodDataSource = response[0];
                $scope.folStateDataSource = response[1];
                //$scope.follwerDataSource = response[2];
                $scope.companyDataSource = response[2];
                $scope.follwAreaDataSource = response[3]; 

            }) 

        }

        $scope.searchData = function ()
        { 
            $scope.getFollowUpHeader();
        }

        $scope.assignJob = function()
        {
            var arrJobList = $scope.gridHeaderApi.selection.getSelectedRows()
            if (!$scope.FOLWERCOD)
            {
                mlsDialog.showWarningDialog({ message: "Please select 'Follower'", messageCode: "inf0002" })
                return
            }

            if (arrJobList.length == 0)
            {
                mlsDialog.showWarningDialog({ message: "Please select job to be Assigned", messageCode: "inf0003" })
                return
            }

           
            var JobStep = 1;
            var JobFunction = 'APPROVE' 
            var confirm = mlsDialog.showConfirmDialog({ message: "Do you want to assign job to '" + $scope.FOLWERCOD + "'?" })
            confirm.then(function ()
            {
                followUpDataSvc.assignJob(arrJobList, JobStep, JobFunction, $scope.FOLWERCOD, $rootScope.Username).then(function (data)
                {
                    mlsDialog.showInfoDialog({ message: "Assign job complete", messaeCode: "INF003" }, {
                        closeByDocument: false,
                        showClose: false,
                        closeByEscape: false
                    });

                    $scope.getFollowUpHeader();
                    $scope.getWorkLoadByUser($scope.FOLWERCOD);
                })
            })
           
        }

        $scope.deAssignJob = function ()
        {
            var arrJobList = $scope.gridDetailApi.selection.getSelectedRows()

            if (!$scope.FOLWERCOD)
            {
                mlsDialog.showWarningDialog({ message: "Please select 'Follower'", messageCode: "inf0002" })
                return
            }

            if (arrJobList.length == 0)
            {
                mlsDialog.showWarningDialog({ message: "Please select job to be Deassigned", messageCode: "inf0003" })
                return
            }

            var JobStep = 1;
            var JobFunction = 'CANCEL'
            var username = 'ADMIN'
            var confirm = mlsDialog.showConfirmDialog({ message: "Do you want to Deassign job from '" + $scope.FOLWERCOD + "'?" })
            confirm.then(function ()
            {
                followUpDataSvc.deAssignJob(arrJobList, JobStep, JobFunction, $scope.FOLWERCOD, username).then(function (data)
                {
                    mlsDialog.showInfoDialog({ message: "Assign job complete", messaeCode: "INF003" }, {
                        closeByDocument: false,
                        showClose: false,
                        closeByEscape: false
                    });

                    $scope.getFollowUpHeader();
                    $scope.getWorkLoadByUser($scope.FOLWERCOD);
                })
            })
        }

        $scope.initialComponents = function ()
        { 
            userDataSvc.getUserData().then(function (userData) {
                
                var sectionLevel = userData.Sections.whereAnd([{ SECTIONID: eBiz.SECTION.DebtManager }]); /*find user have section level in Debt Manager ?*/
                if (sectionLevel.length > 0) {
                     
                    comboBoxDataSvc.getComboSectionManger({ TABKEYTWO: sectionLevel[0].GROUPID }).then(function (data) { 
                        $scope.follwerGroupDataSource = data;
                    }) 
                }
                $scope.initialComboBox();
            })
           
        }

        $scope.getWorkLoadByUser = function (FOLWERCOD)
        { 
            followUpDataSvc.getWorkLoadByUser({ FOLWERCOD: FOLWERCOD }).then(function (data)
            {
                $scope.listFollowUpDetail = data.AllWorkLoad
                $scope.gridDetailOptions.data = data.AllWorkLoad;
            })
        }

        $scope.getFollowUpHeader = function()
        {
            followUpDataSvc.getFollowUpHeader($scope.searchCriteria).then(function (data)
            {
                $scope.listFollowUpHeader = data
                $scope.gridHeaderOptions.data = data;
            })
        }

        $scope.$watch('FOLWERCOD', function (newVal, oldVal, scope)
        { 
            if (newVal)
            {
                $scope.getWorkLoadByUser(newVal);
            }
            else
            {
                $scope.listFollowUpDetail = [];
                $scope.gridDetailOptions.data = [];
            } 
         
        }, true)


        $scope.$watch('FOLWERGRPCOD', function (newVal, oldVal, scope)
        { 
            if (newVal)
            { 
                comboBoxDataSvc.getUserInSectionGroup({ SectionID: 'FOLWER', GroupID: newVal }).then(function (follwerDataSource) {
                    $scope.follwerDataSource = follwerDataSource
                })

            }
            else 
            {
                $scope.follwerDataSource = [];
            }
        })

        $scope.initialComponents(); 

    }]);