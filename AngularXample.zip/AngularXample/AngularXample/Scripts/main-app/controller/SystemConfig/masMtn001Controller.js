﻿angular.module('mainApp').controller('masMtn001Controller', ['$scope', 'sysConfigDataSvc', 'mlsDialog', 'mlsUrlSvc', function ($scope, sysConfigDataSvc, mlsDialog, mlsUrlSvc)
{
    $scope.$emit('on-screen-load', { screenID: "SYSCFG_MASMTN001", screenTitle: "Master data maintainance" });
     
    $scope.initialGrid = function ()
    {
        $scope.gridDefaultOptions = {
            enableRowSelection: true,
            multiSelect: false,
            modifierKeysToMultiSelect: false,
            enableRowHeaderSelection: false,
            noUnselect: true,
            enableSorting: true,
            enableColumnResizing: true,
            rowHeight: 45,
            columnDefs: [
                 {
                     name: 'Action', width: "100",
                     field: 'SubjectID',
                     cellTemplate: '<button class="btn btn-sm btn-warning" type="button" ng-click="grid.appScope.onEditData(row.entity)"><i class="fa fa-pencil fa-2x"></i></button>',
                     cellClass: 'cell-aligh-center',
                     enableSorting: false
                 },
              {  field: 'TABKEYONE', width: "150", displayName: "TABKEYONE" },
              {  field: 'TABKEYTWO', width: "120", displayName: "TABKEYTWO" },
              {  field: 'TABDSCTHA' , displayName: "TABDSCTHA" },
            ],
            onRegisterApi: function (gridApi)
            {
                //set gridApi on scope
                $scope.gridApi = gridApi;
                gridApi.selection.on.rowSelectionChanged($scope, function (row)
                {

                });
            }
        };
    }

    $scope.searchData = function ()
    {
        console.log($scope.searchCriteria);

        sysConfigDataSvc.getCDMTABList($scope.searchCriteria).then(function (data)
        {
            $scope.gridDefaultOptions.data  = data;
        })
    }

    $scope.initialComponent = function ()
    {
        $scope.initialGrid();
    }

 
    $scope.onEditData = function (entity)
    {
        $scope.dialogMessage = {
            Message: "Do you want to save data?"
        }

        mlsDialog.showConfirmDialog(
        {
            scope: $scope,
            template: mlsUrlSvc.getUrlContent('/Template/dialog-template/MASMTN002_dlgEditMasterData.html'),
            className: 'ngdialog-theme-default dialog-width-sm',
        }).then(
        function ()
        {
           
        }, function (error)
        {

        });
    };

    $scope.initialComponent();

 

}])