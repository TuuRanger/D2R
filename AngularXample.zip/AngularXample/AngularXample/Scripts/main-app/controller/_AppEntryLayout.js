﻿mainApp.controller('appEntryLayoutController',
     ['$scope', 'mlsLanguage', 'mainAppContext', 'mlsScreenResourceProvider', 'mlsDialog', '$stateParams', '$state', '$rootScope', '$stateParams', 'mlsUrlSvc', 'DTOptionsBuilder', 'DTColumnDefBuilder', 'mlsDtDefaultSetting', '$compile', 'comboBoxDataSvc',
function ($scope, mlsLanguage, mainAppContext, mlsScreenResourceProvider, mlsDialog, $stateParams, $state, $rootScope, $stateParams, mlsUrlSvc, DTOptionsBuilder, DTColumnDefBuilder, mlsDtDefaultSetting, $compile, comboBoxDataSvc)
{ 
    $scope.tabs1 = [ 
             {
                 title: "Customer Info",
                 url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwAppBasicInfoDefault?ngController=appEntryCustomerInfoController"),
                 CRDNXTSTP: 1,
                 id: 'tabCustomerInfo',
                 validateID: "VLD0002"
             },
             {
                 title: "Contract Info",
                 url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwContractInfoDefault?ngController=appEntryContractInfoController"),
                 CRDNXTSTP: 2,
                 id: 'tabContractInfo',
                 validateID: "VLD0013"
             },
             {
                 title: "Product Info",
                 url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwProductInfoDefault?ngController=appEntryProductInfoController"),
                 CRDNXTSTP: 3,
                 id: 'tabProductInfo',
                 validateID: "VLD0009",
             },
             {
                 title: "Financial",
                 url:mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwPreviewCreditLimit?ngController=appEntryPreviewCreditLimitController"),
                 CRDNXTSTP: 4,
                 id: 'tabPreviewCredit',
                 validateID: "VLD0006", 
             }, 
    ]

    $scope.tabs2 = [ 
         {
             title: "Customer Info",
             url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwAppBasicInfoDefault?ngController=appEntryCustomerInfoController"),
             CRDNXTSTP: 1,
             id: 'tabCustomerInfo',
             validateID: "VLD0002",
         },
         {
             title: "Contract Info",
             url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwContractInfoDefault?ngController=appEntryContractInfoController"),
             CRDNXTSTP: 2,
             id: 'tabContractInfo',
             validateID: "VLD0013",
         },
         {
             title: "Credit Analysis",
             url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwCreditAnalysis?ngController=appEntryCreditAnalysisController"),
             CRDNXTSTP: 3,
             id: 'tabCreditAnalysis',
             validateID: "VLD0004",
         }, 
         {
             title: "Verify",
             url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwVerifyDefault?ngController=appEntryVerifyController"),
             CRDNXTSTP: 4,
             id: 'tabVerify',
             validateID: "VLD0005",
         },
         {
             title: "Financial",
             url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwPreviewCreditLimit?ngController=appEntryPreviewCreditLimitController"),
             CRDNXTSTP: 5,
             id: 'tabPreviewCredit',
             validateID: "VLD0006",
         },
         {
             title: "Fee info",
             url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwFeeInfoDefault?ngController=appEntryFeeInfoController"),
             CRDNXTSTP: 6,
             id: 'tabFeeInfo',
             validateID: "VLD0007",
         },
    ]
     
    $scope.tabs3 = [
        {
            title: "Customer Info",
            url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwAppBasicInfoAllInOne"),
            seq: 1
        }
    ]
     
    $scope.tabs4 = [ 
       {
           title: "Customer Info",
           url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwAppBasicInfoDefault?ngController=appEntryCustomerInfoController"),
           CRDNXTSTP: 1,
           id: 'tabCustomerInfo',
           validateID: "VLD0002",
       },
       {
           title: "Contract Info",
           url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwContractInfoDefault?ngController=appEntryContractInfoController"),
           CRDNXTSTP: 2,
           id: 'tabContractInfo',
           validateID: "VLD0003",
       },
       {
           title: "Credit Analysis",
           url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwCreditAnalysis?ngController=appEntryCreditAnalysisController"),
           CRDNXTSTP: 3,
           id: 'tabCreditAnalysis',
           validateID: "VLD0004",
       },
       {
           title: "Product Info",
           url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwProductInfoDefault?ngController=appEntryProductInfoController"),
           CRDNXTSTP: 4,
           id: 'tabProductInfo',
           validateID: "VLD0008",
       },
       {
           title: "Verify",
           url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwVerifyDefault?ngController=appEntryVerifyController"),
           CRDNXTSTP: 5,
           id: 'tabVerify',
           validateID: "VLD0005",
       },
       {
           title: "Financial",
           url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwPreviewCreditLimit?ngController=appEntryPreviewCreditLimitController"),
           CRDNXTSTP: 6,
           id: 'tabPreviewCredit',
           validateID: "VLD0006",
       },
       {
           title: "Repayment Condition",
           url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwRepaymentCondition?ngController=appRepaymentConditionController"),
           CRDNXTSTP: 7,
           id: 'tabPreviewCredit',
           validateID: "VLD0013",
       },
       {
           title: "Fee info",
           url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwFeeInfoDefault?ngController=appEntryFeeInfoController"),
           CRDNXTSTP: 8,
           id: 'tabFeeInfo',
           validateID: "VLD0007",
       },
    ]

    $scope.tabs5 = [
        {
            title: "Customer Info",
            url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwAppCustomerInfo_JR?ngController=appEntryCustomerInfoController"),
            CRDNXTSTP: 1,
            id: 'tabCustomerInfo',
            validateID: "VLD0010",
        },
       {
           title: "Contract Info",
           url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwContractInfoDefault?ngController=appEntryContractInfoController"),
           CRDNXTSTP: 2,
           id: 'tabContractInfo',
           validateID: "VLD0003",
       },
       {
           title: "Credit Analysis",
           url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwAppCreditAnalysis_JR?ngController=appEntryCreditAnalysisController"),
           CRDNXTSTP: 3,
           id: 'tabCreditAnalysis',
           validateID: "VLD0011",
       },
       {
           title: "Product Info",
           url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwProductInfoDefault?ngController=appEntryProductInfoController"),
           CRDNXTSTP: 4,
           id: 'tabProductInfo',
           validateID: "VLD0008",
       },
       {
           title: "Verify",
           url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwAppVerify_JR?ngController=appEntryVerifyController"),
           CRDNXTSTP: 5,
           id: 'tabVerify',
           validateID: "VLD0012",
       },
       {
           title: "Financial",
           url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwPreviewCreditLimit?ngController=appEntryPreviewCreditLimitController"),
           CRDNXTSTP: 6,
           id: 'tabPreviewCredit',
           validateID: "VLD0006",
       },
       {
           title: "Repayment Condition",
           url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwRepaymentCondition?ngController=appRepaymentConditionController"),
           CRDNXTSTP: 7,
           id: 'tabPreviewCredit',
           validateID: "VLD0013",
       },
       {
           title: "Fee info",
           url: mlsUrlSvc.getUrlContent("/ApplicationProcess/partial_vwFeeInfoDefault?ngController=appEntryFeeInfoController"),
           CRDNXTSTP: 8,
           id: 'tabFeeInfo',
           validateID: "VLD0007",
       }, ]

    $scope.$on('sys-language-changed', function (event, args)
    {
        $scope.setScreenText(); /* 2. Refresh when language change*/
    });

    $scope.setScreenText = function ()
    {
        mlsScreenResourceProvider.getScreenLabelTextList(mainAppContext.currentScreenID, $rootScope.userProfile.LanguageCode)
         .then(function (data)
         {
             $scope.screenResource = data;
             $scope.listLabelText = $scope.screenResource.listLabelText;
         });
    }
  
    $scope.InitialComponents = function ()
    { 
        $scope.screenID = "APP001NewApp"
        mainAppContext.setCurrentScreen($scope.screenID);
        $scope.setScreenText(); /* 1. Initial Screen resour on load*/
  
        $scope.dtVerifyOptions = mlsDtDefaultSetting.getDefaultOption();
        $scope.dtVerifyColumnDefs = mlsDtDefaultSetting.getDefaultColumnDef(4);

        $scope.dtPhoneBookOptions = mlsDtDefaultSetting.getDefaultOption().withOption('scrollY', '350px');
        $scope.dtPhoneBookColumnDefs = mlsDtDefaultSetting.getDefaultColumnDef(3);

        $scope.dtFeeInfoOptions = mlsDtDefaultSetting.getDefaultOption()
        $scope.dtFeeInfoColumnDefs = mlsDtDefaultSetting.getDefaultColumnDef(6);

        $scope.dtLoanEvdOptions = mlsDtDefaultSetting.getDefaultOption()
        $scope.dtLoanEvdColumnDefs = mlsDtDefaultSetting.getDefaultColumnDef(4);

        $scope.dtInsTableOptions = mlsDtDefaultSetting.getDefaultOption();
        $scope.dtInsTableColumnDefs = mlsDtDefaultSetting.getDefaultColumnDef(9);

        //$scope.InitialComboBoxData();
    } 
 
   
    /*Call Area*/
    $scope.InitialComponents();
   

}]);
