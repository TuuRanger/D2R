﻿var mainApp = angular.module('mainApp',
    ['ui.router', 'ui.router.stateHelper', 'mls.components']);
 
/* Config Route */
mainApp.config(function ($stateProvider, $urlRouterProvider)
{
    var rooUrl = '../AngularXample'
      
    $stateProvider
        .state('home', {
              url: '', 
              views:
              {
                 '': {
                      templateUrl: 'http://localhost/AngularXample/Angular/Partial',
                      controller: 'mainController',
                  },
                 'content2': {
                     templateUrl: 'http://localhost/AngularXample/Angular/Partial2',
                     controller: 'mainController',
                 }, 
                   'content3': {
                     templateUrl: 'http://localhost/AngularXample/Angular/Partial3',
                     controller: 'mainController',
                 }, 
              },
             
          })
         
   
})
   

 
mainApp.controller('mainController', ['$scope', '$timeout',
function ($scope, $timeout)
{
    $scope.contractDetail = {};
    $scope.ListConApplyProjec = {
        type: "JSON",
        data: [
          {
              TABKEYTWO: "P001",
              TABDSCTHA: "P001 : Normal PL"
          },
          {
              TABKEYTWO: "C001",
              TABDSCTHA: "C001 : Samsung"
          }
        ]
    };

    //$timeout(function ()
    //{
    //    $scope.contractDetail.CONAPPLY_PROJEC = "C001";
    //})

    $scope.setConApplyProjec = function ()
    {
        $scope.contractDetail.CONAPPLY_PROJEC = "C001";
    }
}])

