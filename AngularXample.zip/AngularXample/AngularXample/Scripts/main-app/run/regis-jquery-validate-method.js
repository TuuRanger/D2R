﻿
mainApp.run(['$rootScope', '$timeout',   'mainAppContext',   '$q',  
function ($rootScope,  $timeout, mainAppContext,   $q) {
    jQuery.validator.addMethod("lessThanOrEqual", function (value, element, param) {
        if (!angular.element(element).val())
            return true

        var leftValue = angular.element(element).val();
        var rightValue = param

        if (isNaN(param)) {
            rightValue = angular.element(param).val();
        }
        else {
            rightValue = param;
        }

        return leftValue.toDecimalOrZero() <= rightValue.toDecimalOrZero();

    }, function (param, element) {

        var elementLabel = angular.element("#labelText_lb_" + element.id).text().trim()
        var validateMessage = mainAppContext.getValidateMessage("VLD0004").Message;
        if (isNaN(param) === false) {

            return validateMessage.replace('{0}', '"<strong class="text-danger">' + elementLabel + '</strong>"').replace('{1}', '"<strong class="text-danger">' + param.toMoneyFormat() + '</strong>"');
            //return "<strong class='text-danger'>" + elementLabel + "</strong>" + " should not greather than " + param.toMoneyFormat();
        }
        else if (typeof param == 'string') {
            var rightElement = angular.element(param);
            var elementType = rightElement.attr('type');
        
            if (elementType != 'hidden')
            {
                var rightLabel = angular.element("#labelText_lb_" + param.replace("#", "")).text().trim();
                return validateMessage.replace('{0}', '"<strong class="text-danger">' + elementLabel + '</strong>"').replace('{1}', '"<strong class="text-danger">' + rightLabel + '</strong>"');
            }
            else
            {
                var rightValue = rightElement.val().toDecimalOrZero();
                return validateMessage.replace('{0}', '"<strong class="text-danger">' + elementLabel + '</strong>"').replace('{1}', '"<strong class="text-danger">' + rightValue + '</strong>"');

            }
          }

    });

    jQuery.validator.addMethod("lessThanOrEqual2", function (value, element, param) {
        if (!angular.element(element).val())
            return true

        var leftValue = angular.element(element).val();
        var rightValue = param

        if (isNaN(param)) {
            rightValue = angular.element(param).val();
        }
        else {
            rightValue = param;
        }

        return leftValue.toDecimalOrZero() <= rightValue.toDecimalOrZero();

    }, function (param, element) {

        var elementLabel = angular.element("#labelText_lb_" + element.id).text().trim()
        var validateMessage = mainAppContext.getValidateMessage("VLD0004").Message;

        if (isNaN(param) === false) {

            return validateMessage.replace('{0}', '"<strong class="text-danger">' + elementLabel + '</strong>"').replace('{1}', '"<strong class="text-danger">' + param.toMoneyFormat() + '</strong>"');
            //return "<strong class='text-danger'>" + elementLabel + "</strong>" + " should not greather than " + param.toMoneyFormat();
        }
        else if (typeof param == 'string') {
            var rightLabel = angular.element("#labelText_lb_" + param.replace("#", "")).text().trim();
            return validateMessage.replace('{0}', '"<strong class="text-danger">' + elementLabel + '</strong>"').replace('{1}', '"<strong class="text-danger">' + rightLabel + '</strong>"');
        }

    });

    jQuery.validator.addMethod("greatherThanOrEqual", function (value, element, param) {
        if (!angular.element(element).val())
            return true

        var leftValue = angular.element(element).val();
        var rightValue = param

        if (isNaN(param)) {
            rightValue = angular.element(param).val();
        }
        else {
            rightValue = param;
        }

        return leftValue.toDecimalOrZero() >= rightValue.toDecimalOrZero();

    }, function (param, element) {

        var elementLabel = angular.element("#labelText_lb_" + element.id).text().trim()
        var validateMessage = mainAppContext.getValidateMessage("VLD0005").Message;
        if (isNaN(param) === false) {

            return validateMessage.replace('{0}', '"<strong class="text-danger">' + elementLabel + '</strong>"').replace('{1}', '"<strong class="text-danger">' + param.toMoneyFormat() + '</strong>"');
            //return "<strong class='text-danger'>" + elementLabel + "</strong>" + " should not greather than " + param.toMoneyFormat();
        }
        else if (typeof param == 'string') {
            var rightLabel = angular.element("#labelText_lb_" + param.replace("#", "")).text().trim();

            return validateMessage.replace('{0}', '"<strong class="text-danger">' + elementLabel + '</strong>"').replace('{1}', '"<strong class="text-danger">' + rightLabel + '</strong>"');
        }

    });

    jQuery.validator.addMethod("betweenEx", function (value, element, param) {

        if (!angular.element(element).val())
            return true

        var elementValue = angular.element(element).val().toDecimalOrZero();
        var min = param.min.toDecimalOrZero()
        var max = param.max.toDecimalOrZero()


        return elementValue >= min && elementValue <= max;

    }, function (param, element) {

        var elementLabel = angular.element("#labelText_lb_" + element.id).text().trim()
        var validateMessage = mainAppContext.getValidateMessage("VLD0006").Message;

        return validateMessage.replace('{0}', '"<strong class="text-danger">' + elementLabel + '</strong>"')
              .replace('{1}', '"<strong class="text-danger">' + param.min.toMoneyFormat() + '</strong>"')
              .replace('{2}', '"<strong class="text-danger">' + param.max.toMoneyFormat() + '</strong>"');

    });
}])

