﻿mainApp.run(['$rootScope', '$location', 'authenDataSvc', '$timeout', 'uiSelect2Config', 'mainAppContext', 'mlsScreenResourceProvider', 'localStorageService', 'mlsDialog', 'menuDataSvc', 'locationHelper', '$q', 'screenPermissionSvc',
function ($rootScope, $location, authenDataSvc, $timeout, uiSelect2Config, mainAppContext, mlsScreenResourceProvider, localStorageService, mlsDialog, menuDataSvc, locationHelper, $q, screenPermissionSvc) {
    $rootScope.$on("authen-logged-in", function (event, args) {
        var userData = authenDataSvc.getUserDataByToken(args.token).then(function (userData) {

            if (!userData) {
                $rootScope.$broadcast("user-data-expired");
                return
            }
            mainAppContext.setUserToken(args.token);
            mainAppContext.userProfile.selectedLang = 'en-EN'



            var loginDateTime = userData.LoginDateTime.toDate();
            var TimeToLive = userData.TimeToLive;
            var expireDate = angular.copy(loginDateTime);
            var currentDate = new Date();
            var expireMillisec = 0;
            expireDate.setSeconds(loginDateTime.getSeconds() + TimeToLive);
            expireMillisec = (expireDate - currentDate);
            expireMillisec = expireMillisec < 0 ? 0 : expireMillisec

            console.log("login is expire in : " + expireMillisec / 1000 + " sec(s)")

            localStorageService.set('userStorage', {
                token: args.token,
                username: userData.Username,
                userProfile: userData.UserProfile
            });

            $rootScope.Username = userData.Username;

            $rootScope.userProfile = userData.UserProfile;
            $rootScope.$broadcast("initial-user-profile-complete");

            $timeout(function () {
                $rootScope.$broadcast("user-data-expired");
            }, expireMillisec)


            $q.all([
                 menuDataSvc.getMenus(args.token), //0 menulist
            ]).then(function (response) {
                mainAppContext.setMenuList(response[0]);
                $rootScope.$broadcast("initial-menu-complete");
                locationHelper.path(userData.UserProfile.FIRST_PAGE)
            })

        }, function () {
            $rootScope.$broadcast("user-data-expired");
        });

    });


    $rootScope.$on("user-data-expired", function (event, next, current) {
        localStorageService.set('userStorage', null);
        var ok = mlsDialog.showInfoDialog({ message: "Login session is expired,Please Re-login again", messaeCode: "INF002" }, {
            closeByDocument: false,
            showClose: false,
            closeByEscape: false
        });

        ok.then(function () {
            $location.path("/login");
        })
    })

    $rootScope.$on("authen-logged-out", function (event, next, current) {
        var userStorage = localStorageService.get('userStorage');
        authenDataSvc.logout(userStorage.username, userStorage.token)
        localStorageService.set('userStorage', null);
        $location.path("/login");
    })


    /*Language Process*/
    $rootScope.setScreenText = function () {
        mlsScreenResourceProvider.getScreenLabelTextList(mainAppContext.currentScreenID, mainAppContext.userProfile.selectedLang)
         .then(function (data) {
             $rootScope.screenResource = data;
             $rootScope.listLabelText = $rootScope.screenResource.listLabelText;
             $rootScope.$broadcast('sys-language-changed-complete');
         });
    }

    $rootScope.$on('on-screen-load', function (event, screenData) {

        authenDataSvc.getUserDataByToken(mainAppContext.getUserToken()).then(function (response) {
            if (response) {
                screenPermissionSvc.getScreenPermission(screenData.screenID, mainAppContext.getUserToken()).then(function () {
                    mainAppContext.setCurrentScreen(screenData.screenID);
                    $rootScope.screenTitle = screenData.screenTitle;
                    $rootScope.setScreenText();
                }, function () {
                    locationHelper.path('/login');
                })

            }
            else {
                locationHelper.path('/login');
            }
        }, function () {
            locationHelper.path('/login');
        })

    })


    $rootScope.$on('sys-language-changed', function (event, args) {
        $rootScope.setScreenText(); /* 2. Refresh when language change*/
    });
    /************************************/

    uiSelect2Config.placeholder = "Nothing select";
    uiSelect2Config.allowClear = true
    uiSelect2Config.theme = 'bootstrap'

    $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams, options) {
        //debugger
        //event.preventDefault();
        // transitionTo() promise will be rejected with 
        // a 'transition prevented' error
    })


    $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
        //debugger
    })


}])