﻿mainApp.config(['localStorageServiceProvider',function (localStorageServiceProvider)
{ 
    localStorageServiceProvider.setPrefix('MLS');
    localStorageServiceProvider.setStorageType('localStorage');
    //localStorageServiceProvider.setDefaultToCookie(false);
}])