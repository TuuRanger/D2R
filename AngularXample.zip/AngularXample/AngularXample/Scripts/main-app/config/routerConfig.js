﻿mainApp.config(function ($stateProvider, $urlRouterProvider)
{
    var rooUrl = location.protocol + '//' + location.host + location.pathname
    $urlRouterProvider.otherwise("/home");
    $stateProvider
        .state('home', {
            url: '',
            views:
            {
                '': {
                    templateUrl: rooUrl + '/Layout/BizLayoutDefault',
                    controller: 'bizController',
                }, /* Use BizLayout*/
                'bizContent@home': { templateurl: rooUrl + '/home/home' },
            },

        })
        .state('login', {
            url: '/login',
            views:
            {
                '': { templateUrl: rooUrl + '/Layout/LoginLayoutDefault' },
            },

            data: {
                css: [rooUrl + '/Styles/_LoginLayoutDefault/css/style.css']
            }
        })
        .state('newApp', {
            url: '/newApp',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@newApp': {
                        templateUrl: rooUrl + '/ApplicationProcess/ApplicationEntry?ngController=appEntryController',
                    },
                },
            //controller: 'bizController'
        })
        .state('appList', {
            url: '/appList',
            views:
                {
                    '':
                    {
                        templateUrl: rooUrl + '/Layout/BizLayoutDefault' /*Parent layout*/
                    },
                    'bizContent@appList':
                    {
                        templateUrl: rooUrl + '/ApplicationProcess/ApplicationList',  /*Content Layout*/
                    },
                },
            //controller: 'bizController'
        }).state('judgmentList', {
            url: '/judgmentList',
            views:
                {
                    '':
                    {
                        templateUrl: rooUrl + '/Layout/BizLayoutDefault' /*Parent layout*/
                    },
                    'bizContent@judgmentList':
                    {
                        templateUrl: rooUrl + '/ApplicationProcess/JudgmentList',  /*Content Layout*/
                    },
                },
            //controller: 'bizController'
        })
        .state('editApp', {
            url: '/editApp?GENAPPNUM&ACCBUSTYP&CPNCOD&CPNBRNCOD&purpose', 
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@editApp': {
                        templateUrl: rooUrl + '/ApplicationProcess/ApplicationEntry?ngController=appEntryController',
                    },
                },
        })
        .state('judgmentEntry', {
            url: '/judgmentEntry?GENAPPNUM&ACCBUSTYP&CPNCOD&CPNBRNCOD&purpose',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@judgmentEntry': {
                        templateUrl: rooUrl + '/ApplicationProcess/JudgmentEntry?ngController=appEntryController',
                    },
                },
        }) 
        .state('MasMtn001', {
            url: '/MasMtn001',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@MasMtn001': {
                        templateUrl: rooUrl + '/SystemConfig/MasMtn001_MasterDataMaintenance',
                    },
                },
        })
        .state('JonAssignment', {
            url: '/JonAssignment',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@JonAssignment': {
                        templateUrl: rooUrl + '/DebtManagement/COL001_JonAssignment',
                    },
                },
        })
        .state('FollowUp', {
            url: '/FollowUp',
             views:
                 {
                     '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                     'bizContent@FollowUp': {
                         templateUrl: rooUrl + '/DebtManagement/COL002_FollowUp',
                     },
                 },
        }).state('FollowUpStat', {
            url: '/FollowUpStat',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@FollowUpStat': {
                        templateUrl: rooUrl + '/DebtManagement/COL003_FollowUpStat',
                    },
                },
        })

    
        .state('InqAppList', {
            url: '/InqAppList',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@InqAppList': {
                        templateUrl: rooUrl + '/Inquiry/INQ001_InquiryAppList',
                    },
                },
        }).state('InqAppDetail', {
            url: '/InqAppDetail?GENAPPNUM&ACCBUSTYP&CPNCOD&CPNBRNCOD&purpose',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@InqAppDetail': {
                        templateUrl: rooUrl + '/Inquiry/INQ002_InquiryAppDetail?ngController=appEntryController',
                    },
                },
        }).state('newAccount', {
            url: '/newAccount',
            params: { 
                // here we define default value for foo
                // we also set squash to false, to force injecting
                // even the default value into url
                purpose: {
                    value: 'VIEW',
                    squash: false,
                },
                // this parameter is now array
                // we can pass more items, and expect them as []
                //bar : { 
                //    array : true,
                //},
                // this param is not part of url
                // it could be passed with $state.go or ui-sref 
                hiddenParam: 'YES',
            },
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@newAccount': {
                        templateUrl: rooUrl + '/Account/AccountEntry?ngController=accountEntryController',
                    },
                },
        }).state('editAccount', {
            url: '/editAccount?GENAPPNUM&ACCBUSTYP&CPNCOD&CPNBRNCOD&ACCCOD',
            params: {
                // here we define default value for foo
                // we also set squash to false, to force injecting
                // even the default value into url
                purpose: {
                    value: 'EDIT',
                    squash: false,
                },
                // this parameter is now array
                // we can pass more items, and expect them as []
                //bar : { 
                //    array : true,
                //},
                // this param is not part of url
                // it could be passed with $state.go or ui-sref 
                hiddenParam: 'YES',
            },
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@editAccount': {
                        templateUrl: rooUrl + '/Account/AccountEntry?ngController=accountEntryController',
                    },
                },
        }).state('accountVerify', {
            url: '/accountVerify',
            params: {
                GENAPPNUM: null,
                CPNCOD: null,
                CPNBRNCOD: null,
                ACCBUSTYP : null
            },
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@accountVerify': {
                        templateUrl: rooUrl + '/Account/AccountVerify?ngController=accountVerifyController',
                    },
                },
        }).state('accountApproval', {
            url: '/accountApproval',
            params: {
                GENAPPNUM: null,
                CPNCOD: null,
                CPNBRNCOD: null,
                ACCBUSTYP: null
            },
            views:{
                '': {
                    templateUrl: rooUrl + '/Layout/BizLayoutDefault',
                    //controller: 'accountApprovalController'

                }, /* Use BizLayout*/
                    'bizContent@accountApproval': {
                        templateUrl: rooUrl + '/Account/AccountApproval?ngController=accountApprovalController',
                    },
            },
            controller: 'accountEntryBaseController'
        }) 
        .state('accountVerifyList', {
            url: '/accountVerifyList',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@accountVerifyList': {
                        templateUrl: rooUrl + '/Account/AccountList?ngController=accountVerifyListController',
                    },
                },
        }).state('accountJudgmentList', {
            url: '/accountJudgmentList',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@accountJudgmentList': {
                        templateUrl: rooUrl + '/Account/AccountList?ngController=accountJudgmentListController',
                    },
                },
        }).state('inqAccountList', {
            url: '/inqAccountList',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@inqAccountList': {
                        templateUrl: rooUrl + '/Account/AccountList?ngController=accountInquiryListController',
                    },
                },
        }).state('accountInquiry', {
            url: '/accountInquiry',
            params: {
                GENAPPNUM: null,
                CPNCOD: null,
                CPNBRNCOD: null,
                ACCBUSTYP: null
            },
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@accountInquiry': {
                        templateUrl: rooUrl + '/Account/AccountInquiry?ngController=accountInquiryController',
                    },
                },
        })
        .state('accountNewList', {
            url: '/accountNewList',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@accountNewList': {
                        templateUrl: rooUrl + '/Account/AccountList?ngController=accountNewListController',
                    },
                },
        })
        .state('sponsorDashboard', {
            url: '/sponsorDashboard',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@sponsorDashboard': {
                        templateUrl: rooUrl + '/Factoring/SponsorDashboard?ngController=factoringSponsorDashboardController',
                    },
                },
        })
        .state('sponsorInvoiceUpload', {
            url: '/sponsorInvoiceUpload',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@sponsorInvoiceUpload': {
                        templateUrl: rooUrl + '/Factoring/InvoiceUpload?ngController=factoringSponsorInvoiceUploadController',
                    },
                },
        })
         .state('sponsorInvoiceApproval', {
             url: '/sponsorInvoiceApproval',
             views:
                 {
                     '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                     'bizContent@sponsorInvoiceApproval': {
                         templateUrl: rooUrl + '/Factoring/InvoiceApproval?ngController=factoringSponsorInvoiceApprovalController',
                     },
                 },
         })
        .state('sponsorPaymentUpload', {
            url: '/sponsorPaymentUpload',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@sponsorPaymentUpload': {
                        templateUrl: rooUrl + '/Factoring/PaymentUpload?ngController=factoringSponsorPaymentUploadController',
                    },
                },
        }).state('sponsorPaymentApproval', {
            url: '/sponsorPaymentApproval',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@sponsorPaymentApproval': {
                        templateUrl: rooUrl + '/Factoring/PaymentApproval?ngController=factoringSponsorPaymentApprovalController',
                    },
                },
        })
        .state('supplierDashboard', {
            url: '/supplierDashboard',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@supplierDashboard': {
                        templateUrl: rooUrl + '/Factoring/SupplierDashboard?ngController=factoringSupplierDashboardController',
                    },
                },
        }).state('supplierInvoiceList', {
            url: '/supplierInvoiceList',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@supplierInvoiceList': {
                        templateUrl: rooUrl + '/Factoring/SupplierInvoiceList?ngController=factoringSupplierInvoiceListController',
                    },
                },
        }).state('supplierInfo', {
            url: '/supplierInfo',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@supplierInfo': {
                        templateUrl: rooUrl + '/Factoring/SupplierInfo?ngController=factoringSupplierInfoController',
                    },
                },
        }).state('supplierContractList', {
            url: '/supplierContractList',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@supplierContractList': {
                        templateUrl: rooUrl + '/Factoring/SupplierContractList?ngController=factoringSupplierContractListController',
                    },
                },
        }).state('supplierInvoiceInquiry', {
            url: '/supplierInvoiceInquiry',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@supplierInvoiceInquiry': {
                        templateUrl: rooUrl + '/Factoring/SupplierInvoiceInquiry?ngController=factoringSupplierInvoiceInquiryController',
                    },
                },
        }).state('supplierStatement', {
            url: '/supplierStatement',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@supplierStatement': {
                        templateUrl: rooUrl + '/Factoring/SupplierStatement?ngController=factoringSupplierStatementController',
                    },
                },
        }).state('supplierRequest', {
            url: '/supplierRequest',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@supplierRequest': {
                        templateUrl: rooUrl + '/Factoring/SupplierRequest?ngController=factoringSupplierRequestController',
                    },
                },
        }).state('secapDashboard', {
            url: '/secapDashboard',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@secapDashboard': {
                        templateUrl: rooUrl + '/Home/SECAPDashboard?ngController=secapDashboardController',
                    },
                },
        }).state('secapImportData', {
            url: '/secapImportData',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@secapImportData': {
                        templateUrl: rooUrl + '/Factoring/SECAPImportData?ngController=factoringSecapImportDataController',
                    },
                },
        }).state('secapRequestProcess', {
            url: '/secapRequestProcess',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@secapRequestProcess': {
                        templateUrl: rooUrl + '/Factoring/SECAPRequestProcess?ngController=factoringSecapRequestProcessController',
                    },
                },
        }).state('secapContractList', {
            url: '/secapContractList',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@secapContractList': {
                        templateUrl: rooUrl + '/Factoring/SECAPContractList?ngController=factoringSecapContractListController',
                    },
                },
        }).state('secapJudgmentList', {
            url: '/secapJudgmentList',
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@secapJudgmentList': {
                        templateUrl: rooUrl + '/Factoring/SECAPJudgmentList?ngController=factoringSecapJudgmentListController',
                    },
                },
        }).state('secapContractDetail', {
            url: '/secapContractDetail', 
            params: {
                GENAPPNUM: null,
                CPNCOD: null,
                CPNBRNCOD: null,
                ACCBUSTYP: null,
                purpose: "ENTRY"
                },
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@secapContractDetail': {
                        templateUrl: rooUrl + '/ApplicationProcess/ApplicationEntryFactoring?ngController=factoringAppEntryController',
                    },
                },
        }).state('secapJudgmentEntry', {
            url: '/secapJudgmentEntry',
            params: {
                GENAPPNUM: null,
                CPNCOD: null,
                CPNBRNCOD: null,
                ACCBUSTYP: null,
                purpose : "VERIFY"
            },
            views:
                {
                    '': { templateUrl: rooUrl + '/Layout/BizLayoutDefault' }, /* Use BizLayout*/
                    'bizContent@secapJudgmentEntry': {
                        templateUrl: rooUrl + '/ApplicationProcess/JudgmentEntryFactoring?ngController=factoringAppEntryController',
                    },
                },
        })
    


     

    
})