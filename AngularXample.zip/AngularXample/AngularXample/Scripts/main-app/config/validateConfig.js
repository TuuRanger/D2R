﻿/* Config Validate */
mainApp.config(['$validatorProvider', 'validationDataSvcProvider', function ($validatorProvider, validationDataSvcProvider) {
    $validatorProvider.setDefaults({
        ignore: ""   /* kendo numeric text box hidden actual field*/,
        errorPlacement: function (error, element) {
            var element_name = angular.element(element).attr('name');


            if ($(element).attr('type') == 'hidden') {
                var refFieldSelector = $(element).attr('ref-field');
                var refField = $(refFieldSelector)
                if (refField.hasClass("radio-group")) {
                    refField.find('label').addClass('has-error');
                }

            }
            else {
                var parent = $(element).parent()
                parent.addClass('has-error');
            }



            $('#vld_symbol_' + element_name).remove();



            if ($(element).parents('td').length > 0) // Table Cell
            {
                if ($("#lb_" + element_name).text().trim() != "") {
                    $("#lb_" + element_name).prepend('<span id="vld_symbol_' + element_name + '">' +
                     '<i class="fa fa-exclamation-triangle" style="color:#c9302c" aria-hidden="true"></i></span> ')

                    $('#vld_symbol_' + element_name).popover({
                        html: true,
                        content: error.text(),
                        trigger: "hover",
                        placement: "top"
                    })
                }
                else {
                    var tdParent = $($(element).parents('td')[0]);

                    $(element).prev().prepend('<span id="vld_symbol_' + element_name + '">' +
        '<i class="fa fa-exclamation-triangle" style="color:#c9302c" aria-hidden="true"></i></span> ')

                    $('#vld_symbol_' + element_name).popover({
                        html: true,
                        content: error.text(),
                        trigger: "hover",
                        placement: "top"
                    })
                }

            }
            else {


                if ($("#lb_" + element_name).text().trim() != "") {
                    $("#lb_" + element_name).prepend('<span id="vld_symbol_' + element_name + '">' +
                   '<i class="fa fa-exclamation-triangle" style="color:#c9302c" aria-hidden="true"></i></span> ')



                    $('#vld_symbol_' + element_name).popover({
                        html: true,
                        //content: error.text(),
                        content: error[0].innerHTML,
                        trigger: "hover",
                        placement: "top"
                    })

                }
                else {
                    $('#' + element_name).popover({
                        html: true,
                        content: error.text(),
                        trigger: "hover",
                        placement: "top"
                    })

                    $('#' + element_name).popover('show')
                }

            }

        },
        unhighlight: function (element, errorClass) {
            var element_name = angular.element(element).attr('name');

            if ($(element).attr('type') == 'hidden') {
                var refFieldSelector = $(element).attr('ref-field');
                var refField = $(refFieldSelector)
                if (refField.hasClass("radio-group")) {
                    refField.find('label').removeClass('has-error');
                }

            }
            else {
                var parent = $(element).parent()
                parent.removeClass('has-error');
            }

            $('#vld_symbol_' + element_name).remove();

            $("#" + element_name).removeAttr("aria-describedby")
            $("#" + element_name).popover('destroy')



        },
        success: function (label, element) {
            var element_name = angular.element(element).attr('name');
            $('#vld_symbol_' + element_name).remove();

            $("#" + element_name).removeAttr("aria-describedby")
            $("#" + element_name).popover('destroy')
        },
    })
     
    var injector = angular.injector(['ng']),
       http = injector.get('$http'),
       q = injector.get('$q');

    $validatorProvider.addMethod("notEarlyThan", function (value, element, param) {
        var dateValue = angular.element(element).data('kendoDatePicker').value();

        if (typeof (dateValue) == "object") {
            dateValue.setSeconds(0);
            dateValue.setMilliseconds(0);

            param.setSeconds(0);
            param.setMilliseconds(0);
            return dateValue >= param;
        }


    }, function (params, element) {
        if (typeof (params) == "object") {
            return "Please input date/time not early than " + kendo.toString(params, angular.element(element).data('kendoDatePicker').options.format + " HH:mm:ss")
        }
        else {
            return "Date/time is early than specific value"
        }

    });
     


}]);