﻿var JQueryValidateService = (function () {
    var _service = {};

    _service.getAccountMaxCreditLine = function (element) {

        var maxCreditLine = 0;
         
        jQuery.ajax({
            url: "http://localhost/mls.api/api/SetupServices/GetSetup",
            method: "get",
            async: false,
            cache: false,
            data: {
                TABKEYONE: "CREDITVALUE" + $("#cboACCBUSTYP").val(),
                TABKEYTWO: "CREDITLINE",
                SHOWALL: "N"
            },
            dataType: "json",
            success: function (data) {
                if (data.length > 0) {
                    maxCreditLine = data[0].TABSETAMT1.toDecimalOrZero();
                }
            }
        });
         
        return maxCreditLine;
    };


    _service.getAccountMaxCreditPerTime = function ()
    {
        var result = 0;
         
        jQuery.ajax({
            url: "http://localhost/mls.api/api/SetupServices/GetSetup",
            method: "get",
            async: false,
            cache: false,
            data: {
                TABKEYONE: "CREDITVALUE" + $("#cboACCBUSTYP").val(),
                TABKEYTWO: "MAXIMUM",
                SHOWALL: "N"
            },
            dataType: "json",
            success: function (data) {
                if (data.length > 0) {
                    result = data[0].TABSETAMT1.toDecimalOrZero();
                }
            }
        });
         
        return result;
         
    }


    _service.getAccountMinCreditPerTime = function () {
        var result = 0;

        jQuery.ajax({
            url: "http://localhost/mls.api/api/SetupServices/GetSetup",
            method: "get",
            async: false,
            cache: false,
            data: {
                TABKEYONE: "CREDITVALUE" + $("#cboACCBUSTYP").val(),
                TABKEYTWO: "MINIMUM",
                SHOWALL: "N"
            },
            dataType: "json",
            success: function (data) {
                if (data.length > 0) {
                    result = data[0].TABSETAMT1.toDecimalOrZero();
                }
            }
        });

        return result;

    }

    _service.getAccountMinMaxAdvanceRate = function () {
        var result = {
            min: 0,
            max: 0
        };

        jQuery.ajax({
            url: "http://localhost/mls.api/api/SetupServices/GetSetup",
            method: "get",
            async: false,
            cache: false,
            data: {
                TABKEYONE: "MLSVALUE",
                TABKEYTWO: "FACADVRTE",
                SHOWALL: "N"
            },
            dataType: "json",
            success: function (data) {
                if (data.length > 0) {
                    result.min = data[0].TABSETRTE1.toDecimalOrZero() * 100;
                    result.max = data[0].TABSETRTE2.toDecimalOrZero() * 100; 
                }
            }
        });

        return result;

    }



    return _service;


})();