﻿appComponents.factory('productDataSvc', ['httpHelper', 'mlsStringUtils','mlsUrlSvc',
function (httpHelper, mlsStringUtils, mlsUrlSvc)
{
    var _service = {};

    _service.getProductSpecInputField = function (criteria)
    {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/ProductServices/GetProductSpecInputField'),
            params: {
                PRDGRPCOD: mlsStringUtils.toStringOrEmpty(criteria.PRDGRPCOD),
                PRDSUBCOD: mlsStringUtils.toStringOrEmpty(criteria.PRDSUBCOD),
            }
        }) 
    }

    _service.InsertOrUpdateProductSepc = function(CPNCOD,CPNBRNCOD,ACCBUSTYP,CONNUM,productSpec)
    {
        return httpHelper.post({
            url: mlsUrlSvc.getApiUrlContent('/ProductServices/InsertOrUpdateProductSepc/' + CPNCOD + '/' + CPNBRNCOD + '/' + ACCBUSTYP + '/' + CONNUM),
            params: JSON.stringify(productSpec)
        })
    }

    _service.getProductDetail = function (criteria) {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/ProductServices/GetProductDetail'),
            params: {
                CPNCOD:  mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
                CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
                ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP),
                CONNUM: mlsStringUtils.toStringOrEmpty(criteria.CONNUM)
            }
        })
    }

    _service.getProduct = function (criteria)
    {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/ProductServices/GetProduct'),
            params: {
                CPNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
                CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
                ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP),
                CONNUM: mlsStringUtils.toStringOrEmpty(criteria.CONNUM)
            }
        })
    }

    return _service;

}]);