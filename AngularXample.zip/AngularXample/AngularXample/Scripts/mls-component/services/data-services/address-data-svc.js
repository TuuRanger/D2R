﻿appComponents.factory('addressDataSvc', ['httpHelper', 'mlsStringUtils', 'mlsUrlSvc',
function (httpHelper, mlsStringUtils, mlsUrlSvc)
{
    var _service = {};

    _service.getCustomerAddress = function (criteria)
    {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/AddressServices/GetCustomerAddress'),
            params: {
                CUSCOD: criteria.CUSCOD
            }
        })
    }

    _service.insertOrUpdateAddress = function (arrAddress, CUSCOD,userName)
    {
        return httpHelper.post({
            url: mlsUrlSvc.getApiUrlContent('/AddressServices/InsertOrUpdateAddress/' + CUSCOD +'/' + userName),
            params: arrAddress
        })
    }

    return _service;

}]);