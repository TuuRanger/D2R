﻿appComponents.factory('guarantorPersonDataSvc', ['httpHelper', 'mlsUrlSvc', 'mlsStringUtils', '$http',
function (httpHelper, mlsUrlSvc, mlsStringUtils, $http)
{
    var service = {
        getGuarantorPersonList: function (criteria)
        {
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/GuarantorServices/GetGuarantorList'),
                params: { 
                    CPNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
                    CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
                    ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP),
                    CONNUM: mlsStringUtils.toStringOrEmpty(criteria.CONNUM)
                }
            })
        },
        insertOrUpdateGuarantorPerson: function (
            arrGuaPerson,
            CPNCOD,
            CPNBRNCOD,
            ACCBUSTYP,
            GENAPPNUM,
            username)
        {

            return httpHelper.post({
                url: mlsUrlSvc.getApiUrlContent('/GuarantorServices/InsertOrUpdateGuarantor/' + CPNCOD + '/' + CPNBRNCOD + '/' + ACCBUSTYP + '/' + GENAPPNUM + '/'  + username),
                params: JSON.stringify(arrGuaPerson)
            })

        },
    }
    return service;

}]);