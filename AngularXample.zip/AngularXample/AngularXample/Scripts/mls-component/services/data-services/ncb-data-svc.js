﻿appComponents.factory('ncbDataSvc', ['httpHelper', 'mlsStringUtils', 'mlsUrlSvc',
function (httpHelper, mlsStringUtils, mlsUrlSvc)
{
    var _service = {};

    _service.getNCBResult = function ( firstName,  middleName,  lastName,  birthDate,  IDCard,  userID)
    {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/NCBServices/GetNCBResult'),
            params: {
                firstName: mlsStringUtils.toStringOrEmpty(firstName),
                middleName: mlsStringUtils.toStringOrEmpty(middleName),
                lastName: mlsStringUtils.toStringOrEmpty(lastName),
                birthDate: mlsStringUtils.toStringOrEmpty(birthDate),
                IDCard: mlsStringUtils.toStringOrEmpty(IDCard),
                userID: mlsStringUtils.toStringOrEmpty(userID)
            }
        })
    }

    _service.insertNCBResult = function (ncbResult, username)
    {
        return httpHelper.post({
            url: mlsUrlSvc.getApiUrlContent('/NCBServices/InsertNCBResult/' + username),
            params: JSON.stringify(ncbResult)
        })
    }


     
    return _service;

}]);