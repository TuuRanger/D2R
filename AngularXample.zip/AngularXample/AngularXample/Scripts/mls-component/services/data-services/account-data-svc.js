﻿appComponents.factory('accountDataSvc', ['httpHelper', 'mlsUrlSvc', 'mlsStringUtils',
function (httpHelper, mlsUrlSvc, mlsStringUtils)
{
    var accountDataSvc = {}

    accountDataSvc.searchAccount = function (criteria) {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/AccountServices/SearchAccount'),
            params: {
                CPNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
                CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
                ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP),
                ACCDEAWTH: mlsStringUtils.toStringOrEmpty(criteria.ACCDEAWTH),
                SEARCH_STR: mlsStringUtils.toStringOrEmpty(criteria.SEARCH_STR),
            }
        })
    }
    

    accountDataSvc.getContractByAccount = function (criteria)
    {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/AccountServices/GetContractByAccount'),
            params: {
                CPNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
                CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
                ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP),
                ACCCOD: mlsStringUtils.toStringOrEmpty(criteria.ACCCOD)
            }
        })
    }

    accountDataSvc.InsertOrUpdateAccount = function (accountViewModel,username)
    {
        return httpHelper.post({
            url: mlsUrlSvc.getApiUrlContent('/AccountServices/InsertOrUpdateAccount/' + username),
            params: JSON.stringify(accountViewModel)
        }) 
    }

    accountDataSvc.verifyAccount = function (accountViewModel, username) {
        return httpHelper.post({
            url: mlsUrlSvc.getApiUrlContent('/AccountServices/VerifyAccount/' + username),
            params: JSON.stringify(accountViewModel)
        })
    }

    accountDataSvc.sendBackAccount = function (accountViewModel, username) {
        return httpHelper.post({
            url: mlsUrlSvc.getApiUrlContent('/AccountServices/SendBackAccount/' +username),
            params: JSON.stringify(accountViewModel)
        })
    }

    accountDataSvc.genAccount = function (accountViewModel, username) {
        return httpHelper.post({
            url: mlsUrlSvc.getApiUrlContent('/AccountServices/GenAccount/' + username),
            params: JSON.stringify(accountViewModel)
        })
    }

    accountDataSvc.searchAccountWithPaging = function (criteria)
    {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/AccountServices/SearchAccountWithPaging'),
            params: {
                ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP),
                ACCCOD: mlsStringUtils.toStringOrEmpty(criteria.ACCCOD),
                GENAPPNUM: mlsStringUtils.toStringOrEmpty(criteria.GENAPPNUM),
                ACCNAMTHA: mlsStringUtils.toStringOrEmpty(criteria.ACCNAMTHA),
                ACCDEAWTH: mlsStringUtils.toStringOrEmpty(criteria.ACCDEAWTH),
                RECSTSCOD_FROM: mlsStringUtils.toStringOrEmpty(criteria.RECSTSCOD_FROM),
                RECSTSCOD_TO: mlsStringUtils.toStringOrEmpty(criteria.RECSTSCOD_TO),
                pageNo: criteria.pageNo,
                pageSize: criteria.pageSize,
            }
        })
    }
     
    accountDataSvc.getAccountDetail = function (criteria) {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/AccountServices/GetAccountDetail'),
            params: {
                ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP), 
                GENAPPNUM: mlsStringUtils.toStringOrEmpty(criteria.GENAPPNUM),
                CPNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
                CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
            }
        })
    }

    accountDataSvc.getAccountCustomers = function (criteria) {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/AccountServices/GetAccountCustomers'),
            params: {
                ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP),
                GENAPPNUM: mlsStringUtils.toStringOrEmpty(criteria.GENAPPNUM),
                CPNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
                CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
            }
        })
    }


    accountDataSvc.getAccountConfig = function (criteria) {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/AccountServices/GetAccountConfig'),
            params: {
                ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP),
                ACCDEAWTH: mlsStringUtils.toStringOrEmpty(criteria.ACCDEAWTH),
                CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
            }
        })
    }

    accountDataSvc.checkCustomerInAccount = function (criteria) {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/AccountServices/CheckCustomerInAccount'),
            params: {
                CUSCOD: mlsStringUtils.toStringOrEmpty(criteria.CUSCOD),
                ACCCOD: mlsStringUtils.toStringOrEmpty(criteria.ACCCOD)
            }
        })
    }
     

    accountDataSvc.checkAccountExistsBeforeGen = function (criteria, httpOptions) {
        var params = angular.extend({
            url: mlsUrlSvc.getApiUrlContent('/AccountServices/CheckAccountExistsBeforeGen'),
            params: {
                GENAPPNUM: mlsStringUtils.toStringOrEmpty(criteria.GENAPPNUM),
                ACCCOD: mlsStringUtils.toStringOrEmpty(criteria.ACCCOD)
            }
        }, httpOptions);
         
        return httpHelper.get(params)
    }

    return accountDataSvc;

}]);