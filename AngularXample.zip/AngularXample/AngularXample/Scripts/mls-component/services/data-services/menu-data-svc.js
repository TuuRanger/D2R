﻿appComponents.factory('menuDataSvc', ['httpHelper', 'mlsUrlSvc', 'mlsStringUtils',
function (httpHelper, mlsUrlSvc, mlsStringUtils) {
    var service = {}

    service.getMenus = function (token) {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/MenuServices/GetMenus'),
            params: {
                token: token
            }
        })
    }

    return service;

}]);