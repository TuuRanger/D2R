﻿appComponents.factory('feeDataSvc', ['httpHelper', 'mlsUrlSvc', 'mlsStringUtils',
function (httpHelper, mlsUrlSvc, mlsStringUtils)
{
    var service = {};

        service.getFeeList = function (criteria)
        {
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/FeeServices/GetFeeList'),
                params: {
                    CPNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
                    CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
                    ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP),
                    CONNUM: mlsStringUtils.toStringOrEmpty(criteria.CONNUM),
                    CREDIT_APPROVE: mlsStringUtils.toStringOrEmpty(criteria.CONFINAMT),
                    CONDWNAMT: mlsStringUtils.toStringOrEmpty(criteria.CONDWNAMT),
                    CONAPPLY_PROJEC: mlsStringUtils.toStringOrEmpty(criteria.CONAPPLY_PROJEC)
                }
            })
        }

        service.insertOrUpdateFee = function (arrFee,username)
        {
            return httpHelper.post({
                url: mlsUrlSvc.getApiUrlContent("/FeeServices/InsertOrUpdateFee/" + username),
                params: arrFee
            })
        }

        //getFeeConfig: function (criteria)
        //{
        //    return httpHelper.get({
        //        url: mlsUrlSvc.getApiUrlContent('/FeeServices/GetFeeConfig'),
        //        params: {
        //            CPNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
        //            CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
        //            ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP)
        //        }
        //    })
        //},
  
    return service;

}]);