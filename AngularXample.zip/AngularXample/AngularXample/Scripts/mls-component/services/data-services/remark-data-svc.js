﻿appComponents.factory('remarkDataSvc', ['httpHelper', 'mlsStringUtils', 'mlsUrlSvc',
function (httpHelper, mlsStringUtils, mlsUrlSvc) {
    var _service = {};

    _service.insertOrUpdateRemark = function (  
            arrRemark,
            CPNCOD,
            CPNBRNCOD,
            ACCBUSTYP,
            CONNUM,
            USRCOD)
    {
        return httpHelper.post({
            url: mlsUrlSvc.getApiUrlContent('/RemarkServices/InsertOrUpdateRemark/' + CPNCOD + '/' + CPNBRNCOD + '/' + ACCBUSTYP + '/' + CONNUM + '/' + USRCOD),
            params: JSON.stringify(arrRemark)
        })
    } 

    return _service;

}]);