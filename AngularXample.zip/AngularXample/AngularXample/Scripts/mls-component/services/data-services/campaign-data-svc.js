﻿appComponents.factory('campaignDataSvc', ['httpHelper', 'mlsUrlSvc', 'mlsStringUtils',
function (httpHelper, mlsUrlSvc, mlsStringUtils)
{
    var service = {};

    service.getMLMCampaignByProjectCode = function(CONAPPLY_PROJEC)
    {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/CampaignServices/GetMLMCampaignByProjectCode'),
            params: {
                CONAPPLY_PROJEC: mlsStringUtils.toStringOrEmpty(CONAPPLY_PROJEC)
            }
        })
    }
    return service;

}]);