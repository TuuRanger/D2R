﻿appComponents.factory('userDataSvc', ['$http', 'componentContext', '$cookies', '$cookieStore', '$timeout', '$rootScope', 'authenDataSvc', '$q', 'localStorageService',
function ($http, componentContext, $cookies, $cookieStore, $timeout, $rootScope, authenDataSvc, $q, localStorageService)
{
    var userDataSvc = {}
    userDataSvc.token = null;
    userDataSvc.username = null;
  
    userDataSvc.setUserData = function (token)
    {
        var defer = $q.defer();
        userDataSvc.token = token; 
        userDataSvc.getUserData().then(function (result)
        { 
           
        })
        return defer.promise;
    }

    userDataSvc.getUserToken = function ()
    {
        return userDataSvc.token;
    }

    userDataSvc.validateUserToken = function ()
    {

    }


    userDataSvc.getUserData = function ()
    {
        var userStorage = localStorageService.get('userStorage');
        return authenDataSvc.getUserDataByToken(userStorage.token);
    }

    userDataSvc.clearUserData = function () {
        
    }

    return userDataSvc;

}]);