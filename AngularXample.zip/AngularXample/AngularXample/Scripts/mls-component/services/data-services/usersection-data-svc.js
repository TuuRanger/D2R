﻿appComponents.factory('userSectionDataSvc', ['httpHelper', 'mlsUrlSvc', 'mlsStringUtils',
function (httpHelper, mlsUrlSvc, mlsStringUtils) {
    var service = {};

    service.getUserSection = function (criteria)
    {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/UserSectionServices/GetUserSection'),
            params: {
                USERID: mlsStringUtils.toStringOrEmpty(criteria.USERID), 
            }
        })
    }
    
    return service;

}]);