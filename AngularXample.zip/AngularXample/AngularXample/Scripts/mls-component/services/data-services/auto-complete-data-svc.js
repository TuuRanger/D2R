﻿appComponents.factory('autoCompleteBoxDataSvc', ['$http',  'mlsStringUtils', 'mainAppContext','httpHelper',
function ($http,   mlsStringUtils,  mainAppContext,httpHelper)
{
    var service = {}

    service.getAutoCompleteTabkeyOne = function (criteria)
    {
        return httpHelper.get({
            url: mainAppContext.getMLSApiContent('/AutoCompleteServices/GetAutoCompleteTabKeyOne'),
            params: {
                input: mlsStringUtils.toStringOrEmpty(criteria.input)
            }
        }); 
    }

    return service;

}]);
