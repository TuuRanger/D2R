﻿appComponents.factory('referencePersonDataSvc', ['httpHelper', 'mlsUrlSvc', 'mlsStringUtils', '$http',
function (httpHelper, mlsUrlSvc, mlsStringUtils, $http)
{
    var service = {
        getReferencePersonList: function (criteria)
        {
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/ReferencePersonService/GetReferencePersonList'),
                params: {
                    CONNUM: mlsStringUtils.toStringOrEmpty(criteria.CONNUM),
                }
            })
        },
        insertOrUpdateReferencePerson: function (
            arrRefPerson,
            CPNCOD,
            CPNBRNCOD,
            ACCBUSTYP,
            CONNUM, 
            username)
        { 
          
            return httpHelper.post({
                url: mlsUrlSvc.getApiUrlContent('/ReferencePersonService/InsertOrUpdateReferencePerson/' + CPNCOD + '/' + CPNBRNCOD + '/' + ACCBUSTYP + '/' + CONNUM + '/'  + username),
                params: JSON.stringify(arrRefPerson)
            })

        },
    }
    return service;

}]);