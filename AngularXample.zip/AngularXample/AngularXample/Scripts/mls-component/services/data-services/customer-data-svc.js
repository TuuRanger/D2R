﻿appComponents.factory('customerDataSvc', ['$http', 'componentContext', '$rootScope', 'httpHelper', 'mlsUrlSvc', '$q', 'mlsStringUtils',
function ($http, componentContext, $rootScope, httpHelper, mlsUrlSvc, $q, mlsStringUtils) {
    var _service = {};
    

    _service.getCustomerInfoWithAccount = function (criteria) {
        return  httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/CustomerServices/GetCustomerInfoWithAccount'),
            params: {
                CPNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
                CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD), 
                ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP),
                ID: mlsStringUtils.toStringOrEmpty(criteria.ID),
                CUSTYPCOD: mlsStringUtils.toStringOrEmpty(criteria.CUSTYPCOD),
            }
        }) 
    }


    _service.getCustomerInfo = function (criteria) {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/CustomerServices/GetCustomerInfo'),
            params: {
                ID: mlsStringUtils.toStringOrEmpty(criteria.ID),
                CUSTYPCOD: mlsStringUtils.toStringOrEmpty(criteria.CUSTYPCOD),
            }
        })
    }


    _service.customerInfoField = [ 
            "CUSTTLTHA",
            "CUSNAMTHA",
            "CUSSURTHA",
            "PSNBTHDTE",
            "PSNBTHDAY",
            "CUSNICNAM",
            "PSNMTHINC",
            "PSNNETINC", 
            "PSNWRKPLCCCP",
            "PSNWRKPLC",  
            "PSNMARSTS",
            "PSNCHDNUM",
            "PSNSEXCOD",   
            "PSNCPNTYP",
            "PSNOCCCOD",
            "PSNPOSITN",
            "PSNCPNSTF",
            "PSNWRKPRD",
            "PSNWRKPRD_MON",
            "PSNEMPLOY_TYP",
            "PSNSALRCVTYP",
            "COOPERATE_TYPE",
            "TELPHNTYP", 
            "FINBNKCODCR",
            "FINBRNCODCR",
            "FINBNKNUMCR",
            "CUSEMAIL",  
            "Age",
            "FullBirthDay", 
            "CUSPHNNUM", 
            "CUSNAMENG",
            "CUSSURENG",
            "PSNREGSIN",
            "PSNREGEXP",
            "PSNSALDTE",
            "PSNRELTME",
            "CUSNICNAM",
            "CUSCOD",
            "ACCCOD",
            "REFDOCDTE",
            "CPNREGDTE",
            "CPNYERINC",
            "CPNYERPRF",
            "CPNBUSTYP",
            "CPNCNTPSN",
            "CPNCNTPOS"
    ]
     

    _service.insertOrUpdateCustomer = function (arrCustomer)
    {
        return httpHelper.post({
            url: mlsUrlSvc.getApiUrlContent('/CustomerServices/InsertOrUpdateCustomer'),
            params: JSON.stringify(arrCustomer)
        })
    }

    _service.getCustomerList = function (criteria)
    {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/CustomerServices/GetCustomerList'),
            params: {
                name: mlsStringUtils.toStringOrEmpty(criteria.name),
                surname: mlsStringUtils.toStringOrEmpty(criteria.surname),
                ID: mlsStringUtils.toStringOrEmpty(criteria.ID),
                customerType: mlsStringUtils.toStringOrEmpty(criteria.customerType),
                pageNo: mlsStringUtils.toStringOrEmpty(criteria.pageNo),
                pageSize: mlsStringUtils.toStringOrEmpty(criteria.pageSize),
            }
        })
    }
    return _service;

}]);