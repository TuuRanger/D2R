﻿appComponents.factory('followUpDataSvc', ['httpHelper', 'mlsUrlSvc', 'mlsStringUtils',
function (httpHelper, mlsUrlSvc, mlsStringUtils)
{
    var service = {};

    service.getFollowUpHeader = function (criteria)
    {
     
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/FollowUpServices/GetFollowUpHeader'),
             params: {
                 CPNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
                 CPNBRNCOD_FROM: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD_FROM),
                 CPNBRNCOD_TO: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD_TO),
                 FOLSTATE: mlsStringUtils.toStringOrEmpty(criteria.FOLSTATE),
                 OVDDAY_FROM: mlsStringUtils.toStringOrEmpty(criteria.OVDDAY_FROM),
                 OVDDAY_TO: mlsStringUtils.toStringOrEmpty(criteria.OVDDAY_TO),
                 ADRSPCARA_FROM: mlsStringUtils.toStringOrEmpty(criteria.ADRSPCARA_FROM),
                 ADRSPCARA_TO: mlsStringUtils.toStringOrEmpty(criteria.ADRSPCARA_TO)
             }
        })
    }
     
    service.getWorkLoadByUser = function (criteria)
    {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/FollowUpServices/GetWorkLoadByUser'),
            params: {
                FOLWERCOD: mlsStringUtils.toStringOrEmpty(criteria.FOLWERCOD),
            }
        })
    }

    service.assignJob = function (arrJobList,JobStep, JobFunction, FOLWERCOD, username)
    {
        return httpHelper.post({
            url: mlsUrlSvc.getApiUrlContent('/FollowUpServices/AssignJob/' + JobStep + '/' + JobFunction + '/' + FOLWERCOD + '/' + username),
            params: JSON.stringify(arrJobList)
        })
    }

    service.deAssignJob = function (arrJobList, JobStep, JobFunction, FOLWERCOD, username)
    {
        return httpHelper.post({
            url: mlsUrlSvc.getApiUrlContent('/FollowUpServices/DeassignJob/' + JobStep + '/' + JobFunction + '/' + FOLWERCOD + '/' + username),
            params: JSON.stringify(arrJobList)
        })
    }

    service.getFollowUpByContract = function (criteria)
    {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/FollowUpServices/GetFollowUpByContract'),
            params: {
                CONNUM: mlsStringUtils.toStringOrEmpty(criteria.CONNUM),
                CPNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
                CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
                ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP)
            }
        }) 
    }

    service.getFollowUpAlarm = function (criteria)
    {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/FollowUpServices/GetFollowUpAlarm'),
            params: {
                FOLWERCOD: mlsStringUtils.toStringOrEmpty(criteria.FOLWERCOD)
            }
        })
    }

    
    service.insertOrUpdateFollowUpDetail = function (data,username)
    {
        return httpHelper.post({
            url: mlsUrlSvc.getApiUrlContent("/FollowUpServices/InsertOrUpdateFollowUpDetail/" + username),
            params: JSON.stringify( data)
        })
    }

    service.InsertOrUpdateAlarm = function (data, username) {
        return httpHelper.post({
            url: mlsUrlSvc.getApiUrlContent("/FollowUpServices/InsertOrUpdateAlarm/" + username),
            params: JSON.stringify(data)
        })
    }

    service.getFollowUpDetail = function(criteria)
    { 
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/FollowUpServices/GetFollowUpDetail'),
            params: {
                JOBASGNUM: mlsStringUtils.toStringOrEmpty(criteria.JOBASGNUM),
                CPNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
                CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
                ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP)
            }
        })
    }


    service.getChildFollower = function (criteria)
    {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/FollowUpServices/GetChildFollower'),
            params: {
                GROUPID: mlsStringUtils.toStringOrEmpty(criteria.GROUPID)
            }
        })
    }
     
    return service;

}]);