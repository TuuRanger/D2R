﻿appComponents.factory('comboBoxDataSvc', ['httpHelper', 'mlsUrlSvc', 'setupDataSvc', 'accountDataSvc', 'mlsStringUtils', 'mainAppContext', 'eBiz', '$q',
function (httpHelper, mlsUrlSvc,setupDataSvc, accountDataSvc, mlsStringUtils, mainAppContext, eBiz,$q)
{
    var coboBoxDataSvc = {
        getComboFromSetup: function (criteria) {
            criteria = criteria || {}; 
            return setupDataSvc.getSetup(criteria);
        },
        getComboConApplyProjec: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "CONAPPLY_PROJEC";
            return setupDataSvc.getSetup(criteria);
        },
        getComboAccBusTyp: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "ACCBUSTYP" 
            return setupDataSvc.getSetup(criteria);
        },
        getComboCusTypCod: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "CUSTYPCOD";
            return setupDataSvc.getSetup(criteria);
        },
        getComboConTaxTyp: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "CONTAXTYP";
            return setupDataSvc.getSetup(criteria);
        },
        getComboConApplyTyp: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "CONAPPLY_TYP" + mlsStringUtils.toStringOrEmpty(criteria.CONAPPLY_PROJEC);;
            return setupDataSvc.getSetup(criteria);
        },
        getComboConApplyVia: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "CONAPPLY_VIA" + mlsStringUtils.toStringOrEmpty(criteria.CONAPPLY_PROJEC);
            return setupDataSvc.getSetup(criteria);
        },
        getComboConApplyProMot: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "CONAPPLY_PROMOT" + mlsStringUtils.toStringOrEmpty(criteria.CONAPPLY_PROJEC);
            return setupDataSvc.getSetup(criteria);
        },
        getComboConObjCod: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "CONOBJCOD"
            return setupDataSvc.getSetup(criteria);
        },
        getComboConApplyViaBrn: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "CONAPPLY_VIABRN" + criteria.CONAPPLY_VIA;
            return setupDataSvc.getSetup(criteria);
        },
        getComboCusTtlPsn: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "CUSTTLTHAPSN";
            return setupDataSvc.getSetup(criteria);
        } ,
        getComboDayOfWeek: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "DAYOFWEEK";
            return setupDataSvc.getSetup(criteria);
        },
        getComboCocCusRel: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "COCCUSREL";
            return setupDataSvc.getSetup(criteria);
        },
        getComboPsnMarSts: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "PSNMARSTS";
            return setupDataSvc.getSetup(criteria);
        },
        getComboPsnSexCod: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "GENDER";
            return setupDataSvc.getSetup(criteria);
        },
        getComboAdrOwnCod: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "ADROWNERCOD";
            return setupDataSvc.getSetup(criteria);
        },
        getComboPsnCpnTyp: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "PSNCPNTYP";
            return setupDataSvc.getSetup(criteria);
        },
        getComboPsnCpnTyp: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "PSNCPNTYP";
            return setupDataSvc.getSetup(criteria);
        },
        getComboPsnOccCod: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "PSNOCCCOD";
            return setupDataSvc.getSetup(criteria);
        },
        getComboPsnSalRcvTyp: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "PSNSALRCVTYP";
            return setupDataSvc.getSetup(criteria);
        },
        getComboPsnEmployTyp: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "PSNEMPLOY_TYP";
            return setupDataSvc.getSetup(criteria);
        }, 
        getComboCoOperateTyp: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "COOPERATE_TYPE";
            return setupDataSvc.getSetup(criteria);
        }, 
        getComboFinBnkCod: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "FINBNKCOD";
            return setupDataSvc.getSetup(criteria);
        }, 
        getComboFinBnkBrn: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "FINBNKBRN" +  mlsStringUtils.toStringOrEmpty(criteria.FINBNKCOD);
            return setupDataSvc.getSetup(criteria);
        }, 
        getComboDBDResult: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "TELLEVRSLDBD";
            return setupDataSvc.getSetup(criteria);
        }, 
        getComboRmkCalRsl: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "RMKCALRSL";
            return setupDataSvc.getSetup(criteria);
        },
        getComboVendor: function (criteria)
        {
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/ComboBoxServices/GetDropDownDealer'),
                params: {
                    CPNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
                    CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
                    ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP),
                    PROJECTCODE: mlsStringUtils.toStringOrEmpty(criteria.PROJECTCODE),
                }
            }) 
        }, 
        getComboMarketing: function (criteria)
        { 
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/ComboBoxServices/SearchAccount'),
                params: {
                    CPNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
                    CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
                    ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP),
                    ACCDEAWTH: "MKT",
                    SEARCH_STR: mlsStringUtils.toStringOrEmpty(criteria.SEARCH_STR),
                }
            }) 
        },
        getComboAccountCustomer: function (criteria) {
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/ComboBoxServices/SearchAccount'),
                params: {
                    CPNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
                    CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
                    ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP),
                    ACCDEAWTH: "CUS",
                    SEARCH_STR: mlsStringUtils.toStringOrEmpty(criteria.SEARCH_STR),
                }
            })
        },
        getComboAccount: function (criteria) {
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/ComboBoxServices/SearchAccount'),
                params: {
                    CPNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
                    CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
                    ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP),
                    ACCDEAWTH: mlsStringUtils.toStringOrEmpty(criteria.ACCDEAWTH),
                    SEARCH_STR: mlsStringUtils.toStringOrEmpty(criteria.SEARCH_STR),
                }
            })
        },
        getComboPsnPosItn: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "PSNPOSITN";
            return setupDataSvc.getSetup(criteria);
        },
        getTelLogResultFamily: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "TELLEVRSLF";
            return setupDataSvc.getSetup(criteria);
        },
        getTelLogResultHome: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "TELLEVRSLH";
            return setupDataSvc.getSetup(criteria, false);
        },
        getTelLogResultOffice: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "TELLEVRSLO";
            return setupDataSvc.getSetup(criteria, false);
        },
        getTelLogResultMobile: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "TELLEVRSLM";
            return setupDataSvc.getSetup(criteria, false);
        },
        getTelLogResultRelative: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "TELLEVRSLR";
            return setupDataSvc.getSetup(criteria, false);
        },
        getTelLogResultNone: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "TELLEVRSL";
            return setupDataSvc.getSetup(criteria, false);
        }, 
        getComboProductGroupCode: function (criteria)
        { 
            criteria = criteria || {};
            criteria.TABKEYONE = "PRDGRPCOD";
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboProductSubCode: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "PRDSUBCOD" + criteria.PRDGRPCOD;
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboProductBrand: function (criteria)
        { 
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/ComboBoxServices/GetDropDownProductBrand'),
                params: {
                    PRDGRPCOD: mlsStringUtils.toStringOrEmpty(criteria.PRDGRPCOD),
                    PRDSUBCOD: mlsStringUtils.toStringOrEmpty(criteria.PRDSUBCOD),
                    CONAPPLY_PROJEC: mlsStringUtils.toStringOrEmpty(criteria.CONAPPLY_PROJEC),
                    BrandInput: mlsStringUtils.toStringOrEmpty(criteria.BrandInput)
                }
            }) 
        },
        getComboProductModel: function (criteria)
        {
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/ComboBoxServices/GetDropDownProductModel'),
                params: {
                    PRDGRPCOD: mlsStringUtils.toStringOrEmpty(criteria.PRDGRPCOD),
                    PRDSUBCOD: mlsStringUtils.toStringOrEmpty(criteria.PRDSUBCOD),
                    Brnad: mlsStringUtils.toStringOrEmpty(criteria.Brnad),
                    CONAPPLY_PROJEC: mlsStringUtils.toStringOrEmpty(criteria.CONAPPLY_PROJEC),
                    ModelInput: mlsStringUtils.toStringOrEmpty(criteria.ModelInput)
                }
            }) 
        },
        getComboProductSpec: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = "PRDSPC_" + criteria.suffix;
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboTabKeyOne: function ()
        {
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/ComboBoxServices/GetDropDownTabkeyOne'),
                params: {
                    PRDGRPCOD: mlsStringUtils.toStringOrEmpty(criteria.PRDGRPCOD),
                    PRDSUBCOD: mlsStringUtils.toStringOrEmpty(criteria.PRDSUBCOD),
                    Brnad: mlsStringUtils.toStringOrEmpty(criteria.Brnad),
                    CONAPPLY_PROJEC: mlsStringUtils.toStringOrEmpty(criteria.CONAPPLY_PROJEC),
                    ModelInput: mlsStringUtils.toStringOrEmpty(criteria.ModelInput)
                }
            }) 
        },
        getComboTabKeyTwo: function (criteria)
        {
            criteria = criteria || {}; 
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboDownCondition: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = 'CONDWNCND'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboInterestType: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = 'CONINTTYP'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboCreditType: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = 'ACCLNDTYP'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboAdressTypeCode: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = 'ADRTYPCOD' + criteria.CUSTYPCOD
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboInserestCalcCondtion : function(criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = 'CONINTCAL'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboProductType: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = 'PRDNEWUSE'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboCompanyBranch: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = 'CPNBRNCOD'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboFollowState: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = 'FOLSTATE'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboFollower: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = 'FOLLOWER'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboCusTtlCcp : function(criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = 'CUSTTLCCP'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboCustomerTitleByCustomerType : function(customerType)
        { 
            if(customerType == eBiz.CUSTYPCOD.NaturalPerson)
            {
                return coboBoxDataSvc.getComboCusTtlPsn();
            }
            else if (customerType == eBiz.CUSTYPCOD.JuristicPerson)
            {
                return coboBoxDataSvc.getComboCusTtlCcp();
            }
        },
        getComboPayType: function (criteria) {
            criteria = criteria || {};
            criteria.TABKEYONE = 'CONPAYTYP'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboCONDUEDAY: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = 'CONDUEDAY'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboInterestRate: function (criteria)
        {
            criteria = criteria || {};
            criteria.TABKEYONE = 'CONINTRTE' + criteria.CONAPPLY_PROJEC
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboInterestRate: function (criteria) {
            criteria = criteria || {};
            criteria.TABKEYONE = 'CONINTRTE' + criteria.CONAPPLY_PROJEC
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboCompany: function (criteria)
        {
            return  httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/ComboBoxServices/GetDropDownCompany'),
                //params: { 
                //}
            }) 
        },
        getComboFollowUpArea: function (criteria) {
            criteria = criteria || {};
            criteria.TABKEYONE = 'ADRSPCARA'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboSectionManger: function (criteria) {
            var defer = $q.defer();

            criteria = criteria || {};
            criteria.TABKEYONE = 'SECTINMGR'
            setupDataSvc.getSetup(criteria, false).then(function (data1) {
                if (data1.length > 0) {
                    setupDataSvc.getSetup({ TABKEYONE: data1[0].TABLNKKEY }, false).then(function (data2) {
                        defer.resolve(data2)
                    });
                }
                else {
                    defer.resolve([])
                }
            });

            return defer.promise;
        },
        getUserInSectionGroup: function (criteria) {
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/ComboBoxServices/GetUserInSectionGroup'),
                params: {
                    SectionID: criteria.SectionID,
                    GroupID: criteria.GroupID
                }
            })
        },
        getComboRejectAppReason: function (criteria) {
            criteria = criteria || {};
            criteria.TABKEYONE = 'CRDDEVIAT'  
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboCancelAppReason: function (criteria) {
            criteria = criteria || {};
            criteria.TABKEYONE = 'CRDDEVIATC'  
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboFollowUpActivity: function (criteria) {
            criteria = criteria || {};
            criteria.TABKEYONE = 'FOLACTCOD'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboFollowUpPlace: function (criteria) {
            criteria = criteria || {};
            criteria.TABKEYONE = 'FOLWHERE'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboFollowUpResult: function (criteria) {
            criteria = criteria || {};
            criteria.TABKEYONE = 'FOLWUPRSL'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboAccountDealWith: function (criteria) {
            criteria = criteria || {};
            criteria.TABKEYONE = 'ACCDEAWTH'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboAccountContractType: function (criteria) {
            criteria = criteria || {};
            criteria.TABKEYONE = 'ACCCNTTYP'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboIRate: function (criteria) {
            criteria = criteria || {};
            criteria.TABKEYONE = 'IRATE'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboPayBy: function (criteria) {
            criteria = criteria || {};
            criteria.TABKEYONE = 'TRNPAYBY'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboAccountGrade: function (criteria) {
            criteria = criteria || {};
            criteria.TABKEYONE = 'ACCGRDCOD'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboLendingPeriod: function (criteria) {
            criteria = criteria || {};
            criteria.TABKEYONE = 'LNDPER'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboAccountLevel: function (criteria) {
            criteria = criteria || {};
            criteria.TABKEYONE = 'ACCLEVCOD'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboAccountDueTerm: function (criteria) {
            criteria = criteria || {};
            criteria.TABKEYONE = 'ACCDUETRM'
            return setupDataSvc.getSetup(criteria, false);
        },
        getComboAccountCreditTerm: function (criteria) {
            criteria = criteria || {};
            criteria.TABKEYONE = 'ACCCRDTRM'
            return setupDataSvc.getSetup(criteria, false);
        },
        

        

        

        

        
    }

    return coboBoxDataSvc;

}]);
