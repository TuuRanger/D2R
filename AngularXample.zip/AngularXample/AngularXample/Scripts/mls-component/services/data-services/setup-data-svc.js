﻿appComponents.factory('setupDataSvc', ['httpHelper', 'mlsUrlSvc', 'mlsStringUtils',
function (httpHelper, mlsUrlSvc, mlsStringUtils)
{
    var setupSvc = {
        getSetup: function (criteria)
        { 
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/SetupServices/GetSetup'),
                params: {
                    TABKEYONE: mlsStringUtils.toStringOrEmpty(criteria.TABKEYONE),
                    TABKEYTWO: mlsStringUtils.toStringOrEmpty(criteria.TABKEYTWO),
                    SHOWALL: mlsStringUtils.toStringOrEmpty(criteria.SHOWALL) 
                }
            })
             
        }
    }
    return setupSvc;

}]);
 