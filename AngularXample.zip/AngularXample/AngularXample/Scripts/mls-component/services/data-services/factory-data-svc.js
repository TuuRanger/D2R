﻿appComponents.factory('factoryDataSvc', ['httpHelper', 'mlsUrlSvc', 'mlsStringUtils',
function (httpHelper, mlsUrlSvc, mlsStringUtils)
{
    var _services = {}
     
    _services.invoiceVerifying = function(fileNames,username)
    {
        return httpHelper.post({
            url: mlsUrlSvc.getApiUrlContent('/FactoringServices/InvoiceVerifying/' + username),
            params: JSON.stringify(fileNames)
        })
    }

    _services.getInvoiceList = function (criteria) {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/FactoringServices/GetInvoiceList'),
            params: {
                productType: mlsStringUtils.toStringOrEmpty(criteria.productType),
                InvoiceDateFrom: mlsStringUtils.toStringOrEmpty(criteria.InvoiceDateFrom),
                invoiceDateTo: mlsStringUtils.toStringOrEmpty(criteria.invoiceDateTo),
                dueDateFrom: mlsStringUtils.toStringOrEmpty(criteria.dueDateFrom),
                dueDateTo: mlsStringUtils.toStringOrEmpty(criteria.dueDateTo)
            }
        })
    }


    _services.onAssignCredit = function (criteria) {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/FactoringServices/OnAssignCredit'),
            params: {
                productType: mlsStringUtils.toStringOrEmpty(criteria.productType),
                InvoiceDateFrom: mlsStringUtils.toStringOrEmpty(criteria.InvoiceDateFrom),
                invoiceDateTo: mlsStringUtils.toStringOrEmpty(criteria.invoiceDateTo),
                dueDateFrom: mlsStringUtils.toStringOrEmpty(criteria.dueDateFrom),
                dueDateTo: mlsStringUtils.toStringOrEmpty(criteria.dueDateTo),
                creditRequest: mlsStringUtils.toStringOrEmpty(criteria.creditRequest),
            }
        })
    }

    _services.insertInvoiceTransaction = function (selectedInvoices,username)
    {
        return httpHelper.post({
            url: mlsUrlSvc.getApiUrlContent('/FactoringServices/InsertInvoiceTransaction/' + username),
            params: JSON.stringify(selectedInvoices)
        })
    }

    _services.getInvoiceCreditInfo = function (criteria) {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/FactoringServices/GetInvoiceCreditInfo')
        })
    }
     
    _services.getSponsorInvoiceList = function (criteria)
    {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/FactoringServices/GetSponsorInvoiceList'),
            params: { 
                CPNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
                CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
                ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP),
                ACCCOD: mlsStringUtils.toStringOrEmpty(criteria.ACCCOD)
            }
        })
    }

    _services.getContractInvoiceList = function (criteria) {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/FactoringServices/GetContractInvoiceList'),
            params: {
                CPNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
                CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
                ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP),
                CONNUM: mlsStringUtils.toStringOrEmpty(criteria.CONNUM)
            }
        })
    }

    return _services;

}]);