﻿appComponents.factory('mlsScreenResourceProvider', ['httpHelper', 'componentContext','mlsUrlSvc',
    function (httpHelper, componentContext,mlsUrlSvc)
{
    var mlsScreenResourceProvider = {
        screenResouceList: [], 
        getScreenLabelTextList: function (screenID, language)
        {
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/UIServices/getScreenLabelTextList'),
                params: {
                    screenID: screenID,
                    language: language
                }
            })  
        },
        getGlobalMessage: function (language)
        {
            if (componentContext.showLog)
            {
                console.log('getGlobalResource');
            }
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/UIServices/GetGlobalMessage'),
                params: { 
                    language: language
                }
            })
 
        }
    }
     
    return mlsScreenResourceProvider;

}]);