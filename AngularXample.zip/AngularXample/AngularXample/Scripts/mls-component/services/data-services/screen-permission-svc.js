﻿appComponents.factory('screenPermissionSvc', ['httpHelper', 'mlsUrlSvc', 'mlsStringUtils','$q',
function (httpHelper, mlsUrlSvc, mlsStringUtils,$q)
{
    var _service = {}

    _service.getScreenPermission = function ()
    {
        var defered = $q.defer();
        defered.resolve();
        return defered.promise;
    }

    return _service;

}]);