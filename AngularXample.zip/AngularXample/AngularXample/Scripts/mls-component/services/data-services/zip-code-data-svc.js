﻿appComponents.factory('zipCodeDataSvc', ['$http', 'mlsUrlSvc', 'mlsStringUtils', 'httpHelper',
function ($http, mlsUrlSvc, mlsStringUtils, httpHelper)
{
    var zipCodeDataSvc = {
        getZipCode: function (criteria)
        {
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/ZipCodeServices/GetZipCode'),
                params: {
                    districtID: mlsStringUtils.toStringOrEmpty(criteria.districtID),
                    amphurID: mlsStringUtils.toStringOrEmpty(criteria.amphurID),
                    provinceID: mlsStringUtils.toStringOrEmpty(criteria.provinceID),
                }
            })
             
        },
        getZipCodeByZipCode: function (criteria)
        {
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/ZipCodeServices/GetZipCodeByZipCode'),
                params: {
                    zipCode: mlsStringUtils.toStringOrEmpty(criteria.zipCode)
                }
            }) 
        }
    }
    return zipCodeDataSvc;

}]);