﻿appComponents.factory('sysConfigDataSvc', ['$http', 'httpHelper', 'mlsStringUtils','mlsUrlSvc',
function ($http, httpHelper, mlsStringUtils, mlsUrlSvc)
{
    var setupSvc = {
        getCDMTABList: function (criteria)
        {
            criteria = criteria || {};
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/SysConfigServices/GetCDMTABList'),
                params: {
                    TABKEYONE: mlsStringUtils.toStringOrEmpty(criteria.TABKEYONE),
                    TABKEYTWO: mlsStringUtils.toStringOrEmpty(criteria.TABKEYTWO),
                }
            })
        }
    }
    return setupSvc;

}]);
