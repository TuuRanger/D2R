﻿appComponents.factory('amphurDataSvc', ['httpHelper', 'mlsUrlSvc', 'mlsStringUtils',
function (httpHelper, mlsUrlSvc, mlsStringUtils)
{
    var aumphurDataSvc = {
        getAumphurByName: function (criteria)
        {
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/AumphurServices/GetAumphurByName'),
                params: {
                    aumphurName: mlsStringUtils.toStringOrEmpty(criteria.aumphurName)
                }
            } ) 
        },
        getAumphurByID: function (criteria)
        {
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/AumphurServices/GetAumphurByID'),
                params: {
                    amhurId: mlsStringUtils.toStringOrEmpty(criteria.amhurId)
                }
            }) 
        }
    }
    return aumphurDataSvc;

}]);