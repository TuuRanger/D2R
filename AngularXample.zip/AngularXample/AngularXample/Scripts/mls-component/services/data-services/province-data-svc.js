﻿appComponents.factory('provinceDataSvc', ['$http', 'mlsUrlSvc', 'mlsStringUtils', 'httpHelper',
function ($http, mlsUrlSvc, mlsStringUtils, httpHelper)
{
    var provinceDataSvc = {
        getProvinceByID: function (criteria)
        {
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/ProvinceServices/GetProvinceByID'),
                params: {
                    provinceID: mlsStringUtils.toStringOrEmpty(criteria.provinceID)
                }
            }) 
        },
        getProvinceByName: function (criteria)
        {
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/ProvinceServices/GetProvinceByName'),
                params: {
                    provinceName: mlsStringUtils.toStringOrEmpty(criteria.provinceName)
                }
            })
             
        }
    }
    return provinceDataSvc;

}]);