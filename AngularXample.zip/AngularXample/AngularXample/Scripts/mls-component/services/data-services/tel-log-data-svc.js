﻿appComponents.factory('telLogDataSvc', ['httpHelper', 'mlsUrlSvc', 'mlsStringUtils',
function (httpHelper, mlsUrlSvc, mlsStringUtils)
{
    var service = {};
    service.getTelList = function (criteria)
    { 
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/TelLogServices/GetTelList'),
            params: {
                CPNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
                CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
                CONNUM: mlsStringUtils.toStringOrEmpty(criteria.CONNUM),
                ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP),
            }
        })
    }

    service.insertOrUpdateTelLog = function (arrTelLog,
            CPNCOD,
            CPNBRNCOD,
            ACCBUSTYP,
            CONNUM,
            username)
    { 
        return httpHelper.post({
            url: mlsUrlSvc.getApiUrlContent('/TelLogServices/InsertOrUpDateTelLog/' + CPNCOD + '/' + CPNBRNCOD + '/' + ACCBUSTYP + '/' + CONNUM + '/' + username),
            params: JSON.stringify(arrTelLog)
        })
    }
     
    return service;

}]);