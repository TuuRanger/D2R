﻿appComponents.factory('contractDataSvc', ['httpHelper', 'mlsUrlSvc', 'mlsStringUtils',
function (httpHelper, mlsUrlSvc, mlsStringUtils) {
    var contractSvc = {
        getContractList: function (criteria) {
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/ContractServices/GetContractList'),
                params: {
                    CONAPPLY_PROJEC: mlsStringUtils.toStringOrEmpty(criteria.CONAPPLY_PROJEC),
                    VENDOR: mlsStringUtils.toStringOrEmpty(criteria.VENDOR),
                    CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
                    CRDSTPFROM: mlsStringUtils.toStringOrEmpty(criteria.CRDSTPFROM),
                    CRDSTPTO: mlsStringUtils.toStringOrEmpty(criteria.CRDSTPTO),
                    PSNREGIDN: mlsStringUtils.toStringOrEmpty(criteria.PSNREGIDN),
                    CUSNAMTHA: mlsStringUtils.toStringOrEmpty(criteria.CUSNAMTHA),
                    CUSSURTHA: mlsStringUtils.toStringOrEmpty(criteria.CUSSURTHA),
                    GENAPPNUM: mlsStringUtils.toStringOrEmpty(criteria.GENAPPNUM),
                }
            })
        },
        getContractDetail: function (criteria) {
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/ContractServices/GetContractDetail'),
                params: {
                    CPNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNCOD),
                    CPNBRNCOD: mlsStringUtils.toStringOrEmpty(criteria.CPNBRNCOD),
                    GENAPPNUM: mlsStringUtils.toStringOrEmpty(criteria.GENAPPNUM),
                    ACCBUSTYP: mlsStringUtils.toStringOrEmpty(criteria.ACCBUSTYP),
                }
            })
        },

        InsertOrUpdateContract: function (contractDetail) {
            return httpHelper.post({
                url: mlsUrlSvc.getApiUrlContent('/ContractServices/InsertOrUpdateContract'),
                params: JSON.stringify(contractDetail)
            })
        },

        InsertOrUpdateContractFactoring: function (contractDetail, username) {
            return httpHelper.post({
                url: mlsUrlSvc.getApiUrlContent('/ContractServices/InsertOrUpdateContractFactoring/' + username),
                params: JSON.stringify(contractDetail)
            })
        }, 
        getContractListFactoringWithPaging: function (criteria) {
            return httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/ContractServices/GetContractListFactoringWithPaging'),
                params: {
                    sponsorName: mlsStringUtils.toStringOrEmpty(criteria.sponsorName),
                    CONNUM: mlsStringUtils.toStringOrEmpty(criteria.CONNUM),
                    GENAPPNUM: mlsStringUtils.toStringOrEmpty(criteria.GENAPPNUM),
                    stepFrom: mlsStringUtils.toStringOrEmpty(criteria.stepFrom),
                    stepTo: mlsStringUtils.toStringOrEmpty(criteria.stepTo),
                    pageSize: mlsStringUtils.toStringOrEmpty(criteria.pageSize),
                    pageNo: mlsStringUtils.toStringOrEmpty(criteria.pageNo),
                }
            })
        }


    }
    return contractSvc;

}]);