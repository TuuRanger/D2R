﻿appComponents.factory('authenDataSvc', ['$http', 'componentContext', '$rootScope', 'httpHelper', 'mlsUrlSvc', '$q',
function ($http, componentContext, $rootScope, httpHelper, mlsUrlSvc, $q)
{
    var authenSvc = {};
    authenSvc.login = function (username, password)
    {
        //String Username,String Password
        var defer = $q.defer();
        httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/AuthenServices/Login'),
            params: {
                Username: username,
                Password: password
            }
        }).then(function (token)
        {
            if (!token)
                defer.resolve({ isLoggenIn: false })

            defer.resolve({ isLoggenIn: true, token: token })
        }, function (response)
        {
            defer.reject(response)
        }) 
       return defer.promise;
    }

    authenSvc.getUserDataByToken = function (token)
    {
        var defer = $q.defer();
        if (!token)
        {
            defer.reject({ message: "TOKEN_IS_EMPTY" });
            return defer.promise;
        }

        httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/AuthenServices/GetUserDataByToken'),
            params: {
                Token: token
            }
        }).then(function (data) {
            defer.resolve(data);
        }, function()
        {
            defer.reject({message : "An error occured"});
        });
        return defer.promise;
    }

    authenSvc.isTokenValid = function (username,token)
    {
        var defer = $q.defer();
        if (!token)
        {
            defer.reject({ message: "TOKEN_IS_EMPTY" });
            return defer.promise;
        }

        if (!username)
        {
            defer.reject({ message: "USERNAME_IS_EMPTY" });
            return defer.promise;
        }

        httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/AuthenServices/IsTokenValid'),
            params: {
                Username : username,
                Token: token
            }
        }).then(function (data) {
            defer.resolve(data);
        }, function () {
            defer.reject({ message: "An error occured" });
        });
        return defer.promise;
    }

    authenSvc.logout = function (username,token)
    {
        //Implment later
        //1. call server site the client will be logout
        //2. clear cache at server site
        //3. return promise
        //4. clear local storage at client site
    }

    return authenSvc;

}]);