﻿appComponents.factory('financeCalcDataSvc', ['httpHelper', 'mlsUrlSvc', 'mlsStringUtils', 'numberHelper', 'setupDataSvc', '$q',
function (httpHelper, mlsUrlSvc, mlsStringUtils, numberHelper, setupDataSvc, $q)
{
    var service = {};
    service.getInstallmentTable = function (ACCBUSTYP,
                                            CONDUEDAY,
                                            CONFINAMT,
                                            CONLNDTRM,
                                            CONLNDAMT,
                                            CONINSAMT,
                                            CONEFFRTE,
                                            CONINTRTE,
                                            INCOMERTE,
                                            CRUSGRTE,
                                            CONEFFDTE,
                                            CONSTRINS,
                                            CONSECINS,
                                            CONINTPER,
                                            SUBSDYAMT,
                                            CONINTCAL)
    {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/FinanceCalcServices/GetInstallmentTable'),
            params: {
                ACCBUSTYP: mlsStringUtils.toStringOrEmpty(ACCBUSTYP),
                CONDUEDAY: mlsStringUtils.toStringOrEmpty(CONDUEDAY),
                CONFINAMT: mlsStringUtils.toStringOrEmpty(CONFINAMT),
                CONLNDTRM: mlsStringUtils.toStringOrEmpty(CONLNDTRM),
                CONLNDAMT: mlsStringUtils.toStringOrEmpty(CONLNDAMT),
                CONINSAMT: mlsStringUtils.toStringOrEmpty(CONINSAMT),
                CONEFFRTE: mlsStringUtils.toStringOrEmpty(CONEFFRTE),
                CONINTRTE: mlsStringUtils.toStringOrEmpty(CONINTRTE),
                INCOMERTE: mlsStringUtils.toStringOrEmpty(INCOMERTE),
                CRUSGRTE: mlsStringUtils.toStringOrEmpty(CRUSGRTE),
                CONEFFDTE: mlsStringUtils.toStringOrEmpty(CONEFFDTE),
                CONSTRINS: mlsStringUtils.toStringOrEmpty(CONSTRINS),
                CONSECINS: mlsStringUtils.toStringOrEmpty(CONSECINS),
                CONINTPER: mlsStringUtils.toStringOrEmpty(CONINTPER),
                SUBSDYAMT: mlsStringUtils.toStringOrEmpty(SUBSDYAMT),
                CONINTCAL: mlsStringUtils.toStringOrEmpty(CONINTCAL)
            }
        });
    }

    service.installmentCalc = function (CONFINAMTx,
                                        CONLNDTRMx,
                                        CONINTRTEx,
                                        CONINTTYPx,
                                        CONINSPERx,
                                        CONINTCALx,
                                        CONINTPERx,
                                        CONIRATEx,
                                        CONFRATEx,
                                        CONIRATEBNKREFx,
                                        CONBLNAMTx,
                                        SUBSDYAMTx,
                                        ROUND_UPx,
                                        ROUND_FACTORx,
                                        INS_EQUAx,
                                        LND_RoundUP,
                                        LND_RoundFactor)
    {
        return httpHelper.get({
            url: mlsUrlSvc.getApiUrlContent('/FinanceCalcServices/InstallmentCalc'),
            params: {
                CONFINAMTx: numberHelper.toDecimalOrZero(CONFINAMTx),
                CONLNDTRMx: numberHelper.toDecimalOrZero(CONLNDTRMx),
                CONINTRTEx: numberHelper.toDecimalOrZero(CONINTRTEx),
                CONINTTYPx: mlsStringUtils.toStringOrEmpty(CONINTTYPx),
                CONINSPERx: mlsStringUtils.toStringOrEmpty(CONINSPERx),
                CONINTCALx: mlsStringUtils.toStringOrEmpty(CONINTCALx),
                CONINTPERx: mlsStringUtils.toStringOrEmpty(CONINTPERx),
                CONIRATEx: mlsStringUtils.toStringOrEmpty(CONIRATEx),
                CONFRATEx: numberHelper.toDecimalOrZero(CONFRATEx),
                CONIRATEBNKREFx: mlsStringUtils.toStringOrEmpty(CONIRATEBNKREFx),
                CONBLNAMTx: numberHelper.toDecimalOrZero(CONBLNAMTx),
                SUBSDYAMTx: numberHelper.toDecimalOrZero(SUBSDYAMTx),
                ROUND_UPx: numberHelper.toDecimalOrZero(ROUND_UPx),
                ROUND_FACTORx: numberHelper.toDecimalOrZero(ROUND_FACTORx),
                INS_EQUAx: numberHelper.toDecimalOrZero(INS_EQUAx),
                LND_RoundUP: numberHelper.toDecimalOrZero(LND_RoundUP),
                LND_RoundFactor: numberHelper.toDecimalOrZero(LND_RoundFactor)
            }
        });
    }

    service.termCalc = function (CONFINAMTx,
                                 CONINSAMTx,
                                 CONINTRTEx,
                                 CONINTTYPx,
                                 CONINSPERx,
                                 CONINTCALx,
                                 CONINTPERx,
                                 CONIRATEx,
                                 CONFRATEx,
                                 CONIRATEBNKREFx,
                                 CONBLNAMTx,
                                 SUBSDYAMTx,
                                 ROUND_UPx,
                                 ROUND_FACTORx,
                                 INS_EQUAx,
                                 LND_RoundUP,
                                 LND_RoundFactor)
    {
        var defered = $q.defer();
        setupDataSvc.getSetup({ TABKEYONE: 'MLSVALUE', TABKEYTWO: 'TERMSTEP' }).then(function (data)
        {
            var TRMSTEPUPx = data[0].TABSETAMT1;
            
            httpHelper.get({
                url: mlsUrlSvc.getApiUrlContent('/FinanceCalcServices/TermCalc'),
                params: {
                    CONFINAMTx: numberHelper.toDecimalOrZero(CONFINAMTx),
                    CONINSAMTx: numberHelper.toDecimalOrZero(CONINSAMTx),
                    CONINTRTEx: numberHelper.toDecimalOrZero(CONINTRTEx),
                    CONINTTYPx: mlsStringUtils.toStringOrEmpty(CONINTTYPx),
                    CONINSPERx: mlsStringUtils.toStringOrEmpty(CONINSPERx),
                    CONINTCALx: mlsStringUtils.toStringOrEmpty(CONINTCALx),
                    CONINTPERx: mlsStringUtils.toStringOrEmpty(CONINTPERx),
                    CONIRATEx: mlsStringUtils.toStringOrEmpty(CONIRATEx),
                    CONFRATEx: numberHelper.toDecimalOrZero(CONFRATEx),
                    CONIRATEBNKREFx: mlsStringUtils.toStringOrEmpty(CONIRATEBNKREFx),
                    CONBLNAMTx: numberHelper.toDecimalOrZero(CONBLNAMTx),
                    SUBSDYAMTx: numberHelper.toDecimalOrZero(SUBSDYAMTx),
                    TRMSTEPUPx: numberHelper.toDecimalOrZero(TRMSTEPUPx),
                    ROUND_UPx: numberHelper.toDecimalOrZero(ROUND_UPx),
                    ROUND_FACTORx: numberHelper.toDecimalOrZero(ROUND_FACTORx),
                    INS_EQUAx: mlsStringUtils.toStringOrEmpty(INS_EQUAx),
                    LND_RoundUP: numberHelper.toDecimalOrZero(LND_RoundUP),
                    LND_RoundFactor: numberHelper.toDecimalOrZero(LND_RoundFactor)
                }
            }).then(function (response)
            { 
                defered.resolve(response);
            }, function (response)
            {
                defered.reject('error occur from server');
            });

        })

        return defered.promise;

    }

    return service;

}]);