﻿appComponents.factory('districtDataSvc', ['$http', 'mlsUrlSvc', 'mlsStringUtils', '$cacheFactory',
function ($http, mlsUrlSvc, mlsStringUtils, $cacheFactory)
{
    var districtDataSvc = {
        getDistrictByName: function (criteria)
        {
            var promise = $http({
                method: 'GET',
                url: '/mls.services/api/DistrictService/GetDistrictByName', 
                params: {
                    districtName: mlsStringUtils.toStringOrEmpty(criteria.districtName)
                },
                cache : true
            }).then(function successCallback(response)
            { 
                return response.data;
            },
            function errorCallback(response)
            {
                return response
            });

            return promise;
        }
    }
    return districtDataSvc;

}]);