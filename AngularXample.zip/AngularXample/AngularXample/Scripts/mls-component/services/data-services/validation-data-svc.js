﻿appComponents.factory('validationDataSvc', ['httpHelper', 'mlsUrlSvc', 'mlsStringUtils', 'accountDataSvc',
function (httpHelper, mlsUrlSvc, mlsStringUtils,accountDataSvc)
{
    var service = {}

    service.getFieldValidation = function (arrValidateID)
    { 
        return httpHelper.post({
            url: mlsUrlSvc.getApiUrlContent('/ValidationServices/GetFieldValidation'),
            params: arrValidateID
        })
         
    }


    service.getContractAutoRejectResult = function (contractDetail)
    {
        return httpHelper.post({
            url: mlsUrlSvc.getApiUrlContent('/ValidationServices/GetContractAutoRejectResult'),
            params: JSON.stringify(contractDetail)
        })

    }

    service.checkAccountExistsBeforeGen = function (criteria)
    { 
      return  accountDataSvc.checkAccountExistsBeforeGen(criteria, { async: false }) 
    }

 

    return service;

}]);