﻿appComponents.factory('mlsLanguage', ['$http', 'componentContext', '$q', '$timeout', 'mlsUrlSvc', function ($http, componentContext, $q, $timeout, mlsUrlSvc)
{
    var mlsLang = { 
        GetSysLanguage : function()
        { 
            var promise = $http({
                method: 'GET',
                //url: componentContext.rootUrl + '/mls.services/api/UIServices/GetSysLanguageList/',
                url: mlsUrlSvc.getApiUrlContent("/UIServices/GetSysLanguageList") 
            }).then(function successCallback(response)
            { 
                return response.data;
            },
           function errorCallback(response)
           {
               throw JSON.stringify(response)
           });
             
            return promise;
        },
        GetSysLanguage2: function ()
        { 
            return ["x","y"];
        }, 
        //GetSysLanguage: function ()
        //{ 
        //    var deferred = $q.defer();
        //    $http({
        //        method: 'GET',
        //        url: componentContext.rootUrl + '/mls.services/api/UIServices/GetSysLanguageList/',
        //    }).then(function (data)
        //    {
        //        deferred.resolve(data);
        //    },
        //   function (error)
        //   {
        //       deferred.reject(error);
        //   });

        //    return deferred.promise;
        //}
    }

    return mlsLang;

}]);