﻿appComponents.factory('uiGridHelper', [
    function () {
        var services = {}

        services.sortNumberFn = function (a, b)
        {
            if (isNaN(a) || isNaN(b))
            {
                return 0;
            }

            if (parseFloat(a) >= parseFloat(b)) {
                return 1;
            }
            else {
                return -1
            } 
        }

        return services;

    }]);