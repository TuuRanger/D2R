﻿appComponents.factory('locationHelper', ['$location',
function ($location)
{
    var service = {}

    service.path = function (path)
    {
        if ($location.$$search)
        {
            delete $location.$$search
        }
        $location.path(path);
    }
    
    return service;

}]);
