﻿appComponents.factory('numberHelper', ['$filter', function ($filter)
{
    var service = {};

    service.toDecimalOrZero = function(val)
    {
        if (!val)
            return 0;
        if (isNaN(val))
            return 0;
        return parseFloat(val);
    }

    return service;

}]);