﻿appComponents.factory('mlsControlSvc', ['$http', 'componentContext', '$q', '$timeout', function ($http, componentContext, $q, $timeout)
{
    var mlsControlSvc = { 
        InputClass : "form-control"
    }

    mlsControlSvc.alighLabelToCenter = function (inputSelector, labelSelector)
    {
        var labelHeight = $(labelSelector).height();
        var inputHeight = $(inputSelector).height();
        $(labelSelector).css("margin-top", (Math.abs(inputHeight + labelHeight) / 5))
    }

    return mlsControlSvc;

}]);