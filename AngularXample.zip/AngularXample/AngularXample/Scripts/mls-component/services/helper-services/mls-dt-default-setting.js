﻿appComponents.factory('mlsDtDefaultSetting',
['DTColumnDefBuilder','DTOptionsBuilder',
function (DTColumnDefBuilder,DTOptionsBuilder)
{
    var mlsDtDefaultSetting = {
        getDefaultOption: function ()
        {
            return DTOptionsBuilder.newOptions()
           .withOption('bFilter', false)
           .withOption('bPaginate', false)
           .withOption('aaSorting', [])
           .withOption('scrollY', '300px')
           .withOption('scrollCollapse', true)
           .withOption('bSortable', false)
           .withDOM('C<"clear">lfrtip')
        },
        getDefaultColumnDef : function(columnCount)
        {
            var arr = [];
            for(var i = 0 ; i < columnCount ; i ++)
            {
                arr.push(DTColumnDefBuilder.newColumnDef(i).notSortable())
            }
            return arr  
        }

    }

    return mlsDtDefaultSetting;

}]);