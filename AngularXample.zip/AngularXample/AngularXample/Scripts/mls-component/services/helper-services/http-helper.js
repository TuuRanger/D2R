﻿appComponents.factory('httpHelper', ['$http', 'mlsStringUtils', 'mainAppContext','mlsExceptionDialog','$q',
function ($http, mlsStringUtils, mainAppContext,mlsExceptionDialog,$q)
{
    var service = {}

    var callHttp = function (params)
    {
        var defered = $q.defer();
        var promise = $http({
            method: params.method,
            url: params.url,
            params: params.params,
            async: params.async || true,
        }).then(function successCallback(response)
        {
            defered.resolve(response.data) 
        },
       function errorCallback(response)
       { 
           mlsExceptionDialog.show({
               exceptionObject: response.data
           })
           defered.reject(response) 
       });
        return defered.promise;
    }
    
    service.get = function (params)
    {
        params.method = 'GET';
        return callHttp(params)
    }

    //service.post = function (params)
    //{
    //    params.method = 'POST';
    //    $http.post
    
    //    return callHttp(params)
    //}

    service.post = function (params)
    {
        params.config = params.config || {}; 
        params.config.headers = $.extend({ 'Content-Type': 'application/json' }, params.config.headers);
        var defered = $q.defer();
        $http.post(
              params.url,
              params.params,
              params.config)
              .then(function (response)
              {  
                  defered.resolve(response.data);
              }
              , function (response)
              { 
                  var contenType = response.headers()['content-type'];

                  mlsExceptionDialog.show({
                      exceptionObject: response.data,
                      contenType: contenType
                  })
                  defered.reject(response); 
              });
        return defered.promise;
    }

    return service;

}]);
