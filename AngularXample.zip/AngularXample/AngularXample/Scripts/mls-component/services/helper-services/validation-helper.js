﻿appComponents.factory('validationHelper', ['$http', 'componentContext', '$q', '$timeout', 'mainAppContext', 'mlsStringUtils','validationDataSvc','httpHelper',
    function ($http, componentContext, $q, $timeout, mainAppContext, mlsStringUtils, validationDataSvc,httpHelper)
{
    var validationHelper = {}

    validationHelper.parseValidateConition = function (rule, rule_val, messageCode, selector)
    {
        eval("var statement = " + rule_val);

        var leftFieldLabelText = "";
        var rightFieldLabelText = "";
        

        if (selector[0] == "#")
        {
            leftFieldLabelText = $("#labelText_lb_" + selector.replace("#", "")).text().trim();
        }

        if (typeof statement == "string" && statement[0] == "#") {
            rightFieldLabelText = $("#labelText_lb_" + statement.replace("#", "")).text().trim();
        } 
        else if (typeof statement == "object" && rule == 'remote') {
            
            //httpHelper.callHttp({
            //    method: statement.type,
            //    params: statement.data
            //}).then(function ()
            //{

            //})
            //rightFieldLabelText = "";
        }

        //if (rule == "lessThanOrEqual")
        //{
        //    debugger
        //}

        var validateMessage = mainAppContext.getValidateMessage(messageCode);
     
        var item = {};
        item[rule] = statement;
        item['messages'] = item['messages'] || {};
        if (validateMessage.Message)
        {
            item['messages'][rule] = mainAppContext.getValidateMessage(messageCode).Message.replace('{0}', '"<strong class="text-danger">' + leftFieldLabelText + '</strong>"').replace('{1}', '"<strong class="text-danger">' + rightFieldLabelText + '</strong>"');
        }
 
         
        return item;
    }

    validationHelper.parseValidationList = function (form, validationList)
    {
        form.removeData('validator');
        form.removeData('$formController');
        form.validate();
        var skipRemoveClassRules = ['creditcard',
                                    'date',
                                    'dateISO',
                                    'digits',
                                    'email',
                                    'number',
                                    'required',
                                    'url'] /*Initial class rules*/

        angular.forEach(angular.copy(jQuery.validator.classRuleSettings), function (key, classRule) {
            if (!skipRemoveClassRules.includes(classRule)) { /*if classRule not in array then remove*/
                delete jQuery.validator.classRuleSettings[classRule];
            }
        });

       
        for (var i = 0; i < validationList.length; i++)
        {
            var item = validationList[i];
       
            var validationRule = validationHelper.parseValidateConition(item.RULE_NAME, item.RULE_VALUE, item.MESSAGE_CD, item.SELECTOR);

            if (item.SELECTOR[0] == "#")
            {
                var element = $(item.SELECTOR);
                var fieldID = item.SELECTOR.replace('#', '');
                 
                element.rules("add", validationRule);
                element.valid();

                if (element.prop("tagName") == 'SELECT')
                {
                    element.bind('change', function ()
                    {
                        $(this).valid();
                    })
                }

                if (item.RULE_NAME == 'required')
                {
                     
                    if ($("#lb_" + fieldID).text().trim() != "") /*id label is empty text*/
                    {
                        $("#prefix_lb_" + fieldID).text("* ");
                    }
                    /*add * to label of field*/
                }
            }
            else if(item.SELECTOR[0] == ".")
            {
                //jQuery.validator.addClassRules("refPerson-field-1", {
                //    required: true
                //});
                var inputClass = item.SELECTOR.replace('.', '');
                var rule = {};
                rule[item.RULE_NAME] = validationRule[item.RULE_NAME];
                jQuery.validator.addClassRules(inputClass, rule);
                var inputList = $('input.' + inputClass + ',textarea.' + inputClass + ',select.' + inputClass); 
                  
                $.each(inputList, function (index, val)
                {  
                    var element = $(val);
                    var fieldID = element.hasClass('autocomplete-control') ? element.attr('id').replace('_value', '') : element.attr('id');
                    if (item.RULE_NAME == 'required')
                    {
                        if (!mlsStringUtils.isStringEmpty($("#lb_" + fieldID).text())) /*id label is empty text*/
                        {
                            $("#prefix_lb_" + fieldID).text("* ");
                        } 
                        /*add * to label of field*/
                    }

                    element.valid()

                    if (element.prop("tagName") == 'SELECT')
                    {
                        element.bind('change', function ()
                        {
                            $(this).valid()
                        })
                    }
                });
               
            }
             
            //angular.forEach(item.Condition, function (value, key)
            //{
            //    var condition = validationHelper.parseValidateConition(key, value, item.Message[key]); 
            //    $("#" + item.FIELD_ID).rules("add", condition);
            //});
        }
    }


    validationHelper.isEquals = function (val1, val2)
    {
        return val1 == val2;
    }
    
    validationHelper.IsRequiredCheckedNCB = function ()
    {
        var flgCheckNCB = $("#hddflgCheckNCB").val() ;
        
        if (flgCheckNCB)
            return false;
        else
            return true;
    }

    validationHelper.processValidation = function (validationList,formElement)
    {
        var defered = $q.defer();
        validationDataSvc.getFieldValidation(validationList).then(function (response) {
            $timeout(function () {
                var fieldList = response;
                var from = formElement
                var invalidFields = [];
                validationHelper.parseValidationList(from, fieldList);

                var isValid = from.valid();
                var elementList = from.validate().errorList;


                for (var i = 0 ; i < elementList.length ; i++) {
                    var ele = elementList[i].element;
                    var fieldLabelText = null;
                    if (angular.element("#" + ele.id).hasClass('autocomplete-control')) // auto complete
                    {
                        fieldLabelText = angular.element("#labelText_lb_" + ele.id.replace("_value", "")).text().replace(/(?:\r\n|\r|\n)/g, '').trim();
                    }
                    else {
                        fieldLabelText = angular.element("#labelText_lb_" + ele.id).text().replace(/(?:\r\n|\r|\n)/g, '').trim();
                    }


                    if (!mlsStringUtils.isStringEmpty(fieldLabelText)) {
                        invalidFields.push(fieldLabelText);
                    }
                    else {
                        console.log(ele.id + "Not have field label text");
                    }

                    console.log("Invalid : " + fieldLabelText);
                }

                for (var i = 0 ; i < elementList.length ; i++) {
                    var ele = elementList[i].element; 
                }

                defered.resolve({
                    isValid: isValid,
                    elementList: elementList,
                    invalidFields: invalidFields
                })
            });
        })
        return defered.promise;
    }
    
    return validationHelper;

}]);