﻿appComponents.factory('arrayHelper', [
function ()
{
    var service = {} 
    service.where = function (array,option)
    { 
        var result = array;
        for (var i = 0 ; i < option.length ; i++)
        { 
            result = result.filter(function (item)
            { 
                for (var prop in option[i])
                { 
                    return item[prop] == option[i][prop]
                }
                 
            })

            if (result.length > 0)
                continue
            else
                break;
        }

        if (result.length > 0)
        {
            return result
        }
        else
        {
            if (array.length > 0)
            {
                var emtypObj = {}
                for (var prop in array[0])
                {
                    if (array[0].hasOwnProperty(prop))
                    {
                        emtypObj[prop] = null;
                    }
                }

                return emtypObj
            }
            return {} 
        }
    }
     
    return service;

}]);
