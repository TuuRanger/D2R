﻿appComponents.factory('mlsStringUtils', ['$filter', function ($filter)
{
    var mlsStringUtils = {
        unformatTel: function (value)
        {
            return (value || "").toString().replace(new RegExp('-', 'g'), '')
        },
        toTelFormat: function (value)
        {
            value = mlsStringUtils.unformatTel(value);
            if (value.length == 9)
            {
                if (!value)
                    return null
                /*021234567*/
                value = value.substring(0, 2) + '-' + value.substring(2, 5) + '-' + value.substring(5, 9)
            }
            else if (value.length == 10)
            {
                if (!value)
                    return null
                /*0891234567*/
                value = value.substring(0, 3) + '-' + value.substring(3, 6) + '-' + value.substring(6, 10)
            }
            return value
        },
        unformatMoney: function (value)
        {
            if (!value)
                return
            return parseFloat((value || "").toString().replace(/[^0-9\.]+/g, ""))
        },
        toMoneyFormat: function (value, decimalPlace)
        {
            if (!value)
                return
            return $filter('number')(mlsStringUtils.unformatMoney(value), decimalPlace)
        },
        toStringOrEmpty: function (str)
        {
            if (parseFloat(str) === 0)
                return 0
            if (!str)
            {
                return ""
            }
            return str
        },
        isStringEmpty: function (str)
        {
            return !str;
        }
    }

    return mlsStringUtils;

}]);