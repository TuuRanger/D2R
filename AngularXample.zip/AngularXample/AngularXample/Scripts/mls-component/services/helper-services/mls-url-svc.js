﻿appComponents.service('mlsUrlSvc', ['$filter', 'mainAppContext', function ($filter, mainAppContext)
{
    var mlsUrlSvc = {
        siteUrl: location.protocol + '//' + location.host + location.pathname,
        apiUrl: location.protocol + '//' + location.host + mainAppContext.mlsApiUrl,
        getUrlContent: function (url)
        {
            return this.siteUrl + url;
        },
        getApiUrlContent: function (url)
        { 
            return this.apiUrl + url;
        },
    }

    return mlsUrlSvc
   
}]);
