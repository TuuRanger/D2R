﻿appComponents.constant('eBiz', {
    CONOBJCOD: {
        PersonalLoan: "01",
        Collaborate: "11",
        HirePurchase : "H1"
    },
    ACCBUSTYP: {
        InstallmentLoan: "2050",
        InstallmentLoanSw: "2060",
        HirePurchase: "2010",
    },
    TEL_LOG_TYPE: {
        HOME: "H",
        OFFICE: "O",
        RELATIVE: "R",
        FAMILY: "F",
        MOBILE : "M"
    },
    CUSTYPCOD:
    {
        JuristicPerson: "01",
        NaturalPerson: "02", 
    },
    InstallmentRoundBy:
    {
        PROJECT: "PROJECT",
        PRODUCT: "PRODUCT"
    },
    SECTION : 
    {
        DebtManager : "DEBMGN"
    },
    CRDRSLSTP : 
    {
        Approve: "Y",
        Reject: "N",
        Cancel: "C",
        SendBack: "SB"
    },
    FollowUpStatus:
    { 
        UnAssigned: '1',
        Assigned: '2',
        FailAppointment: '5',
        Broke: '7',
        Appointment: '8',
        Close: '9',
    },
    ACCDEAWTH:
    {
        Customer: 'CUS',
        Dealer: 'DLR',
        Marketing: 'MKT',
        Insurance: 'INS',
        Receiver: 'RCV',
        Subsidy: 'SDY',
        Verifier: 'VER',
    }

});
