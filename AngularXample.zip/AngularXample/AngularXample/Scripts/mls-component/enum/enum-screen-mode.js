﻿appComponents.constant('eScreenMode', {
    ADD: 'ADD',
    EDIT: 'EDIT',
    VIEW: 'VIEW'
});


appComponents.constant('eScreenPurpose', {
    VERIFY: 'VERIFY',
    ENTRY: 'ENTRY',
    VIEW: 'VIEW',
    APPROVAL: 'APPROVAL',
});