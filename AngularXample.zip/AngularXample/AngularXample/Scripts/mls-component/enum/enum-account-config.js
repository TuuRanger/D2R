﻿appComponents.constant('eAccountConfig', {
    ShowRefType: {
        NONE: "NON",
        BOTH: "BOT",
        GUARANTOR: "GUA",
        REFERENCE_PERSON: "REF",

    }
});
