﻿appComponents.directive('mlsComboBox', function ()
{
    return {
        scope: {
            "idName": '@idName'
            , 'ngModel': '='
            , "mlsDisplayMembers": "@mlsDisplayMembers"
            , "mlsValueMembers": "@mlsValueMembers"
            , "mlsPlaceHolder": "@mlsPlaceHolder"
            , "mlsFilter": "@mlsFilter"
            , "mlsAutoBind": "@mlsAutoBind"
            , "mlsMinLenght": "@mlsMinLenght"
            , "mlsDataSource": "="
            , "mlsInputClass": "@mlsInputClass"
            //, "mlsInputStyle": "@mlsInputStyle" // not support because reder wrong
            , "onChange": "&"
            , "gridCell": "@gridCell"

        },
        template: function (elem, attr)
        {
            return ' <select ' +
                            ' id="{{idName}}"' +
                            ' name="{{idName}}"' +
                            ' kendo-combo-box' +
                            ' k-data-source="{{mlsDataSource}}"' +
                            ' k-data-value-field="\'{{mlsValueMembers}}\'"' +
                            ' k-data-text-field="\'{{mlsDisplayMembers}}\'"' +
                            ' ng-model="ngModel"' +
                            ' k-min-lenght="{{mlsMinLenght == null ? 3 : mlsMinLenght}}"' +
                            ' k-auto-bind="{{mlsAutoBind == null ? false : mlsAutoBind}}"' +
                            ' k-placeholder="\'{{mlsPlaceHolder == null ? \'Nothing Select\' : mlsPlaceHolder}}\'"' +
                            ' k-filter="\'{{mlsFilter == null ? contains : mlsFilter}}\'"' +
                            ' style="width:100%" ' +
                            ' class="{{mlsInputClass}}" ' +
                            ' k-on-change="onChange()" ' +
                ' > ' + 
                  '</select>'
        },
        link: function (scope, wraperElement, attrs, ctrl)
        {
            var inputElement = angular.element(wraperElement.find('select')[0]);
            
            scope.initialElement = function ()
            {
                //dataSource.data
            }

            scope.clearValue = function ()
            {
                inputElement.data('kendoComboBox').value(null);
                attrs.ngModel = null
                scope.ngModel = null;
            }

            scope.$watch('ngModel', function (newVal, oldVal, scope)
            {
                var dataSource = scope.mlsDataSource;
 
                if (dataSource && dataSource.data && newVal) {
                    var result = dataSource.data.filter(function (item)
                    {
                        return item[scope.mlsValueMembers] == newVal
                    }) 
                    if (result.length == 0) {
                        scope.clearValue();
                    }
                    else
                    {
                        inputElement.data('kendoComboBox').value(newVal);
                    }
                }
                else {
                    scope.clearValue();
                }
            })

        }

    };
});