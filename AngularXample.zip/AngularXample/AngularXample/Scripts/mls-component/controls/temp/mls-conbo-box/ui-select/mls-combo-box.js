﻿appComponents.directive('mlsComboBox', ['mlsUrlSvc', '$timeout', function (mlsUrlSvc, $timeout)
{
    return {
        scope: {
            "idName": '@idName'
            , 'ngModel': '='
            , "mlsDisplayMembers": "@mlsDisplayMembers"
            , "mlsValueMembers": "@mlsValueMembers"
            , "mlsPlaceHolder": "@mlsPlaceHolder"
            , "mlsFilter": "@mlsFilter"
            , "mlsAutoBind": "@mlsAutoBind"
            , "mlsMinLenght": "@mlsMinLenght"
            , "mlsDataSource": "="
            , "mlsInputClass": "@mlsInputClass" 
            ,"ngChange": "&"
            ,"options" : "="

        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/template/combobox_template_ui-select.html"),
       

    };
}]);