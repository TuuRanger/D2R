﻿appComponents.directive('mlsComboBoxWithLabel', function ()
{
    return {
        scope: {
            "idName": '@idName'
            , 'ngModel': '='
            , "mlsDisplayMembers": "@mlsDisplayMembers"
            , "mlsValueMembers": "@mlsValueMembers"
            , "mlsPlaceHolder": "@mlsPlaceHolder" 
            , "mlsDataSource": "="
            , "mlsLabelText": "="
            , "mlsInputContainerClass": "@mlsInputContainerClass"
            , "mlsInputContainerStyle": "@mlsInputContainerStyle"
            , "mlsLabelContainerStyle": "@mlsLabelContainerStyle"
            , "mlsLabelContainerClass": "@mlsLabelContainerClass"
            , "mlsContainerStyle": "@mlsContainerStyle"
            , "mlsContainerClass": "@mlsContainerClass"
            , "mlsLabelClass": "@mlsLabelClass"
            , "mlsLabelStyle": "@mlsLabelStyle"
            , "mlsInputClass": "@mlsInputClass"
            , "mlsInputStyle": "@mlsInputStyle"
            , "onChange": "&"
            , "options":"="
        },
        template: function ()
        {
            return ' <div name="div_{{idName}}_container" id="div_{{idName}}_container" style="{{mlsContainerStyle}} ;padding-top:10px" class="{{mlsContainerClass == null ? \'col-lg-4\' : mlsContainerClass}}">' +
                        '<div style="{{mlsLabelContainerStyle}}" class="{{mlsLabelContainerClass == null ?   \'col-lg-4\' : mlsLabelContainerClass}}">' +
                                 '<mls-label  mls-label-text="!mlsLabelText[idName] ? mlsLabelText : mlsLabelText[idName]"' +
                                        'mls-label-class="{{mlsLabelClass}}"' +
                                        'mls-label-style="{{mlsLabelStyle}}"' +
                                        'id-name="lb_{{idName}}"' +
                                        '></mls-label>' +
                       ' </div>' +
                       ' <div style="{{mlsInputContainerStyle}}" class="{{mlsInputContainerClass == null ? \'col-lg-6\' : mlsInputContainerClass}}">' +
                            ' <mls-combo-box' +
                                     ' ng-model="ngModel"'+
                                     ' mls-display-members="{{mlsDisplayMembers}}"'+
                                     ' mls-value-members="{{mlsValueMembers}}"'+
                                     ' mls-data-source="mlsDataSource"' +
                                     ' ng-change="ngChange()"' +
                                     ' options="options" ' +
                                    ' >'+ 
                            ' </mls-combo-box>' +
                        '</div>' +
                    '</div>'
        }
    };
});

 