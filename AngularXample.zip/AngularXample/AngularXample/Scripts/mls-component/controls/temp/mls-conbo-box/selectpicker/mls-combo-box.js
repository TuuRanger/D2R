﻿appComponents.directive('mlsComboBox', ['mlsUrlSvc', '$timeout', function (mlsUrlSvc, $timeout)
{
    return {
        scope: {
            "idName": '@idName'
            , 'ngModel': '='
            , "mlsDisplayMembers": "@mlsDisplayMembers"
            , "mlsValueMembers": "@mlsValueMembers"
            , "mlsPlaceHolder": "@mlsPlaceHolder"
            , "mlsFilter": "@mlsFilter"
            , "mlsAutoBind": "@mlsAutoBind"
            , "mlsMinLenght": "@mlsMinLenght"
            , "mlsDataSource": "="
            , "mlsInputClass": "@mlsInputClass"
            //, "mlsInputStyle": "@mlsInputStyle" // not support because reder wrong
            , "ngChange": "&"

        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/template/combobox_template.html"),
        link: function (scope, wraperElement, attrs, ctrl)
        { 
            scope.onChange = function (value)
            { 
                $timeout(scope.ngChange, 0);
            };

        }

    };
}]);