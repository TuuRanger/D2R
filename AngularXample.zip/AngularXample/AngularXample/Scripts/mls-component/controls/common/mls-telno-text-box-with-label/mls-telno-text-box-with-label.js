﻿appComponents.directive('mlsTelTextBoxWithLabel', ['mlsUrlSvc',function (mlsUrlSvc)
{
    return {
        restrict: "E",
        scope: {
              "idName": '@idName'
            , "type": '@type'
            , 'ngModel': '='
            , 'objectModel' : '='
            , 'ngChange': '&'
            , "mlsLabelText": "="
            , "mlsInputContainerClass": "@mlsInputContainerClass"
            , "mlsInputContainerStyle": "@mlsInputContainerStyle"
            , "mlsLabelContainerStyle": "@mlsLabelContainerStyle"
            , "mlsLabelContainerClass": "@mlsLabelContainerClass"
            , "mlsContainerStyle": "@mlsContainerStyle"
            , "mlsContainerClass": "@mlsContainerClass"
            , "mlsLabelClass": "@mlsLabelClass"
            , "mlsLabelStyle": "@mlsLabelStyle"
            , "mlsInputClass": "@mlsInputClass"
            , "mlsInputStyle": "@mlsInputStyle"
            , "mlsDecimalPlace": "@mlsDecimalPlace"
            , "mlsMinDate": "@mlsMinDate"
            , "mlsMaxDate": "@mlsMaxDate"
            , "mlsDateDisplayFormat": "@mlsDateDisplayFormat"
            , "mlsDateModelFormat": "@mlsDateModelFormat"
            , "mlsMaskedText": "@mlsMaskedText"
            , "mlsEnabledMaskedText": "@mlsEnabledMaskedText"
            , "mlsInputAddonFront": "="
            , "mlsInputAddonBack": "="
            , "ngReadonly": "="
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-telno-text-box-with-label/template/mls-telno-text-box-with-label.html"),

    };
}]);
