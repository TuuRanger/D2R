﻿appComponents.directive('mlsComboBox', ['mlsUrlSvc', '$timeout', function (mlsUrlSvc, $timeout)
{
    return {
        scope: {
            "idName": '@idName'
            , 'ngModel': '='
            , "mlsDisplayMembers": "@mlsDisplayMembers"
            , "mlsValueMembers": "@mlsValueMembers"
            , "mlsPlaceHolder": "@mlsPlaceHolder"
            , "mlsFilter": "@mlsFilter"
            , "mlsAutoBind": "@mlsAutoBind"
            , "mlsMinLenght": "@mlsMinLenght"
            , "mlsDataSource": "="
            , "mlsInputClass": "@mlsInputClass"
            , "ngReadonly": "="
            , "ngChange": "&"
            , "options" : "="

        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-combo-box/template/mls-combo-box-select2.html"),
        //templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-combo-box/template/mls-combo-box-kendo.html"),
        link: function (scope, wraperElement, attrs, ctrl)
        {
            
            //$timeout(function ()
            //{
            //    scope.$watch('ngModel',function (newVal,oldVal,scope)
            //    { 
            //        if (typeof $("#" + attrs.idName).valid == "function" && (attrs.idName))
            //        { 
            //            $("#" + attrs.idName).valid()
            //        }
            //    }) 
            //})
            
        }

    };
}]);