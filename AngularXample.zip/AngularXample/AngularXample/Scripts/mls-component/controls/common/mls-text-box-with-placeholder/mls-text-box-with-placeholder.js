﻿
appComponents.directive('mlsTextBoxWithPlaceHolder',[ 'mlsUrlSvc',function (mlsUrlSvc)
{
    return {
        restrict: "E",
        scope: {
            "idName": '@idName'
            , "type": '@type'
            , 'ngModel': '='
            , 'ngChange': '&' 
            , "mlsInputContainerClass": "@mlsInputContainerClass"
            , "mlsInputContainerStyle": "@mlsInputContainerStyle" 
            , "mlsContainerStyle": "@mlsContainerStyle"
            , "mlsContainerClass": "@mlsContainerClass"
            , "mlsLabelClass": "@mlsLabelClass"
            , "mlsLabelStyle": "@mlsLabelStyle"
            , "mlsInputClass": "@mlsInputClass"
            , "mlsInputStyle": "@mlsInputStyle"
            , "mlsDecimalPlace": "@mlsDecimalPlace"
            , "mlsMinDate": "@mlsMinDate"
            , "mlsMaxDate": "@mlsMaxDate"
            , "mlsDateDisplayFormat": "@mlsDateDisplayFormat"
            , "mlsDateModelFormat": "@mlsDateModelFormat"
            , "mlsMaskedText": "@mlsMaskedText"
            , "mlsEnabledMaskedText": "@mlsEnabledMaskedText"
            , "ngReadonly": "="
            , "mlsPlaceHolderText": "="
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-text-box-with-placeholder/template/mls-text-box-with-placeholder.html")

    };
}]);
