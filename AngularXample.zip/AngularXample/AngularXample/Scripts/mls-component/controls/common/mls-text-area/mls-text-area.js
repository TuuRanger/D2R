﻿appComponents.directive('mlsTextArea', ['mlsUrlSvc', 'mlsControlSvc', '$timeout',
    function (mlsUrlSvc, mlsControlSvc, $timeout)
{
    return {
        restrict: "E",
        scope: {
            "idName": '@idName', 
            'ngModel': '=',
            'ngChange': '&',
            "mlsInputClass": "@mlsInputClass",
            "mlsInputStyle": "@mlsInputStyle",
            "ngReadonly": "=",  
            "mlsPlaceHolderText": "@mlsPlaceHolderText",
            "rows": "@rows",
            "cols": "@cols"
        },
        require: 'ngModel',
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-text-area/template/mls-text-area.html"),
        link: function (scope, wraperElement, attrs, ctrl)
        {
            var inputElement = angular.element(wraperElement.find('textarea')[0])
            scope.initialElement = function ()
            { 
                inputElement.addClass(attrs.mlsInputClass)
                inputElement.addClass(mlsControlSvc.InputClass);
                inputElement.attr('style', attrs.mlsInputStyle)
                //$timeout(function ()
                //{
                //    scope.$watch('ngModel', function (newVal, oldVal, scope)
                //    {
                //        if (typeof $("#" + attrs.idName).valid == "function")
                //        {
                //            $("#" + attrs.idName).valid()
                //        }
                //    })
                //})
            }
            scope.initialElement();


        },
    };
}]);