﻿
appComponents.directive('mlsTextAreaWithLabel', ['mlsUrlSvc',function (mlsUrlSvc)
{
    return {
        restrict: "E",
        scope: {
            "idName": '@idName'
            , "type": '@type'
            , 'ngModel': '='
            , 'ngChange': '&'
            , "mlsLabelText": "="
            , "mlsInputContainerClass": "@mlsInputContainerClass"
            , "mlsInputContainerStyle": "@mlsInputContainerStyle"
            , "mlsLabelContainerStyle": "@mlsLabelContainerStyle"
            , "mlsLabelContainerClass": "@mlsLabelContainerClass"
            , "mlsContainerStyle": "@mlsContainerStyle"
            , "mlsContainerClass": "@mlsContainerClass"
            , "mlsLabelClass": "@mlsLabelClass"
            , "mlsLabelStyle": "@mlsLabelStyle"
            , "mlsInputClass": "@mlsInputClass"
            , "mlsInputStyle": "@mlsInputStyle"
            , "mlsDecimalPlace": "@mlsDecimalPlace"
            , "mlsMinDate": "@mlsMinDate"
            , "mlsMaxDate": "@mlsMaxDate"
            , "mlsDateDisplayFormat": "@mlsDateDisplayFormat"
            , "mlsDateModelFormat": "@mlsDateModelFormat"
            , "mlsMaskedText": "@mlsMaskedText"
            , "mlsEnabledMaskedText": "@mlsEnabledMaskedText"
            , "ngReadonly": "="
            ,"rows": "@rows"
            ,"cols": "@cols"
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-text-area-with-label/template/mls-text-area-with-label.html")

    };
}]);
