﻿appComponents.directive('mlsDateTimePicker', ['mlsUrlSvc', 'mlsRegExp', 'mlsDateUtils',
    function (mlsUrlSvc, mlsRegExp, mlsDateUtils)
{
    return {
        restrict: "E",
        scope: {
            "idName": '@idName',
            'objectModel': '=',
            'format': '=',
            'ngReadonly': '=',
            'ismeridian':'='
        }, 
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-date-time-picker/template/mls-date-time-picker.html"),
        link: function (scope, wraperElement, attrs, ctrl)
        { 
            
            scope.$watch("kNgModel", function (newVal, oldVal)
            {
                if(newVal)
                {
                    scope.objectModel = newVal.toISODateString();
                    scope.timeModel = newVal;
                    console.log(scope.objectModel)
                }  
            })

            scope.$watch("timeModel", function (newVal, oldVal) {
                 
                if (newVal && (!scope.ngReadonly))
                {
                    newVal.setSeconds(0)
                    scope.kNgModel = newVal;
                }
            })


            scope.$watch("objectModel", function (newVal, oldVal)
            {
                if(newVal === undefined)
                {
                    newVal = oldVal;
                }

                var dateObject = null;
                if (mlsRegExp.isISODateString(newVal))
                {
                    dateObject = mlsDateUtils.parseIsoDatetime(newVal);
                }
                else
                {
                    dateObject = kendo.parseDate(newVal, scope.format);
                }
                dateObject.setSeconds(0);
                scope.kNgModel = dateObject;

            })
             
        } 
    };
    }]);

 