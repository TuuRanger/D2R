﻿appComponents.directive('mlsDatePicker', ['mlsUrlSvc', 'mlsRegExp', 'mlsDateUtils',
    function (mlsUrlSvc, mlsRegExp, mlsDateUtils)
{
    return {
        restrict: "E",
        scope: {
            "idName": '@idName',
            'objectModel': '=',
            'format': '=',
            'ngReadonly' : '='
        }, 
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-date-picker/template/mls-date-picker.html"), 
        link: function (scope, wraperElement, attrs, ctrl)
        {

            scope.$watch("kNgModel", function (newVal, oldVal)
            {
                if(newVal)
                {
                    scope.objectModel = newVal.toISODateString();
                }  
            })

            scope.$watch("objectModel", function (newVal, oldVal)
            {
                if(newVal === undefined)
                {
                    newVal = oldVal;
                }

                var dateObject = null;
                if (mlsRegExp.isISODateString(newVal))
                {
                    dateObject = mlsDateUtils.parseIsoDatetime(newVal);
                }
                else
                {
                    dateObject = kendo.parseDate(newVal, scope.format);
                }

                scope.kNgModel = dateObject;

            })
             
        } 
    };
    }]);

 