﻿appComponents.directive('mlsRadioButtonGroup', ['mlsUrlSvc',function (mlsUrlSvc)
{
    return { 
        scope: {
              "idName": '@idName'
             , "ngTrueValue": '@ngTrueValue'
             , "ngFalseValue": '@ngFalseValue'
             , "ngModel": '='
             , "mlsDataSource": "="
             , "mlsDisplayMember": "@mlsDisplayMember"
             , "mlsValueMember": "@mlsValueMember"
             
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-radio-button-group/template/mls-radio-button-group.html")

    };
}]);
 