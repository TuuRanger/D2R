﻿appComponents.directive('mlsCheckBox', ['mlsUrlSvc', function (mlsUrlSvc)
{
    return {
        restrict: "E",
        scope: {
              "idName": '@idName'
             , "ngTrueValue": '@ngTrueValue'
             , "ngFalseValue": '@ngFalseValue'
             , "ngModel": '='
             , "mlsCheckBoxLabel": "="
             , "ngReadonly": "="

        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-check-box/template/mls-check-box.html")

    };
}]);
 