﻿appComponents.directive('mlsCheckBoxGroupWithLabel', function ()
{
    return {
        restrict: "E",
        scope: {
             "idName": '@idName'
            , "ngTrueValue": '@ngTrueValue'
            , "ngFalseValue": '@ngFalseValue' 
            , "mlsDisplayMembers": "@mlsDisplayMembers"
            , "mlsValueMembers": "@mlsValueMembers"
            , "mlsPlaceHolder": "@mlsPlaceHolder"
            , "mlsFilter": "@mlsFilter"
            , "mlsAutoBind": "@mlsAutoBind"
            , "mlsMinLenght": "@mlsMinLenght"
            , "mlsDataSource": "="
            , "mlsLabelText": "="
            , "mlsInputContainerClass": "@mlsInputContainerClass"
            , "mlsInputContainerStyle": "@mlsInputContainerStyle"
            , "mlsLabelContainerStyle": "@mlsLabelContainerStyle"
            , "mlsLabelContainerClass": "@mlsLabelContainerClass"
            , "mlsContainerStyle": "@mlsContainerStyle"
            , "mlsContainerClass": "@mlsContainerClass"
            , "mlsLabelClass": "@mlsLabelClass"
            , "mlsLabelStyle": "@mlsLabelStyle"
            , "mlsInputClass": "@mlsInputClass"
            , "mlsInputStyle": "@mlsInputStyle"
            , "onChange": "&"
            , "mlsCheckBoxLabel": "@mlsCheckBoxLabel"
            , "mlsDataSource" : "="
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-check-box-group-with-label/template/mls-check-box-group-with-label.html")
      
    };
});
 