﻿appComponents.directive('mlsNumericTextBox', ['mlsUrlSvc', '$filter', 'mlsRegExp', 'mlsDateUtils','$timeout','mlsControlSvc',
    function (mlsUrlSvc, $filter, mlsRegExp, mlsDateUtils, $timeout, mlsControlSvc)
    {
        return {
            restrict: "E",
            scope: {
                "idName": '@idName', 
                'ngModel': '=',
                'format': '=',
                'decimals': '=',
                'ngReadonly' :'=',
                'mlsInputClass': '@mlsInputClass',
                'mlsInputStyle': '@mlsInputStyle',
                'ngChange': '&'
            },
            templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-numeric-text-box/template/mls-numeric-text-box.html"),
            link: function (scope, wraperElement, attrs, ctrl)
            {
               
                var inputElement = angular.element(wraperElement.find('input')[1])
                

                $timeout(function ()
                {
                     
                    var txtNumeric = inputElement.data("kendoNumericTextBox");
                    if (txtNumeric)
                    {
                        txtNumeric.element.off("keydown")
                    }
                    
                    

                    inputElement.addClass('k-formatted-value  k-input')
                     
                })
            }
        };
    }]);