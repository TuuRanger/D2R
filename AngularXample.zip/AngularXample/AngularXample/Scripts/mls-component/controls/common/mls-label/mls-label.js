﻿appComponents.directive('mlsLabel',['mlsUrlSvc', function (mlsUrlSvc)
{
    return {
        scope: {
              "mlsLabelText": '='
            , "mlsLabelClass": '@mlsLabelClass'
            , "mlsLabelStyle": '@mlsLabelStyle' 
            , "idName" : "@idName"
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-label/template/mls-label.html"),
        replace: true,
        restrict: 'E',
        transclude: true,
        link: function (scope, wraperElement, attrs, ctrl)
        {
             
        }

    };
}]);