﻿appComponents.directive('mlsDateTextBox', ['mlsUrlSvc', '$filter', 'mlsRegExp', 'mlsDateUtils','$timeout',
    function (mlsUrlSvc, $filter, mlsRegExp, mlsDateUtils, $timeout)
    {
        return {
            restrict: "E",
            scope: {
                "idName": '@idName',
                'objectModel': '=',
                'ngModel' : '=',
                'format': '=',
                'maskText': '=',
                'mlsInputClass': '@mlsInputClass',
                'mlsInputStyle': '@mlsInputStyle',
                'isBuddhist': '=',
                'ngReadonly': '='
            },
            templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-date-text-box/template/mls-date-text-box.html"),
            link: function (scope, wraperElement, attrs, ctrl)
            {
                var inputElement = angular.element(wraperElement.find('input')[0])

                scope.setViewModelValue = function(viewValue)
                {
                    inputElement.val('');
                    var dateObject = null;
                    var dateDisplay = null; 
                    if (mlsRegExp.isISODateString(viewValue)) /*for first load from database*/
                    {
                        dateObject = mlsDateUtils.parseIsoDatetime(viewValue);
                    }
                    else
                    {
                        dateObject = kendo.parseDate(viewValue, scope.format);
                    }

                    if (dateObject)
                    {
                        dateDisplay = dateObject;
                        if (dateObject.getFullYear() > 2400)
                        {
                            dateObject = new Date(dateObject.getFullYear() - 543, dateObject.getMonth(), dateObject.getDate(), 0, 0, 0, 0)
                        }


                        if (scope.isBuddhist == 'true') /*for Buddhist year*/
                        {
                            dateDisplay = new Date(dateObject.getFullYear() + 543, dateObject.getMonth(), dateObject.getDate(), 0, 0, 0, 0)
                        }

                        $timeout(function ()
                        {
                            inputElement.val($filter('date')(dateDisplay, scope.format, null));
                        })

                    }

                    //scope.objectModel = dateObject;
                    if (dateObject)
                    {
                        scope.objectModel = dateObject.toISODateString();
                        console.log(scope.objectModel);
                    }
                    else
                    {
                        scope.objectModel = null;
                    }
                    
                }

                scope.$watch('objectModel', function (newVal, oldVal, scope)
                {
                    //if (attrs.idName == 'txtPSNBTHDTE')
                    //{
                    //    debugger
                    //}

                    scope.setViewModelValue(newVal)


                })
                 


                inputElement.bind('change', function () /*for change text if isBuddhist*/
                { 
                    scope.setViewModelValue(scope.ngModel);
                })

             

                 
            }
        };
    }]);