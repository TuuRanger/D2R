﻿appComponents.directive('mlsDateTextBoxWithLabel', ['mlsUrlSvc','$timeout','mlsControlSvc',
    function (mlsUrlSvc, $timeout, mlsControlSvc)
    {
        return {
            restrict: "E",
            scope: {
                "idName": '@idName',
                'objectModel': '=',
                'ngModel': '=',
                'format': '=',
                'maskText': '=',
                'mlsLabelText': "=",
                'mlsInputContainerClass': "@mlsInputContainerClass",
                'mlsInputContainerStyle': "@mlsInputContainerStyle",
                'mlsLabelContainerStyle': "@mlsLabelContainerStyle",
                'mlsLabelContainerClass': "@mlsLabelContainerClass",
                'mlsContainerStyle': "@mlsContainerStyle",
                'mlsContainerClass': "@mlsContainerClass",
                'mlsLabelClass': "@mlsLabelClass",
                'mlsLabelStyle': "@mlsLabelStyle",
                'mlsInputClass': "@mlsInputClass",
                'mlsInputStyle': "@mlsInputStyle",
                'mlsDecimalPlace': "@mlsDecimalPlace",
                'mlsMinDate': "@mlsMinDate",
                'mlsMaxDate': "@mlsMaxDate",
                'mlsDateDisplayFormat': "@mlsDateDisplayFormat",
                'mlsDateModelFormat': "@mlsDateModelFormat",
                'mlsMaskedText': "@mlsMaskedText",
                'mlsEnabledMaskedText': "@mlsEnabledMaskedText",
                'mlsInputAddonFront': "=",
                'mlsInputAddonBack': "=",
                'ngReadonly': "=",
                'isBuddhist': "=",
                'ngReadonly' : '='
            },
            templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-date-text-box-with-label/template/mls-date-text-box-with-label.html"),
            link: function (scope, wraperElement, attrs, ctrl)
            {
                $timeout(function ()
                {
                    mlsControlSvc.alighLabelToCenter("#" + attrs.idName, "#lb_" + attrs.idName)
                })
            }
        };
    }]);