﻿appComponents.directive('mlsTextBox', ['$timeout', '$filter', '$compile', 'mlsRegExp', 'mlsStringUtils', 'mlsRegExp','mlsUrlSvc',
    function ($timeout, $filter, $compile, mlsRegExp, mlsStringUtils, mlsRegExp, mlsUrlSvc)
{
    return {
        restrict: "E",
        terminal: true,
        scope: {
            "idName": '@idName',
            "type": '@type',
            'ngModel': '=',
            'objectModel': '=',
            'ngChange': '&',
            "mlsInputClass": "@mlsInputClass",
            "mlsInputStyle": "@mlsInputStyle",
            "mlsDecimalPlace": "@mlsDecimalPlace",
            "mlsMinDate": "=",
            "mlsMaxDate": "=",
            "mlsDateDisplayFormat": "@mlsDateDisplayFormat",
            "mlsDateModelFormat": "@mlsDateModelFormat",
            "mlsMaskedText": "@mlsMaskedText",
            "mlsEnabledMaskedText": "@mlsEnabledMaskedText",
            "ngReadonly": "=", 
            "required": "@required",
            "mlsPlaceHolderText": "@mlsPlaceHolderText",
            "mlsInputAddonFront": "=",
            "mlsInputAddonBack": "=",
            "wraperHtml": '=',
            "addonFront": "=",
            "addonRear": "=",
            "addonRearClick" : "&"
        },
        require: 'ngModel',
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-text-box/template/mls-text-box.html"),
        link: function (scope, wraperElement, attrs, ctrl)
        {
            var input = wraperElement.find('input')[0];
            
            scope.addonRearClick = scope.addonRearClick();

            $(input).bind('change', function ()
            { 
                $timeout(scope.ngChange, 0);
            })

            if (scope.addonFront || scope.addonRear)
            {
                var wraperAddon = angular.element("<div class='input-group'></div>");
     
                wraperAddon = angular.element(input).wrap(wraperAddon).parent();
                wraperAddon = angular.element(wraperAddon).prepend(scope.addonFront);
                wraperAddon = angular.element(wraperAddon).append(scope.addonRear);
                   
                $compile(wraperAddon.contents())(scope);

            }

            if (scope.wraperHtml)
            { 
                $compile(angular.element(input).wrap(scope.wraperHtml))(scope);
            }
             

        },
    };
}]);