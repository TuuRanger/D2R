﻿appComponents.directive('mlsTelTextBox', ['$timeout', '$filter', '$compile', 'mlsRegExp', 'mlsStringUtils', 'mlsControlSvc', 'mlsRegExp', 'mlsUrlSvc',
    function ($timeout, $filter, $compile, mlsRegExp, mlsStringUtils, mlsControlSvc, mlsRegExp, mlsUrlSvc)
    {
        return {
            restrict: "E",
            scope: {
                "idName": '@idName',
                "type": '@type',
                'ngModel': '=',
                'objectModel': '=',
                'ngChange': '&',
                "mlsInputClass": "@mlsInputClass",
                "mlsInputStyle": "@mlsInputStyle",
                "ngReadonly": "=",
                "required": "@required",
                "mlsPlaceHolderText": "@mlsPlaceHolderText",
                "mlsInputAddonFront": "=",
                "mlsInputAddonBack": "=",
            },
            require: 'ngModel',
            templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-telno-text-box/template/mls-telno-text-box.html"),
            link: function (scope, wraperElement, attrs, ctrl)
            {
                var inputElement = angular.element(wraperElement.find('input')[0])
                var html = ''
                var el = null;
                var decimalPlace = scope.mlsDecimalPlace || 2;
                var i = 0;
                var format = ''
                var keyCtrlDown = false;
                var updating = false;
               

                scope.validateBeforeSet = function ()
                {
                    var value = angular.element(inputElement).val();
                    var obj = scope.getTelViewModel(value);
                    scope.setViewModelValue(obj.viewValue, obj.modelValue);
                }

                scope.setViewModelValue = function (viewValue, modelValue)
                {
                   
                    scope.ngModel = viewValue;
                    $timeout(function ()
                    {
                        inputElement.val(viewValue);
                    })

                    scope.objectModel = modelValue; 
                }

                inputElement.bind('change', function ()
                { 
                    scope.validateBeforeSet(); 
                })

                scope.$watch('objectModel', function (n, o, s)
                { 
                    obj = scope.getTelViewModel(n); 
                    scope.setViewModelValue(obj.viewValue, obj.modelValue);
                }, true)


                scope.$watch('ngModel', function (n, o, s)
                {
                   
                    if (n === undefined) 
                    {
                        /*case load new date from database ,this value maybe undefined
                          because this value is dummy object for complement objectModel,
                          therefore : when it is undefined ,then assign old-value to new-value 
                        */
                        n = o;
                    }
                    obj = scope.getTelViewModel(n);
                    scope.setViewModelValue(obj.viewValue, obj.modelValue);
                }, true)

                scope.initialElement = function ()
                {
                    scope.ngModel = scope.objectModel;

                }

                scope.getTelViewModel = function (value)
                {
                    var viewValue = value;
                    var modelValue = value;
                    if (mlsRegExp.isTelNoFormat(value))
                    {
                        value = mlsStringUtils.unformatTel(value);
                        viewValue = mlsStringUtils.toTelFormat(value);
                        modelValue = value;
                    }
                   

                    var obj =
                    {
                        viewValue: mlsStringUtils.toTelFormat(value),
                        modelValue: value
                    }

                    return obj
                }

                ///************************************************/ 
                inputElement.bind("keydown", function (event)
                {
                    var value = inputElement.val();
                    if (event.which == 17 || event.which == 123 || event.which == 8) // Ctrl
                    {
                        if (event.which == 17)
                        {
                            keyCtrlDown = true;
                            return
                        }
                        return
                    }

                    if (!keyCtrlDown)
                    {
                        if (isNaN(String.fromCharCode(event.which)) && !(event.which >= 96 && event.which <= 105))
                        {
                            event.preventDefault();
                            return
                        }
                    }

                });

                inputElement.bind("paste", function (event)
                {
                    var oldValue = inputElement.val();
                    var pasteData = event.originalEvent.clipboardData.getData('text/plain');
                    var selectionLength = window.getSelection().toString().length

                    if (!mlsRegExp.isTelNoFormat(pasteData))
                    {
                        event.preventDefault();
                    }
                    else if ((pasteData.toString() + oldValue.toString()).length > 10 && selectionLength != oldValue.length)
                    {
                        event.preventDefault();
                    }
                })

                inputElement.bind("keyup", function (event)
                {
                    if (event.which == 17) // Ctrl
                    {
                        keyCtrlDown = false;
                        return
                    }
                });

                inputElement.bind('focusin', function (event)
                {
                    var value = mlsStringUtils.unformatTel(inputElement.val());
                    inputElement.val(value);
                })

                inputElement.bind("focusout", function (event)
                {
                    scope.validateBeforeSet();
                });

                scope.initialElement();
            },
        };
    }]);