﻿appComponents.directive('mlsDatePickerWithLabel',['mlsUrlSvc', function ( mlsUrlSvc)
{
    return {
        restrict: "E",
        scope: {
            "idName": '@idName' 
            , 'objectModel': '='
            , 'ngChange': '&'
            , 'format' : '='
            , "mlsLabelText": "="
            , "mlsInputContainerClass": "@mlsInputContainerClass"
            , "mlsInputContainerStyle": "@mlsInputContainerStyle"
            , "mlsLabelContainerStyle": "@mlsLabelContainerStyle"
            , "mlsLabelContainerClass": "@mlsLabelContainerClass"
            , "mlsContainerStyle": "@mlsContainerStyle"
            , "mlsContainerClass": "@mlsContainerClass"
            , "mlsLabelClass": "@mlsLabelClass"
            , "mlsLabelStyle": "@mlsLabelStyle"
            , "mlsInputClass": "@mlsInputClass"
            , "mlsInputStyle": "@mlsInputStyle"
            , "mlsDecimalPlace": "@mlsDecimalPlace"
            , "mlsMinDate": "@mlsMinDate"
            , "mlsMaxDate": "@mlsMaxDate"
            , "mlsDateDisplayFormat": "@mlsDateDisplayFormat"
            , "mlsDateModelFormat": "@mlsDateModelFormat"
            , "mlsMaskedText": "@mlsMaskedText"
            , "mlsEnabledMaskedText": "@mlsEnabledMaskedText"
            , "mlsInputAddonFront": "="
            , "mlsInputAddonBack": "="
            , "ngReadonly": "="
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-date-picker-with-lable/template/mls-date-picker-with-label.html"),

    };
}]);
