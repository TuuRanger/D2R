﻿


appComponents.directive('mlsComboBoxWithLabel', ['mlsUrlSvc', '$timeout', 'mlsControlSvc', function (mlsUrlSvc, $timeout, mlsControlSvc)
{
    return {
        scope: {
            "idName": '@idName'
            , 'ngModel': '='
            , "mlsDisplayMembers": "@mlsDisplayMembers"
            , "mlsValueMembers": "@mlsValueMembers"
            , "mlsPlaceHolder": "@mlsPlaceHolder" 
            , "mlsDataSource": "="
            , "mlsLabelText": "="
            , "mlsInputContainerClass": "@mlsInputContainerClass"
            , "mlsInputContainerStyle": "@mlsInputContainerStyle"
            , "mlsLabelContainerStyle": "@mlsLabelContainerStyle"
            , "mlsLabelContainerClass": "@mlsLabelContainerClass"
            , "mlsContainerStyle": "@mlsContainerStyle"
            , "mlsContainerClass": "@mlsContainerClass"
            , "mlsLabelClass": "@mlsLabelClass"
            , "mlsLabelStyle": "@mlsLabelStyle"
            , "mlsInputClass": "@mlsInputClass"
            , "mlsInputStyle": "@mlsInputStyle"
            , "ngChange": "&"
            , "options": "="
            , "ngReadonly": "=" 
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-combo-box-with-label/template/mls-combo-box-with-label.html"),
        link: function (scope, wraperElement, attrs, ctrl)
        {
            $timeout(function ()
            {
                mlsControlSvc.alighLabelToCenter("#" + attrs.idName, "#lb_" + attrs.idName)
            })
        }
    };
}]);

 