﻿appComponents.controller('mlsLoadingDialogController', ['$scope', 'dialogParam', 'mlsDialog', function ($scope, dialogParam, mlsDialog) {
    //$scope.rejectReasonDataSource = dialogParam.rejectReasonDataSource;
    //$scope.cboRejectReasonLabelText = dialogParam.cboRejectReasonLabelText;
    //$scope.txtRejectRemarkLabelText = dialogParam.txtRejectRemarkLabelText;
   
     
}])

appComponents.factory('mlsLoadingDialog', ['mlsDialog', 'mlsUrlSvc', '$q', function (mlsDialog, mlsUrlSvc, $q) {
    var service = {};
    service.dialog = null;

    service.show = function ()
    { 
        return mlsDialog.openDialog({
            template: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-loading-dialog/template/mls-loading-dialog.html"),
            controller: "mlsLoadingDialogController",
            className: 'ngdialog-theme-default dialog-loading',
            closeByDocument: false,
            showClose: false,
            closeByEscape: false, 
        }, {});

    } 
    


    service.hide = function ()
    {
        if (service.dialog) {
            service.dialog.close();
        }
    }

    return service;

}]);