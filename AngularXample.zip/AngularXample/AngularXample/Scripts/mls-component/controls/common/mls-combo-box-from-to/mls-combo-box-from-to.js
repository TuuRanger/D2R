﻿appComponents.directive('mlsComboBoxFromTo', ['mlsUrlSvc', '$timeout', function (mlsUrlSvc, $timeout)
{
    return {
        scope: {
            "idName": '@idName'
            , 'ngModel': '='
            , "mlsDisplayMembers": "@mlsDisplayMembers"
            , "mlsValueMembers": "@mlsValueMembers"
            , "mlsPlaceHolder": "@mlsPlaceHolder"
            , "mlsFilter": "@mlsFilter"
            , "mlsAutoBind": "@mlsAutoBind"
            , "mlsMinLenght": "@mlsMinLenght"
            , "mlsDataSource": "="
            , "mlsInputClass": "@mlsInputClass"
            , "ngReadonly": "="
            , "ngChange": "&"
            , "options" : "="

        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-combo-box-from-to/template/mls-combo-box-from-to-select2.html"),
        //templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-combo-box/template/mls-combo-box-kendo.html"),
        link: function (scope, wraperElement, attrs, ctrl)
        {
           
            
        }

    };
}]);