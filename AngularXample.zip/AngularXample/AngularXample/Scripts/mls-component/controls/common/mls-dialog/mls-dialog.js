﻿appComponents.controller('mlsDialogController', ['$scope', 'dialogParam', function ($scope, dialogParam)
{
    $scope.message = dialogParam.message;
    $scope.messageCode = dialogParam.messageCode;
}])

appComponents.factory('mlsDialog', ['ngDialog', 'mlsUrlSvc', function (ngDialog, mlsUrlSvc)
{
    var service = {};

    _initDefaultOption = function (options, dialogType, messageObj)
    {
        options = options || {}
        var defaultTemplate = '';
        if (dialogType == "INFO")
        {
            defaultTemplate =  mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-dialog/template/messageDialogTemplate.html");
        }
        else if (dialogType == "CONFIRM")
        {
            defaultTemplate = options.template || mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-dialog/template/confirmDialogTemplate.html");
        }
        else if (dialogType == "WARNING")
        {
            defaultTemplate = mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-dialog/template/warningDialogTemplate.html");
        }

        options.template = options.template || defaultTemplate;
        options.controller = options.controller || "mlsDialogController";

        options.resolve = options.resolve ||  {
            "dialogParam": function ()
            {
                return {
                    "message": messageObj.message,
                    "messageCode": messageObj.messageCode
                };
            }
        };
        return options;
    }

    service.showInfoDialog = function (messageObj, options)
    {
        var dialogOptions = _initDefaultOption(options, "INFO", messageObj);
        var promise = ngDialog.openConfirm(dialogOptions);
        return promise;
    }

    service.showConfirmDialog = function (messageObj, options)
    {
        var dialogOptions = _initDefaultOption(options, "CONFIRM", messageObj);
        var promise = ngDialog.openConfirm(dialogOptions);
        return promise;
    }

    service.showWarningDialog = function (messageObj, options)
    {
        var dialogOptions = _initDefaultOption(options, "WARNING", messageObj);
        ngDialog.open(dialogOptions);
    }

    service.showCustomDialog = function (messageObj, options, dialogType)
    {
        var dialogOptions = _initDefaultOption(options, dialogType, messageObj);
        var promise = ngDialog.openConfirm(dialogOptions); 
        return promise;
    }

    service.openDialog = function (options,messageObj)
    {
        dialogOptions = _initDefaultOption(options, "WARNING", messageObj);
        return ngDialog.open(dialogOptions);
    }

    return service;

}]); 