﻿appComponents.directive('mlsNumericTextBoxWithLabel', ['mlsUrlSvc', '$filter', 'mlsRegExp', 'mlsDateUtils', '$timeout', 'mlsControlSvc',
    function (mlsUrlSvc, $filter, mlsRegExp, mlsDateUtils, $timeout, mlsControlSvc)
    {
        return {
            restrict: "E",
            scope: {
                "idName": '@idName',
                'dateModel': '=',
                'ngModel': '=',
                'ngChange': '&',
                'format': '=',
                'decimals' : '=',
                'ngReadonly': '=',
                'mlsLabelText': "=",
                'mlsInputContainerClass': "@mlsInputContainerClass",
                'mlsInputContainerStyle': "@mlsInputContainerStyle",
                'mlsLabelContainerStyle': "@mlsLabelContainerStyle",
                'mlsLabelContainerClass': "@mlsLabelContainerClass",
                'mlsContainerStyle': "@mlsContainerStyle",
                'mlsContainerClass': "@mlsContainerClass",
                'mlsLabelClass': "@mlsLabelClass",
                'mlsLabelStyle': "@mlsLabelStyle",
                'mlsInputClass': "@mlsInputClass",
                'mlsInputStyle': "@mlsInputStyle",
                'mlsDecimalPlace': "@mlsDecimalPlace",
                'mlsMinDate': "@mlsMinDate",
                'mlsMaxDate': "@mlsMaxDate",
                'mlsDateDisplayFormat': "@mlsDateDisplayFormat",
                'mlsDateModelFormat': "@mlsDateModelFormat",
                'mlsMaskedText': "@mlsMaskedText",
                'mlsEnabledMaskedText': "@mlsEnabledMaskedText",
                'mlsInputAddonFront': "=",
                'mlsInputAddonBack': "=",
                'ngReadonly': "=",
            },
            templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-numeric-text-box-with-label/template/mls-numeric-text-box-with-label.html"),
            link: function (scope, wraperElement, attrs, ctrl)
            { 
                $timeout(function ()
                { 
                    mlsControlSvc.alighLabelToCenter("#" + attrs.idName, "#lb_" + attrs.idName)
                })
            }
        };
    }]);