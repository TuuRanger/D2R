﻿
appComponents.directive('mlsTextBoxWithLabel', ['mlsUrlSvc', '$timeout','mlsControlSvc' ,function (mlsUrlSvc, $timeout, mlsControlSvc)
{
    return {
        restrict: "E",
        terminal: true,
        scope: {
              "idName": '@idName'
            , "type": '@type'
            , 'ngModel': '='
            , 'objectModel' : '='
            , 'ngChange': '&'
            , "mlsLabelText": "="
            , "mlsInputContainerClass": "@mlsInputContainerClass"
            , "mlsInputContainerStyle": "@mlsInputContainerStyle"
            , "mlsLabelContainerStyle": "@mlsLabelContainerStyle"
            , "mlsLabelContainerClass": "@mlsLabelContainerClass"
            , "mlsContainerStyle": "@mlsContainerStyle"
            , "mlsContainerClass": "@mlsContainerClass"
            , "mlsLabelClass": "@mlsLabelClass"
            , "mlsLabelStyle": "@mlsLabelStyle"
            , "mlsInputClass": "@mlsInputClass"
            , "mlsInputStyle": "@mlsInputStyle"
            , "mlsDecimalPlace": "@mlsDecimalPlace"
            , "mlsMinDate": "@mlsMinDate"
            , "mlsMaxDate": "@mlsMaxDate"
            , "mlsDateDisplayFormat": "@mlsDateDisplayFormat"
            , "mlsDateModelFormat": "@mlsDateModelFormat"
            , "mlsMaskedText": "@mlsMaskedText"
            , "mlsEnabledMaskedText": "@mlsEnabledMaskedText"
            , "mlsInputAddonFront": "="
            , "mlsInputAddonBack": "="
            , "ngReadonly": "="
            , "wraperHtml": '=' ,
            "addonFront": "=",
            "addonRear": "=",
            'addonRearClick' :'&'
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-text-box-with-label/template/mls-text-box-with-label.html"),
        link: function (scope, wraperElement, attrs, ctrl)
        {
            $timeout(function ()
            {
                mlsControlSvc.alighLabelToCenter("#" + attrs.idName, "#lb_" + attrs.idName)
            })

            
        }
    };
}]);
