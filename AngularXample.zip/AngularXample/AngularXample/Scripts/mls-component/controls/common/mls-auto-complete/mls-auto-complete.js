﻿appComponents.directive('mlsAutoComplete', [ 'mlsUrlSvc','$timeout',
    function (mlsUrlSvc,$timeout)
    {
        return {
            restrict: "E",
            scope: {
                "idName": '@idName',  
                "mlsInputClass": "@mlsInputClass",
                "mlsInputStyle": "@mlsInputStyle",
                "mlsDataSource": "=",
                "selectedObject": "=",
                "titleField": "@titleField",
                "searchFields": "@searchFields",
                "minlength": "@minlength",
                "maxlength": "@maxlength",
                "placeHolder": '@placeHolder',
                "pause": '@pause',
                "matchClass": "@matchClass",
                "remoteUrl" : "@remoteUrl",
                "remoteUrlRequestFormatter"  : "=",
                "remoteUrlDataField": "@remoteUrlDataField",
                "descriptionField": "@descriptionField",
                "selectedText": "=",
                "selectedTextField": "@selectedTextField",
                "initialValue": "=",
                "useSelectedText": "@useSelectedText",
                "clearSelected": "@clearSelected",
                "ngReadonly" :'='

            }, 
            templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/common/mls-auto-complete/template/mls-auto-complete.html"),
            link: function (scope, wraperElement, attrs, ctrl)
            { 
                $timeout(function ()
                {
                    var input = angular.element(wraperElement).find('input')[0];

                    angular.element(input).bind("change", function ()
                    { 
                        scope.selectedText = angular.element(input).val()
                        console.log("scope.selectedText : " + scope.selectedText)
                        scope.selectedObject = null;
                    })

                    $(input).off('focusout');

                    scope.$watch('selectedText', function (newVal, oldVal, scope)
                    { 
                        if (scope.useSelectedText == 'true')
                        {
                            angular.element(input).val(newVal);
                            angular.element(input).trigger('change')
                        }
                       
                    },true)

                    scope.$watch('selectedObject', function (newVal, oldVal, scope)
                    { 
                        if (newVal)
                        {
                            console.log("selectedObject : " + newVal) 
                            scope.selectedText = newVal.originalObject[scope.selectedTextField];
                            console.log("newVal.originalObject[scope.selectedTextField] : " + newVal.originalObject[scope.selectedTextField])
                            if (scope.useSelectedText == 'true')
                            {
                                angular.element(input).val(scope.selectedText)
                                //angular.element(input).trigger('change')
                            }
                        }
                        //else
                        //{
                        //    scope.selectedObject = scope.selectedText;
                        //}

                    },true)
                     
                     
                })
            },
        };
    }]);



