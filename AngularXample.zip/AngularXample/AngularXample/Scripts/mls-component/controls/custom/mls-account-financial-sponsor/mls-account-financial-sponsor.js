﻿appComponents.directive('mlsAccountFinancialSponsor', ['mlsUrlSvc', '$timeout', '$rootScope', 'mlsStringUtils',
function (mlsUrlSvc, $timeout, $rootScope, mlsStringUtils) {
    return {
        restrict: "E",
        scope: {
            'model': '=',
            'interestTypeLabelText': '=',
            'interestTypeDataSource': '=',
            'interestTypeDisplayMembers': '@interestTypeDisplayMembers',
            'interestTypeValueMembers': '@interestTypeValueMembers',
            'interestRateLabelText': '=',
            'interestPeriodLabelText': '=',
            'interestPeriodDataSource': '=',
            'interestPeriodDisplayMembers': '@interestPeriodDisplayMembers',
            'interestPeriodValueMembers': '@interestPeriodValueMembers',
            'termLabelText': '=',
            'termPeriodLabelText': '=',
            'termPeriodDataSource': '=',
            'termPeriodDisplayMembers': '@termPeriodDisplayMembers',
            'termPeriodValueMembers': '@termPeriodValueMembers',
            'advanceRateLabelText' :'=',
            'totalCreditLabelText' : '=',
            'mlsLabelClass': "@mlsLabelClass",
            'mlsLabelStyle': "@mlsLabelStyle",
            'mlsInputClass': "@mlsInputClass",
            'mlsInputStyle': "@mlsInputStyle",
            'mlsInputContainerClass': "@mlsInputContainerClass",
            'mlsLabelContainerStyle': "@mlsLabelContainerStyle",
            'mlsLabelContainerClass': "@mlsLabelContainerClass",
            'mlsContainerStyle': "@mlsContainerStyle",
            'mlsContainerClass': "@mlsContainerClass",
            'mlsInputContainerStyle': "@mlsInputContainerStyle",
            'id': '@id',
            'title': '=',
            'readonly': '='

        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-account-financial-sponsor/template/mls-account-financial-sponsor.html"),
        link: function (scope, wraperElement, attrs, ctrl) {


        }

    };
}]);
