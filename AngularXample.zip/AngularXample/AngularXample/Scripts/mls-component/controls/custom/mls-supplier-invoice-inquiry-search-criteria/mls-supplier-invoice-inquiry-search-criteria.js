﻿appComponents.directive('mlsSupplierInvoiceInquirySearchCriteria', ['mlsUrlSvc', function (mlsUrlSvc) {
    return {
        restrict: "E",
        scope: {
            'model': '=',
            'dateFormat' : '=',
            'mlsLabelClass': "@mlsLabelClass",
            'mlsLabelStyle': "@mlsLabelStyle",
            'mlsInputClass': "@mlsInputClass",
            'mlsInputStyle': "@mlsInputStyle",
            'mlsInputContainerClass': "@mlsInputContainerClass",
            'mlsLabelContainerStyle': "@mlsLabelContainerStyle",
            'mlsLabelContainerClass': "@mlsLabelContainerClass",
            'mlsContainerStyle': "@mlsContainerStyle",
            'mlsContainerClass': "@mlsContainerClass",
            'mlsInputContainerStyle': "@mlsInputContainerStyle",
            'id': '@id',
            'readonly': '=',
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-supplier-invoice-inquiry-search-criteria/template/mls-supplier-invoice-inquiry-search-criteria.html"),
        link: function (scope, wraperElement, attrs, ctrl) {
        }
    };
}]);
