﻿appComponents.directive('mlsSupplierContractListSearchCriteria', ['mlsUrlSvc', function (mlsUrlSvc) {
    return {
        restrict: "E",
        scope: {
            'model': '=',
            'dateFormat': '=',
            'applicationNoLabelText': '=',
            'contractNoLabelText': '=',
            'sponsorNameLabelText' : '=',
            'mlsLabelClass': "@mlsLabelClass",
            'mlsLabelStyle': "@mlsLabelStyle",
            'mlsInputClass': "@mlsInputClass",
            'mlsInputStyle': "@mlsInputStyle",
            'mlsInputContainerClass': "@mlsInputContainerClass",
            'mlsLabelContainerStyle': "@mlsLabelContainerStyle",
            'mlsLabelContainerClass': "@mlsLabelContainerClass",
            'mlsContainerStyle': "@mlsContainerStyle",
            'mlsContainerClass': "@mlsContainerClass",
            'mlsInputContainerStyle': "@mlsInputContainerStyle",
            'id': '@id',
            'readonly': '=',
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-supplier-contract-list-search-criteria/template/mls-supplier-contract-list-search-criteria.html"),
        link: function (scope, wraperElement, attrs, ctrl) {
        }
    };
}]);
