﻿appComponents.controller('mlsAppRejectDialogController', ['$scope', 'dialogParam', 'mlsDialog', function ($scope, dialogParam, mlsDialog) {
    $scope.rejectReasonDataSource = dialogParam.rejectReasonDataSource;
    $scope.cboRejectReasonLabelText = dialogParam.cboRejectReasonLabelText;
    $scope.txtRejectRemarkLabelText = dialogParam.txtRejectRemarkLabelText;
    $scope.model = {
        rejectReasonID: dialogParam.rejectReasonID,
        rejectRemark: dialogParam.rejectRemark
    };
     
    $scope.onOK = function ()
    {
        var form = $("#frmRejectApp");
        if (form.valid())
        {
            var confirmReject = mlsDialog.showConfirmDialog({ message: "Are you sure do you want to 'Reject' this case?" })
            confirmReject.then(function () {
                $scope.confirm({ dialogModel: $scope.model })
            })
        }
       
    }

    $scope.validationOptions = {
        rules: {
            cboRejectReason: {
                required: true,
            }
        }
    } 
}])

appComponents.factory('mlsAppRejectDialog', ['mlsDialog', 'mlsUrlSvc', '$q', function (mlsDialog, mlsUrlSvc, $q) {
    var service = {}; 
    service.show = function (params) { 
        
        var promise = mlsDialog.showCustomDialog({}, { 
            template: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-app-reject-dialog/template/mls-app-reject-dialog.html"),
            controller : "mlsAppRejectDialogController",
            className: 'ngdialog-theme-default dialog-medium',
            closeByDocument: false,
            showClose: false,
            closeByEscape: false,
            resolve : {
                "dialogParam": function () {
                    return {
                        "rejectReasonDataSource": params.rejectReasonDataSource,
                        "cboRejectReasonLabelText": params.cboRejectReasonLabelText,
                        "txtRejectRemarkLabelText": params.txtRejectRemarkLabelText,
                        "rejectReasonID": params.rejectReasonID,
                        "rejectRemark": params.rejectRemark,
                    };
                }
            }
        }, null);

        return promise
    } 
    return service;

}]);