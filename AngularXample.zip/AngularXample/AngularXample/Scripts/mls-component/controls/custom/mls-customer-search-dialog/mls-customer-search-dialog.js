﻿appComponents.controller('mlsCustomerSearchDialogController', ['$scope', 'dialogParam', 'mlsDialog', 'customerDataSvc', 'mlsLoadingDialog', function ($scope, dialogParam, mlsDialog, customerDataSvc, mlsLoadingDialog) {
    $scope.listLabelText = dialogParam.listLabelText;
    $scope.customerTypeDataSource = dialogParam.customerTypeDataSource
    $scope.customerDisplayMembers = dialogParam.customerDisplayMembers
    $scope.customerValueMembers = dialogParam.customerValueMembers
    $scope.staticCriteria = dialogParam.staticCriteria;
    $scope.id = "customerSearchDialog"
    $scope.model = {  };
    $scope.searchCriteria = $scope.staticCriteria || {};
    $scope.onOK = function ()
    {
        var selectedRows = $scope.gridApi.selection.getSelectedRows()
        if (selectedRows.length > 0) {
            $scope.model.selectedCustomer = selectedRows[0];
            $scope.confirm({ dialogModel: $scope.model })
        }
        else {
            mlsDialog.showWarningDialog({ message: "Please select customer.", messageCode: "WRN001" })
        }
         
    }

    $scope.validationOptions = {
        rules: {
            cboCancelReason: {
                required: true,
            }
        }
    }

    $scope.gridOptions = {
        enableSelectAll: true,
        enableRowSelection: true,
        multiSelect: false,
        enableRowHeaderSelection: true,
        useExternalPagination: true,
        paginationPageSize: 50,
        paginationPageSizes: [50, 100,150],
        noUnselect: false,
        enableSorting: true,
        enableColumnResizing: true,
        showGridFooter: true,
        rowHeight: 30,
        columnDefs: [
          { name: 'ประเภทลูกค้า', field: 'CUSTYPCOD_DESC', width: "170", },
          { name: 'เลขบัตรประชาชน/รหัสบริษัท', field: 'ID', width: "240", },
          { name: 'ชื่อ-นามสกุล/ชื่อบริษัท', field: 'FullName', width: "300" }, 
        ],
        data : [],
        onRegisterApi: function (gridApi) {
            //set gridApi on scope
            $scope.gridApi = gridApi;

            //gridApi.selection.on.rowSelectionChanged($scope, function (row, evt) {
                 
            //});
              
            gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) { 
                $scope.getCustomerData(newPage, pageSize);
            });
        }
    };

    $scope.getCustomerData = function (pageNo, pageSize)
    {
        var dialog = mlsLoadingDialog.show();
        customerDataSvc.getCustomerList({
            name: $scope.searchCriteria.CUSNAMTHA,
            surname: $scope.searchCriteria.CUSSURTHA,
            ID: $scope.searchCriteria.PSNREGIDN,
            customerType: $scope.searchCriteria.CUSTYPCOD,
            pageNo: pageNo,
            pageSize: pageSize
        }).then(function (data) {
            if (data.length > 0) {
                $scope.gridOptions.data = data;
                $scope.gridOptions.totalItems = data[0].TotalRecords;
            }
            else
            {
                $scope.gridOptions.data = [];
                $scope.gridOptions.totalItems = 0;
            }
           
            dialog.close();
        })
    }

    $scope.search = function (pageNo,pageSize)
    { 
        $scope.getCustomerData(1, $scope.gridOptions.paginationPageSize)
        $scope.gridApi.pagination.seek(1);
    }
     
}])

appComponents.factory('mlsCustomerSearchDialog', ['mlsDialog', 'mlsUrlSvc', '$q', function (mlsDialog, mlsUrlSvc, $q) {
    var service = {}; 
    service.show = function (params) { 
        
        var promise = mlsDialog.showCustomDialog({}, { 
            template: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-customer-search-dialog/template/mls-customer-search-dialog.html"),
            controller: "mlsCustomerSearchDialogController",
            className: 'ngdialog-theme-default dialog-large',
            closeByDocument: false,
            showClose: false,
            closeByEscape: false,
            resolve : {
                "dialogParam": function () {
                    return  params.dialogParam
                }
            }
        }, null);

        return promise
    } 
    return service;

}]);