﻿appComponents.directive('mlsSupplierInvoiceListSearchCriteria', ['mlsUrlSvc', function (mlsUrlSvc) {
    return {
        restrict: "E",
        scope: {
            'model': '=',
            'dateFormat': '=',
            'productTypeLabelText': '=',
            'productTypeDataSource': '=',
            'productTypeDisplayMembers': '@productTypeDisplayMembers',
            'productTypeValueMembers': '@productTypeValueMembers',
            'invoiceDateFromLabelText': '=',
            'invoiceDateToLabelText': '=',
            'dueDateFromLabelText': '=',
            'dueDateToLabelText' : '=',
            'mlsLabelClass': "@mlsLabelClass",
            'mlsLabelStyle': "@mlsLabelStyle",
            'mlsInputClass': "@mlsInputClass",
            'mlsInputStyle': "@mlsInputStyle",
            'mlsInputContainerClass': "@mlsInputContainerClass",
            'mlsLabelContainerStyle': "@mlsLabelContainerStyle",
            'mlsLabelContainerClass': "@mlsLabelContainerClass",
            'mlsContainerStyle': "@mlsContainerStyle",
            'mlsContainerClass': "@mlsContainerClass",
            'mlsInputContainerStyle': "@mlsInputContainerStyle",
            'id': '@id',
            'readonly': '=',
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-supplier-invoice-list-search-criteria/template/mls-supplier-invoice-list-search-criteria.html"),
        link: function (scope, wraperElement, attrs, ctrl) {
        }
    };
}]);
