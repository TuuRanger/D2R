﻿appComponents.directive('mlsAccountApproval', ['mlsUrlSvc', '$timeout', '$rootScope', 'mlsStringUtils',
function (mlsUrlSvc,$timeout, $rootScope, mlsStringUtils) {
    return {
        restrict: "E",
        scope: {
            'model': '=',
            'accountGradeLabelText': '=',
            'accountGradeDataSource': '=',
            'accountGradeDisplayMembers': '@accountGradeDisplayMembers',
            'accountGradeValueMembers': '@accountGradeValueMembers',
            'accountLevelLabelText': '=',
            'accountLevelDataSource': '=',
            'accountLevelDisplayMembers': '@accountLevelDisplayMembers',
            'accountLevelValueMembers': '@accountLevelValueMembers',
            'approveDateLabelText': '=',
            'creditScoreLabelText': '=',
            'remarkLabelText': '=',
            'verifierLabelText': '=',
            'verifierDataSource' : '=',
            'verifierDisplayMembers': '@verifierDisplayMembers',
            'verifierValueMembers': '@verifierValueMembers',
            'approverLabelText': '=',
            'approverDataSource': '=',
            'approverDisplayMembers': '@approverDisplayMembers',
            'approverValueMembers': '@approverValueMembers',
            'isPassedLabelText': '=',
            'passValue': '=',
            'notPassValue': '=',
            'passLabelText': '=',
            'notPassLabelText': '=',
            'creditDeviateLabelText': '=',
            'creditDeviateDataSource': '=',
            'creditDeviateDisplayMembers': '@creditDeviateDisplayMembers',
            'creditDeviateValueMembers': '@creditDeviateValueMembers',
            'mlsLabelClass': "@mlsLabelClass",
            'mlsLabelStyle': "@mlsLabelStyle",
            'mlsInputClass': "@mlsInputClass",
            'mlsInputStyle': "@mlsInputStyle",
            'mlsInputContainerClass': "@mlsInputContainerClass",
            'mlsLabelContainerStyle': "@mlsLabelContainerStyle",
            'mlsLabelContainerClass': "@mlsLabelContainerClass",
            'mlsContainerStyle': "@mlsContainerStyle",
            'mlsContainerClass': "@mlsContainerClass",
            'mlsInputContainerStyle': "@mlsInputContainerStyle",
            'id': '@id',
            'readonly': '='
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-account-approval/template/mls-account-approval.html"),
        link: function (scope, wraperElement, attrs, ctrl) {


        }

    };
}]);
