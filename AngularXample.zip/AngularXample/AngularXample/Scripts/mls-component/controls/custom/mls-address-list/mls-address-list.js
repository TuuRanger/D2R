﻿appComponents.directive('mlsAddressList', ['mlsUrlSvc', 'provinceDataSvc', 'amphurDataSvc', 'zipCodeDataSvc', 'arrayHelper', '$timeout',
    function (mlsUrlSvc, provinceDataSvc, amphurDataSvc, zipCodeDataSvc, arrayHelper, $timeout)
    {
        return {
            restrict: "E",
            scope: { 
                'addressLine1LabelText': '='
                , 'districtLabelText': '='
                , 'amphurLabelText': '='
                , 'provinceLabelText': '='
                , 'zipCodeLabelText': '='
                , 'phoneNoLabelText': '='
                , 'phoneEndNoLabelText': '='
                , 'phoneFromNoLabelText': '='
                , 'phoneExtNoLabelText': '='
                , 'referenceAddressLabelText': '='
                , 'addressTypeCodeLabelText': '='
                , 'adrReferenceDataSource': '='
                , 'adrReferenceValueMembers': '@'
                , 'adrReferenceDisplayMembers': '@'
                , 'adrReferenceSelectorMembers': '@' 
                , 'addressTypeCodeDataSource': '='
                , 'addressTypeCodeValueMembers': '@'
                , 'addressTypeCodeDisplayMembers': '@'
                , 'mlsLabelClass': "@mlsLabelClass"
                , 'mlsLabelStyle': "@mlsLabelStyle"
                , 'mlsInputClass': "@mlsInputClass"
                , 'mlsInputStyle': "@mlsInputStyle"
                , 'mlsInputContainerClass': "@mlsInputContainerClass"
                , 'mlsLabelContainerStyle': "@mlsLabelContainerStyle"
                , 'mlsLabelContainerClass': "@mlsLabelContainerClass"
                , 'mlsContainerStyle': "@mlsContainerStyle"
                , 'mlsContainerClass': "@mlsContainerClass"
                , 'mlsInputContainerStyle': "@mlsInputContainerStyle" 
                , 'addressDataSource': '='
                , 'requiredClass': "@requiredClass"
                , 'id': '@id'
                , 'panelContainerClass': "@"
                , 'readonly': '='
                , 'model' : '='
            },
            templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-address-list/template/mls-address-list.html"),
            link: function (scope, wraperElement, attrs, ctrl)
            {
                scope.model = scope.model || {
                    deleteList: [],
                    addList: [],
                };
                 
                scope.$watch('model', function (newValue)
                { 
                    if (newValue) {
                        if (!scope.model.hasOwnProperty('deleteList')) {
                            scope.model.deleteList = [];
                        }

                        if (!scope.model.hasOwnProperty('addList')) {
                            scope.model.addList = [];
                        }
                    }
                })

                scope.index = 0; 
                scope.delete = function (obj)
                {
                    obj.RECACTCOD = 'I'
                    scope.model.deleteList.push(angular.copy(obj));
                    var idx = scope.addressDataSource.indexOf(obj);
                    if (idx !== -1)
                    {
                        scope.addressDataSource.splice(idx, 1);
                    } 

                }


                scope.add = function ()
                {
                    scope.addressDataSource = scope.addressDataSource || [];
                    var obj = { RECACTCOD  : 'A'};
                    obj.open = true; 
                    scope.addressDataSource.push(obj);
                    var idx = scope.addressDataSource.indexOf(obj);

                    scope.model.addList.push(angular.copy(obj));
                }
                 
                scope.getDataSourceLength = function ()
                {
                    return scope.addressDataSource.length;
                }

                scope.$watchCollection('addressDataSource', function (newArr, oldArr, scope1)
                { 
                    if (scope.addressDataSource)
                    {
                        for (var i = 0 ; i < scope.addressDataSource.length ; i++)
                        {
                            var watch = scope.$watch('addressDataSource[' + i + ']', function (newObj, oldObj, scope)
                            {  
                                if (newObj && oldObj)
                                {
                                    newObj.watch = watch;
                                    if (angular.equals(newObj, oldObj) == false)
                                    { 
                                        if (newObj.ADRREFCOD != oldObj.ADRREFCOD)
                                        {
                                            scope.copyMasterAddress(newObj);
                                        }
                                        else
                                        {
                                            scope.madeSameAddress(newObj);
                                        }
                                    }

                                }
                                
                            }, true)

                        }
                    }  
                })
                


                scope.notCopyKey = ['ADRREFCOD', 'ADRTYPCOD', 'ADRCOD', 'open', 'addressTypeDesc', '$$hashKey']

                scope.copyAddress = function (target,source)
                { 
                    angular.forEach(source, function (value, key)
                    { 
                        if(scope.notCopyKey.indexOf(key) === -1)
                        {
                            target[key] = source[key]
                        }
                    })
                }

                scope.copyMasterAddress = function (newObj)
                {
                    var idx = scope.addressDataSource.indexOf(newObj);
                     
                    if (newObj.ADRREFCOD)
                    {
                        var masterAddress = scope.addressDataSource.whereAnd([{ ADRTYPCOD: newObj.ADRREFCOD }]);
                        var copyToObj = newObj;
                        if (masterAddress.length > 0) // found
                        { 
                            copyToObj  = scope.copyAddress(scope.addressDataSource[idx],masterAddress[0])   
                            //scope.addressDataSource[idx] = copyToObj;
                        }
                    }
             
                }

                scope.madeSameAddress = function(masterAddress)
                { 
                    if (masterAddress.ADRTYPCOD)
                    {
                        var sameAddress = scope.addressDataSource.whereAnd([{ ADRREFCOD: masterAddress.ADRTYPCOD }]);
                        for (var i = 0 ; i < sameAddress.length ; i++)
                        {
                            var objSameAddress = sameAddress[i];

                            var temp = objSameAddress;
                            var idx = scope.addressDataSource.indexOf(objSameAddress);
                            objSameAddress = scope.copyAddress(scope.addressDataSource[idx], masterAddress)
             
                        }
                    }
                   
                }
            }

        };
    }]);
