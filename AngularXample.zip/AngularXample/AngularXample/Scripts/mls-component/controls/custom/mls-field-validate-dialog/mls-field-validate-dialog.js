﻿appComponents.controller('mlsFieldValidateDialogController', ['$scope', 'dialogParam', 'mlsDialog', function ($scope, dialogParam, mlsDialog) {
    $scope.message = dialogParam.message;
    $scope.messageCode = dialogParam.messageCode;
    $scope.invalidFields = dialogParam.invalidFields; 
     
}])

appComponents.factory('mlsFieldValidateDialog', ['mlsDialog', 'mlsUrlSvc', '$q', function (mlsDialog, mlsUrlSvc, $q) {
    var service = {}; 
    service.show = function (params) { 
        
        var promise = mlsDialog.showCustomDialog({}, { 
            template: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-field-validate-dialog/template/mls-field-validate-dialog.html"),
            controller: "mlsFieldValidateDialogController",
            className: 'ngdialog-theme-default dialog-medium',
            closeByDocument: false,
            showClose: false,
            closeByEscape: false,
            resolve : {
                "dialogParam": function () {
                    return {
                        "message": params.message,
                        "messageCode": params.messageCode,
                        "invalidFields": params.invalidFields,
                    };
                }
            }
        }, null);

        return promise
    } 
    return service;

}]);