﻿appComponents.directive('mlsGuarantorPersonList', ['mlsUrlSvc', function (mlsUrlSvc)
{
    return {
        restrict: "E",
        scope: {  
            'guarantorPersonDataSource': '='
            ,'idLabelText' :'='
            ,'nameLabelText': '='
            ,'lastNameLabelText': '='
            ,'nickNameLabelText' :'='
            ,'relationLabelText': '='
            ,'relationYearLabelText':'='
            ,'telNoLabelText': '='
            , 'titleNameLabelText': '='
            ,'addressLine1LabelText': '='
            ,'districtLabelText': '='
            ,'amphurLabelText': '='
            ,'provinceLabelText': '='
            ,'zipCodeLabelText': '='
            ,'phoneNoLabelText': '='
            ,'phoneEndNoLabelText': '='
            ,'phoneFromNoLabelText': '='
            ,'phoneExtNoLabelText': '='
            ,'referenceAddressLabelText': '='
            ,'addressTypeCodeLabelText': '=' 
            ,"referenceAddressLabelText": '='
            ,"addressTypeCodeLabelText": '='
            ,"addressTypeCodeDataSource": '=' 
            ,"addressTypeCodeDisplayMembers": '@addressTypeCodeDisplayMembers'
            ,"addressTypeCodeValueMembers": '@addressTypeCodeValueMembers'
            ,'customerTitleDataSource': '='
            ,'relationDataSource' : '='
            ,'mlsLabelClass': "@mlsLabelClass"
            ,'mlsLabelStyle': "@mlsLabelStyle"
            ,'mlsInputClass': "@mlsInputClass"
            ,'mlsInputStyle': "@mlsInputStyle"
            ,'mlsInputContainerClass': "@mlsInputContainerClass" 
            ,'mlsLabelContainerStyle': "@mlsLabelContainerStyle"
            ,'mlsLabelContainerClass': "@mlsLabelContainerClass"
            ,'mlsContainerStyle': "@mlsContainerStyle"
            ,'mlsContainerClass': "@mlsContainerClass"
    		, 'mlsInputContainerStyle': "@mlsInputContainerStyle"
            , 'addressInputClass': '@addressInputClass'
            , 'addressRequiredClass': '@addressRequiredClass'
            ,'id': '@id'
            ,'title': '='
            , 'mlsColumnCount': "@mlsColumnCount"
            , 'readonly': '='
            , 'model': '='
            , 'fnSearchCustomer': '&'
            , 'fnFindCustomerById' : '&'
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-guarantor-person-list/template/mls-guarantor-person-list.html"),
        link: function (scope, wraperElement, attrs, ctrl)
        {
            scope.fnFindCustomerById = scope.fnFindCustomerById();
            scope.fnSearchCustomer = scope.fnSearchCustomer(); 
            scope.model = scope.model || {
                deleteList: [],
                addList: [],
            };

            if (scope.model) {
                if (!scope.model.hasOwnProperty('deleteList')) {
                    scope.model.deleteList = [];
                }

                if (!scope.model.hasOwnProperty('addList')) {
                    scope.model.addList = [];
                }
            }

            scope.index = 0;
            scope.delete = function (obj)
            {
                obj.RECACTCOD = 'I'
                scope.model.deleteList.push(angular.copy(obj));
                var idx = scope.guarantorPersonDataSource.indexOf(obj);
                if (idx !== -1) {
                    scope.guarantorPersonDataSource.splice(idx, 1);
                }
            }

            scope.add = function ()
            {
                scope.guarantorPersonDataSource = scope.guarantorPersonDataSource || []; 
                scope.guarantorPersonDataSource.push({ CUSTYPCOD: "02", open: true, RECACTCOD: 'A', AddressList: [{ open: true }] });
            }
        }
    };
}]);
