﻿appComponents.directive('mlsCustomerInfoBox', ['mlsUrlSvc', 'eBiz', 'customerDataSvc', '$timeout', function (mlsUrlSvc, eBiz, customerDataSvc, $timeout)
{
    return {
        restrict: "E",
        scope: {
            "model": "=",
            "idLabelText": "=",
            "nameLabelText": "=",
            "lastNameLabelText": "=",
            "nickNameLabelText": "=",
            "birthDateLabelText": "=",
            "birthDayLabelText": "=",
            "birthDayDisplayMembers": "@birthDayDisplayMembers",
            "birthDayValueMembers": "@birthDayValueMembers",
            "birthDayDataSource": "=",
            "monthIncomeLabelText": "=",
            "netIncomeLabelText": "=",
            "mobileLabelText": "=",
            "titleNameLabelText": "=",
            "titleNameIndividualDataSource": "=",
            "titleNameIndividualDisplayMembers": "@titleNameIndividualDisplayMembers",
            "titleNameIndividualValueMembers": "@titleNameIndividualValueMembers",
            "titleNameJuristicDataSource": "=",
            "titleNameJuristicDisplayMembers": "@titleNameJuristicDisplayMembers",
            "titleNameJuristicValueMembers": "@titleNameJuristicValueMembers",
            'yearIncomeLabelText': '=',
            'profitIncomeLabelText': '=',
            'companyRegisDateLabelText': '=',
            'refDocDateLabelText': '=',
            'companyRegisNoLabelText' : '=',
            "mlsLabelClass": "@mlsLabelClass",
            "mlsLabelStyle": "@mlsLabelStyle",
            "mlsInputClass": "@mlsInputClass",
            "mlsInputStyle": "@mlsInputStyle",
            "mlsInputContainerClass": "@mlsInputContainerClass",
            "mlsLabelContainerStyle": "@mlsLabelContainerStyle",
            "mlsLabelContainerClass": "@mlsLabelContainerClass",
            "mlsContainerStyle": "@mlsContainerStyle",
            "mlsContainerClass": "@mlsContainerClass",
            "mlsInputContainerStyle": "@mlsInputContainerStyle",
            "id": "@id",
            "readonly": "=",
            "addressLine1LabelText": "=",
            "districtLabelText": "=",
            "amphurLabelText": "=",
            "provinceLabelText": "=",
            "zipCodeLabelText": "=",
            "phoneNoLabelText": "=",
            "phoneExtNoLabelText": "=",
            "phoneFromNoLabelText": "=",
            "phoneEndNoLabelText": "=",
            "referenceAddressLabelText": "=",
            "addressTypeCodeLabelText": "=",
            "addressTypeCodeIndividualDataSource": "=",
            "addressTypeCodeIndividualDisplayMembers": "@addressTypeCodeIndividualDisplayMembers",
            "addressTypeCodeIndividualValueMembers": "@addressTypeCodeIndividualValueMembers",
            "addressTypeCodeJuristicDataSource": "=",
            "addressTypeCodeJuristicDisplayMembers": "@addressTypeCodeJuristicDisplayMembers",
            "addressTypeCodeJuristicValueMembers": "@addressTypeCodeJuristicValueMembers",
            "requiredClass": "@requiredClass",
            "addressRequiredClass" : "@addressRequiredClass",
            "mlsCustomerTypeDisplayMembers": "@mlsCustomerTypeDisplayMembers",
            "mlsCustomerTypeValueMembers": "@mlsCustomerTypeValueMembers",
            "customerTypeDataSource": "=",
            "customerTypeLabelText": "=",
            "fnFindCustomerById" : '&'
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-customer-info-box/template/mls-customer-info-box.html"),
        link: function (scope, wraperElement, attrs, ctrl)
        {
            scope.fnFindCustomerById = scope.fnFindCustomerById();

            scope.IndividualCustomerTemplateUrl = mlsUrlSvc.getUrlContent('/Scripts/mls-component/controls/custom/mls-individual-customer-info-input/template/mls-individual-customer-info-input.html');
            scope.JuristicCustomerTemplateUrl = mlsUrlSvc.getUrlContent('/Scripts/mls-component/controls/custom/mls-juristic-customer-info-input/template/mls-juristic-customer-info-input.html');
            scope.customerInfoTemplateUrl = '';
            scope.$watch('model.CUSTYPCOD', function (newVal, oldVal, scope) /*Change by programatically or maybe user*/
            {
                if (newVal)
                {  
                    if (newVal == eBiz.CUSTYPCOD.JuristicPerson)
                    {
                        // title name for juristic
                        scope.titleNameDataSource = scope.titleNameJuristicDataSource;
                        scope.titleNameDisplayMembers = scope.titleNameJuristicDisplayMembers;
                        scope.titleNameValueMembers = scope.titleNameJuristicValueMembers;

                        // address typ code for juristic
                        scope.addressTypeCodeDataSource = scope.addressTypeCodeJuristicDataSource;
                        scope.addressTypeCodeDisplayMembers = scope.addressTypeCodeJuristicDisplayMembers;
                        scope.addressTypeCodeValueMembers = scope.addressTypeCodeJuristicValueMembers;

                        // template
                        scope.customerInfoTemplateUrl = scope.JuristicCustomerTemplateUrl;
                    }
                    else if (newVal == eBiz.CUSTYPCOD.NaturalPerson)
                    {
                        // title name for individual
                        scope.titleNameDataSource = scope.titleNameIndividualDataSource;
                        scope.titleNameDisplayMembers = scope.titleNameIndividualDisplayMembers;
                        scope.titleNameValueMembers = scope.titleNameIndividualValueMembers;

                        // address typ code for individual
                        scope.addressTypeCodeDataSource = scope.addressTypeCodeIndividualDataSource;
                        scope.addressTypeCodeDisplayMembers = scope.addressTypeCodeIndividualDisplayMembers;
                        scope.addressTypeCodeValueMembers = scope.addressTypeCodeIndividualValueMembers;

                        scope.customerInfoTemplateUrl = scope.IndividualCustomerTemplateUrl;
                    }
                }
            })

            scope.cboCustomerType_Changed = function () { /*Change by user*/
                $timeout(function ()
                {
                    angular.forEach(customerDataSvc.customerInfoField, function (value, key) {
                        scope.model[value] = null;
                    }) 
                })
               
            }
                
             
              
        }
    };
}]);
