﻿appComponents.controller('mlsAppCancelDialogController', ['$scope', 'dialogParam', 'mlsDialog', function ($scope, dialogParam, mlsDialog) {
    $scope.cancelReasonDataSource = dialogParam.cancelReasonDataSource;
    $scope.cboCancelReasonLabelText = dialogParam.cboCancelReasonLabelText;
    $scope.txtCancelRemarkLabelText = dialogParam.txtCancelRemarkLabelText;
    $scope.model = {
        cancelReasonID: dialogParam.cancelReasonID,
        cancelRemark: dialogParam.cancelRemark
    };

    $scope.onOK = function ()
    {
        var form = $("#frmCancelApp")
        if (form.valid())
        { 
            var confirmCancel = mlsDialog.showConfirmDialog({ message: "Are you sure do you want to 'Cancel' this case?" })
            confirmCancel.then(function () {
                $scope.confirm({ dialogModel: $scope.model })
            })
        } 
    }

    $scope.validationOptions = {
        rules: {
            cboCancelReason: {
                required: true,
            }
        }
    }
}])

appComponents.factory('mlsAppCancelDialog', ['mlsDialog', 'mlsUrlSvc', '$q', function (mlsDialog, mlsUrlSvc, $q) {
    var service = {}; 
    service.show = function (params) { 
        
        var promise = mlsDialog.showCustomDialog({}, { 
            template: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-app-cancel-dialog/template/mls-app-cancel-dialog.html"),
            controller: "mlsAppCancelDialogController",
            className: 'ngdialog-theme-default dialog-medium',
            closeByDocument: false,
            showClose: false,
            closeByEscape: false,
            resolve : {
                "dialogParam": function () {
                    return {
                        "cancelReasonDataSource": params.cancelReasonDataSource,
                        "cboCancelReasonLabelText": params.cboCancelReasonLabelText,
                        "txtCancelRemarkLabelText": params.txtCancelRemarkLabelText,
                        "cancelReasonID": params.cancelReasonID,
                        "cancelRemark": params.cancelRemark,
                    };
                }
            }
        }, null);

        return promise
    } 
    return service;

}]);