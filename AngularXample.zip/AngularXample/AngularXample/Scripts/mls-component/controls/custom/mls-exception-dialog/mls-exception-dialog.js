﻿appComponents.controller('mlsExceptionDialogController', ['$scope', 'dialogParam', 'mlsDialog', '$sce', function ($scope, dialogParam, mlsDialog, $sce) {
    $scope.exceptionObject = dialogParam.exceptionObject;
    $scope.contenType = dialogParam.contenType;
    if ($scope.contenType == 'text/html; charset=utf-8')
    {
        $scope.htmlContent = $sce.trustAsHtml(dialogParam.exceptionObject);
    }
    
}])

appComponents.factory('mlsExceptionDialog', ['mlsDialog', 'mlsUrlSvc', '$q', function (mlsDialog, mlsUrlSvc, $q) {
    var service = {}; 
    service.show = function (params) { 
        
        var promise = mlsDialog.showCustomDialog({}, { 
            template: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-exception-dialog/template/mls-exception-dialog.html"),
            controller: "mlsExceptionDialogController",
            className: 'ngdialog-theme-default dialog-large',
            closeByDocument: false,
            showClose: false,
            closeByEscape: false,
            resolve : {
                "dialogParam": function () {
                    return {
                        "exceptionObject": params.exceptionObject,
                        "contenType": params.contenType
                    };
                }
            }
        }, null);

        return promise
    } 
    return service;

}]);