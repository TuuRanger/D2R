﻿appComponents.directive('mlsCustomerSearchCriteria', ['mlsUrlSvc', 'setupDataSvc', '$templateRequest', '$compile', '$q', '$templateCache', function (mlsUrlSvc, setupDataSvc, $templateRequest, $compile, $q, $templateCache) {
    return {
        restrict: "E",
        scope: {
            'model': '=',
            'idLabelText': '=',
            'nameLabelText': '=',
            'surnameLabelText': '=',
            'customerTypeLabelText': '=',
            'customerTypeDataSource': '=',
            'customerDisplayMembers': '@customerDisplayMembers',
            'customerValueMembers': '@customerValueMembers',
            'mlsLabelClass': "@mlsLabelClass",
            'mlsLabelStyle': "@mlsLabelStyle",
            'mlsInputClass': "@mlsInputClass",
            'mlsInputStyle': "@mlsInputStyle",
            'mlsInputContainerClass': "@mlsInputContainerClass",
            'mlsLabelContainerStyle': "@mlsLabelContainerStyle",
            'mlsLabelContainerClass': "@mlsLabelContainerClass",
            'mlsContainerStyle': "@mlsContainerStyle",
            'mlsContainerClass': "@mlsContainerClass",
            'mlsInputContainerStyle': "@mlsInputContainerStyle",
            "containerTemplate": '=',
            "fnSearch": '&',
            'isCustomerTypeReadonly': '=',
            'id' : '@id'
        },
        template: '<div id="mlsCustomerSearchCriteria"><div ng-include="criteriaTemplateUrl"></div></div>',
        link: function (scope, element, attrs, ctrl) {


            scope.criteriaTemplateUrl = mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-customer-search-criteria/template/mls-customer-search-criteria.html");
            
            if (scope.containerTemplate) {
                $q.all([
                     $templateRequest(scope.containerTemplate),
                ]).then(function (response) {

                    element.html(response[0]);
                    $compile(element.contents())(scope);
                })

            } 
        }
    };
}]);
