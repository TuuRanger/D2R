﻿appComponents.directive('mlsCustomerInfoList', ['mlsUrlSvc', 'mlsDialog', '$rootScope', function (mlsUrlSvc, mlsDialog, $rootScope)
{
    return {
        restrict: "E",
        scope: {   
            "customerDataSource": "=",
            "idLabelText": "=",
            "nameLabelText": "=",
            "lastNameLabelText": "=",
            "nickNameLabelText": "=",
            "birthDateLabelText": "=",
            "birthDayLabelText": "=",
            "birthDayDisplayMembers": "@birthDayDisplayMembers",
            "birthDayValueMembers": "@birthDayValueMembers",
            "birthDayDataSource": "=",
            "monthIncomeLabelText": "=",
            "netIncomeLabelText": "=",
            "mobileLabelText": "=",
            "titleNameLabelText": "=",
            "titleNameIndividualDataSource": "=",
            "titleNameIndividualDisplayMembers": "@titleNameIndividualDisplayMembers",
            "titleNameIndividualValueMembers": "@titleNameIndividualValueMembers",
            "titleNameJuristicDataSource": "=",
            "titleNameJuristicDisplayMembers": "@titleNameJuristicDisplayMembers",
            "titleNameJuristicValueMembers": "@titleNameJuristicValueMembers",
            'yearIncomeLabelText': '=',
            'profitIncomeLabelText': '=',
            'companyRegisDateLabelText': '=',
            'refDocDateLabelText': '=',
            'companyRegisNoLabelText' : '=',
            "mlsLabelClass": "@mlsLabelClass",
            "mlsLabelStyle": "@mlsLabelStyle",
            "mlsInputClass": "@mlsInputClass",
            "mlsInputStyle": "@mlsInputStyle",
            "mlsInputContainerClass": "@mlsInputContainerClass",
            "mlsLabelContainerStyle": "@mlsLabelContainerStyle",
            "mlsLabelContainerClass": "@mlsLabelContainerClass",
            "mlsContainerStyle": "@mlsContainerStyle",
            "mlsContainerClass": "@mlsContainerClass",
            "mlsInputContainerStyle": "@mlsInputContainerStyle",
            "id": "@id",
            "readonly": "=",
            "addressLine1LabelText": "=",
            "districtLabelText": "=",
            "amphurLabelText": "=",
            "provinceLabelText": "=",
            "zipCodeLabelText": "=",
            "phoneNoLabelText": "=",
            "phoneExtNoLabelText": "=",
            "phoneFromNoLabelText": "=",
            "phoneEndNoLabelText": "=",
            "referenceAddressLabelText": "=",
            "addressTypeCodeLabelText": "=",
            "addressTypeCodeIndividualDataSource": "=",
            "addressTypeCodeIndividualDisplayMembers": "@addressTypeCodeIndividualDisplayMembers",
            "addressTypeCodeIndividualValueMembers": "@addressTypeCodeIndividualValueMembers",
            "addressTypeCodeJuristicDataSource": "=",
            "addressTypeCodeJuristicDisplayMembers": "@addressTypeCodeJuristicDisplayMembers",
            "addressTypeCodeJuristicValueMembers": "@addressTypeCodeJuristicValueMembers",
            "requiredClass": "@requiredClass",
            "addressRequiredClass" : "@addressRequiredClass",
            "mlsCustomerTypeDisplayMembers": "@mlsCustomerTypeDisplayMembers",
            "mlsCustomerTypeValueMembers": "@mlsCustomerTypeValueMembers",
            "customerTypeDataSource": "=",
            "customerTypeLabelText": "=",
            "fnSearchCustomer": '&',
            'fnFindCustomerById': '&',
            'model' : '='

        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-customer-info-list/template/mls-customer-info-list.html"),
        link: function (scope, wraperElement, attrs, ctrl)
        {
            scope.fnFindCustomerById = scope.fnFindCustomerById();
            scope.fnSearchCustomer = scope.fnSearchCustomer();
            scope.model = scope.model || {
                deleteList: [],
                addList: [],
            };

            if (scope.model) {
                 
                if (!scope.model.hasOwnProperty('deleteList')) {
                    scope.model.deleteList = [];
                }

                if (!scope.model.hasOwnProperty('addList')) {
                    scope.model.addList = [];
                }
            }

            scope.index = 0;
            scope.delete = function (obj)
            {
                confirm = mlsDialog.showConfirmDialog({ message: "Do you want to 'Delete' this customer ?" });
                confirm.then(function ()
                {
                    obj.RECACTCOD = 'I'
                    scope.model.deleteList.push(angular.copy(obj));
                    var idx = scope.customerDataSource.indexOf(obj);
                    if (idx !== -1) {
                        scope.customerDataSource.splice(idx, 1);
                    }

                })
               
            }
 

            scope.add = function ()
            {
                var newCustomer = {
                    open: true,
                    ADDNEW_FLAG: true,
                    RECACTCOD: 'A',
                    readonly: false,
                    AddressList: [{ open: true }]
                };
                scope.customerDataSource = scope.customerDataSource || [];
                scope.customerDataSource.push(newCustomer);
                scope.model.addList.push(newCustomer);
                
            }
             

             
        }
    };
}]);
    