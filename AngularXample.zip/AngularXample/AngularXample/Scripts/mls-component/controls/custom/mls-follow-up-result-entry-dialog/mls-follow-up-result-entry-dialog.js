﻿appComponents.controller('mlsFollowUpResultEntryDialogController', ['$scope', 'dialogParam', 'mlsDialog', 'eBiz', function ($scope, dialogParam, mlsDialog, eBiz) {
    $scope.followUpResultDataSource = dialogParam.followUpResultDataSource;
    $scope.followUpPlaceDataSource = dialogParam.followUpPlaceDataSource;
    $scope.followUpActivityDataSource = dialogParam.followUpActivityDataSource;
    $scope.status = dialogParam.status;
    $scope.title = dialogParam.title;
    $scope.model = {
        appointmentDate: new Date().toISODateString(),
        status: dialogParam.status
    };
     
    $scope.Appointment = eBiz.FollowUpStatus.Appointment;
    if ($scope.status == eBiz.FollowUpStatus.FailAppointment)
    {
        $scope.model.appointmentDate = null;
    }

    $scope.onOK = function ()
    {
        var form = $("#frmEntry");
        if (form.valid())
        {
            var confirmReject = mlsDialog.showConfirmDialog({ message: "Are you sure do you want to 'Save data'?" })
            confirmReject.then(function () {
                $scope.confirm({ dialogModel: $scope.model })
            })
        }
       
    }

    $scope.validationOptions = {
        rules: {
            cboFollowActivity: {
                required: true,
            },
            cboFollowPlace: {
                required: true,
            },
            cboFollowResult: {
                required: true,
            },
            dtpAppointmentDate: {
                required: function () { return $scope.status == eBiz.FollowUpStatus.Appointment },
                notEarlyThan: function () { return new Date()}
            }
        }
    }

    //$scope.model.appointmentDate = '1991-03-20T20:19:00'
}])

appComponents.factory('mlsFollowUpResultEntryDialog', ['mlsDialog', 'mlsUrlSvc', '$q', function (mlsDialog, mlsUrlSvc, $q) {
    var service = {}; 
    service.show = function (params) { 
        
        var promise = mlsDialog.showCustomDialog({}, { 
            template: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-follow-up-result-entry-dialog/template/mls-follow-up-result-entry-dialog.html"),
            controller: "mlsFollowUpResultEntryDialogController",
            className: 'ngdialog-theme-default dialog-medium',
            closeByDocument: false,
            showClose: false,
            closeByEscape: false,
            resolve : {
                "dialogParam": function () {
                    return {
                        "followUpResultDataSource": params.followUpResultDataSource,
                        "followUpPlaceDataSource": params.followUpPlaceDataSource,
                        "followUpActivityDataSource": params.followUpActivityDataSource,
                        'status': params.status,
                        'title': params.title
                    };
                }
            }
        }, null);

        return promise
    } 
    return service;

}]);