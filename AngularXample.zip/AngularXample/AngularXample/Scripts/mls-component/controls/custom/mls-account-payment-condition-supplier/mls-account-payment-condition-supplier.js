﻿appComponents.directive('mlsAccountPaymentConditionSupplier', ['mlsUrlSvc', '$timeout', '$rootScope', 'mlsStringUtils',
function (mlsUrlSvc,$timeout, $rootScope, mlsStringUtils) {
    return {
        restrict: "E",
        scope: {
            'model': '=', 
            'payByLabelText': '=',
            'payByDataSource': '=',
            'payByDisplayMembers': '@payByDisplayMembers',
            'payByValueMembers': '@payByValueMembers',
            'bankCodeLabelText': '=',
            'bankCodeDataSource': '=',
            'bankCodeDisplayMembers': '@bankCodeDisplayMembers',
            'bankCodeValueMembers': '@bankCodeValueMembers',
            'bankBranchLabelText': '=',
            'bankBranchDataSource': '=',
            'bankBranchDisplayMembers': '@bankBranchDisplayMembers',
            'bankBranchValueMembers': '@bankBranchValueMembers',
            'payableToLabelText': '=',
            'bankAccNoLabelText' : '=',
            'mlsLabelClass': "@mlsLabelClass",
            'mlsLabelStyle': "@mlsLabelStyle",
            'mlsInputClass': "@mlsInputClass",
            'mlsInputStyle': "@mlsInputStyle",
            'mlsInputContainerClass': "@mlsInputContainerClass",
            'mlsLabelContainerStyle': "@mlsLabelContainerStyle",
            'mlsLabelContainerClass': "@mlsLabelContainerClass",
            'mlsContainerStyle': "@mlsContainerStyle",
            'mlsContainerClass': "@mlsContainerClass",
            'mlsInputContainerStyle': "@mlsInputContainerStyle",
            'id': '@id',
            'readonly': '='
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-account-payment-condition-supplier/template/mls-account-payment-condition-supplier.html"),
        link: function (scope, wraperElement, attrs, ctrl) {


        }

    };
}]);
