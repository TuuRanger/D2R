﻿appComponents.directive('mlsAccountFinancial1Supplier', ['mlsUrlSvc', '$timeout', '$rootScope', 'mlsStringUtils',
function (mlsUrlSvc, $timeout, $rootScope, mlsStringUtils) {
    return {
        restrict: "E",
        scope: {
            'model': '=',
            'creditLine1LabelText': '=',
            'irRateLabelText': '=',
            'irRateDataSource': '=',
            'irRateDisplayMembers': '@irRateDisplayMembers',
            'irRateValueMembers': '@irRateValueMembers',
            'bankReferenceLabelText': '=',
            'bankReferenceDataSource': '=',
            'bankReferenceDisplayMembers': '@bankReferenceDisplayMembers',
            'bankReferenceValueMembers': '@bankReferenceValueMembers',
            'maxCreditPerTimeLabelText': '=',
            'minCreditPerTimeLabelText': '=',
            'maxCreditPerDocLabelText': '=',
            'interestConditionLabelText': '=',
            'interestConditionDataSource': '=',
            'interestConditionDisplayMembers': '@interestConditionDisplayMembers',
            'interestConditionValueMembers': '@interestConditionValueMembers',
            'interestRateLabelText' : '=',
            'termLabelText': '=',
            'termDataSource': '=',
            'termDisplayMembers': '@termDisplayMembers',
            'termValueMembers': '@termValueMembers',
            'creditTimeLabelText': '=', 
            'isSendTaxInvoiceLabelText': '=',
            'isSendTaxInvoiceTrueValue': '=',
            'isSendTaxInvoiceFalseValue': '=',
            'parentCompanyLabelText' : '=',
            'parentCompanyDataSource' : '=',
            'parentCompanyValueMembers': '@parentCompanyValueMembers',
            'parentCompanyDisplayMembers': '@parentCompanyDisplayMembers',
            'mlsLabelClass': "@mlsLabelClass",
            'mlsLabelStyle': "@mlsLabelStyle",
            'mlsInputClass': "@mlsInputClass",
            'mlsInputStyle': "@mlsInputStyle",
            'mlsInputContainerClass': "@mlsInputContainerClass",
            'mlsLabelContainerStyle': "@mlsLabelContainerStyle",
            'mlsLabelContainerClass': "@mlsLabelContainerClass",
            'mlsContainerStyle': "@mlsContainerStyle",
            'mlsContainerClass': "@mlsContainerClass",
            'mlsInputContainerStyle': "@mlsInputContainerStyle",
            'id': '@id',
            'title': '=',
            'readonly': '='

        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-account-financial1-supplier/template/mls-account-financial1-supplier.html"),
        link: function (scope, wraperElement, attrs, ctrl) {


        }

    };
}]);
