﻿appComponents.directive('mlsReferencePersonBox', ['mlsUrlSvc', 'comboBoxDataSvc', function (mlsUrlSvc, comboBoxDataSvc)
{
    return {
        restrict: "E",
        scope: { 
            'ngModel': '=' 
            ,'nameModel': '='
            ,'lastNameModel': '='
            ,'relationModel': '='
            , 'telNoModel': '='
            ,'titleNameModel' : '='
            ,'nameLabelText': '='
            ,'lastNameLabelText': '='
            ,'relationLabelText': '='
            ,'telNoLabelText': '='
            ,'titleNameLabelText' : '='
            ,'mlsLabelClass': "@mlsLabelClass"
            ,'mlsLabelStyle': "@mlsLabelStyle"
            ,'mlsInputClass': "@mlsInputClass"
            ,'mlsInputStyle': "@mlsInputStyle"
            ,'mlsInputContainerClass': "@mlsInputContainerClass" 
            ,'mlsLabelContainerStyle': "@mlsLabelContainerStyle"
            ,'mlsLabelContainerClass': "@mlsLabelContainerClass"
            ,'mlsContainerStyle': "@mlsContainerStyle"
            ,'mlsContainerClass': "@mlsContainerClass"
    		,'mlsInputContainerStyle': "@mlsInputContainerStyle"
            ,'relationDataSource': '='
            ,'relationDisplayMembers': '@'
            ,'relationValueMembers': '@'
            ,'customerTitleDataSource': '='
            ,'customerTitleDisplayMembers': '@'
            ,'customerTitleValueMembers': '@'
            ,'id': '@id'
            ,'title': '='
            , 'mlsColumnCount': "@mlsColumnCount"
            , 'readonly': '='
            ,'readonlyCustomerInfo' : '='

        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-reference-person-box/template/mls-reference-person-box.html"),
        link: function (scope, wraperElement, attrs, ctrl)
        { 
        }

       
    };
}]);
