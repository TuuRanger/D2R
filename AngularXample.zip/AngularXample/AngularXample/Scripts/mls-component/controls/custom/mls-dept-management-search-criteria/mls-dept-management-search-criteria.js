﻿appComponents.directive('mlsDeptManagementSearchCriteria', ['mlsUrlSvc', 'setupDataSvc', function (mlsUrlSvc, setupDataSvc)
{
    return {
        restrict: "E",
        scope: {  
            'model': '='
            ,'cpnCodLabelText' : '='
            ,'cpnBrnCodLabelText': '=' 
            ,'folStateLabelText': '='
            ,'overDueDayLabelText': '='
            ,'areaLabelText': '='
            ,'toLabelText': '='
            ,'cpnCodDataSource' :'='
            ,'cpnBrnCodDataSource': '=' 
            ,'folStateDataSource': '='
            ,'areaDataSource' :'='
            ,'mlsLabelClass': "@mlsLabelClass"
            ,'mlsLabelStyle': "@mlsLabelStyle"
            ,'mlsInputClass': "@mlsInputClass"
            ,'mlsInputStyle': "@mlsInputStyle"
            ,'mlsInputContainerClass': "@mlsInputContainerClass" 
            ,'mlsLabelContainerStyle': "@mlsLabelContainerStyle"
            ,'mlsLabelContainerClass': "@mlsLabelContainerClass"
            ,'mlsContainerStyle': "@mlsContainerStyle"
            ,'mlsContainerClass': "@mlsContainerClass"
    		,'mlsInputContainerStyle': "@mlsInputContainerStyle"
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-dept-management-search-criteria/template/mls-dept-management-search-criteria.html"),
    };
}]);
