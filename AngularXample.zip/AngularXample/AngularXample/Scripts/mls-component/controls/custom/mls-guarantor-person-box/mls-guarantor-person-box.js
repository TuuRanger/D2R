﻿appComponents.directive('mlsGuarantorPersonBox', ['mlsUrlSvc', function (mlsUrlSvc)
{
    return {
        restrict: "E",
        scope: {  
              'guarantorModel' : '='
            , 'idModel' : '='
            ,'idLabelText': '='
            ,'nameLabelText': '='
            ,'lastNameLabelText': '='
            ,'nickNameLabelText': '='
            ,'relationLabelText': '='
            ,'telNoLabelText': '='
            ,'titleNameLabelText': '='
            ,'relationYearLabelText': '='
            ,'addressLine1LabelText': '='
            ,'districtLabelText': '='
            ,'amphurLabelText': '='
            ,'provinceLabelText': '='
            ,'zipCodeLabelText': '='
            ,'phoneNoLabelText': '='
            ,'phoneEndNoLabelText': '='
            ,'phoneFromNoLabelText': '='
            ,'phoneExtNoLabelText': '='
            ,'referenceAddressLabelText': '='
            , 'addressTypeCodeLabelText': '='
            , 'customerTitleDataSource': '='
            ,'relationDataSource' : '='
            ,"guarantorAddressList" : '=' 
            ,"addressTypeCodeLabelText": '='
            ,"addressTypeCodeDataSource": '=' 
            ,"addressTypeCodeDisplayMembers" : '@addressTypeCodeDisplayMembers'
            ,"addressTypeCodeValueMembers": '@addressTypeCodeValueMembers'
            ,'mlsLabelClass': "@mlsLabelClass"
            ,'mlsLabelStyle': "@mlsLabelStyle"
            ,'mlsInputClass': "@mlsInputClass"
            ,'mlsInputStyle': "@mlsInputStyle"
            ,'mlsInputContainerClass': "@mlsInputContainerClass" 
            ,'mlsLabelContainerStyle': "@mlsLabelContainerStyle"
            ,'mlsLabelContainerClass': "@mlsLabelContainerClass"
            ,'mlsContainerStyle': "@mlsContainerStyle"
            ,'mlsContainerClass': "@mlsContainerClass"
            ,'addressInputClass': '@addressInputClass'
            ,'addressRequiredClass': '@addressRequiredClass'
    		,'mlsInputContainerStyle': "@mlsInputContainerStyle"
            ,'id': '@id'
            ,'title': '='
            ,'mlsColumnCount': "@mlsColumnCount"
            , 'readonly': '='
            , 'readonlyCustomerInfo' : '='
            ,'fnFindCustomerById' : '&'

        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-guarantor-person-box/template/mls-guarantor-person-box.html"),
        link: function (scope, wraperElement, attrs, ctrl)
        {
             
            scope.fnFindCustomerById = scope.fnFindCustomerById();
        }
    };
}]);
