﻿appComponents.directive('mlsIndividualCustomerInfoInput', ['mlsUrlSvc', function (mlsUrlSvc) {
    return {
        restrict: "E",
        scope: {
            'model': '='
            , 'idLabelText': '='
            , 'nameLabelText': '='
            , 'lastNameLabelText': '='
            , 'nickNameLabelText': '='
            , 'birthDateLabelText': '='
            , 'birthDayLabelText': '='
            , 'birthDayDisplayMembers': '@birthDayDisplayMembers'
            , 'birthDayValueMembers': '@birthDayValueMembers'
            , 'birthDayDataSource': '='
            , 'nickNameLabelText': '='
            , 'monthIncomeLabelText': '='
            , 'netIncomeLabelText': '='
            , 'mobileLabelText' : '='
            , 'titleNameLabelText': '='
            , 'titleNameDataSource': '='
            , 'titleNameDisplayMembers': '@titleNameDisplayMembers'
            , 'titleNameValueMembers': '@titleNameValueMembers'
            , 'mlsLabelClass': "@mlsLabelClass"
            , 'mlsLabelStyle': "@mlsLabelStyle"
            , 'mlsInputClass': "@mlsInputClass"
            , 'mlsInputStyle': "@mlsInputStyle"
            , 'mlsInputContainerClass': "@mlsInputContainerClass"
            , 'mlsLabelContainerStyle': "@mlsLabelContainerStyle"
            , 'mlsLabelContainerClass': "@mlsLabelContainerClass"
            , 'mlsContainerStyle': "@mlsContainerStyle"
            , 'mlsContainerClass': "@mlsContainerClass"
    		, 'mlsInputContainerStyle': "@mlsInputContainerStyle"
            , 'id': '@id'
            , 'readonly': '='
            , "fnFindCustomerById": '&'
           
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-individual-customer-info-input/template/mls-individual-customer-info-input.html"),
        link: function (scope, wraperElement, attrs, ctrl) {
            scope.fnFindCustomerById = scope.fnFindCustomerById();
        }
    };
}]);
