﻿appComponents.directive('mlsReferncePersonList', ['mlsUrlSvc','comboBoxDataSvc', function (mlsUrlSvc,comboBoxDataSvc)
{
    return {
        restrict: "E",
        scope: {  
            'referencePersonDataSource': '='
            ,'nameLabelText': '='
            ,'lastNameLabelText': '='
            ,'relationLabelText': '='
            ,'telNoLabelText': '='
            ,'titleNameLabelText' : '='
            ,'mlsLabelClass': "@mlsLabelClass"
            ,'mlsLabelStyle': "@mlsLabelStyle"
            ,'mlsInputClass': "@mlsInputClass"
            ,'mlsInputStyle': "@mlsInputStyle"
            ,'mlsInputContainerClass': "@mlsInputContainerClass" 
            ,'mlsLabelContainerStyle': "@mlsLabelContainerStyle"
            ,'mlsLabelContainerClass': "@mlsLabelContainerClass"
            ,'mlsContainerStyle': "@mlsContainerStyle"
            ,'mlsContainerClass': "@mlsContainerClass"
    		,'mlsInputContainerStyle': "@mlsInputContainerStyle"
            ,'id': '@id'
            ,'title': '='
            ,'mlsColumnCount': "@mlsColumnCount"
            ,'relationDataSource': '='
            ,'relationDisplayMembers': '@'
            ,'relationValueMembers': '@'
            ,'customerTitleDataSource': '='
            ,'customerTitleDisplayMembers': '@'
            ,'customerTitleValueMembers': '@'
            , 'readonly': '='
            , 'panelContainerClass': '@'
            , 'model': '=' 
            , 'fnSearchCustomer': '&' 
        },  
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-reference-person-list/template/mls-reference-person-list.html"),
        link: function (scope, wraperElement, attrs, ctrl)
        { 
            scope.fnSearchCustomer = scope.fnSearchCustomer();

            scope.model = scope.model || {
                deleteList: [],
                addList: [],
            };

            if (scope.model) {
                if (!scope.model.hasOwnProperty('deleteList')) {
                    scope.model.deleteList = [];
                }

                if (!scope.model.hasOwnProperty('addList')) {
                    scope.model.addList = [];
                }
            }

            scope.index = 0;
            scope.delete = function (obj)
            {
                obj.RECACTCOD = 'I'
                scope.model.deleteList.push(angular.copy(obj));
                var idx = scope.referencePersonDataSource.indexOf(obj);
                if (idx !== -1) {
                    scope.referencePersonDataSource.splice(idx, 1);
                }
            }

            scope.add = function ()
            {
                scope.referencePersonDataSource = scope.referencePersonDataSource || []; 
                var ref = { RECACTCOD: 'A' };
                ref.open = true;
                scope.referencePersonDataSource.push(ref);
            }

        }
    };
}]);
