﻿appComponents.controller('mlsAppSendBackDialogController', ['$scope', 'dialogParam', 'mlsDialog', function ($scope, dialogParam, mlsDialog) {
 
    $scope.txtRemarkLabelText = dialogParam.txtRemarkLabelText;
    $scope.model = { 
        remark: dialogParam.remark
    };
     
    $scope.onOK = function ()
    {
        var form = $("#frmEntry");
        if (form.valid())
        {
            var confirmReject = mlsDialog.showConfirmDialog({ message: "Are you sure do you want to 'Send Back' this case?" })
            confirmReject.then(function () {
                $scope.confirm({ dialogModel: $scope.model })
            })
        }
       
    }

    $scope.validationOptions = {
        rules: {
            txtRemark: {
                required: true,
            }
        }
    } 
}])

appComponents.factory('mlsAppSendBackDialog', ['mlsDialog', 'mlsUrlSvc', '$q', function (mlsDialog, mlsUrlSvc, $q) {
    var service = {}; 
    service.show = function (params) { 
        
        var promise = mlsDialog.showCustomDialog({}, { 
            template: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-send-back-dialog/template/mls-send-back-dialog.html"),
            controller: "mlsAppSendBackDialogController",
            className: 'ngdialog-theme-default dialog-medium',
            closeByDocument: false,
            showClose: false,
            closeByEscape: false,
            resolve : {
                "dialogParam": function () {
                    return { 
                        "txtRemarkLabelText": params.txtRemarkLabelText,
                    };
                }
            }
        }, null);

        return promise
    } 
    return service;

}]);