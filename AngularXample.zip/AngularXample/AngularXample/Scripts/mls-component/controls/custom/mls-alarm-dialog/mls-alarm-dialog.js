﻿appComponents.controller('mlsAlarmDialogController', ['$scope', 'dialogParam', 'mlsDialog', 'eBiz', function ($scope, dialogParam, mlsDialog, eBiz) {
    $scope.title = dialogParam.title; 
    $scope.model = {
        alarmDate: new Date(),
        message : dialogParam.message
    };

    $scope.onOK = function ()
    {
        var form = $("#frmEntry");
        if (form.valid())
        {
            var confirmReject = mlsDialog.showConfirmDialog({ message: "Are you sure do you want to 'Save data'?" })
            confirmReject.then(function () {
                $scope.confirm({ dialogModel: $scope.model })
            })
        }
       
    }

    $scope.validationOptions = {
        rules: {
            txtRejectRemark: {
                required: true,
            },
            dtpAlarmDate: {
                required: true,
                notEarlyThan: function () { return new Date()}
            }
        }
    } 
}])

appComponents.factory('mlsAlarmDialog', ['mlsDialog', 'mlsUrlSvc', '$q', function (mlsDialog, mlsUrlSvc, $q) {
    var service = {}; 
    service.show = function (params) { 
        
        var promise = mlsDialog.showCustomDialog({}, { 
            template: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-alarm-dialog/template/mls-alarm-dialog.html"),
            controller: "mlsAlarmDialogController",
            className: 'ngdialog-theme-default dialog-medium',
            closeByDocument: false,
            showClose: false,
            closeByEscape: false,
            resolve : {
                "dialogParam": function () {
                    return {
                        "title": params.title,
                        "message": params.message
                    };
                }
            }
        }, null);

        return promise
    } 
    return service;

}]);