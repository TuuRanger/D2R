﻿appComponents.directive('mlsDynamicInputList', ['mlsUrlSvc', 'setupDataSvc', function (mlsUrlSvc, setupDataSvc)
{
    return {
        restrict: "E",
        scope: {  
            'inputListDataSource': '='
            ,'column':'='
            ,'model': '=' 
            ,'mlsLabelClass': "@mlsLabelClass"
            ,'mlsLabelStyle': "@mlsLabelStyle"
            ,'mlsInputClass': "@mlsInputClass"
            ,'mlsInputStyle': "@mlsInputStyle"
            ,'mlsInputContainerClass': "@mlsInputContainerClass" 
            ,'mlsLabelContainerStyle': "@mlsLabelContainerStyle"
            ,'mlsLabelContainerClass': "@mlsLabelContainerClass"
            ,'mlsContainerStyle': "@mlsContainerStyle"
            ,'mlsContainerClass': "@mlsContainerClass"
    		,'mlsInputContainerStyle': "@mlsInputContainerStyle"
            ,'readonly':'='
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-dynamic-input-list/template/mls-dynamic-input-list.html"),
        link: function (scope, wraperElement, attrs, ctrl)
        {
            
            scope.column = scope.column || 2; 
            scope.inputList = [];
            
            scope.$watch('inputListDataSource', function ()
            {
                var i = 0;
                if (!scope.inputListDataSource)
                {
                    scope.inputList = [];
                    return
                }
                else if (scope.inputListDataSource.length == 0)
                {
                    scope.inputList = [];
                    return
                }
                   

                angular.forEach(scope.inputListDataSource, function (item, key) { 
                    if (item.ControlType == "mlsAutoComplete") {
                        item.fnRequestFormatter = function (str) {
                            var field = item.AutoCompleteConditionFiledCSV.split(",")
                            if (field.length > 0) {
                                var param = {};
                                for (var j = 0 ; j < field.length ; j++) {
                                    param[field[j]] = str;
                                }
                                return param;
                            }
                            return {};
                        }
                    }

                    if ((i + 1) % scope.column != 0) {
                        var rowItem = []
                        var alreadyExist = false;
                        for (var col = 0 ; col < scope.column ; col++) { 
                            for (var k = 0 ; k < this.length ; k++) {
                                var tempRowItem = this[k];
                                if (scope.inputListDataSource[i + col]) {
                                    var temp = tempRowItem.filter(function (item) {
                                        return item.Seq == scope.inputListDataSource[i + col].Seq
                                    })
                                }
                                else {
                                    break;
                                }

                                if (temp.length > 0) {
                                    alreadyExist = true;
                                    break;
                                }
                            }

                            if (!alreadyExist) {
                                if (scope.inputListDataSource[i + col]) {
                                    rowItem.push(scope.inputListDataSource[i + col])
                                }
                            }
                            else {
                                break;
                            }
                        }
                        this.push(rowItem);
                    }
                    i++;
                }, scope.inputList);
            })
           

        }
    };
}]);
