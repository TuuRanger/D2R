﻿appComponents.directive('mlsInvoiceListSearchCriteria', ['mlsUrlSvc', function (mlsUrlSvc) {
    return {
        restrict: "E",
        scope: {
            'model': '=',
            'dateFormat': '=',
            'invoiceStatusLabelText': '=',
            'invoiceStatusDataSource': '=',
            'invoiceStatusDisplayMembers': '@invoiceStatusDisplayMembers',
            'invoiceStatusValueMembers': '@invoiceStatusValueMembers',
            'supplierNameLabelText': '=', 
            'invoiceDateFromLabelText': '=',
            'invoiceDateToLabelText': '=',
            'dueDateFromLabelText': '=',
            'dueDateToLabelText' :'=',
            'mlsLabelClass': "@mlsLabelClass",
            'mlsLabelStyle': "@mlsLabelStyle",
            'mlsInputClass': "@mlsInputClass",
            'mlsInputStyle': "@mlsInputStyle",
            'mlsInputContainerClass': "@mlsInputContainerClass",
            'mlsLabelContainerStyle': "@mlsLabelContainerStyle",
            'mlsLabelContainerClass': "@mlsLabelContainerClass",
            'mlsContainerStyle': "@mlsContainerStyle",
            'mlsContainerClass': "@mlsContainerClass",
            'mlsInputContainerStyle': "@mlsInputContainerStyle",
            'id': '@id',
            'readonly': '=',
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-invoice-list-search-criteria/template/mls-invoice-list-search-criteria.html"),
        link: function (scope, wraperElement, attrs, ctrl) {
        }
    };
}]);
