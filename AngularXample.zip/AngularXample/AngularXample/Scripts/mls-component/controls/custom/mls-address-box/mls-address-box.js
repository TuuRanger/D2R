﻿appComponents.directive('mlsAddressBox', ['mlsUrlSvc', 'provinceDataSvc', 'amphurDataSvc', 'zipCodeDataSvc', 'arrayHelper', '$timeout','$rootScope','mlsStringUtils',
function (mlsUrlSvc, provinceDataSvc, amphurDataSvc, zipCodeDataSvc, arrayHelper, $timeout, $rootScope, mlsStringUtils)
{
    return {
        restrict: "E",
        scope: {  
             'addressLine1': '='
            ,'district': '='
            ,'amphur': '='
            ,'province':'='
            ,'zipCode' : '='
            ,'phoneNo': '='
            ,'phoneFromNo': '='
            ,'phoneEndNo': '='
            ,'phoneExtNo': '=' 
            ,'addressCode': '='
            ,'addressTypeCode': '='
            ,'addressTypeDesc' : '='
            ,'addressRefCode': '='
            ,'addressLine1LabelText': '='
            ,'districtLabelText'    : '='
            ,'amphurLabelText'      : '='
            ,'provinceLabelText'    : '='
            ,'zipCodeLabelText'     : '='
            ,'phoneNoLabelText': '='
            ,'phoneEndNoLabelText': '='
            ,'phoneFromNoLabelText': '='
            ,'phoneExtNoLabelText': '='
            ,'referenceAddressLabelText': '='
            ,'addressTypeCodeLabelText': '='
            ,'adrReferenceDataSource': '='
            ,'adrReferenceValueMembers': '@'
            ,'adrReferenceDisplayMembers': '@'
            ,'adrReferenceSelectorMembers': '@'
            ,'addressTypeCodeDataSource': '='
            ,'showAddressRefCode' : '='
            ,'addressTypeCodeValueMembers': '@'
            ,'addressTypeCodeDisplayMembers': '@'
            ,'mlsLabelClass': "@mlsLabelClass"
            ,'mlsLabelStyle': "@mlsLabelStyle"
            ,'mlsInputClass': "@mlsInputClass"
            ,'mlsInputStyle': "@mlsInputStyle"
            ,'mlsInputContainerClass': "@mlsInputContainerClass" 
            ,'mlsLabelContainerStyle': "@mlsLabelContainerStyle"
            ,'mlsLabelContainerClass': "@mlsLabelContainerClass"
            ,'mlsContainerStyle': "@mlsContainerStyle"
            ,'mlsContainerClass': "@mlsContainerClass"
    		,'mlsInputContainerStyle': "@mlsInputContainerStyle"
            , 'requiredClass': "@requiredClass"
            ,'id': '@id'
            , 'title': '='
            , 'readonly': '='
            ,'addressTypeDesc' :'='

        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-address-box/template/mls-address-box.html"),
        link: function (scope, wraperElement, attrs, ctrl)
        {
             
            scope.districtUrlRequestFormatter = function (str)
            {
                return { districtName: str };
            }

            scope.amphurUrlRequestFormatter = function (str)
            {
                return { aumphurName: str };
            }

            scope.provinceUrlRequestFormatter = function (str)
            {
                return { provinceName: str };
            }

            scope.zipCodeUrlRequestFormatter = function(str)
            {
                return { zipCode : str}
            }

            scope.$watch('addressRefCode', function (newVal, oldVal, scope)
            { 
            })

            scope.$watch('addressTypeCode', function (newVal, oldVal, scope)
            {
                if (scope.addressTypeCodeDataSource && newVal)
                {
                    var result = scope.addressTypeCodeDataSource.whereAnd([{ TABKEYTWO: newVal }])
                    if (result.length > 0)
                    {
                        scope.addressTypeDesc = result[0].TABDSCTHA;
                    }

                }
                else
                {
                    scope.addressTypeDesc = "ยังไม่ได้เลือกประเภทที่อยู่"
                }

            })
                         
            scope.$watch('districtSelectedObject', function (newVal, oldVal, scope)
            { 
                if (newVal != oldVal && (newVal))
                { 
                    var oDistrict = newVal.originalObject;
                     
                    if (mlsStringUtils.toStringOrEmpty(scope.amphur) == "")
                    {
                        amphurDataSvc.getAumphurByID({ amhurId: oDistrict.AMPHUR_ID }).then(function (data)
                        {
                            console.log("AMPHUR.length : " + data.length)
                            if (data.length > 0)
                            {
                                console.log("data.AMPHUR_NAME : " + data[0].AMPHUR_NAME)
                                scope.amphur = data[0].AMPHUR_NAME
                            }
                        })
                    }


                    if (mlsStringUtils.toStringOrEmpty(scope.province) == "")
                    {
                        provinceDataSvc.getProvinceByID({ provinceID: oDistrict.PROVINCE_ID }).then(function (data)
                        {
                            console.log("PROVINCE.length : " + data.length)
                            if (data.length > 0)
                            {
                                console.log("data.PROVINCE_NAME : " + data[0].PROVINCE_NAME)
                                scope.province = data[0].PROVINCE_NAME
                            }
                        })
                    }
                     
                    if (mlsStringUtils.toStringOrEmpty(scope.zipCode) == "")
                    {
                        zipCodeDataSvc.getZipCode({
                            districtID: oDistrict.DISTRICT_ID,
                            amphurID: oDistrict.AMPHUR_ID,
                            provinceID: oDistrict.PROVINCE_ID
                        }).then(function (data)
                        {
                            console.log("ZIPCODE.length : " + data.length)
                            if (data.length > 0)
                            {
                                console.log("data.ZIPCODE : " + data[0].ZIPCODE)
                                scope.zipCode = data[0].ZIPCODE
                            }
                        })
                    } 
                } 
            },true)

            scope.$watch('amphurSelectedObject', function (newVal, oldVal, scope)
            {
                if (newVal != oldVal)
                {
                    console.log(newVal);
                }
            })

            scope.$watch('provinceSelectedObject', function (newVal, oldVal, scope)
            {
                if (newVal != oldVal)
                {
                    console.log(newVal);
                }
            })

            scope.$watch('zipCodeSelectedObject', function (newVal, oldVal, scope)
            {
                if (newVal != oldVal)
                {
                    console.log(newVal);
                }
            })

           
        }
        
    };
}]);
