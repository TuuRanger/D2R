﻿appComponents.directive('mlsAppListSearchCriteria', ['mlsUrlSvc', 'setupDataSvc', function (mlsUrlSvc, setupDataSvc)
{
    return {
        restrict: "E",
        scope: {  
            'model': '='
            ,'idLabelText': '='
            ,'nameLabelText': '='
            ,'surnameLabelText': '='
            ,'conApplyProjecLabelText': '='
            ,'genAppNumLabelText': '='
            ,'mlsLabelClass': "@mlsLabelClass"
            ,'mlsLabelStyle': "@mlsLabelStyle"
            ,'mlsInputClass': "@mlsInputClass"
            ,'mlsInputStyle': "@mlsInputStyle"
            ,'mlsInputContainerClass': "@mlsInputContainerClass" 
            ,'mlsLabelContainerStyle': "@mlsLabelContainerStyle"
            ,'mlsLabelContainerClass': "@mlsLabelContainerClass"
            ,'mlsContainerStyle': "@mlsContainerStyle"
            ,'mlsContainerClass': "@mlsContainerClass"
    		,'mlsInputContainerStyle': "@mlsInputContainerStyle"
        },
        templateUrl: mlsUrlSvc.getUrlContent("/Scripts/mls-component/controls/custom/mls-app-list-search-criteria/template/mls-app-list-search-criteria.html"),
        link: function (scope, wraperElement, attrs, ctrl)
        {
            
            scope.initialConApplyProjec = function ()
            {
                setupDataSvc.getSetup({ TABKEYONE: "CONAPPLY_PROJEC" }).then(function (data)
                {
                    scope.conApplyProjectDataSource = data;
                })
            }

            scope.InitialComponent = function ()
            {
                scope.initialConApplyProjec(); 
            }

            scope.InitialComponent();
        }
    };
}]);
