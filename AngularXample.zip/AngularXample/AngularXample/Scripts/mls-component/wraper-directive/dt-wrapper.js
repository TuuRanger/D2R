﻿appComponents.directive('dtWrapper', ['$timeout', '$window', function ($timeout, $window)
{
    return function link($scope, $elm, $attr)
    { 
        $scope.refreshColHeader = function() 
        {
            $timeout(function ()
            {
                    
                var colhead = $($($elm[0]).find(".dataTables_scrollHeadInner")[0])
                var table = $(colhead.find(".dataTable")[0])

                var colFooter = $($($elm[0]).find(".dataTables_scrollFootInner")[0])
                var footTable = $(colFooter.find(".table")[0])

                
                table.css("width", "100%");
                colhead.css("width", "100%"); 
                colFooter.css("width", "100%"); 
                footTable.css("width", "100%");
              
                var table = $($($elm[0]).find("table[id]")[0])
                var tds = table.find('tbody tr:first-child td')
                var ths = table.find('thead tr:first-child th')
                var sumWidth = 0;

                colhead.css("width", table.outerWidth() + 'px');
                footTable.css("width", table.outerWidth() + 'px');

                console.log(table.attr('id'))
                //for (var i = 0 ; i < tds.length ; i++)
                //{
                //    //debugger
                //    sumWidth += $(tds[i]).width();
                //    $(ths[i]).css('width', $(tds[i]).width() + 'px');
                    
                //}
     
                ////debugger 
            }, 1000)
        }   

        $scope.$watch(tableDataLoaded, function (isTableDataLoaded)
        {
            if (isTableDataLoaded)
            {
                $scope.refreshColHeader();
            }
        });

        function tableDataLoaded()
        {
            // first cell in the tbody exists when data is loaded but doesn't have a width
            // until after the table is transformed
            var firstCell = $($($elm[0]).find("table[id]")[0]).find('tbody tr:first-child td:first-child');
             
            return firstCell[0];
        }

        var w = angular.element($window);
        w.bind('resize', function ()
        { 
            $scope.refreshColHeader(); 
        })

        $scope.refreshColHeader();
    };
}]);

appComponents.directive('fixedTableHeaders', ['$timeout', function ($timeout)
{
    return {
        restrict: 'A',
        link: function (scope, element, attrs)
        {
            $timeout(function ()
            {
                var container = element.parentsUntil(attrs.fixedTableHeaders);
                element.stickyTableHeaders({ scrollableArea: container, "fixedOffset": 2 });
            }, 0);
        }
    }
}]);