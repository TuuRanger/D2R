﻿uiSelectWrap.$inject = ['$document', 'uiGridEditConstants'];
function uiSelectWrap($document, uiGridEditConstants)
{
    return function link($scope, $elm, $attr)
    {
        $document.on('click', docClick);

        function docClick(evt)
        { 
            if ($(evt.target).closest('.k-state-hover').length === 0) {
                $scope.$emit(uiGridEditConstants.events.END_CELL_EDIT);
                $document.off('click', docClick);
            }
        }
    };
}
appComponents.directive('girdCellWraper', uiSelectWrap)