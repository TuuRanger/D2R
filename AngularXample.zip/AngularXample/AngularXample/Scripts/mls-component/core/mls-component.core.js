﻿'use strict';
var appComponents = angular.module("mls.components", [
    "kendo.directives",
    'ngDialog',
    'angucomplete-alt',
    'ui.bootstrap.contextMenu',
    'ui-notification',
    'ui.grid',
    'ui.grid.edit',
    'ui.grid.cellNav',
    'ui.grid.rowEdit',  
    'ui.grid.resizeColumns',
    'ui.grid.selection',
    'ui.grid.autoResize',
    'ui.grid.pagination',
    'ui.grid.treeView',
    'ui.grid.expandable',
    'ui.grid.pinning',
    'ui.grid.validate',
    'jsonFormatter',
    'angularFileUpload',
    'highcharts-ng'
]);

appComponents.value('componentContext', {
    rootUrl: '',
    showLog: true, 
});

appComponents.factory('mlsRegExp', function () {
    var RegExList = {
        onlyNumeric: "^[0-9]+$",
        homeTel: "^[0-9]{2}-[0-9]{3}-[0-9]{4}$|^[0-9]{9}$",
        mobileTel: "^[0-9]{3}-[0-9]{3}-[0-9]{4}$|^[0-9]{10}$",
        isoDateString: "^[0-9]{4}-[0-9]{2}-[0-9]{2}[T][0-9]{2}:[0-9]{2}:[0-9]{2}$",
        isoDateString2: "^[0-9]{4}-[0-9]{2}-[0-9]{2}[T][0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{2}$",
        isoDateString3: "^[0-9]{4}-[0-9]{2}-[0-9]{2}[T][0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}$"
    }

    var TestRegEx = function (regString, value) {
        var reg = new RegExp(regString);
        return reg.test(value);
    };

    var isTelNoFormat = function (value) {
        return isHomeTelFormat(value) || isMobileTelFormat(value);
    };

    var isISODateString = function (value) {
        return TestRegEx(RegExList.isoDateString, value) || TestRegEx(RegExList.isoDateString2, value) || TestRegEx(RegExList.isoDateString3, value);
    }

    var isHomeTelFormat = function (value) {
        return TestRegEx(RegExList.homeTel, value);
    };

    var isMobileTelFormat = function (value) {
        return TestRegEx(RegExList.mobileTel, value);
    };

    return {
        isTelNoFormat: isTelNoFormat,
        isISODateString: isISODateString
    }
});
