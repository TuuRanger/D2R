﻿appComponents.directive('onContextMenuOpen', function ($parse) {
    return function (scope, element, attrs) {
        var fn = $parse(attrs.onContextMenuOpen);
        element.bind('contextmenu', function (event) {
            scope.$apply(function () {
                event.preventDefault(); 
                fn(scope, { $event: event });
            });
        });
    };
});