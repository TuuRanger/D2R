﻿appComponents.filter("decimal", [function ()
{ // register new filter

    return function (input)
    {  
        return (input || 0).toMoneyFormat();
    };
}]);


