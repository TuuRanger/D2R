﻿appComponents.filter("domainUrl", ['mlsUrlSvc', function (mlsUrlSvc)
{ // register new filter

    return function (input)
    {
        return mlsUrlSvc.getUrlContent(input) 
    };
}]);


appComponents.filter("apiUrl", ['mlsUrlSvc', function (mlsUrlSvc)
{ // register new filter

    return function (input)
    {
        return mlsUrlSvc.getApiUrlContent(input)
    };
}]);


