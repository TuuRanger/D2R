﻿appComponents.filter("toStringOrEmpty", 'mlsStringUtils', function (mlsStringUtils)
{ // register new filter

    return function (input)
    {  
        return mlsStringUtils.toStringOrEmpty(input)
    };
});


