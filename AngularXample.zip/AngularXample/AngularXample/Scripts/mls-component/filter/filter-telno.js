﻿appComponents.filter("telno", ['mlsStringUtils', function (mlsStringUtils)
{ // register new filter

    return function (input)
    {  
        var unFormated = mlsStringUtils.unformatTel(input)
        return mlsStringUtils.toTelFormat(unFormated)
    };
}]);


