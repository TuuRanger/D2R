﻿appComponents.filter("displaydate", ['$filter', function ($filter)
{ // register new filter

    return function (input, format, isBuddhist)
    {
        if (input)
        {
            var dateObject = input.toDate(format);
            if (dateObject)
            {
                dateDisplay = dateObject;
                if (dateObject.getFullYear() > 2400)
                {
                    dateObject = new Date(dateObject.getFullYear() - 543, dateObject.getMonth(), dateObject.getDate(), dateObject.getHours(), dateObject.getMinutes(), dateObject.getSeconds(), dateObject.getMilliseconds())
                }


                if (isBuddhist == true) /*for Buddhist year*/
                {
                    dateDisplay = new Date(dateObject.getFullYear() + 543, dateObject.getMonth(), dateObject.getDate(), dateObject.getHours(), dateObject.getMinutes(), dateObject.getSeconds(), dateObject.getMilliseconds())
                }
                return $filter('date')(dateDisplay, format, null)
            }
        }
        return '';
     
    };
     
}]);


