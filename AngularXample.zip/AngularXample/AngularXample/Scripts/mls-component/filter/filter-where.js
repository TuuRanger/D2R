﻿appComponents.filter("where", function ()
{ // register new filter

    return function (input, vals, props)
    { // filter arguments 
        var arr = input;
        var result = arr;
        for (var i = 0 ; i < props.length ; i++) {
            result = result.filter(function (item)
            {
                return item[props[i]] == vals[i]
            })

            if (result.length > 0)
                continue
            else
                break;
        }

        if (result.length > 0) {
            return result[0]
        }
        else {
            if (arr.length > 0) {
                var emtypObj = {}
                for (var attr in arr[0]) {
                    if (arr[0].hasOwnProperty(attr)) {
                        emtypObj[attr] = null;
                    }
                }

                return emtypObj
            }
            return {}

        }
    };
});


