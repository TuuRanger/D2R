﻿(function (window)
{
    if (!window.Array.prototype.last)
    {
        window.Array.prototype.last = function ()
        {
            return this[this.length - 1];
        };
    };

    if (!window.Array.prototype.first)
    {
        window.Array.prototype.first = function ()
        {
            return this[0];
        };
    };

    if (!window.Array.prototype.whereAnd)
    {
        window.Array.prototype.whereAnd = function (arrCriteria)
        {
            var result = this.slice();

            for (var i = 0 ; i < arrCriteria.length ; i++)
            { 
                result = result.filter(function (item)
                {
                    for (var prop in arrCriteria[i])
                    {
                        return item[prop] == arrCriteria[i][prop]
                    } 
                })

                if (result.length > 0)
                    continue
                else
                    break;
            }

            if (result.length > 0)
            {
                return result
            }
            else
            {
                //if (this.length > 0)
                //{
                //    var emtypObj = {}
                //    for (var prop in this[0])
                //    {
                //        if (this[0].hasOwnProperty(prop))
                //        {
                //            emtypObj[prop] = null;
                //        }
                //    }

                //    return [emtypObj]
                //}
                return []
            }
        }
    }

    if (!window.Array.prototype.whereOr)
    {
        window.Array.prototype.whereOr = function (arrCriteria)
        { 
            var result = [];
            var arr = this.slice();

            for (var i = 0 ; i < arrCriteria.length ; i++)
            { 
                var filterResult = arr.filter(function (item)
                { 
                    for (var prop in arrCriteria[i])
                    {
                        return item[prop] == arrCriteria[i][prop]
                    }

                })
                
                if (filterResult.length > 0)
                {
                    result = $.merge(result, filterResult)
                }
            }
 

            if (result.length > 0)
            {
                return result
            }
            else
            {
                //if (this.length > 0)
                //{
                //    var emtypObj = {}
                //    for (var prop in this[0])
                //    {
                //        if (this[0].hasOwnProperty(prop))
                //        {
                //            emtypObj[prop] = null;
                //        }
                //    }

                //    return emtypObj
                //}
                return []
            }
        }
    }


    if (!window.Array.prototype.range) {
        window.Array.prototype.range = function (property, min, max) {
            return this.filter(function (item) {
                return item[property] >= min && item[property] <= max;
            });
        }
    }


    if (!window.Array.prototype.min) {
        window.Array.prototype.min = function (property) {
            var temp = this[0][property];
            var result = this[0];
            for (var i = 1 ; i < this.length ; i++)
            {
                if (this[i][property] < temp) {
                    result = this[i];
                    temp = this[i][property];
                } 
            }
            return result
        }
    }

    if (!window.Array.prototype.max) {
        window.Array.prototype.max = function (property) {
            var temp = this[0][property];
            var result = this[0];
            for (var i = 1 ; i < this.length ; i++) {
                if (this[i][property] > temp) {
                    result = this[i];
                    temp = this[i][property];
                }
            }
            return result
        }
    }


     
})(window);
