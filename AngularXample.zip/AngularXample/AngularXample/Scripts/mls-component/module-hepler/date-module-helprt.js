﻿(function (window)
{
    if (!Date.prototype.toISODateString)
    {
        Date.prototype.toISODateString = function ()
        { 
            return this.getFullYear() + "-" + (this.getMonth()+ 1).padLeft("0", 2) + "-" + this.getDate().padLeft("0", 2) +
                "T" + this.getHours().padLeft("0", 2) + ":" + this.getMinutes().padLeft("0", 2) + ":" + this.getSeconds().padLeft("0", 2) + "." + this.getMilliseconds().padLeft("0", 3)
        };
    };
      
})(window);
