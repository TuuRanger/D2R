﻿(function (window)
{
    if (!Number.prototype.isEmpty)
    {
        Number.prototype.isEmpty = function ()
        {
            if (this == undefined || this == null)
                return true; 
            return false;
        };
    };

    if (!Number.prototype.toDecimalOrZero)
    {
        Number.prototype.toDecimalOrZero = function ()
        {
            return parseFloat(this);
        };
    };
     
    if (!Number.prototype.toMoneyFormat)
    {
        Number.prototype.toMoneyFormat = function (decimalPlace)
        {
            if (this == null || this == 0 || this == undefined)
                return "0.00"

            if (!decimalPlace)
                decimalPlace = 2
            return accounting.formatMoney(parseFloat(this), "", 2, ",", ".")
        }
    }
    

    if (!Number.prototype.padLeft)
    {
        Number.prototype.padLeft = function (str, n)
        {
            return (this < 0 ? '-' : '') +
            Array(n - String(Math.abs(this)).length + 1)
             .join(str || '0') +
           (Math.abs(this));
        }
    }

    if(!Number.prototype.round)
    {
        Number.prototype.round = function(digit)
        {
            digit = digit || 0
            var multiplier = "1";
            for(var i = 0 ; i < digit ; i++)
            {
                multiplier += "0";
            }

            multiplier = parseFloat(multiplier);

            return Math.round(this * multiplier) / multiplier
        }
    }

    if (!Number.prototype.getTaxByGross)
    {
        Number.prototype.getTaxByGross = function (taxPercent)
        {
            var divisor = 100 + taxPercent;
            return (this * taxPercent / divisor).round(2)
        }
    }

    if (!Number.prototype.getTaxByNet)
    {
        Number.prototype.getTaxByNet = function (taxPercent)
        {
            var divisor = 100;
            return (this * taxPercent / divisor).round(2)
        }
    }




})(window);
