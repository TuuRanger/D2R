﻿
(function (window)
{
     
    if (!window.Boolean.prototype.boolToYesNoFlag)
    {
        window.Boolean.prototype.boolToYesNoFlag = function ()
        { 
             return this ? "Y" : "N" 
        }
    }


     
})(window);
