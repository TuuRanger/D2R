﻿(function (window)
{

    var RegExList = {
        onlyNumeric: "^[0-9]+$",
        homeTel: "^[0-9]{2}-[0-9]{3}-[0-9]{4}$|^[0-9]{9}$",
        mobileTel: "^[0-9]{3}-[0-9]{3}-[0-9]{4}$|^[0-9]{10}$",
        isoDateString: "^[0-9]{4}-[0-9]{2}-[0-9]{2}[T][0-9]{2}:[0-9]{2}:[0-9]{2}$"
    }


    if (!String.prototype.TestRegEx)
    {
        String.prototype.TestRegEx = function (regString)
        {
            var reg = new RegExp(regString);
            return reg.test(this);
        };

    } 

    if (!String.prototype.isHomeTelFormat)
    {
        String.prototype.isHomeTelFormat = function ()
        {
            return this.TestRegEx(RegExList.homeTel);
        };
    }


    if (!String.prototype.isMobileTelFormat)
    {
        String.prototype.isMobileTelFormat = function ()
        {
            return this.TestRegEx(RegExList.mobileTel);
        };
    }

    if (!String.prototype.isTelNoFormat)
    {
        String.prototype.isTelNoFormat = function ()
        {
            return this.isHomeTelFormat() || this.isMobileTelFormat();
        };
    }
     

    if (!String.prototype.isISODateString)
    {
        
        String.prototype.isISODateString = function ()
        { 
            return this.TestRegEx(RegExList.isoDateString) || this.TestRegEx(RegExList.isoDateString2) || this.TestRegEx(RegExList.isoDateString3);
        }
    }
     

    if (!String.prototype.isEmpty)
    {
        String.prototype.isEmpty = function ()
        {
            if (this == undefined || this == null)
                return true;
            if (this.trim() == "")
                return true
            return false;
        };
    };

    if (!String.prototype.toDecimalOrZero)
    {
        String.prototype.toDecimalOrZero = function ()
        {
            if (!isNaN(this.unformatMoney()) && this.trim() != "")
            {
                return parseFloat(this.unformatMoney())
            }
            else
            {
                return 0
            }
        };
    };

    if (!String.prototype.unformatMoney)
    {
        String.prototype.unformatMoney = function ()
        {
            return parseFloat(this.replace(/[^0-9\.]+/g, ""))
        }
    }

    if (!String.prototype.toMoneyFormat)
    {
        String.prototype.toMoneyFormat = function (decimalPlace)
        {
            if (this == null || this == 0 || this == undefined)
                return "0.00";
            if (isNaN(this.unformatMoney()))
            {
                return "0.00";
            }

            if (!decimalPlace)
                decimalPlace = 2
            return accounting.formatMoney(parseFloat(this.unformatMoney()), "", 2, ",", ".")
        }
    }

     

    if (!String.prototype.parseIsoDatetime)
    {
        String.prototype.parseIsoDatetime = function ()
        { 
            var dt = this.split(/[: T-]/).map(parseFloat);
            return new Date(dt[0], dt[1] - 1, dt[2], dt[3] || 0, dt[4] || 0, dt[5] || 0, 0);
        }
    }

    if (!String.prototype.toDate)
    {
        String.prototype.toDate = function (format)
        { 
            if (this.isISODateString()) /*for first load from database*/
            {
                dateObject = this.parseIsoDatetime();
            }
            else
            {
                dateObject = kendo.parseDate(this, format);
            }
            return dateObject;
        }
    }

    if(!String.prototype.padLeft)
    {
        String.prototype.padLeft = function (str, n)
        {
            return Array(n - String(this).length + 1).join(str || '0') + this;
        }
    }



})(window);
