﻿appComponents.value('mainAppContext',
{
    currentScreenID: null,
    globalResourList: {},
    mlsApiUrl: '/mls.api/api',
    userProfile: {
        userName: null,
        selectedLang: null
    },
    menuList : null,
    screenResouceList: null,
    userToken: null,
    sysLanguageList: null,
    setCurrentScreen: function (screenID)
    {
        this.currentScreenID = screenID;

    },
    setCurrentLanguage: function (lang, flag)
    {
        this.userProfile.selectedLang = lang
        angular.element("#langSelected").html('<span class="flag-icon flag-icon-' + flag + '"></span>') 
    },
    getDialogMessage: function (messageCode)
    {
        var message =  this.globalResourList.listDialogMsg[messageCode]
        return {
            MessageCode: messageCode,
            Message: message
        }
    },
    getValidateMessage: function (messageCode)
    {
        var message = this.globalResourList.listValidateMsg[messageCode]
        return {
            MessageCode: messageCode,
            Message: message
        }
    },
    getMLSApiUrlContent : function(url){
        return this.mlsApiUrl + url
    },
    getMenuList : function()
    {
        return this.menuList;
    },
    setMenuList: function (menuList)
    {
        this.menuList = menuList;
    },
    getUserToken: function (userToken) {
        return this.userToken 
    }, 
    setUserToken: function (userToken) {
        this.userToken = userToken;
    },
    getLaguageInfo: function (languageCode)
    { 
       var result =  this.sysLanguageList.filter(function (item) {
           return item.TABKEYTWO == languageCode
       })
       return result
    },
    template: {
        uiGridSumFooter: '/Template/grid/grid-columns/ui-grid-sum-footer.html'
    }
     
});


