﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AngularXample.Models
{
    public class ScreenProperty
    {
         public String DefaultContainerClass { get; set; }
         public String DefaultLabelContainerClass { get; set; }
         public String DefaultInputContainerClass { get; set; }
    }
}