﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AngularXample.Models
{
    public class ContractListViewModel
    {
        public string CONNUM { get; set; }
        public DateTime GENAPPDTE { get; set; }
        public string DIS_GENAPPDTE
        {
            get {
                return GENAPPDTE.ToString("dd/MM/yyyy");
            }
        }
        public string ACCNAMTHA { get; set; }
        public string CONAPPLY_PROJEC_DESC { get; set; }
        public string CRDNXTSTP_DESC { get; set; }
    }
}