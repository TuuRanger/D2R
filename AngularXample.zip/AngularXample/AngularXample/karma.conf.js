﻿module.exports = function (config)
{
    config.set({

        // base path, that will be used to resolve files and exclude
        basePath: '',

        // frameworks to use
        frameworks: ['jasmine'],

        // list of files / patterns to load in the browser
        files: [ 
            'wwwroot/lib/jquery/jquery.js',
            'wwwroot/lib/kendo-ui-core/js/angular.min.js',
            'wwwroot/lib/angular-mocks/angular-mocks.js',
            'wwwroot/lib/kendo-ui-core/js/kendo.ui.core.min.js',
            'wwwroot/lib/ng-dialog/js/ngDialog.min.js',

            // Source
            'Scripts/mls-component/core/mls-component.core.js',
            'Scripts/mls-component/services/mls-screen-resource-provider.js',
             
            // Tests
            'test/unit-test/specs/mls.components-core-spec.js',
            'test/unit-test/specs/mls-screen-resource-provider-spec.js'
        ],

        // list of files to exclude
        exclude: [
        ],

        // test results reporter to use
        reporters: ['progress', 'html', 'coverage', 'jasmine-runner'],
        htmlReporter: {
            outputDir: 'test-result/unit-test-summary', // where to put the reports  
            templatePath: null, // set if you moved jasmine_template.html 
            focusOnFailures: true, // reports show failures on start 
            namedFiles: false, // name files instead of creating sub-directories 
            pageTitle: null, // page title for reports; browser info by default 
            urlFriendlyName: false, // simply replaces spaces with _ for files/dirs 
            //reportName: 'report', // report summary filename; browser info by default 
             
            // experimental 
            preserveDescribeNesting: false, // folded suites stay folded  
            foldAll: false, // reports start folded (only with preserveDescribeNesting) 
        },
        coverageReporter: {
            type: 'html',
            dir: 'test-result/unit-test-coverage',
            reporters: [
               {
                   type: 'html',
                   //subdir: 'report'
               }
            ]
        },
        jasmineRunnerReporter: {
            outputFile: 'test-result/jasmine-unit-test/jasmine-runner.html', 
        },
        jasmineSpecRunnerReporter: {
            jasmineCoreDir: 'node_modules\jasmine-core'
        },
        // web server port
        port: 9876,

        // enable / disable colors in the output (reporters and logs)
        colors: true,

        // level of logging
        logLevel: config.LOG_INFO,

        // enable / disable watching file and executing tests whenever any file changes
        autoWatch: true,

        // Start these browsers
        browsers: ['Chrome', 'Firefox'],

        // If browser does not capture in given timeout [ms], kill it
        captureTimeout: 60000,

        // Continuous Integration mode
        // if true, it capture browsers, run tests and exit
        singleRun: false,

        preprocessors: {
            'Scripts/mls-component/core/mls-component.core.js': ['coverage'],
            'Scripts/mls-component/services/mls-screen-resource-provider.js': ['coverage']
        }, 
    });
};